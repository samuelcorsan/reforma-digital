# Cómo mueve cada uno sus rasgos al hablar, partiendo de su cara de base: Ada Colau y Jordi Wild (YouTube · The Wild Project, 13/11/2026)

*Anexo. Mide cuánto y cómo se aparta la cara de cada uno, mientras habla, de su propia cara mientras escucha: cejas, ojos, boca y cabeza. Las cifras salen del vídeo de la entrevista. Es una aproximación y describe movimiento, no emociones, intenciones ni rasgos de carácter; tampoco sirve para saber si alguien dice la verdad. Las frases que comparan se generan a partir de las cifras, con el criterio indicado en cada una.*

## 1. Lo esencial

- **Cejas al hablar** (altura respecto a su base al escuchar): +11 % el entrevistado y +3 % el entrevistador; más altas en el entrevistado.
- **Apertura de la boca al hablar** (en % de la anchura de su boca, respecto a su base): habitual 0,6 % el entrevistado y 1,7 % el entrevistador; en las aperturas amplias (percentil 95), 7,0 % y 20,1 %. La habitual es mayor en el entrevistador.
- **Ojos al hablar** (apertura respecto a su base): +5 % el entrevistado y +5 % el entrevistador; parecido en los dos (menos de 2 puntos de diferencia).
- **Giro de cabeza:** el entrevistado, 14,5°/s al hablar y 9,4°/s al escuchar (más al hablar); el entrevistador, 12,8°/s al hablar y 8,8°/s al escuchar (más al hablar).
- **Qué rasgos acompañan a la intensidad de la voz** (correlación frase a frase de 0,10 o más en valor absoluto): en el entrevistado, cabeza: movimiento (+0,19), boca: apertura (+0,17), comisuras: altura (+0,17); en el entrevistador, boca: anchura (+0,25), comisuras: altura (+0,25), boca: apertura (+0,16).

## 2. Tabla: dónde queda cada rasgo al hablar

Cambio respecto a la cara de cada uno mientras escucha. Cejas, ojos y anchura de boca, en % de su propio valor de base; apertura de boca y comisuras, en % de la anchura de su boca.

| Rasgo | Entrevistado: habitual | recorrido (del 5 % al 95 % de los fotogramas) | Entrevistador: habitual | recorrido |
|---|---|---|---|---|
| cejas: altura | +11 % | de -12 % a +40 % | +3 % | de -21 % a +46 % |
| ojos: apertura | +5 % | de -50 % a +26 % | +5 % | de -65 % a +39 % |
| boca: apertura | +1 % | de -2 % a +7 % | +2 % | de -5 % a +20 % |
| boca: anchura | -2 % | de -9 % a +8 % | +1 % | de -9 % a +13 % |
| comisuras: altura | 0 % | de -6 % a +7 % | +2 % | de -5 % a +12 % |

| Cabeza | Entrevistado hablando | Entrevistado escuchando | Entrevistador hablando | Entrevistador escuchando |
|---|---|---|---|---|
| velocidad de giro (°/s) | 14,5 | 9,4 | 12,8 | 8,8 |
| velocidad de cabeceo (°/s) | 16,6 | 15,0 | 16,6 | 10,6 |
| velocidad de inclinación (°/s) | 11,6 | 11,0 | 9,3 | 5,9 |
| amplitud de giro (desviación, °) | 9,4 | 7,8 | 9,9 | 8,6 |
| amplitud de cabeceo (desviación, °) | 9,2 | 9,6 | 10,9 | 9,8 |

El «recorrido» incluye el ruido de la medida (ver límites), así que es más fiable comparar los valores habituales que los extremos.

## 3. Qué hace la cara cuando sube la voz

Para cada frase se compara el movimiento medio de cada rasgo con la intensidad de la voz en esa frase (tono, volumen y tensión, del anexo de tonalidad). «Más intensas» y «más apagadas» son el 20 % de frases de cada extremo.

| Rasgo | Entrevistado: frases más intensas | más apagadas | correlación | Entrevistador: frases más intensas | más apagadas | correlación |
|---|---|---|---|---|---|---|
| cejas: altura | +10 % | +12 % | -0,07 | +6 % | +9 % | -0,07 |
| ojos: apertura | -2 % | -1 % | -0,04 | -7 % | -3 % | -0,10 |
| boca: apertura | +2 % | +1 % | +0,17 | +5 % | +3 % | +0,16 |
| boca: anchura | -1 % | -2 % | +0,10 | +3 % | 0 % | +0,25 |
| comisuras: altura | 0 % | 0 % | +0,17 | +3 % | +1 % | +0,25 |
| cabeza: movimiento (°/s) | 22,0 | 19,1 | +0,19 | 21,1 | 18,0 | +0,10 |

- La correlación más alta en valor absoluto es 0,25: todas quedan por debajo de 0,30, así que la cara acompaña a la voz poco y no siempre.
- Cejas al preguntar (entrevistado): +6 % en sus 24 frases interrogativas con la cara en pantalla y +12 % en las demás (más bajas al preguntar).
- Cejas al preguntar (entrevistador): +4 % en sus 83 frases interrogativas con la cara en pantalla y +7 % en las demás (más bajas al preguntar).

![grafica](grafica_movimiento.png)

## 4. Relación con el anexo de expresiones

En `informe_expresiones.md` un gesto es un pico por encima del nivel habitual de esa persona en el mismo estado (hablando o escuchando). Aquí se mide el nivel mientras habla respecto a su cara mientras escucha. Un rasgo que se mantiene alto todo el tiempo que la persona habla aparece aquí y no como gesto allí, de modo que las dos medidas pueden no coincidir sin contradecirse.

## 5. Límites

- **Precisión.** A la distancia habitual de estos planos, una ceja se mueve unos pocos píxeles. Los puntos faciales tiemblan de un fotograma a otro, y por eso el «recorrido» sale amplio incluso cuando escuchan. Los valores habituales (medianas) son más fiables que los extremos; las cifras exactas son aproximadas.
- **Ángulo de cámara.** Se corrige el efecto del giro de cabeza, pero la corrección es aproximada, y se descartan los planos lejanos y las posturas muy distintas de la habitual.
- **5 fotogramas por segundo.** Los movimientos muy rápidos (un parpadeo, un golpe de ceja breve) se pierden, y las velocidades de cabeza están suavizadas.
- **La base es la cara de cada uno mientras escucha en esta entrevista.** Si alguien escucha con un gesto mantenido, su base lo incluye.
- **El vello facial** afecta a los puntos de la boca y la mandíbula.
- **La realización.** Fotogramas usados: entrevistado, 15852 hablando y 563 escuchando; entrevistador, 8551 y 583. Con menos de 1500 fotogramas escuchando (5 minutos), la base de esa persona es poco sólida.
- Son maneras de mover la cara al hablar, no estados de ánimo, y no dicen nada sobre la sinceridad de nadie.

## 6. Archivos

`movimiento_resumen.csv`, `movimiento_frases_entrevistado.csv`, `movimiento_frases_entrevistador.csv`, `movimiento_fotogramas_*.csv`; `grafica_movimiento.png`; scripts `26_movimiento_rasgos.py` y `27_informe_movimiento.py`.
