# Expresiones respecto a la cara de base de cada uno: Ada Colau y Jordi Wild (YouTube · The Wild Project, 13/11/2026)

*Anexo. Cada persona tiene unas facciones de partida distintas, y un programa que compara una cara con un patrón universal confunde esas facciones con gestos. Aquí se hace al revés: se calcula la **cara de base** de cada uno y se mide solo lo que se aparta de ella. Las facciones dejan de contar; cuenta el movimiento. Un gesto medido no dice qué siente la persona ni si dice la verdad. Las frases que comparan se generan a partir de las cifras, con el criterio indicado en cada una.*

## 1. Cómo se ha hecho

1. **Se quita el efecto de la cámara.** Cada persona puede estar grabada desde un ángulo distinto. Para cada unidad de acción facial (AU) se resta la parte que depende del giro, el cabeceo y la inclinación de la cabeza de esa persona.
2. **Se calcula la cara de base de cada uno**: el valor central (mediana) de cada AU en sus propios fotogramas, por separado cuando habla y cuando escucha, porque hablar mueve la boca.
3. **Cada fotograma se mide en desviaciones respecto a esa base**, con una escala robusta propia de cada persona. Un valor de 0 es «su cara de siempre», tenga las facciones que tenga.
4. **Un gesto** es un tramo de al menos 0,6 s en el que una zona de la cara se aparta claramente de su base (2,5 desviaciones). Se cuentan por cada 10 minutos en pantalla, porque la cámara no enfoca a los dos el mismo tiempo.

No se usa ninguna etiqueta de emoción: los gestos se nombran por lo que hace la cara.

## 2. Lo esencial

Criterios: «parecida» = menos de un 20 % de diferencia; con menos de 5 minutos en pantalla en un estado, el dato se marca como frágil.

- **Ceño y labios apretados.** Episodios por encima de la base en toda la entrevista: ceño, 89 en el entrevistado y 3 en el entrevistador; labios apretados, 0 y 0.
- **Gesto más frecuente de cada uno** (por 10 minutos en pantalla): en el entrevistado, ojos más abiertos (32,8); en el entrevistador, sonrisa (25,7).
- **Sonrisa.** 30,5 por 10 minutos en pantalla el entrevistado y 25,7 el entrevistador (frecuencia parecida). Dentro de cada uno: el entrevistado, 30,8 por 10 min al hablar y 27,0 al escuchar (parecida); el entrevistador, 27,0 por 10 min al hablar y 15,1 al escuchar (más al hablar).
- **Cejas arriba.** 1,0 por 10 minutos en pantalla el entrevistado y 12,7 el entrevistador (más frecuente en el entrevistador). Dentro de cada uno: el entrevistado, 1,1 por 10 min al hablar y 0,0 al escuchar (más al hablar); el entrevistador, 15,9 por 10 min al hablar y 3,0 al escuchar (más al hablar).
- **Ojos más abiertos.** 32,8 por 10 minutos en pantalla el entrevistado y 22,2 el entrevistador (más frecuente en el entrevistado). Dentro de cada uno: el entrevistado, 37,0 por 10 min al hablar y 6,7 al escuchar (más al hablar); el entrevistador, 30,4 por 10 min al hablar y 4,5 al escuchar (más al hablar).
- **Mentón arriba.** 0,0 por 10 minutos en pantalla el entrevistado y 7,6 el entrevistador (más frecuente en el entrevistador). Dentro de cada uno: el entrevistado, 0,0 por 10 min al hablar y 0,0 al escuchar (parecida); el entrevistador, 6,8 por 10 min al hablar y 11,3 al escuchar (más al escuchar).

## 3. Tabla completa

Tiempo con la cara en pantalla: entrevistado 84,0 min (de ellos 5,9 mientras habla el otro); entrevistador 60,4 min (13,2 mientras habla el otro).

| Gesto | Entrevistado: nº | por 10 min | hablando | escuchando | duración media | Entrevistador: nº | por 10 min | hablando | escuchando | duración media |
|---|---|---|---|---|---|---|---|---|---|---|
| sonrisa (comisuras arriba + mejillas) | 256 | 30,5 | 30,8 | 27,0 | 1,1 s | 155 | 25,7 | 27,0 | 15,1 | 1,3 s |
| cejas arriba | 8 | 1,0 | 1,1 | 0,0 | 0,9 s | 77 | 12,7 | 15,9 | 3,0 | 1,2 s |
| ojos más abiertos | 275 | 32,8 | 37,0 | 6,7 | 1,1 s | 134 | 22,2 | 30,4 | 4,5 | 1,2 s |
| mentón arriba | 0 | 0,0 | 0,0 | 0,0 | 0,0 s | 46 | 7,6 | 6,8 | 11,3 | 1,0 s |
| ceño (cejas bajan y se juntan) | 89 | 10,6 | 12,3 | 0,0 | 0,9 s | 3 | 0,5 | 0,9 | 0,0 | 1,1 s |
| labios apretados | 0 | 0,0 | 0,0 | 0,0 | 0,0 s | 0 | 0,0 | 0,0 | 0,0 | 0,0 s |
| comisuras hacia abajo | 3 | 0,4 | 0,5 | 0,0 | 0,7 s | 0 | 0,0 | 0,0 | 0,0 | 0,0 s |

«Hablando» y «escuchando» son gestos por cada 10 minutos en pantalla en ese estado.

![expresiones](grafica_expresiones.png)

## 4. Los gestos más marcados de cada uno

**Entrevistado**

- Sonrisa: 34:12, mientras dice «pues para cambiar eso tienes que entrar y pringarte las manos si…»; 35:10, mientras dice «Por ejemplo, te decía, el tema de la vivienda tiene que cambiar radicalmente.…»; 69:29, mientras dice «populares, por ejemplo, de Barcelona, es esta gente que tiene memoria de lo…»; 97:10, mientras dice «de los datos que vi como alcaldesa y es que durante todos los…»
- Cejas arriba: 28:58, mientras dice «ha hecho un mal uso de la justicia ¿para qué? para una cosa…»; 31:15, mientras dice «y en cambio hay casos del PP que llevan…»; 37:19, mientras dice «que no dimitiera porque el problema venía de desinversiones de muchos años antes.…»; 72:28, mientras dice «Entonces, buscar como culpables fáciles…»
- Ojos más abiertos: 21:21, mientras dice «Si se decide solo el jefe de lista o se…»; 43:25, mientras dice «pero el personal solo sube un 10 % y no sube el mantenimiento,…»; 120:09, mientras dice «Mira el PSOE. El PSOE al principio era pro -Israel y ahora mismo…»; 133:08, mientras dice «Hay mucha gente en las instituciones luchando para bajar…»

**Entrevistador**

- Sonrisa: 7:23, mientras dice «Sí, eso cantaríamos en un debate ahora.…»; 86:06, mientras dice «Vamos a meterle el turbo que esto aparece en…»; 126:34, mientras el otro dice «que también es verdad que te vienes un poco más arriba, Y en…»; 130:20, mientras el otro dice «habías dicho que sería duro ha sido muy duro y seguramente…»
- Cejas arriba: 2:25, mientras dice «habéis ido junto, y esto es la realidad, junto con el Pepe, los…»; 6:49, mientras dice «por ejemplo, usas Instagram, que es Meta, Meta Zuckerberg. Zuckerberg ha sido ya,…»; 10:49, mientras dice «y tendremos otros a los que les voy a machacar mucho con esto…»; 75:07, mientras el otro dice «antes hablábamos de marrocos yo creo que hay muchos elementos, por ejemplo si…»
- Ojos más abiertos: 19:08, mientras el otro dice «No quisieron sentarse, no quisieron quedar físicamente.…»; 29:53, mientras dice «nombrado lo de Zapatero. ¿Crees entonces que lo de Zapatero tiene pinta de…»; 61:31, mientras dice «libertad de orientación. nuestro vecino, ¿qué tenemos…»; 83:50, mientras el otro dice «Hombre, yo creo que ahí sí que puedes pedir unos mínimos para que…»

Son los momentos en que cada cara más se aparta de su propia base, no los más «emocionales»: una sonrisa puede ser de cortesía, de ironía o de incomodidad, y unas cejas arriba pueden ser énfasis o sorpresa. El gesto se puede medir; su significado, no.

## 5. Límites

- **La cara de base se calcula con la propia entrevista.** Si alguien mantuviera un gesto toda la entrevista, ese gesto pasaría a ser su «base» y no se detectaría. Para saberlo haría falta material suyo de otro día.
- **Gestos con valor de base alto.** Cuando una AU tiene en una persona un valor de base alto y variable, un gesto leve puede no superar el umbral. Que no haya episodios significa que no hay ninguno claro, no que la cara esté inmóvil.
- **El umbral lo fija el analista** (2,5 desviaciones, 0,6 s). Con otro umbral cambian las cifras.
- **Facciones, gafas y giros.** El vello facial y las gafas afectan a las medidas de la boca, el mentón y los ojos; la corrección por ángulo de cámara es aproximada.
- **La realización decide a quién se ve.** Hay 84,0 min de la cara del entrevistado y 60,4 min de la del entrevistador; mientras escuchan, 5,9 y 13,2 min.
- Hablar mueve la boca: por eso la base se calcula aparte al hablar y al escuchar, pero la sonrisa mientras se habla sigue siendo más difícil de medir que en silencio.
- Ningún gesto de este anexo permite saber qué siente una persona, qué pretende o si dice la verdad.

## 6. Archivos

`expresiones_eventos.csv` (cada gesto: quién, cuál, minuto, duración, intensidad, si hablaba o escuchaba y qué se decía), `expresiones_resumen.csv`, `grafica_expresiones.png`; scripts `22_expresiones_base.py` y `23_informe_expresiones.py`.
