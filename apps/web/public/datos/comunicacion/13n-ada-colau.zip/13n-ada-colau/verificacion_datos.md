# Comprobación de los datos citados en la entrevista

*Entrevista de Jordi Wild a Ada Colau en The Wild Project, publicada el 13/11/2026. Se comprueban las afirmaciones factuales (cifras, hechos, atribuciones, normas) de las dos personas; no las opiniones ni las promesas. El veredicto dice si el dato tiene respaldo en las fuentes localizadas, no si la persona actuó de buena o mala fe.*

## Cómo leerlo

| Veredicto | Significado |
|---|---|
| respaldada | las fuentes coinciden con lo dicho |
| respaldada en parte / imprecisa | el dato de fondo existe, pero la cifra, la fecha o la formulación no coinciden |
| engañosa por contexto | dato real presentado omitiendo algo que cambia su sentido |
| sin respaldo | las fuentes localizadas lo contradicen |
| no verificable | no hay fuente pública suficiente, o es una relación causal o una interpretación |
| no he podido comprobarlo | no se encontraron fuentes suficientes |

**Límites que conviene tener presentes antes de citar nada de aquí:**

- La búsqueda se hizo el 13/11/2026 con buscador web. **La mayoría de las fuentes se consultaron a través de extractos del buscador y de prensa, no abriendo el documento oficial**: solo se abrieron 38 páginas completas, que sostienen 40 de las 118 filas comprobadas. Cada fila indica «Fuente abierta: sí/no»; donde pone «no», hay que abrir la fuente enlazada antes de publicar el veredicto.
- No se pudieron leer varias fuentes: Deia (error 406, querella de Vauras) y dos fichas de Maldita.es (hurtos en Barcelona; Feijóo y el SMI), de las que solo se obtuvo el titular. Sus datos proceden del extracto del buscador. Las únicas fuentes primarias abiertas son dos notas del INE y una nota de Igualdad en La Moncloa; BOE, Exteriores, Ministerio de Inclusión, CNMC, Mossos y Ayuntamiento de Barcelona se citan por extracto o a través de prensa.
- Muchos hechos de 2026 (desahucio de Maricarmen, decretos de vivienda y adelanto electoral, composición de Frente Amplio, accidente de Urda, crisis de Ceuta, joyas de Zapatero, Núcleo Nacional, declaraciones de Figaredo) descansan en uno o dos medios, a veces de un solo signo político. ARA aparece en muchas filas porque era de los pocos medios cuyas páginas se dejaban abrir. Las fuentes de cada fila lo dejan ver.
- La transcripción es automática: hay errores en nombres y cifras («Adam Woods» por Adamuz, «Ayala» por Alaya, «Ada Polau», «loafer» por lawfare, «Nucleonacional», «Caetana») y frases cortadas. Las citas se copian tal cual. Cuando el dato depende de una palabra dudosa se indica en la fila; en un caso (el 15M «del 2015») no se da veredicto por ese motivo.
- El recuento no es una «nota»: los dos hablan de cosas distintas (la invitada hace sobre todo afirmaciones sobre su gestión, su coalición y terceros; el entrevistador lee datos preparados y cifras de encuestas), y varias afirmaciones repiten el mismo dato (columna `grupo` del CSV). **Comparar porcentajes entre los dos no es válido.**
- De las 126 afirmaciones extraídas, 8 venían marcadas como no comprobables (experiencias personales, valoraciones, frases cortadas). No se buscaron; figuran al final y en el CSV como «no verificable», y se cuentan aparte.
- Cinco filas repiten hechos ya comprobados en la entrevista paralela a Feijóo (condena de Ábalos, vacaciones del presidente durante la crisis de Ceuta, CIS, elecciones en EE. UU., Gürtel y ERE): se reutilizan sus fuentes y su veredicto, y se marcan como no abiertas porque no se reabrieron aquí.
- Alguna cifra es un cálculo propio a partir de datos de la fuente (población de Ceuta frente a entradas; años de gobierno del PSOE); se indica en la fila. En varias filas el veredicto «respaldada» cubre el dato central y la explicación señala qué parte secundaria no se comprobó.
- Los veredictos negativos de las dos entrevistas pasaron el 13/11/2026 una segunda revisión independiente abriendo las fuentes; dos se suavizaron, ambos en la entrevista a Feijóo, y los dos de esta (45:35 y 122:06) se mantienen con la explicación ampliada y la marca «Revisión independiente 13/11/2026». En esa revisión sí se leyó la ficha de Maldita sobre Feijóo y el SMI: es un contenido de redes sin verificar.

## Recuento

| Veredicto | Invitada (Colau) | Entrevistador (Jordi Wild) |
|---|---|---|
| sin respaldo | 2 | 0 |
| engañosa por contexto | 0 | 0 |
| respaldada en parte / imprecisa | 21 | 7 |
| respaldada | 43 | 30 |
| no verificable | 3 | 0 |
| no he podido comprobarlo | 8 | 4 |
| **Total comprobadas** | **77** | **41** |
| no comprobables según la extracción (no buscadas; «no verificable» en el CSV) | 8 | 0 |
| **Total filas** | **85** | **41** |

Fuente abierta en 27 filas de la invitada y 13 del entrevistador; en el resto solo se vio el extracto.

## Ada Colau (invitada)

### Sin respaldo (2)

**45:35 · La derecha no dimitió por la DANA.** (hecho)

- Cita literal: «no han dimitido nunca cuando les han pasado cosas incluso más graves como lo de la DANA»
- Qué dicen las fuentes: En contexto habla de la dimisión de Óscar Puente (3-11-2026) tras el accidente de Urda; «ellos» es «la derecha, que ha estado gritando que dimita Pedro Sánchez», y repite a continuación que «no han dimitido jamás por cosas incluso más graves». Carlos Mazón (PP) anunció su dimisión como presidente de la Generalitat Valenciana el 3-11-2025, vinculándola a la gestión de la DANA («Es momento de reconocer errores propios», «Ya no puedo más»). Matiz: lo hizo un año después de la riada, conservó el escaño y no convocó elecciones; nadie dimitió en los días posteriores. Revisión independiente 13/11/2026
- Fuentes: <https://orain.eus/es/politica/2025/11/03/mazon-dimite-presidente-la-generalitat-valenciana/> · <https://www.diaridetarragona.com/espana/274809/dimite-oscar-puente.html>
- Fuente abierta: sí

**122:06 · Feijóo ha dicho que bajará las pensiones y el salario mínimo.** (cita_de_tercero)

- Cita literal: «O sea, ha dicho que bajara las pensiones, que bajara el salario mínimo.»
- Qué dicen las fuentes: La transcripción dice «bajara»; en contexto es «bajaría» o «bajará». No localicé ninguna declaración de Feijóo en ese sentido, y sí en sentido contrario: «Las pensiones son innegociables y ya. Se acabó» y «se actualizarán conforme al IPC sin duda» (15-10-2026); «Mi objetivo no solo es que suba el salario mínimo, sino también el salario medio» y «Para mí las pensiones no se pueden tocar» (Cadena SER, 23-10-2026). Lo más cercano a un respaldo: su portavoz Ester Muñoz dijo que el sistema de pensiones «va a colapsar»; Feijóo llamó a la subida del SMI «incremento indiscriminado» (junio de 2025) y «buen negocio» para el Gobierno; que quiera congelar el SMI es la inferencia de una columna de opinión de El Plural, sin cita suya. La ficha de Maldita sobre «Feijóo quiere congelar el SMI» es un contenido de redes marcado como no verificado, no una verificación. Búsqueda no exhaustiva. Revisión independiente 13/11/2026
- Fuentes: <https://www.democrata.es/politica/feijoo-insiste-en-que-la-subida-de-las-pensiones-con-el-ipc-es-innegociable-y-quiere-cerrar-la-polemica-se-acabo/> · <https://www.elnacional.cat/es/politica/polemica-pensiones-acorrala-pp-feijoo-rectifica-innegociables-basta_1710037_102.html> · <https://www.moncloa.com/2026/10/23/feijoo-subir-salario-inflacion-3453948/> · <https://es.ara.cat/politica/elecciones-generales/feijoo-equivoca-gobierno-espanol-no-hecho-buen-negocio-subida-salario-minimo_1_5888276.html> · <https://www.eldiario.es/1_cfa93a> · <https://www.infobae.com/espana/2025/06/20/feijoo-muestra-su-rechazo-a-la-subida-del-smi-y-oscar-puente-responde-y-ya-si-restauramos-la-esclavitud/> · <https://www.elplural.com/opinion/feijoo-contra-salario-minimo-cobra-mas-140000-quiere-congelar-smi_355025102>
- Fuente abierta: sí

### Respaldada en parte / imprecisa (21)

**7:20 · Elon Musk hizo el saludo nazi.** (hecho)

- Cita literal: «pero Elon Musk, ¿te acuerdas que hizo el saludo nazi?»
- Qué dicen las fuentes: El gesto es real: el 20-1-2025, en la investidura de Trump, Musk extendió dos veces el brazo derecho. Que fuera un saludo nazi es una interpretación disputada: lo sostuvieron políticos demócratas e historiadores; la Liga Antidifamación lo describió como un gesto torpe y Musk lo negó.
- Fuentes: <https://www.articulo14.es/internacional/el-saludo-nazi-de-elon-musk-que-colapso-la-investidura-de-trump-20250121.html> · <https://amp.cbc.ca/lite/story/1.7436957> · <https://forbes.co/actualidad/el-saludo-de-elon-musk-genera-criticas-de-lideres-extranjeros-y-democratas>
- Fuente abierta: no (solo extracto)

**9:00 · En mayo hará cuatro años que dejó la alcaldía.** (hecho)

- Cita literal: «porque en mayo hará cuatro años que dejé de ser alcaldesa»
- Qué dicen las fuentes: Las elecciones municipales que perdió fueron el 28-5-2023, pero dejó la Alcaldía en junio de 2023, cuando fue investido Collboni; siguió como concejala hasta octubre de 2024 (Artículo14).
- Fuentes: <https://www.articulo14.es/politica/quien-encabeza-frente-amplio-en-el-29n-trayectoria-politica-y-personal-de-ada-colau-20261105.html>
- Fuente abierta: sí

**12:06 · Cientos de miles de personas salieron a la calle tras ese desahucio.** (cifra)

- Cita literal: «o sea que cientos de miles salgan a la calle y digan basta ya,»
- Qué dicen las fuentes: La manifestación de Madrid del 26-9-2026 reunió a 300.000 personas según los organizadores y a 25.000 según la Delegación del Gobierno (ARA). «Cientos de miles» solo encaja con la cifra de los convocantes; hubo además protestas en otras ciudades sin cifra localizada.
- Fuentes: <https://es.ara.cat/politica/empieza-manifestacion-maricarmen-abascal-quiero-cambien-leyes-injustas-han-permitido-desahucio_1_5861515.amp.html> · <https://www.teleamazonas.com/actualidad/noticias/internacional/masiva-marcha-maricarmen-abascal-crisis-vivienda-madrid-130034/>
- Fuente abierta: sí · Grupo: `maricarmen`

**19:02 · Podemos no quiso sentarse a hablar pese a varias propuestas.** (hecho)

- Cita literal: «eso lo propusimos y lo repropusimos y no quisieron ni sentarse a hablar»
- Qué dicen las fuentes: Podemos rechazó la oferta de Frente Amplio (puestos de salida en Madrid y Cataluña, portavoz, reparto de recursos), pero Diari de Tarragona describe negociaciones durante meses e intercambio de propuestas hasta el último momento, y hubo acuerdos territoriales. Montero sostiene que fueron los partidos de Frente Amplio quienes bloquearon acuerdos en otros territorios.
- Fuentes: <https://www.diaridetarragona.com/espana/273314/frente-amplio-concurriran-separado-catalunya-madrid.html> · <https://www.elsaltodiario.com/elecciones/montero-asegura-frente-amplio-ha-bloqueado-acuerdos-territoriales-alcanzaron-otros-territorios>
- Fuente abierta: sí · Grupo: `frente_amplio`

**20:26 · Quince formaciones integran el Frente Amplio.** (cifra)

- Cita literal: «15 formaciones políticas finalmente van en el frente amplio»
- Qué dicen las fuentes: Según el propio comunicado de Frente Amplio la coalición agrupa a 15 organizaciones (Diari de Tarragona); EFE, citada por Artículo14, cuenta once registradas ante la Junta Electoral Central. La cifra coincide con la de la coalición, no con el recuento de la agencia.
- Fuentes: <https://www.diaridetarragona.com/espana/273314/frente-amplio-concurriran-separado-catalunya-madrid.html> · <https://www.articulo14.es/politica/que-partidos-forman-frente-amplio-integrantes-acuerdos-y-diferencias-con-sumar-20261107.html>
- Fuente abierta: sí · Grupo: `frente_amplio`

**28:22 · Le pusieron más de 22 querellas siendo alcaldesa, todas archivadas.** (cifra)

- Cita literal: «a mí me han puesto más de 22 querellas»
- Qué dicen las fuentes: ARA (12-3-2025) cuenta 22 causas, todas archivadas, pero contra Colau y su gobierno en conjunto (incluye concejales), no «más de 22 querellas» contra ella. Otras fuentes de 2023 hablaban de 15.
- Fuentes: <https://es.ara.cat/sociedad/barcelona/acaba-via-crucis-judicial-gobierno-colau_1_5313128.html> · <https://www.eldiario.es/catalunya/justicia-archiva-causa-colau-afea-exarquitecto-psc-via-penal_1_10785241.amp.html>
- Fuente abierta: sí · Grupo: `querellas`

**31:23 · Un portavoz del PP escribió en un mensaje que tenían el Supremo controlado 'por la puerta de detrás'.** (cita_de_tercero)

- Cita literal: «tenemos el Supremo controlado por la puerta de detrás»
- Qué dicen las fuentes: El mensaje existe: Ignacio Cosidó, portavoz del PP en el Senado, envió el 17-11-2018 un WhatsApp a sus senadores sobre el pacto del CGPJ que decía «controlando la Sala Segunda desde detrás». La cita de Colau es aproximada (Sala Segunda, no «el Supremo»), el texto era reenviado y se atribuyó a un cargo de Génova.
- Fuentes: <https://www.elindependiente.com/politica/2018/11/19/cosido-niega-intento-de-control-del-ts-ante-el-malestar-generado-por-su-whatsapp/amp/> · <https://www.vozpopuli.com/espana/politica/supremo-inaceptable-whatsapp-cosido-tribunal_0_1199880869.html> · <https://www.elindependiente.com/politica/2018/11/20/cosido-reenvio-el-mensaje-que-un-cargo-de-genova-escribio-en-otro-grupo-de-whatsaap/amp/>
- Fuente abierta: no (solo extracto)

**35:17 · Pedro Sánchez le prometió en 2019 regular los alquileres.** (hecho)

- Cita literal: «Pedro Sánchez me prometió en el 2019 regular los alquileres.»
- Qué dicen las fuentes: La fuente del compromiso es la propia Colau: el 21-12-2018 (no en 2019) dijo que Sánchez se había comprometido a permitir a los ayuntamientos limitar precios abusivos de alquiler; volvió a tratarlo con él en febrero de 2020 y en 2022 le exigió cumplir su «palabra». No localicé un registro del Gobierno.
- Fuentes: <https://www.elindependiente.com/economia/2018/12/21/sanchez-confirma-colau-permitira-los-ayuntamientos-limitar-precios-abusivos-alquiler/amp/> · <https://www.que.es/2022/04/04/colau-enmienda-regulacion-alquiler-ley-sanchez/> · <https://beteve.cat/politica/colau-sanchez-regular-preu-lloguer/>
- Fuente abierta: no (solo extracto) · Grupo: `alquileres`

**35:21 · La regulación de alquileres no se hizo hasta 2024-2025.** (hecho)

- Cita literal: «No se hizo hasta el 2024 -2025.»
- Qué dicen las fuentes: La Ley 12/2023 por el derecho a la vivienda es de mayo de 2023; el índice de referencia se aprobó en febrero-marzo de 2024 y los topes empezaron a aplicarse en Cataluña en marzo de 2024. La regulación se aprobó en 2023 y se aplicó desde 2024.
- Fuentes: <https://maldita.es/malditateexplica/20240315/indice-precios-alquiler-ministerio-vivienda/> · <https://www.lamoncloa.gob.es/serviciosdeprensa/notasprensa/vivienda-agenda-urbana/paginas/2024/150324-indice-precios-alquiler-areas-tensionadas.aspx>
- Fuente abierta: no (solo extracto) · Grupo: `alquileres`

**37:27 · Pidió la dimisión del ministro tras el segundo accidente.** (hecho)

- Cita literal: «con el segundo accidente lo dije inmediatamente»
- Qué dicen las fuentes: Pidió la dimisión, pero no el primer día: el accidente fue el 28-10-2026; el 29 Frente Amplio pidió la comparecencia de Puente (El Salto: la primera petición de dimisión desde la izquierda fue de Adelante Andalucía) y el 30 Colau dijo que la dimisión «se debería producir lo antes posible».
- Fuentes: <https://www.elsaltodiario.com/politica/frente-amplio-pide-comparecencia-puente-accidente-toledo-adelante-andalucia-dimision> · <https://www.esdiario.com/nacional/261030/201709/ada-colau-dimision-oscar-puente.html> · <https://www.democrata.es/politica/ampliacion-frente-amplio-incrementa-la-presion-sobre-puente-al-exigir-formalmente-su-dimision/>
- Fuente abierta: sí · Grupo: `accidentes`

**41:40 · Francia y Alemania tienen un único operador público; en España se separó Renfe de Adif.** (comparacion)

- Cita literal: «en lugar de tener un único operador público como tienen en Francia o tienen en Alemania»
- Qué dicen las fuentes: Francia y Alemania mantienen el gestor de la infraestructura y el operador dentro de un mismo holding público (SNCF, Deutsche Bahn), mientras España separó Renfe y Adif en dos empresas en 2005. Eso no equivale a «un único operador»: no comprobé el grado de apertura a otros operadores en esos países.
- Fuentes: <https://en.ara.cat/society/adif-renfe-the-price-of-divorce_1_5634822.html> · <https://www.bolsamania.com/noticias/empresas/economia--el-presidente-de-renfe-apuesta-por-su-fusion-con-adif-para-una-mejor-coordinacion-entre-trenes-y-vias--22389221.html>
- Fuente abierta: no (solo extracto)

**59:24 · La Liga española ha llevado competiciones a Arabia Saudí.** (hecho)

- Cita literal: «la Liga Española ha tenido actuaciones también más que discutibles llevando a Arabia Saudí.»
- Qué dicen las fuentes: La competición que se juega en Arabia Saudí es la Supercopa de España, que organiza la Real Federación Española de Fútbol (contrato firmado en 2019), no LaLiga.
- Fuentes: <https://www.clarosports.com/futbol/laliga/supercopa-de-espana-2024-por-que-se-juega-en-arabia-saudita/> · <https://www.goal.com/es/noticias/supercopa-la-rfef-pacto-una-comision-de-24-millones-para-la/blt62f9a839fd58cc38>
- Fuente abierta: no (solo extracto)

**81:40 · Europa ha dicho que la baja natalidad hace necesaria la migración para sostener el estado del bienestar.** (cita_de_tercero)

- Cita literal: «la baja natalidad de Europa hace que se necesite la migración»
- Qué dicen las fuentes: Los informes demográficos de la Comisión Europea dicen que la inmigración compensa parcialmente el envejecimiento y la reducción de la población activa, pero no la presentan como solución suficiente ni permanente y priorizan la formación y el empleo de quienes ya residen en la UE.
- Fuentes: <https://www.que.es/2026/07/16/declive-demografico-europa/> · <https://euobserver.com/227838/eu-warns-of-worker-shortage-as-population-ages-and-says-migration-is-now-a-necessity/>
- Fuente abierta: no (solo extracto)

**85:40 · Los 7 millones de inmigrantes aportan el 10 % de las cotizaciones y suponen el 1 % del gasto público (datos del ministerio, según dice).** (cifra)

- Cita literal: «aportan el 10 % de las contribuciones a la seguridad social y suponen solo un 1 % del gasto público»
- Qué dicen las fuentes: La cifra es del Ministerio de Inclusión, pero con dos formulaciones: la ministra Saiz habla del 10 % de los ingresos y el 1 % del gasto de la Seguridad Social; las conclusiones del informe del CES (noviembre de 2025) dicen «1 % del gasto público», que es lo que dice Colau. Son magnitudes distintas y el ministerio no publica el cálculo. Los residentes de nacionalidad extranjera eran 7,4 millones en julio de 2026 (INE).
- Fuentes: <https://www.inclusion.gob.es/w/elma-saiz-el-60-de-los-jovenes-que-han-sido-menores-tutelados-esta-trabajando-> · <https://www.lamoncloa.gob.es/serviciosdeprensa/notasprensa/inclusion/Documents/2025/121125-conclusiones-informe-ces.pdf> · <https://www.ine.es/dyngs/Prensa/ECP2T26.htm>
- Fuente abierta: no (solo extracto)

**88:48 · Su gobierno aumentó en miles los agentes de la Guardia Urbana.** (cifra)

- Cita literal: «O sea, aumentamos miles de agentes de Guardia Urbana.»
- Qué dicen las fuentes: Hubo aumento, pero no de «miles»: las fuentes sitúan la plantilla en torno a 2.800-3.000 agentes al principio y en unos 3.400-3.500 hacia 2023, con convocatorias de 233 y 260 plazas en 2019 y 2020 que en parte cubrían jubilaciones. Las cifras proceden de fuentes no homogéneas.
- Fuentes: <https://www.csif.es/es/articulo/cataluna/general/93888> · <https://beteve.cat/societat/collboni-presenta-132-agents-nous-guardia-urbana/> · <https://okdiario.com/espana/almeida-no-quiere-caer-inseguridad-suma-policia-municipal-230-agentes-doble-que-barcelona-12549073>
- Fuente abierta: no (solo extracto)

**92:38 · Las cifras de inseguridad en Barcelona fueron más o menos estables durante su mandato.** (hecho)

- Cita literal: «la inseguridad en Barcelona ha tenido unas cifras más o menos estables desde que entramos hasta que salimos»
- Qué dicen las fuentes: El principio y el final se parecen (Mossos y Guardia Urbana dicen que el balance de 2025 es «muy parecido al de 2015», y 2023 quedó un 7,3 % por debajo de 2019), pero en medio hubo una subida fuerte: los delitos crecieron un 17,2 % en 2018 y marcaron máximo en 2019, antes de la caída de la pandemia.
- Fuentes: <https://www.xataka.com/magnet/300-robos-al-dia-cifras-que-explican-alarma-inseguridad-barcelona> · <https://es.ara.cat/sociedad/sucesos/seguridad-barcelona-hurtos-no-bajaban_1_5647691.html> · <https://www.cnnchile.com/mundo/delitos-aumentaron-barcelona-2023/>
- Fuente abierta: no (solo extracto)

**94:13 · El conseller de Interior de Junts no acudía a las juntas locales de seguridad.** (hecho)

- Cita literal: «ni siquiera venía a reunirse a las juntas locales de seguridad»
- Qué dicen las fuentes: Colau dijo en julio de 2019 que la Junta Local de Seguridad de esa semana era la primera a la que asistía el conseller Miquel Buch (JxCat), en el cargo desde junio de 2018. No acudió durante más de un año, pero después sí asistió.
- Fuentes: <https://www.elindependiente.com/politica/2019/07/30/colau-recrimina-a-torra-la-falta-de-compromiso-de-buch-con-la-seguridad-en-barcelona/amp/> · <https://www.eldiario.es/catalunya/barcelona/colau-problemas-seguridad-denuncia-politica_1_1374594.html>
- Fuente abierta: no (solo extracto)

**105:29 · Con la ley actual, si ocupan tu vivienda se desaloja en el mismo día.** (hecho)

- Cita literal: «Si es tu vivienda, ahora mismo, con la ley, desaloja en el mismo día.»
- Qué dicen las fuentes: Si la entrada en una morada se detecta en flagrante delito, la policía puede desalojar de inmediato sin orden judicial (instrucción de Interior). Si no es flagrante hace falta autorización judicial; la LO 1/2025 permite juicio rápido, con vista en unos 15 días. No es automático «en el mismo día».
- Fuentes: <https://www.vozpopuli.com/espana/policia-desalojar-inmediatamente-allanamiento-flagrante_0_1392761203.html> · <https://www.idealista.com/news/node/825725> · <https://www.spanishpropertyinsight.com/2025/01/02/how-the-new-fast-track-evictions-process-for-squatters-works/>
- Fuente abierta: no (solo extracto)

**112:56 · Más de la mitad del sueldo se va en pagar la vivienda.** (cifra)

- Cita literal: «porque más de la mitad de sus sueldos le va a pagar la vivienda»
- Qué dicen las fuentes: Depende de la fuente: Fotocasa/InfoJobs calcula que alquilar 80 m² absorbió en 2025 el 50 % del salario bruto medio (71 % en Madrid); idealista da un 37,8 % del salario neto y CaixaBank Research alrededor del 30 % en contratos nuevos. Solo la primera se acerca a «más de la mitad», y es una media teórica, no lo que paga cada hogar.
- Fuentes: <https://es.euronews.com/2026/06/01/espanoles-mitad-sueldo-alquiler-madrid-barcelona-vivienda> · <https://www.que.es/2026/06/03/alquiler-salario-medio-espana-bomba/> · <https://www.caixabankresearch.com/es/analisis-sectorial/inmobiliario/nos-dicen-datos-alta-frecuencia-sobre-alquileres-espana>
- Fuente abierta: no (solo extracto)

**117:12 · Catorce o quince gobiernos emitieron un comunicado y declararon la flotilla bajo su protección.** (cifra)

- Cita literal: «14 o 15 gobiernos hicieron un comunicado contra el gobierno de Israel»
- Qué dicen las fuentes: Fueron 16 países (comunicado de 16-9-2025, publicado por Exteriores). El texto expresa preocupación por la seguridad de la flotilla, pide abstenerse de actos ilegales o violentos contra ella y advierte de rendición de cuentas; según los extractos no es un comunicado «contra el gobierno de Israel».
- Fuentes: <https://www.exteriores.gob.es/es/Comunicacion/Comunicados/Paginas/2025_COMUNICADOS/Comunicado-de-Espana-y-otros-15-paises-sobre-la-flotilla-a-Gaza.aspx> · <https://www.gulf-times.com/article/710846/qatar/joint-statement-by-16-countries-on-safety-of-global-sumud-flotilla>
- Fuente abierta: no (solo extracto) · Grupo: `flotilla`

**123:06 · Vox reivindica la dictadura, que mató a cientos de miles de personas.** (cifra)

- Cita literal: «reivindica la dictadura en España que mató a cientos de miles de personas»
- Qué dicen las fuentes: Las estimaciones localizadas de víctimas mortales de la represión franquista (guerra y posguerra) rondan las 130.000-150.000: más de cien mil, no «cientos de miles». Fuentes secundarias. Que Vox reivindique la dictadura es una caracterización que no se evalúa.
- Fuentes: <https://rebelion.org/un-posible-genocidio-de-mas-de-135-000-victimas/> · <https://www.diaridetarragona.com/opinion/Ochenta-anos-despues-1939-2019-20190412-0032.html>
- Fuente abierta: no (solo extracto)

### Respaldada (43)

**9:06 · Rechazó ser ministra en el gobierno de Sánchez.** (voto_o_decision)

- Cita literal: «Me propusieron ser ministra en el gobierno de Sánchez y dije que no.»
- Qué dicen las fuentes: El 26-10-2023 Colau anunció que había decidido no ser ministra pese a que su espacio político se lo había pedido con insistencia; Yolanda Díaz la había propuesto para Vivienda en agosto de 2023. Las fuentes atribuyen la propuesta a Sumar, no a una oferta directa de Sánchez.
- Fuentes: <https://www.eldebate.com/espana/cataluna/20231026/colau-anuncia-decidido-no-ministra-pese-insistencia-sumar_149187.html> · <https://www.ultimahora.es/noticias/elecciones-23j/2023/10/26/2038119/colau-anuncia-decidido-ser-ministra.html> · <https://www.elindependiente.com/opinion/2023/10/26/colau-ministra-y-martir/>
- Fuente abierta: no (solo extracto)

**9:10 · Rechazó presentarse a las elecciones europeas.** (voto_o_decision)

- Cita literal: «Me propusieron presentarme a las europeas y dije que no,»
- Qué dicen las fuentes: En enero de 2024 rechazó ser la candidata de Sumar a las elecciones europeas («No iré a Europa»).
- Fuentes: <https://theobjective.com/espana/politica/2024-01-15/colau-candidata-europea-sumar-sustituto/> · <https://www.eldebate.com/espana/cataluna/20240113/colau-asegura-discurso-inmigratorio-junts-como-vox_166819.html>
- Fuente abierta: no (solo extracto)

**11:48 · Mari Carmen, de 87 años, fue desahuciada en camilla sin haber dejado de pagar el alquiler, porque un gran propietario quería subir el precio.** (hecho)

- Cita literal: «ver a una mujer de 87 años que la sacan en camilla de su casa cuando no deja de pagar ni un mes el alquiler,»
- Qué dicen las fuentes: Maricarmen Abascal, de 87 años, fue desahuciada el 23-9-2026 en Madrid y salió en camilla. Según ARA pagaba 500 euros de renta antigua y el propietario (Urbagestión, un fondo de inversión) quería subir el alquiler a 1.650 euros (2.650 según el Sindicato de Inquilinas); el artículo no menciona impagos, aunque tampoco afirma expresamente que no los hubiera.
- Fuentes: <https://es.ara.cat/sociedad/desahuciada-vecina-87-anos-madrid-le-exigian-alquiler-1-650-euros_1_5858449.html> · <https://diariodeavisos.elespanol.com/2026/09/urbagestion-desahucio-maricarmen/> · <https://es.euronews.com/2026/10/02/que-ocurre-con-las-protestas-de-vivienda-de-maricarmen-en-espana>
- Fuente abierta: sí · Grupo: `maricarmen`

**12:17 · Publicó un vídeo en Instagram exigiendo respuesta al gobierno antes de ser candidata.** (hecho)

- Cita literal: «lo que hice fue un vídeo totalmente espontáneo en mi Instagram»
- Qué dicen las fuentes: ARA (24-9-2026): Colau publicó un vídeo en redes sociales contra el Gobierno de coalición por el desahucio («Se ha acabado»), pidiendo salir del Ejecutivo si no se actuaba. El artículo dice «redes sociales», sin precisar Instagram.
- Fuentes: <https://es.ara.cat/politica/operacion-retorno-ada-colau_1_5859191.html>
- Fuente abierta: sí

**12:39 · Se aprobaron dos decretos sobre vivienda que fueron al Congreso.** (hecho)

- Cita literal: «se hicieron dos decretos que finalmente fueron al Congreso,»
- Qué dicen las fuentes: El Consejo de Ministros aprobó dos reales decretos-ley de vivienda que se votaron en el Congreso el 2-10-2026.
- Fuentes: <https://www.articulo14.es/politica/pp-vox-y-junts-tumban-los-dos-decretos-de-vivienda-y-asestan-una-dura-derrota-al-gobierno-20261002.html> · <https://www.elsaltodiario.com/politica/congreso-tumba-dos-decretos-vivienda-deja-legislatura-al-borde-del-fin>
- Fuente abierta: sí · Grupo: `decretos`

**12:52 · PP, Junts y Vox votaron en contra de esos decretos y decayeron.** (voto_o_decision)

- Cita literal: «PP, Junts y Vox tumbaron esos decretos con lo que significa»
- Qué dicen las fuentes: El Congreso derogó los dos decretos el 2-10-2026 con los votos de PP, Vox y Junts (Artículo14 da 184 en contra y 166 a favor). Otras fuentes añaden a UPN y, en el segundo decreto, a PNV y Coalición Canaria.
- Fuentes: <https://www.articulo14.es/politica/pp-vox-y-junts-tumban-los-dos-decretos-de-vivienda-y-asestan-una-dura-derrota-al-gobierno-20261002.html> · <https://www.elsaltodiario.com/politica/congreso-tumba-dos-decretos-vivienda-deja-legislatura-al-borde-del-fin> · <https://brainsre.news/congreso-tumba-dos-decretos-gobierno-vivienda/>
- Fuente abierta: sí · Grupo: `decretos`

**12:58 · Pedro Sánchez convocó elecciones tras caer los decretos.** (hecho)

- Cita literal: «Consecuencia de eso, Pedro Sánchez convocó elecciones.»
- Qué dicen las fuentes: Sánchez anunció el lunes 5-10-2026 el adelanto de las elecciones generales al 29 de noviembre, tres días después de la derrota de los decretos.
- Fuentes: <https://www.esdiario.com/nacional/261005/199417/sanchez-adelanta-elecciones-batacazo-decretos-vivienda-congreso.html> · <https://www.latercera.com/mundo/noticia/congreso-de-espana-rechaza-dos-decretos-sobre-vivienda-y-pedro-sanchez-decidira-el-fin-de-semana-si-adelanta-elecciones/>
- Fuente abierta: sí · Grupo: `decretos`

**15:25 · Los últimos gobiernos subieron el salario mínimo de forma histórica.** (hecho)

- Cita literal: «con los últimos gobiernos se ha subido el salario mínimo, ¿no?»
- Qué dicen las fuentes: El SMI pasó de 735,90 euros (2018) a 1.221 euros en 14 pagas (2026), un 66 % más en ocho subidas (La Moncloa). «Histórica» es una valoración.
- Fuentes: <https://www.lamoncloa.gob.es/presidente/actividades/Paginas/2026/160226-sanchez-subida-salario-minimo.aspx> · <https://calcuris.com/es/espana/laboral/evolucion-smi/>
- Fuente abierta: no (solo extracto)

**16:16 · Florentino Pérez tiene 4.900 millones de euros.** (cifra)

- Cita literal: «Florentino Pérez, tiene 4 .900 millones de euros.»
- Qué dicen las fuentes: La lista Forbes España 2026 (publicada el 3-11-2026) le atribuye 4.900 millones de euros, según Demócrata. Otras estimaciones de 2026 son más altas (unos 5.400 millones de euros en la lista mundial de Forbes).
- Fuentes: <https://www.democrata.es/economia/forbes-ricos-amancio-ortega-botin-iglesias-pino/> · <https://www.money.it/quanto-guadagna-florentino-perez-il-patrimonio-dello-storico-presidente-del-real-madrid>
- Fuente abierta: sí

**16:59 · Ni Podemos ni Gabriel Rufián están en el Frente Amplio.** (hecho)

- Cita literal: «No está Podemos ni tampoco está Gabriel Rufián.»
- Qué dicen las fuentes: No hubo acuerdo estatal con Podemos, que concurre por separado salvo en la Comunidad Valenciana y Canarias; en Cataluña Podemos va en las listas de ERC y Rufián hace campaña con Irene Montero.
- Fuentes: <https://www.articulo14.es/politica/que-partidos-forman-frente-amplio-integrantes-acuerdos-y-diferencias-con-sumar-20261107.html> · <https://www.democrata.es/elecciones-generales-espana/mapa-alianzas-izquierda-29n-pactos-candidaturas/>
- Fuente abierta: sí · Grupo: `frente_amplio`

**17:32 · Puso su candidatura a disposición para facilitar el acuerdo.** (voto_o_decision)

- Cita literal: «De hecho, puse a disposición mi candidatura.»
- Qué dicen las fuentes: El 14-10-2026 Colau se mostró dispuesta a retirarse como candidata, e incluso a cambiar la marca, si con ello se incorporaba Podemos («Todo se puede discutir», en TVE).
- Fuentes: <https://www.esdiario.com/nacional/261014/200222/colau-ofrece-cabeza-salvar-izquierda-sigue-ponerse-acuerdo_amp.html> · <https://www.democrata.es/en/general-elections-spain/colau-is-open-to-stepping-aside-as-a-candidate-if-it-facilitates-a-united-list-of-the-left/>
- Fuente abierta: sí · Grupo: `frente_amplio`

**21:00 · El Frente Amplio no hizo primarias.** (voto_o_decision)

- Cita literal: «No hicimos primarias porque no daba tiempo.»
- Qué dicen las fuentes: Frente Amplio no celebró primarias: la candidata se designó por acuerdo de los partidos el 12-10-2026 y ARA recoge que la coalición no compartía hacerlas. El motivo («no daba tiempo») no se comprobó.
- Fuentes: <https://en.ara.cat/politics/ada-colau-says-that-she-will-only-be-candidate-if-joins-the-broad-front-the-citizenry-is-asking-for-one-ballot_1_5873045.html> · <https://orain.eus/es/politica/2026/10/12/frente-amplio-acuerda-designar-ada-colau-cabeza-lista-en-las-generales/>
- Fuente abierta: sí · Grupo: `frente_amplio`

**21:34 · Podemos convocó sus propias primarias y decidió ir solo.** (voto_o_decision)

- Cita literal: «Convocó sus propias primarias y ya está, porque había decidido ir solo.»
- Qué dicen las fuentes: Podemos celebró primarias propias el 14 y 15 de octubre de 2026 (ganó Irene Montero con el 90,7 %) y concurre por separado en la mayor parte de España.
- Fuentes: <https://www.elsaltodiario.com/elecciones/montero-asegura-frente-amplio-ha-bloqueado-acuerdos-territoriales-alcanzaron-otros-territorios> · <https://www.diaridetarragona.com/espana/273314/frente-amplio-concurriran-separado-catalunya-madrid.html>
- Fuente abierta: sí · Grupo: `frente_amplio`

**22:07 · Unidas Podemos estuvo en el primer gobierno de coalición y Sumar en el segundo.** (hecho)

- Cita literal: «En el primer mandato estuvo Unidas Podemos y luego estuvo en el segundo mandato Sumar.»
- Qué dicen las fuentes: Unidas Podemos formó parte del Gobierno de coalición de 2020-2023 y Sumar del formado en noviembre de 2023.
- Fuentes: <https://es.ara.cat/politica/unidas-descarta-salir-gobierno-pesar-acusar-pedro-sanchez-opacidad-relacion-sahara_1_4311311.amp.html> · <https://www.noticiasdenavarra.com/politica/2023/11/02/ernest-urtasun-monica-garcia-ministrables-7458837.html>
- Fuente abierta: no (solo extracto)

**24:06 · Ábalos está en la cárcel.** (hecho)

- Cita literal: «la justicia ha actuado y está en la cárcel»
- Qué dicen las fuentes: Ábalos está en prisión desde el 27-11-2025 (primero provisional) y la condena del Supremo de 22-6-2026 es firme.
- Fuentes: <https://es.ara.cat/politica/supremo-condena-exministro-abalos-24-anos-prision_1_5776792.html> · <https://www.menorca.info/actualidad/nacional/2025/11/27/2520971/psoe-tras-prision-para-abalos-veniamos-llorados.html>
- Fuente abierta: no (solo extracto) · Grupo: `abalos`

**25:00 · Su espacio político no tiene ningún caso de corrupción tras ocho años en la alcaldía y presencia en el gobierno.** (hecho)

- Cita literal: «podemos responder que tenemos cero casos de corrupción»
- Qué dicen las fuentes: Para el gobierno municipal está respaldado: ARA (12-3-2025) cuenta 22 causas contra Colau y su gobierno, todas archivadas, sin ninguna condena. Es una negación general («cero casos») y no hice una búsqueda exhaustiva de todos los cargos de su espacio en el Gobierno central; no localicé condenas.
- Fuentes: <https://es.ara.cat/sociedad/barcelona/acaba-via-crucis-judicial-gobierno-colau_1_5313128.html>
- Fuente abierta: sí · Grupo: `querellas`

**28:44 · Una jueza escribió al archivar que un fondo se querelló porque no le gustaban sus políticas de vivienda.** (cita_de_tercero)

- Cita literal: «este fondo buitre ha puesto esta denuncia porque no le gustaban las políticas de vivienda de Ada Polau»
- Qué dicen las fuentes: El Juzgado de Instrucción 18 de Barcelona archivó en diciembre de 2023 la querella del fondo Vauras: la jueza escribió que se querelló «simplemente porque no le eran favorables las políticas de vivienda» y que buscaba un «efecto mediático». La cita de Colau es una paráfrasis fiel. No se pudo abrir la página de Deia (error 406).
- Fuentes: <https://www.deia.eus/politica/2023/12/15/ada-colau-ve-archivada-causa-7639587.html> · <https://www.publico.es/politica/archivan-causa-ada-colau-abierta-meses-elecciones.html>
- Fuente abierta: no (solo extracto) · Grupo: `querellas`

**30:10 · A Zapatero le han encontrado joyas por más de un millón de euros.** (cifra)

- Cita literal: «le han encontrado joyas por más de un millón de euros»
- Qué dicen las fuentes: La UDEF halló el 19-5-2026 una caja fuerte con 103 objetos en su despacho; la tasación pericial pedida por el juez las valoró en 1,3 millones de euros (junio de 2026). La defensa había hablado de 30.000-50.000 euros.
- Fuentes: <https://www.eldebate.com/espana/20260611/joyas-intervenidas-zapatero-tienen-valor-13-millones-euros-segun-tasacion-pidio-juez_427835.html> · <https://es.euronews.com/my-europe/2026/06/11/tasacion-eleva-millones-euros-valor-joyas-zapatero> · <https://maldita.es/desinfo/20260526/el-valor-de-las-joyas-encontradas-en-el-despacho-de-zapatero/>
- Fuente abierta: no (solo extracto)

**32:33 · Joan Clos, exministro y exalcalde, ha sido después portavoz de grandes fondos.** (hecho)

- Cita literal: «ahí tienes Joan Clos, que fue ministro y alcalde de Barcelona,»
- Qué dicen las fuentes: Joan Clos, exalcalde de Barcelona (1997-2006) y exministro de Industria, presidió de 2020 a diciembre de 2025 Asval, la asociación de propietarios de vivienda en alquiler impulsada por grandes inmobiliarias. «Portavoz de los grandes buitres» es una caracterización.
- Fuentes: <https://forbes.es/nombramientos/404806/asval-nombra-presidenta-de-la-asociacion-a-helena-beunza/> · <https://brainsre.news/asval-helena-baunza-nueva-presidenta/>
- Fuente abierta: no (solo extracto)

**38:52 · Los ferroviarios hacían huelgas antes del accidente por falta de mantenimiento e inversión.** (hecho)

- Cita literal: «los propios ferroviarios que estaban haciendo huelgas antes de que pasara el accidente»
- Qué dicen las fuentes: Los maquinistas hicieron huelga del 9 al 11 de febrero de 2026 por la seguridad y el mantenimiento, y Semaf había convocado el 16 de octubre otra huelga para el 29, antes del accidente de Urda (28-10-2026).
- Fuentes: <https://www.articulo14.es/economia/los-maquinistas-mantienen-la-huelga-de-renfe-tras-el-accidente-de-toledo-estos-son-los-servicios-minimos-20261029.html> · <https://www.diaridetarragona.com/espana/274262/sindicato-maquinistas-semaf-mantiene-huelga-jueves.html> · <https://www.diariodeleon.es/leon/260210/2075151/gobierno-sube-mantenimiento-vias-frenar-huelga-tres-dias-renfe.html>
- Fuente abierta: no (solo extracto) · Grupo: `accidentes`

**39:43 · El mantenimiento ferroviario se ha dejado en subcontratas privadas.** (hecho)

- Cita literal: «en la parte del mantenimiento se ha privatizado a subcontratas privadas»
- Qué dicen las fuentes: El mantenimiento del tramo de Adamuz estaba adjudicado a una UTE de FCC, Ferrovial, OHLA y Azvi (2023-2028), y el acuerdo de Transportes con los sindicatos de febrero de 2026 habla de valorar la internalización de «contratos de mantenimiento actualmente externalizados». La inspección y el control siguen siendo de Adif.
- Fuentes: <https://www.vozpopuli.com/economia/empresas/el-gobierno-adjudico-a-fcc-ferrovial-ohla-y-azvi-el-cuidado-de-la-via-en-adamuz-por-56-millones-hasta-2028.html> · <https://www.lamoncloa.gob.es/serviciosdeprensa/notasprensa/transportes-movilidad-sostenible/Paginas/2026/090226-transportes-acuerdo-sindicatos-ferroviarios.aspx> · <https://www.noticiasdenavarra.com/economia/2026/02/09/claves-acuerdo-transportes-maquinistas-desconvocar-renfe-10680262.amp.html>
- Fuente abierta: no (solo extracto)

**41:49 · La inversión en mantenimiento es la mitad que en Francia.** (comparacion)

- Cita literal: «se ha bajado en la inversión en mantenimiento que tenemos la mitad que en Francia»
- Qué dicen las fuentes: Comisión Europea (informe RMMS, 2018-2022), según ARA: España dedicó al mantenimiento de la alta velocidad 239 millones de euros anuales de media (16,2 % del gasto) y Francia 463 millones (34 %). Otra fuente da 95.860 euros por kilómetro de red en España frente a 241.850 en Francia.
- Fuentes: <https://es.ara.cat/sociedad/espana-dedica-mitad-presupuesto-francia-alemania-mantenimiento-alta-velocidad_1_5894680.html> · <https://www.motorpasion.com/industria/espana-tiene-segunda-red-trenes-alta-velocidad-grande-mundo-gasta-mantenimiento-mitad-que-francia> · <https://www.articulo14.es/economia/espana-destino-solo-el-16-de-su-gasto-en-alta-velocidad-al-mantenimiento-entre-2018-y-2022-segun-la-ue-20261029.html>
- Fuente abierta: sí

**44:50 · El presidente dijo que era 'inasumible'.** (cita_de_tercero)

- Cita literal: «es que lo dijo el mismo presidente, que era inasumible»
- Qué dicen las fuentes: Sánchez calificó de «inasumibles» los dos accidentes ferroviarios en un mismo año (ARA; Diari de Tarragona recoge «no es asumible»).
- Fuentes: <https://es.ara.cat/politica/saldra-oscar-puente_129_5893607.html> · <https://www.diaridetarragona.com/espana/274428/sanchez-promete-soluciones-reforzar-sistema-alta-velocidad.html>
- Fuente abierta: sí · Grupo: `accidentes`

**46:41 · El atentado de la Rambla fue justo antes del referéndum de 2017.** (hecho)

- Cita literal: «porque era justo antes del referéndum del 2017, hubo el atentado en la Rambla»
- Qué dicen las fuentes: El atentado de la Rambla fue el 17-8-2017, unas seis semanas antes del referéndum del 1 de octubre.
- Fuentes: <https://www.elindependiente.com/politica/2017/08/18/de-5-de-la-tarde-a-5-de-la-manana-relato-de-una-tarde-noche-de-terror-en-cataluna/amp/> · <https://www.libertaddigital.com/espana/2017-08-17/una-furgoneta-atropella-a-varias-personas-en-las-ramblas-de-barcelona-1276604479/>
- Fuente abierta: no (solo extracto)

**49:14 · En la crisis de Ceuta se movieron 70.000 personas.** (cifra)

- Cita literal: «70 .000 personas no se mueven sin que se dé cuenta el gobierno de Marruecos»
- Qué dicen las fuentes: Marlaska cifró en 72.000 las personas que cruzaron desde Marruecos (El Faro de Ceuta, 4-8-2026); ARA habla de unas 80.000 entre el 30 y el 31 de julio. Sobre el papel de Marruecos, la frase es una inferencia.
- Fuentes: <https://elfarodeceuta.es/marlaska-niega-cni-avisara-entrada-masiva-ceuta-confirma-72-000-personas-cruzaron-marruecos/> · <https://es.ara.cat/politica/gobierno-sanchez-rinde-cuentas-26-dias-despues-crisis-ceuta_1_5831446.html> · <https://www.ondavasca.com/marlaska-cifra-en-72-000-las-entradas-en-ceuta-durante-la-crisis-migratoria/>
- Fuente abierta: sí · Grupo: `ceuta_70000`

**50:21 · La población de Ceuta se duplicó.** (cifra)

- Cita literal: «como es Ceuta, se duplica la población.»
- Qué dicen las fuentes: Entraron entre 72.000 y 80.000 personas en una ciudad de 83.595 habitantes (padrón oficial a 1-1-2025): durante unos días la población casi se duplicó. Cálculo propio a partir de esas dos cifras.
- Fuentes: <https://elfarodeceuta.es/marlaska-niega-cni-avisara-entrada-masiva-ceuta-confirma-72-000-personas-cruzaron-marruecos/> · <https://www.boe.es/eli/es/rd/2025/12/03/1117> · <https://www.infobae.com/espana/agencias/2026/08/06/ceuta-y-melilla-dos-de-los-pocos-lugares-donde-crece-la-poblacion-nacida-en-espana/>
- Fuente abierta: sí · Grupo: `ceuta_70000`

**52:15 · España acogió a muchos más refugiados ucranianos que personas llegaron a Ceuta.** (comparacion)

- Cita literal: «para acojar a miles y miles de personas refugiadas de Ucrania, muchas más»
- Qué dicen las fuentes: España había concedido protección temporal a 236.570 personas desplazadas de Ucrania a febrero de 2025 (más de 264.000 un año después, según el extracto de una nota de Inclusión), frente a las 72.000-80.000 personas que entraron en Ceuta.
- Fuentes: <https://www.lamoncloa.gob.es/serviciosdeprensa/notasprensa/inclusion/paginas/2025/250225-proteccion-afectados-guerra-ucrania.aspx> · <https://www.lamoncloa.gob.es/serviciosdeprensa/notasprensa/inclusion/Paginas/2026/240226-ucranianos-seguridad-social.aspx> · <https://elfarodeceuta.es/marlaska-niega-cni-avisara-entrada-masiva-ceuta-confirma-72-000-personas-cruzaron-marruecos/>
- Fuente abierta: no (solo extracto)

**53:09 · La mayoría de quienes entraron en Ceuta regresaron.** (hecho)

- Cita literal: «de esas personas que entraron, la mayoría tenían que regresar, ¿no?»
- Qué dicen las fuentes: El Faro de Ceuta (4-8-2026): unas 70.000 de las 72.000 personas habían abandonado Ceuta en la primera semana; quedaban 2.500 según el Gobierno y entre 3.000 y 5.000 según las autoridades locales.
- Fuentes: <https://elfarodeceuta.es/marlaska-niega-cni-avisara-entrada-masiva-ceuta-confirma-72-000-personas-cruzaron-marruecos/>
- Fuente abierta: sí · Grupo: `ceuta_70000`

**57:43 · El Frente Amplio ha dicho públicamente que no comparte el cambio de posición sobre el Sáhara.** (hecho)

- Cita literal: «Que no compartimos por parte del Frente Amplio y que lo hemos dicho públicamente.»
- Qué dicen las fuentes: Los partidos que integran Frente Amplio lo han dicho públicamente: Sumar (con Podemos y Bildu) exigió en noviembre de 2025 a Sánchez rectificar el apoyo al plan de autonomía marroquí. No localicé una declaración de campaña firmada como Frente Amplio.
- Fuentes: <https://www.elindependiente.com/espana/2025/11/12/sumar-podemos-y-bildu-exigen-a-sanchez-que-rectifique-en-el-sahara-deje-de-estar-plegado-a-la-dictadura-marroqui/amp/> · <https://www.diariodeleon.es/internacional/251104/2065020/sumar-fuerza-retratarse-sobre-sahara-marruecos-psoe_amp.html>
- Fuente abierta: no (solo extracto)

**75:59 · Este año hay 44 mujeres asesinadas por violencia machista.** (cifra)

- Cita literal: «Hay este año 44 asesinatos de mujeres por parte de hombres»
- Qué dicen las fuentes: Nota del Ministerio de Igualdad de 30-10-2026: 44 mujeres asesinadas por violencia de género en 2026 y 1.385 desde 2003.
- Fuentes: <https://www.lamoncloa.gob.es/serviciosdeprensa/notasprensa/igualdad/Paginas/2026/301026-condena-feminicidio-barcelona.aspx> · <https://www.moncloa.com/2026/10/24/mujeres-asesinadas-madrid-3453844/>
- Fuente abierta: sí · Grupo: `violencia_genero`

**76:10 · La mayoría de los autores de esos asesinatos son nacidos en España.** (hecho)

- Cita literal: «Quien ha producido esos asesinatos, la mayoría de veces no son personas del»
- Qué dicen las fuentes: Con 43 casos (24-10-2026), 28 agresores eran españoles (65,1 %) y 15 de otro país (34,9 %); el boletín oficial de mayo daba un 72,7 % de agresores nacidos en España. El primer dato es por nacionalidad y el segundo por país de nacimiento.
- Fuentes: <https://www.moncloa.com/2026/10/24/mujeres-asesinadas-madrid-3453844/> · <https://violenciagenero.igualdad.gob.es/wp-content/uploads/VMortales_2026_05_26.pdf>
- Fuente abierta: sí · Grupo: `violencia_genero`

**89:24 · Aceptó la Copa América al final del segundo mandato; la decidieron también la Generalitat y otras administraciones.** (voto_o_decision)

- Cita literal: «A finales del segundo mandato aceptar la Copa América»
- Qué dicen las fuentes: Barcelona fue elegida sede de la Copa América de vela el 29-3-2022 (segundo mandato, 2019-2023), en un acto con Aragonès y Colau; la impulsaron la Generalitat, el Ayuntamiento, el Puerto y Barcelona Global.
- Fuentes: <https://www.vilaweb.cat/noticies/barcelona-copa-america-de-vela-cost-70-milions/> · <https://www.3cat.cat/esport3/barcelona-candidata-a-ser-la-seu-de-la-copa-america-2024/noticia/3151434/>
- Fuente abierta: no (solo extracto)

**90:16 · Implantó la recogida selectiva de basura en Sant Andreu al salir de la pandemia.** (voto_o_decision)

- Cita literal: «empezamos en un barrio de Barcelona, en San Andreu a hacer una cosa que la Unión Europea recomienda»
- Qué dicen las fuentes: La recogida puerta a puerta empezó en Sant Andreu de Palomar en mayo de 2021 (más de 12.000 viviendas) y provocó rechazo vecinal. Que la UE lo recomiende no se comprobó.
- Fuentes: <https://www.interempresas.net/Equipamiento_Municipal/351989-Barcelona-implanta-servicio-recogida-residuos-puerta-puerta-barrio-Sant-Andreu-Palomar.html> · <https://www.eldiario.es/catalunya/barcelona/problema-limpieza-barcelona-convierte-mayor-frente-colau_1_8367636.amp.html>
- Fuente abierta: no (solo extracto)

**99:28 · La ley de vivienda actual ya incluye un índice de referencia.** (hecho)

- Cita literal: «Ya hay un índice ahora mismo con la ley de alquileres, la ley de vivienda actual,»
- Qué dicen las fuentes: La Ley 12/2023 prevé el Sistema Estatal de Referencia del Precio del Alquiler (SERPAVI), aprobado por resolución en 2024; en zonas tensionadas actúa como tope para grandes tenedores.
- Fuentes: <https://maldita.es/malditateexplica/20240315/indice-precios-alquiler-ministerio-vivienda/> · <https://www.lamoncloa.gob.es/serviciosdeprensa/notasprensa/vivienda-agenda-urbana/paginas/2024/indice-referencia-precio-alquiler-vivienda-sepavi.aspx>
- Fuente abierta: no (solo extracto) · Grupo: `alquileres`

**100:20 · El ayuntamiento compró 1.600 viviendas por debajo del precio de mercado mediante tanteo y retracto.** (cifra)

- Cita literal: «compramos 1 .600 viviendas a precio inferior»
- Qué dicen las fuentes: El Ayuntamiento incorporó más de 1.600 viviendas por tanteo y retracto (cifra de Barcelona en Comú y del propio Ayuntamiento; casi 1.400 en agosto de 2022). No comprobé cuánto por debajo del mercado se pagaron.
- Fuentes: <https://es.ara.cat/sociedad/barcelona/ayuntamiento-barcelona-no-compro-casa-orsola_1_5272209.html> · <https://www.ultimahora.es/noticias/comunidades/2022/08/06/1768995/ayuntamiento-barcelona-compra-dos-nuevas-fincas-total-viviendas.html>
- Fuente abierta: no (solo extracto) · Grupo: `viviendas_1600`

**108:24 · Su propuesta de ley fija en la cuarta vivienda el límite del pequeño propietario.** (hecho)

- Cita literal: «hemos dicho que a partir de una cuarta vivienda se deja de ser un pequeño propietario»
- Qué dicen las fuentes: La propuesta de Frente Amplio (octubre de 2026) fija un gravamen anual del 10 % a las personas físicas a partir de la cuarta vivienda (y a las empresas desde la primera), con un umbral de 800.000 euros.
- Fuentes: <https://www.que.es/2026/10/28/impuesto-vivienda-colau/> · <https://www.eldiario.es/1_cfd550>
- Fuente abierta: no (solo extracto)

**114:29 · Trump está castigando a España/Europa con aranceles.** (hecho)

- Cita literal: «Ya está castigando con aranceles, generando inestabilidad en todo el mundo.»
- Qué dicen las fuentes: La Administración Trump aplica aranceles a las importaciones de la UE (un medio habla de un 10 % anunciado en mayo de 2026) y ha amenazado varias veces a España con aranceles más altos por el gasto en defensa. No consta un arancel específico contra España.
- Fuentes: <https://www.cronista.com/espana/politica-es/trump-impone-nuevas-tasas-a-espana-estados-unidos-aplicara-un-arancel-del-10-a-las-importaciones-de-la-union-europea/> · <https://www.elnuevodia.com/noticias/mundo/notas/donald-trump-amenaza-a-espana-con-aranceles-por-gasto-en-defensa-la-union-europea-responde/>
- Fuente abierta: no (solo extracto)

**117:52 · Los puertos italianos impulsaron una huelga general vinculada a la flotilla.** (hecho)

- Cita literal: «los puertos italianos impulsaron toda la huelga general a partir de decir, si se toca la flotilla»
- Qué dicen las fuentes: Un portavoz del sindicato USB en el puerto de Génova advirtió a finales de agosto de 2025 de que, si se perdía el contacto con la flotilla, lo bloquearían todo; el 22 de septiembre los estibadores pararon el puerto y USB convocó movilizaciones nacionales. Fuentes mayoritariamente militantes o del propio sindicato.
- Fuentes: <https://www.wantedinrome.com/news/italy-dockworkers-threaten-to-block-shipments-to-israel-if-flotilla-for-gaza-stopped.html> · <https://www.izquierdadiario.es/Bloquearemos-toda-Europa-los-estibadores-de-Genova-iran-a-la-huelga-para-proteger-la-flotilla-hacia> · <https://es.euronews.com/2025/09/27/los-estibadores-europeos-coordinan-el-boicot-a-los-buques-con-carga-militar-enviados-a-isr>
- Fuente abierta: no (solo extracto) · Grupo: `flotilla`

**119:02 · A los miembros de la flotilla les dispararon con drones, los interceptó el ejército y los encarcelaron.** (hecho)

- Cita literal: «nos secuestró el ejército, nos pusieron en la cárcel»
- Qué dicen las fuentes: Colau fue interceptada por fuerzas israelíes a unas 80 millas de Gaza, trasladada a una prisión del sur de Israel y deportada el 5-10-2025. Los ataques con drones y explosiones los denunció la propia flotilla; no localicé verificación independiente.
- Fuentes: <https://es.ara.cat/politica/colau-coronas-aterrizan-barcelona-deportados-israel_1_5519239.html> · <https://www.catalannews.com/politics/item/flotilla-detainees-spanish-citizens-deported-sunday-october-5-2025> · <https://canaln.pe/internacionales/flotilla-gaza-denuncia-ataques-durante-viaje-mediterraneo-n487016>
- Fuente abierta: no (solo extracto) · Grupo: `flotilla`

**122:43 · Figaredo, diputado de Vox, dijo que hay que salir a cazar inmigrantes.** (cita_de_tercero)

- Cita literal: «un diputado de Vox en el Congreso y dice hay que salir a cazar inmigrantes»
- Qué dicen las fuentes: José María Figaredo, diputado de Vox, habló en agosto de 2026 en televisión (no en el Congreso) de «cazar» a los inmigrantes que entraron en Ceuta y devolverlos a Marruecos; dijo que no se arrepentía ni se retractaba y después matizó que se refería a «apresar o detener». Hay denuncias ante la Fiscalía.
- Fuentes: <https://www.diariodeleon.es/nacional/260820/2094808/figaredo-dicho-arrepiente-retracta-haber-dicho-cazar-llegados-marruecos.html> · <https://www.diariodeleon.es/nacional/260810/2093922/nueva-denuncia-figaredo-vox-llamar-cazar-migrantes-entraron-ilegalmente-ceuta.html> · <https://www.eldiario.es/1_ccfe6f>
- Fuente abierta: no (solo extracto)

**124:22 · Acaban de detener a la cúpula de Núcleo Nacional.** (hecho)

- Cita literal: «acaban de detener a la cúpula de Nucleonacional,»
- Qué dicen las fuentes: La Policía Nacional detuvo el 6-11-2026 a entre 12 y 14 miembros de Núcleo Nacional en varias provincias, entre ellos dirigentes; la causa la lleva un juzgado de Gijón.
- Fuentes: <https://www.diaridetarragona.com/espana/275089/policia-nacional-detiene-12-miembros-grupo-neonazi-nucleo-nacional-siete-provincias.html> · <https://www.democrata.es/tribunales/quienes-son-detenidos-nucleo-nacional-neonazi-alberto-pugilato-fundador-noviembre-nacional-entre-14-arrestados/> · <https://es.ara.cat/politica/policia-nacional-acusa-nucleo-nacional-entrenarse-ucrania-preparar-levantamiento-armado_1_5906770.html>
- Fuente abierta: no (solo extracto)

**124:50 · Vox se fotografía con Milei y con Trump.** (hecho)

- Cita literal: «igual que Vox se fotografía con Milley o se fotografía con Trump»
- Qué dicen las fuentes: Abascal se fotografió con Trump en la CPAC de Washington (febrero de 2024) y se ha reunido y fotografiado con Milei, del que se le describe como principal aliado en Europa.
- Fuentes: <https://theobjective.com/espana/politica/2024-02-21/abascal-foto-trump-washington/> · <https://www.elindependiente.com/espana/2024/02/24/abascal-se-cita-con-trump-en-washington-conversacion-de-quince-minutos-y-foto-posterior/amp/> · <https://www.perfil.com/internacional/milei-se-reunio-con-abascal-en-madrid-y-reforzo-su-alianza-con-la-ultraderecha-europea-aenlM9d2dM7R>
- Fuente abierta: no (solo extracto)

**126:35 · En un mitin criticó a 'Caetana' y dijo 'sus amigos pijos'.** (hecho)

- Cita literal: «Y en un meeting critiqué a Caetana.»
- Qué dicen las fuentes: En el primer acto de precampaña de Frente Amplio en Cataluña (la Sagrera, Barcelona) Colau se dirigió a Cayetana Álvarez de Toledo y habló de subir los impuestos a ella y a sus «amigos pijos» (ARA).
- Fuentes: <https://es.ara.cat/politica/elecciones-generales/frente-amplio-colau-presenta-cataluna-freiremos-impuestos-pijos_1_5903201.html>
- Fuente abierta: no (solo extracto)

### No verificable (3)

**31:07 · El Supremo aceleró procedimientos sobre el entorno de Sánchez mientras hay casos del PP parados años.** (comparacion)

- Cita literal: «se han acelerado muchos procedimientos que afectaban al entorno de Pedro Sánchez, a su mujer, a su hermano,»
- Qué dicen las fuentes: Es una comparación de ritmos judiciales y una interpretación; no hay una medida pública con la que comprobarla. Dato de contexto: al hermano del presidente no lo juzgó el Supremo, sino la Audiencia Provincial de Badajoz (condena de 14-7-2026, no firme); el Supremo sí juzgó a Ábalos. La causa de su esposa no se buscó.
- Fuentes: <https://es.euronews.com/2026/07/14/david-sanchez-condenado-a-nueve-anos-de-inhabilitacion-por-prevaricacion> · <https://es.ara.cat/politica/supremo-condena-exministro-abalos-24-anos-prision_1_5776792.html>
- Fuente abierta: no (solo extracto)

**32:09 · Sitúa el 15M en 2015 (fecha tal como aparece transcrita).** (hecho)

- Cita literal: «¿Te acuerdas antes del 15M del 2015 cuando salía la gente masivamente a la calle»
- Qué dicen las fuentes: El 15M empezó el 15 de mayo de 2011, no en 2015. La fecha «2015» sale de una transcripción automática y puede ser un error de transcripción o un lapsus; sin escuchar el audio no se puede atribuir el error.
- Fuentes: <https://www.publico.es/politica/conto-publico-15-m.html> · <https://en.ara.cat/politics/15-m-ten-years-from-the-anger-that-wanted-to-challenge-the-establishment_1_3985366.html>
- Fuente abierta: no (solo extracto)

**120:07 · El PSOE era al principio proisraelí y después cambió su posición.** (hecho)

- Cita literal: «El PSOE al principio era pro -Israel»
- Qué dicen las fuentes: «Pro-Israel» es una caracterización. Hechos localizados: Sánchez condenó el ataque de Hamás y ya el 14-10-2023 pidió reconocer el Estado palestino; España lo reconoció en mayo de 2024 y endureció el embargo de armas en 2025. Hay evolución, pero la etiqueta inicial no es comprobable.
- Fuentes: <https://maldita.es/malditahemeroteca/20240522/espana-reconocimiento-estado-palestina/> · <https://www.elespanol.com/espana/politica/20231015/agresividad-belarra-israel-eeuu-debilita-posicion-gobierno-conflicto/801919930_0.amp.html>
- Fuente abierta: no (solo extracto)

### No he podido comprobarlo (8)

**6:00 · Su coalición tiene mucho menos dinero de campaña que otros partidos.** (comparacion)

- Cita literal: «tenemos mucho menos dinero para hacer campaña, por ejemplo, que otros partidos»
- Qué dicen las fuentes: Demócrata (9-11-2026) cifra el presupuesto de campaña de Frente Amplio en algo más de 1,6 millones de euros (1,1 de gasto ordinario y 530.125 euros de envío de propaganda). No localicé los presupuestos de PP, PSOE ni Vox para el 29-N, así que no hay con qué comparar.
- Fuentes: <https://www.democrata.es/politica/frente-amplio-destina-1-6-millones-a-su-campana-y-colau-prepara-actos-en-una-decena-de-comunidades/> · <https://www.democrata.es/elecciones-generales-espana/cuanto-interes-paga-cada-partido-por-su-financiacion-29n/>
- Fuente abierta: sí

**16:19 · Florentino Pérez paga 150 millones de euros sobre sus beneficios.** (cifra)

- Cita literal: «está pagando sobre sus beneficios 150 millones de euros»
- Qué dicen las fuentes: No localicé ninguna fuente con lo que paga Florentino Pérez en impuestos ni con la cifra de 150 millones. El análisis de ARA sobre el impuesto que propone Colau (7-11-2026) no lo menciona.
- Fuentes: <https://es.ara.cat/politica/nuevo-impuesto-propone-ada-colau-alto-pagan-ricos_1_5903002.html>
- Fuente abierta: no (solo extracto)

**43:22 · Con la liberalización hay un 40 % más de trenes y el personal solo subió un 10 %.** (cifra)

- Cita literal: «hay un 40 % o más de trenes, pero el personal solo sube un 10 %»
- Qué dicen las fuentes: No localicé esas dos cifras. Datos próximos: la CNMC cifra en un 42 % el aumento de viajeros de alta velocidad entre 2019 y 2024, y Vozpópuli en algo más del 3 % el aumento de plantilla de Adif entre 2017 y 2023 (de 12.333 a 12.619).
- Fuentes: <https://cnmc.es/prensa/balance-liberalizacion-ferroviaria-2024-20250922> · <https://www.vozpopuli.com/economia/transporte/adif-en-la-era-sanchez-un-50-mas-de-viajeros-pero-solo-un-3-de-aumento-de-plantilla-para-mantener-la-red.html>
- Fuente abierta: no (solo extracto)

**74:32 · La mayoría de los migrantes trabaja y cotiza a la Seguridad Social.** (hecho)

- Cita literal: «aportando la seguridad social y contribuyendo a pagar las pensiones de nuestra gente mayor»
- Qué dicen las fuentes: No localicé la tasa de empleo de la población extranjera, que es lo que permitiría decir «la mayoría». Dato próximo: los extranjeros son el 16,4 % de los afiliados a la Seguridad Social en octubre de 2026, según el extracto de la revista de la Seguridad Social.
- Fuentes: <https://revista.seg-social.es/-/afiliacion-octubre-2026>
- Fuente abierta: no (solo extracto)

**95:47 · Durante su mandato la principal nacionalidad de los autores de delitos en Barcelona era la española.** (hecho)

- Cita literal: «La principal nacionalidad no era extranjera, era española.»
- Qué dicen las fuentes: No localicé datos de detenidos por nacionalidad en Barcelona para 2015-2023. Los disponibles: en el primer semestre de 2022, 2.247 de los 2.939 detenidos por la Guardia Urbana eran extranjeros (76 %, cifra difundida por el partido Valents) y en 2024 casi ocho de cada diez. Eso es compatible con que la española fuera la nacionalidad individual más numerosa, pero no con que «la mayoría» fueran españoles, como añade después.
- Fuentes: <https://maldita.es/buloteca/claim/El-83-de-los-detenidos-por-robos-con-violencia-y-el-91-por-hurtos-en-Barcelona-son-extranjeros> · <https://www.vozpopuli.com/espana/cataluna/valents-denuncia-delincuentes-detenidos-barcelona-extranjeros.html>
- Fuente abierta: no (solo extracto) · Grupo: `hurtos`

**97:12 · El 90 % de los delitos en Barcelona los cometían hombres.** (cifra)

- Cita literal: «el 90 % del conjunto de los delitos de todos los realizaban hombres»
- Qué dicen las fuentes: No localicé el desglose por sexo de los detenidos o autores en Barcelona. Referencias próximas: el 94 % de los multirreincidentes de Cataluña son hombres (dato de Mossos recogido por Maldita, sin verificar) y más del 90 % de la población reclusa.
- Fuentes: <https://es.ara.cat/sociedad/inmigracion/extranjeros-cometen-delitos-graves-permisos_130_4934748.html> · <https://maldita.es/buloteca/claim/la-mayoria-de-criminales-y-delincuentes-reincidentes-en-cataluna-son-argelinos-o-marroquies>
- Fuente abierta: no (solo extracto)

**99:44 · Trece fondos internacionales tienen más de 100.000 viviendas en España.** (cifra)

- Cita literal: «13 fondos internacionales que no viven aquí»
- Qué dicen las fuentes: Es una estimación de la propia candidata (Artículo14, 8-11-2026) y no localicé una fuente independiente. Civio, citada por El Cronista, cuenta más de 30.000 viviendas en alquiler de Blackstone, casi 32.200 de otros 16 fondos y unas 7.000 de Cerberus, con otro perímetro.
- Fuentes: <https://www.articulo14.es/politica/ada-colau-candidata-de-frente-amplio-para-el-29n-si-de-mi-depende-los-fondos-buitre-seran-expulsados-de-este-pais-20261108.html> · <https://www.cronista.com/espana/economia-finanzas/alquileres-en-espana-caixabank-y-blackstone-son-los-fondos-de-inversion-con-mas-viviendas-segun-civio>
- Fuente abierta: no (solo extracto)

**106:43 · El ayuntamiento se personó judicialmente contra una ocupación de narcotraficantes en Poble-sec.** (hecho)

- Cita literal: «habían unos bajos de un edificio que era ocupado por grupos de narcotraficantes»
- Qué dicen las fuentes: No localicé el caso concreto ni la personación del Ayuntamiento. Sí hay noticias de operaciones contra narcopisos en Poble-sec (2018).
- Fuentes: <https://beteve.cat/societat/narcopisos-poble-sec-barcelona-mossos/>
- Fuente abierta: no (solo extracto)

### No comprobables según la extracción, no buscadas (8)

- **3:41** · Su hijo de 15 años le dijo que tenía que ir al programa. — «lo primero que me dijo mi hijo de 15 años fue, tienes que ir con Jordi Wild»
- **6:12** · Twitter es de Elon Musk, que está posicionado con la extrema derecha, y su algoritmo favorece a la derecha. — «está en manos de Elon Musk, que claramente está posicionado con la extrema derecha»
- **39:03** · Se ha reunido con trabajadores ferroviarios. — «Yo me he reunido con los trabajadores porque creo que era muy importante escucharles directamente»
- **57:37** · España tiene una responsabilidad directa en el Sáhara. — «ahí está el tema del Sáhara, donde España tiene una responsabilidad directa»
- **60:17** · Marruecos es muy cercano a Trump. — «Claro, pero fíjate que Marruecos es súper amigo de Trump.»
- **68:59** · Su familia procede de Huesca y de Soria. — «yo también vengo de Huesca y de Soria,»
- **111:13** · En otro país o países (el sujeto cae en un hueco de la transcripción) el alquiler está más protegido que en España. — «muy estable y está mucho más protegida que en España»
- **124:27** · Vox es cómplice de Desokupa. — «Y Vox es cómplice de Desocupa,»

## Jordi Wild (entrevistador)

### Respaldada en parte / imprecisa (7)

**7:45 · Elon Musk salió de la administración Trump enfrentado con él.** (hecho)

- Cita literal: «De hecho, se fue de la administración Trump a tiros, muy»
- Qué dicen las fuentes: Musk dejó el DOGE el 30-5-2025 tras discrepar de los aranceles y del proyecto fiscal; la ruptura pública con Trump estalló en redes en los días siguientes. El enfrentamiento existe, pero la salida formal fue anterior a la pelea.
- Fuentes: <https://www.emol.com/noticias/Internacional/2025/05/30/1167785/elon-musk-paso-casa-blanca.html> · <https://www.latercera.com/tendencias/noticia/los-momentos-clave-de-musk-en-la-casa-blanca/>
- Fuente abierta: no (solo extracto)

**25:24 · Un ex primer mandatario de Portugal dimitió por un caso que afectaba a alguien cercano.** (hecho)

- Cita literal: «tenemos el caso del expresidente de Portugal que dimitió por un caso»
- Qué dicen las fuentes: António Costa era primer ministro, no presidente de la República. Dimitió el 7-11-2023 por la Operación Influencer, en la que se ordenó detener a su jefe de gabinete; además el propio Costa era objeto de una investigación separada, no solo alguien cercano.
- Fuentes: <https://maldita.es/malditateexplica/20231107/dimite-antonio-costa-preguntas-respuestas/> · <https://es.ara.cat/internacional/europa/presidente-portugal-convoca-elecciones-anticipadas-dimision-costa_1_4853222.html>
- Fuente abierta: no (solo extracto)

**38:31 · Ábalos fue ministro de Transportes.** (hecho)

- Cita literal: «Ábalos llegó a ser ministro de Transportes, poco tiempo, pero lo fue.»
- Qué dicen las fuentes: Ábalos fue ministro de Fomento (luego Transportes) de junio de 2018 a julio de 2021: tres años, que no encajan con «poco tiempo».
- Fuentes: <https://es.ara.cat/politica/supremo-condena-exministro-abalos-24-anos-prision_1_5776792.html> · <https://maldita.es/control-del-poder/20260623/abalos-condenado-mocion-censura-corrupcion/>
- Fuente abierta: no (solo extracto) · Grupo: `abalos`

**64:12 · Rufián y 'Delgado' han pedido regular seriamente la inmigración.** (cita_de_tercero)

- Cita literal: «Yo he escuchado a Rufián y a Delgado hablar ya de una forma no negativa, pero sí bastante tajante»
- Qué dicen las fuentes: Respaldado para Rufián, que en agosto y septiembre de 2026 pidió más control de fronteras y una inmigración «ordenada y segura». De Emilio Delgado (identificación supuesta del «Delgado» de la cita) solo localicé declaraciones sobre seguridad, no sobre regular la inmigración.
- Fuentes: <https://es.ara.cat/politica/rufian-reclama-control-fronteras-pesar-reivindicar-llegada-padres-lamine-yamal_1_5862652.html> · <https://www.diariodeleon.es/nacional/260803/2093198/rufian-pide-medidas-solidas-inmigracion-ordenada-segura-recalca-paga-te-llames-javier-brahim_amp.html> · <https://www.elindependiente.com/espana/2026/02/19/gabriel-rufian-y-emilio-delgado-los-quinquis-rompen-la-baraja-de-la-izquierda/>
- Fuente abierta: no (solo extracto)

**91:10 · Desde 2018-19 la inseguridad es el primer problema percibido y la limpieza el segundo.** (hecho)

- Cita literal: «Desde 2018 -19 la inseguridad es el primer problema que percibe la gente y el segundo la limpieza.»
- Qué dicen las fuentes: La inseguridad era el primer problema en diciembre de 2018 (21 %) y en julio de 2022 (22 %). El segundo era el acceso a la vivienda en 2018 (12,1 %) y la limpieza en 2022 (11,5 %): la limpieza no fue el segundo «desde 2018-19».
- Fuentes: <https://www.vilaweb.cat/noticies/el-60-dels-barcelonins-creu-que-la-ciutat-ha-empitjorat/> · <https://es.ara.cat/sociedad/colau-suspende-peor-nota-ganaria-elecciones-barometro_1_4423876.html>
- Fuente abierta: sí · Grupo: `barometro`

**103:11 · Más de 16.000 denuncias por allanamiento/usurpación en 2024 y casi 15.000 en 2025; casi 4.500 en la provincia de Barcelona.** (cifra)

- Cita literal: «En España hubo en 2024 más de 16 .000 denuncias por allanamiento de usurpación, casi 15 .000 en 2025.»
- Qué dicen las fuentes: Respaldadas las cifras nacionales: 16.426 hechos de allanamiento o usurpación en 2024 y 14.875 en 2025 (Interior). La de Barcelona no coincide: las fuentes localizadas dan 5.077 para Barcelona en 2024, no «casi 4.500»; no encontré el dato provincial de 2025.
- Fuentes: <https://www.moncloa.com/2025/04/09/los-casos-de-okupacion-de-inmuebles-en-espana-repuntan-en-2024-segun-interior-3220821/> · <https://www.lavozdelanzarote.com/en/ekonomus/housing/analysis-2025-drop-in-raids-and-usurpations-in-spain-with-figures-from-the-canary-islands-and-other-regions_243031_102.html> · <https://www.idealista.com/en/news/node/833587>
- Fuente abierta: no (solo extracto)

**115:59 · Una fragata acompañó a la flotilla y hubo vuelos de regreso con coste público.** (hecho)

- Cita literal: «ha habido una fragata que os ha acompañado y ha habido»
- Qué dicen las fuentes: El Gobierno envió en septiembre de 2025 el Furor, un buque de acción marítima (patrullero), no una fragata, en misión de apoyo y rescate; no entró en la zona de interceptación. Vozpópuli cifra en al menos 25.000 euros el gasto público en la repatriación.
- Fuentes: <https://www.deia.eus/politica/2025/09/24/sanchez-anuncia-envio-buque-armada-10125431.html> · <https://www.menorca.info/actualidad/nacional/2025/09/25/2477393/buque-furor-patrullero-enviado-por-gobierno-para-apoyar-flotilla-dirige-gaza.html> · <https://www.vozpopuli.com/espana/moncloa-gasta-al-menos-25000-euros-en-los-repatriados-de-la-flotilla-y-no-da-credito-a-las-denuncias-de-torturas.html>
- Fuente abierta: no (solo extracto) · Grupo: `flotilla`

### Respaldada (30)

**4:51 · Colau dejó Twitter y volvió para tuitear que aceptaba la entrevista.** (hecho)

- Cita literal: «pero vuelves a Twitter para tuitear que aceptas la propuesta»
- Qué dicen las fuentes: Vozpópuli (21-10-2026): Colau dejó Twitter en 2021 «con carácter indefinido» y volvió a X cinco años después para responder a la invitación de The Wild Project: «Acepto la propuesta, será un placer». Una sola fuente localizada.
- Fuentes: <https://www.vozpopuli.com/espana/politica/la-irrelevancia-fuerza-a-colau-a-superar-su-fiebre-woke-y-regresar-a-la-red-social-de-elon-musk.html>
- Fuente abierta: sí

**6:50 · Zuckerberg (Meta) ha apoyado a Donald Trump.** (hecho)

- Cita literal: «Zuckerberg ha sido ya, en los últimos tiempos, un gran apoyo para Donald Trump.»
- Qué dicen las fuentes: Meta donó un millón de dólares al fondo de investidura de Trump, Zuckerberg se reunió con él en Mar-a-Lago (noviembre de 2024) y en enero de 2025 eliminó el programa de verificadores en EE. UU. «Gran apoyo» es una valoración; no localicé un apoyo electoral expreso.
- Fuentes: <https://www.forbesargentina.com/millonarios/meta-mark-zuckerberg-respalda-donald-trump-una-donacion-us-1-millon-fondo-inaugural-n64269> · <https://www.infobae.com/america/agencias/2025/01/08/zuckerberg-reorienta-meta-y-abraza-la-narrativa-sobre-libertad-de-expresion-de-trump-musk/>
- Fuente abierta: no (solo extracto)

**8:41 · En La Vanguardia (9-nov-2025) Colau dijo que no tenía intención de presentarse a primarias ni a ningunas elecciones.** (cita_de_tercero)

- Cita literal: «9 de noviembre de 2025 dijiste, cito, no tengo intención de presentarme ni a primarias, ni a próximas elecciones,»
- Qué dicen las fuentes: En noviembre de 2025 Colau dijo a La Vanguardia que no tenía intención de presentarse «ni a primarias ni a próximas elecciones», «ni municipales, ni estatales ni ninguna otra» (recogido por VilaWeb y The Objective, 14-11-2025). No confirmé el día exacto (9 de noviembre).
- Fuentes: <https://www.vilaweb.cat/noticies/colau-descarta-tornar-a-ser-candidata/> · <https://theobjective.com/espana/politica/2025-11-14/sumar-celebra-colau-descarte-volver/>
- Fuente abierta: no (solo extracto)

**16:52 · El 8 de octubre Colau dijo 'si estamos todas, yo también estaré'.** (cita_de_tercero)

- Cita literal: «Tú dijiste, si estamos todas, yo también estaré. Pero tenemos que estar todas.»
- Qué dicen las fuentes: ARA (8-10-2026) recoge la frase, dicha en una entrevista en TVE: «Me lo han pedido y he dicho que si estamos todas, yo también estaré. Pero tenemos que estar todas» (el artículo consultado es la versión en inglés).
- Fuentes: <https://en.ara.cat/politics/ada-colau-says-that-she-will-only-be-candidate-if-joins-the-broad-front-the-citizenry-is-asking-for-one-ballot_1_5873045.html>
- Fuente abierta: sí

**21:52 · Irene Montero dijo que Podemos no se unió por discrepancias con la gestión de Sumar en el gobierno.** (cita_de_tercero)

- Cita literal: «por discrepancias políticas serias con la gestión de Sumar dentro del»
- Qué dicen las fuentes: Montero (17-10-2026): «Llevamos años teniendo discrepancias políticas serias con los partidos de Sumar»; dijo ser «muy crítica» con su forma de gobernar y su cercanía al PSOE.
- Fuentes: <https://www.elsaltodiario.com/elecciones/montero-asegura-frente-amplio-ha-bloqueado-acuerdos-territoriales-alcanzaron-otros-territorios>
- Fuente abierta: sí · Grupo: `frente_amplio`

**22:53 · Hay condenados en firme en el caso Ábalos-Cerdán.** (hecho)

- Cita literal: «y esto es una cosa que no es una habladuría, tenemos condenados en firme,»
- Qué dicen las fuentes: El Tribunal Supremo condenó el 22-6-2026 a Ábalos (24 años y 3 meses) y a Koldo García (19 años y 8 meses); la sentencia es firme. Cerdán, al que también alude la cita, sigue investigado, no condenado. Fuente del Poder Judicial reutilizada de la comprobación de la entrevista a Feijóo.
- Fuentes: <https://www.poderjudicial.es/cgpj/es/Poder-Judicial/Tribunal-Supremo/Noticias-Judiciales/El-Tribunal-Supremo-condena-al-exministro-Jose-Luis-Abalos-y-a-su-exasesor-Koldo-Garcia-a-24-anos-y-19-anos-de-prision--respectivamente--por-delitos-de-organizacion-criminal--cohecho--malversacion-y-trafico-de-influencias> · <https://es.ara.cat/politica/supremo-condena-exministro-abalos-24-anos-prision_1_5776792.html> · <https://www.vozpopuli.com/tribunales/el-tribunal-supremo-levanta-las-medidas-cautelares-de-victor-de-aldama-tras-la-sentencia-firme.html>
- Fuente abierta: no (solo extracto) · Grupo: `abalos`

**27:28 · El 'caso Leire' sigue abierto.** (hecho)

- Cita literal: «Tenemos el caso Leire abierto también, que no sabemos dónde va a llegar eso.»
- Qué dicen las fuentes: El juez Pedraz prorrogó la instrucción del caso Leire Díez seis meses, hasta junio de 2027, con declaraciones pendientes.
- Fuentes: <https://www.democrata.es/en/courts/the-judge-in-the-leire-diez-case-extends-the-investigation-until-june-2027-and-leaves-the-door-open-to-more-proceedings/> · <https://www.ondavasca.com/el-juez-prorroga-seis-meses-la-investigacion-del-caso-leire-por-su-gravedad-y-complejidad/>
- Fuente abierta: no (solo extracto)

**31:26 · El PP tiene el caso Gürtel y el PSOE el caso ERE; se apartó a la jueza ('Ayala' en la transcripción).** (hecho)

- Cita literal: «el PP tiene el caso Gürtel, que es terrible, y el PSOE tiene el caso Ere,»
- Qué dicen las fuentes: Gürtel (condena del PP como partícipe a título lucrativo, confirmada por el Supremo en 2020) y ERE existen como grandes causas. La jueza Mercedes Alaya («Ayala» en la transcripción) fue apartada de la instrucción de los ERE en 2015 por el TSJA. «Terrible» es una valoración. Fuentes de Gürtel y ERE reutilizadas de la comprobación de Feijóo.
- Fuentes: <https://www.libertaddigital.com/espana/2015-07-24/el-tsja-pide-apartar-a-la-juez-alaya-de-los-ere-y-las-demas-macrocausas-1276553524/> · <https://www.deia.eus/politica/2020/10/14/supremo-confirma-pp-lucro-trama-4674571.html> · <https://maldita.es/malditateexplica/20240722/sentencias-constitucional-caso-ere-andalucia-penas/>
- Fuente abierta: no (solo extracto)

**36:39 · Ha habido dos accidentes mortales de alta velocidad en menos de un año.** (hecho)

- Cita literal: «uno de los mejores del mundo en alta velocidad, y a dos accidentes mortales,»
- Qué dicen las fuentes: Adamuz (Córdoba), 18-1-2026, 46 muertos; Urda (Toledo), 28-10-2026, 69 muertos según el balance provisional. Los dos en la línea de alta velocidad Madrid-Sevilla, con nueve meses de diferencia.
- Fuentes: <https://es.ara.cat/politica/saldra-oscar-puente_129_5893607.html> · <https://www.diaridetarragona.com/espana/274809/dimite-oscar-puente.html> · <https://www.infobae.com/espana/2026/04/28/conclusion-del-accidente-de-adamuz-la-ciaf-dice-que-se-rompio-el-carril-y-descarta-anomalias-previas-en-los-trenes/>
- Fuente abierta: sí · Grupo: `accidentes`

**38:12 · El PSOE llevaba siete años gobernando cuando ocurrió el primer accidente ('Adam Woods' en la transcripción).** (cifra)

- Cita literal: «El PSOE llevaba siete años gobernando cuando pasa lo de Adam Woods.»
- Qué dicen las fuentes: El PSOE gobierna desde junio de 2018 y el accidente de Adamuz fue el 18-1-2026: siete años y siete meses. «Adam Woods» se interpreta como Adamuz por el contexto (error de transcripción).
- Fuentes: <https://rtvc.es/ultima-hora-descarrilamiento-trenes-cordoba-en-directo-19-de-enero-2026/> · <https://maldita.es/control-del-poder/20260623/abalos-condenado-mocion-censura-corrupcion/>
- Fuente abierta: no (solo extracto) · Grupo: `accidentes`

**42:24 · Al principio el AVE devolvía el dinero si llegaba cinco minutos tarde.** (hecho)

- Cita literal: «yo me acuerdo que el AVE, si llegaba cinco minutos tarde, te devolvían el dinero»
- Qué dicen las fuentes: El compromiso de puntualidad de Renfe devolvía el 100 % del billete en el AVE Madrid-Sevilla por retrasos superiores a cinco minutos; después pasó a 15 minutos y desde julio de 2024 a 90.
- Fuentes: <https://www.consumoteca.com/transporte/compromiso-de-puntualidad-de-renfe/> · <https://www.directoalpaladar.com/actualidad-1/renfe-solo-devolvera-100-billete-ave-retrasos-superiores-a-90-minutos>
- Fuente abierta: no (solo extracto)

**43:52 · Tras el segundo accidente el ministro culpó a una persona y se filtraron unos audios.** (hecho)

- Cita literal: «Y sale el ministro y culpa a una persona.»
- Qué dicen las fuentes: ARA (29-10-2026): Puente habló de «error humano» y atribuyó la orden de reanudar la «marcha normal» a un operario de Adif; tres audios de las conversaciones se filtraron a El País, la SER y elDiario.es.
- Fuentes: <https://es.ara.cat/politica/saldra-oscar-puente_129_5893607.html> · <https://www.diaridetarragona.com/espana/274364/semaf-critica-filtracion-audios-sesgados-centro-control-anuncia-convocara-paros.html>
- Fuente abierta: sí · Grupo: `accidentes`

**49:24 · Marlaska y Robles se contradijeron el mismo día sobre si el CNI avisó.** (hecho)

- Cita literal: «las explicaciones del gobierno, tenemos a Marlaska y a Robles»
- Qué dicen las fuentes: El 25-8-2026 comparecieron los dos: Robles dijo que el CNI compartió información con las fuerzas de seguridad y la Delegación en reuniones del 27 y el 29 de julio (incluida una convocatoria para entrar a nado al día siguiente) y Marlaska que ningún informe anticipaba lo ocurrido. ARA tituló que ambos «se enredan»; Robles no habló de un aviso expreso de entrada masiva.
- Fuentes: <https://es.ara.cat/politica/gobierno-sanchez-rinde-cuentas-26-dias-despues-crisis-ceuta_1_5831446.html> · <https://elfarodeceuta.es/crisis-defensa-interior-cni-aviso-entrada-masiva-ceuta-interior-niega/>
- Fuente abierta: sí · Grupo: `ceuta_cni`

**49:44 · 70.000 personas avanzaron hacia Ceuta tras un llamamiento en redes sociales.** (cifra)

- Cita literal: «70 .000 personas estaban avanzando en masa, encima con un llamamiento hecho en redes sociales»
- Qué dicen las fuentes: 72.000 personas según Interior (unas 80.000 según ARA). Robles atribuyó la entrada a un «efecto llamada» en redes sociales y el informe policial cita mensajes en Facebook, Instagram, TikTok y WhatsApp.
- Fuentes: <https://elfarodeceuta.es/marlaska-niega-cni-avisara-entrada-masiva-ceuta-confirma-72-000-personas-cruzaron-marruecos/> · <https://es.ara.cat/politica/gobierno-sanchez-rinde-cuentas-26-dias-despues-crisis-ceuta_1_5831446.html> · <https://www.vozpopuli.com/tribunales/el-informe-concluye-que-marruecos-fomento-impulso-y-dirigio-un-flujo-masivo-de-personas-a-la-frontera-de-ceuta.html>
- Fuente abierta: sí · Grupo: `ceuta_70000`

**50:46 · El presidente se fue de vacaciones durante la crisis de Ceuta.** (hecho)

- Cita literal: «¿Qué te pareció que el presidente se fuera de vacaciones durante la crisis?»
- Qué dicen las fuentes: Mismo hecho y mismas fuentes que en la comprobación de la entrevista a Feijóo: Sánchez voló el 1-8-2026 a La Mareta (Lanzarote), al día siguiente de la entrada masiva, y publicó ese día su lista de canciones. Fuentes no reabiertas en esta comprobación.
- Fuentes: <https://www.elespanol.com/espana/politica/20260801/sanchez-comparte-playlist-verano-plena-crisis-ceuta-seguro-dan-idea-voy/1003744341448_0.html> · <https://www.esdiario.com/nacional/260801/194612/ceuta-mareta-sanchez-arranca-vacaciones-semana-incendios-crisis-migratoria.html> · <https://www.vozpopuli.com/internacional/la-prensa-internacional-retrata-al-presidente-espana-se-hunde-en-el-caos-sanchez-se-va-de-vacaciones.html>
- Fuente abierta: no (solo extracto) · Grupo: `ceuta_vacaciones`

**56:07 · Un informe policial en la Audiencia Nacional describe un guiado activo de fuerzas marroquíes.** (hecho)

- Cita literal: «Hay un informe policial de la Audiencia Nacional que describe un guiado activo de fuerzas de orden marroquí hacia puntos de entrada.»
- Qué dicen las fuentes: El informe del centro de inmigración y fronteras de la Policía Nacional (CENIF), remitido a la jueza Tardón de la Audiencia Nacional, habla de «guiado activo» de los flujos hacia los puntos de paso por fuerzas de seguridad marroquíes y de una entrada «planificada». El informe es de la Policía, no de la Audiencia; Interior discutió esa lectura.
- Fuentes: <https://www.diariodeleon.es/nacional/260902/2096051/informe-policia-cuestiona-fuerzas-marruecos-apunta-guiado-activo-migrantes-ceuta-planificacion_amp.html> · <https://rtvc.es/el-informe-de-la-policia-nacional-sobre-ceuta-habla-de-entrada-planificada-de-personas-3-septiembre-2026/> · <https://www.vozpopuli.com/tribunales/el-informe-concluye-que-marruecos-fomento-impulso-y-dirigio-un-flujo-masivo-de-personas-a-la-frontera-de-ceuta.html>
- Fuente abierta: no (solo extracto)

**58:02 · Pedro Sánchez envió una carta al rey de Marruecos.** (hecho)

- Cita literal: «Y la carta famosa de Pedro Sánchez al rey de Marruecos.»
- Qué dicen las fuentes: Carta de Sánchez a Mohamed VI de 14-3-2022, difundida por la Casa Real marroquí el 18 de marzo: considera el plan de autonomía «la base más seria, creíble y realista».
- Fuentes: <https://maldita.es/malditahemeroteca/20220323/psoe-sahara-referendum-autonomia-marruecos/> · <https://www.elindependiente.com/espana/2022/03/23/la-moncloa-filtra-la-carta-de-sanchez-a-mohamed-vi-cinco-dias-despues-de-divulgarla-la-casa-real-marroqui/amp/>
- Fuente abierta: no (solo extracto)

**58:31 · Marruecos entró en la candidatura del Mundial, quiere la final y construye un estadio.** (hecho)

- Cita literal: «entra Marruecos y ahora quiere hacer la final y está construyendo un estadio,»
- Qué dicen las fuentes: Marruecos coorganiza el Mundial de 2030 y aspira a albergar la final en el estadio Hassan II de Casablanca, frente al Bernabéu. La construcción del estadio no se comprobó en esta búsqueda.
- Fuentes: <https://www.eldebate.com/deportes/futbol/20260731/infantino-acude-aniversario-coronacion-mohamed-vi-mundial-2030-horizonte_445578.html> · <https://www.elespanol.com/espana/20260806/extrema-debilidad-sanchez-permite-infantino-negociar-entrega-marruecos-final-mundial/1003744345140_0.html>
- Fuente abierta: no (solo extracto) · Grupo: `mundial`

**62:50 · Según el CIS, la inmigración es una de las mayores preocupaciones, por detrás de la vivienda.** (hecho)

- Cita literal: «La inmigración, según el CIS, es una de las mayores preocupaciones de los españoles.»
- Qué dicen las fuentes: Mismo dato y mismas fuentes que en la comprobación de Feijóo: en los barómetros del CIS la inmigración figura entre los primeros problemas (tercer puesto en mayo de 2026), por detrás de la vivienda, que supera el 55 % de menciones en octubre de 2026.
- Fuentes: <https://www.infobae.com/espana/2026/05/29/la-dificultad-de-acceso-a-la-vivienda-se-cronifica-marca-record-como-el-problema-que-mas-preocupa-a-los-espanoles/> · <https://www.democrata.es/politica/la-inquietud-por-la-vivienda-se-dispara-18-puntos-y-bate-record-como-principal-problema-al-superar-el-55-de-menciones/>
- Fuente abierta: no (solo extracto)

**67:30 · Aliança Catalana tiene una proyección de voto elevada.** (hecho)

- Cita literal: «Que Alianza Catalana tenga una proyección de votos como la que tiene»
- Qué dicen las fuentes: Barómetro del CEO de julio de 2026: Aliança Catalana pasaría de 2 a 23-25 escaños en el Parlament, superando a Junts y disputando el segundo puesto a ERC.
- Fuentes: <https://www.elindependiente.com/espana/2026/07/09/encuesta-ceo-catalan-alianca-catalana-puigdemont-sorpasso/> · <https://es.ara.cat/politica/encuestas/alianza-catalana-supera-junts-ceo_1_5793561.html>
- Fuente abierta: no (solo extracto)

**79:37 · Según el INE, casi la mitad de los bebés catalanes son de madre nacida fuera.** (cifra)

- Cita literal: «Casi la mitad de los bebés catalanes Son de madre nacida de fuera»
- Qué dicen las fuentes: El 46,3 % de los nacidos en Cataluña en 2025 eran hijos de madre nacida en el extranjero (45,4 % en 2024). La fuente localizada es el Idescat (datos provisionales), no el INE que cita el entrevistador; por nacionalidad de la madre el porcentaje baja al 34,7 %.
- Fuentes: <https://es.ara.cat/sociedad/nacimientos-remontan-cataluna-primera-vez-17-anos_1_5800185.html> · <https://www.diaridetarragona.com/catalunya/265935/nacimientos-crecen-catalunya-primera-vez-2008.html>
- Fuente abierta: sí

**79:51 · Proyección del INE: en 50 años los nacidos en España pasarían de casi el 80 % al 60 % de los residentes.** (cifra)

- Cita literal: «Los nacidos en España pasen del casi 80 % Al 60 %»
- Qué dicen las fuentes: INE, Proyecciones de Población 2026-2076 (17-6-2026): la población nacida en España «pasaría de significar el actual 79,8 % del total, al 59,6 % dentro de 50 años». Es una proyección condicionada a que se mantengan las tendencias, como dice la cita.
- Fuentes: <https://ine.es/dyngs/Prensa/PROP20262076.htm> · <https://ine.es/dyngs/Prensa/PROP20242074.htm>
- Fuente abierta: sí

**86:28 · Barómetro municipal: empezó con un 5,8, bajó a 4,1 en julio de 2022 y acabó con 4,5.** (cifra)

- Cita literal: «Llegaste al punto más bajo en julio de 2022 de 4 ,1 de valoraciones,»
- Qué dicen las fuentes: El 4,1 de julio de 2022 está respaldado (ARA: su peor nota, una décima menos que en la edición anterior) y el 5,8 aparece en una encuesta postelectoral municipal recogida por Betevé (sin fecha en el extracto). No localicé el 4,5 final; en julio de 2024, ya fuera de la Alcaldía, tenía un 4,4.
- Fuentes: <https://es.ara.cat/sociedad/colau-suspende-peor-nota-ganaria-elecciones-barometro_1_4423876.html> · <https://beteve.cat/politica/ada-colau-valoracio-liders-munisipals-ajuntament-enquesta-postelectoral-barometre/>
- Fuente abierta: sí · Grupo: `barometro`

**90:58 · Al inicio del mandato el 30,9 % creía que Barcelona había empeorado.** (cifra)

- Cita literal: «barceloneses, de que Barcelona había empeorado con los años, era un 30 ,9»
- Qué dicen las fuentes: VilaWeb (3-1-2019), con el barómetro semestral municipal: el porcentaje que creía que la ciudad había empeorado pasó del 30,9 % del inicio del mandato al 59,9 %.
- Fuentes: <https://www.vilaweb.cat/noticies/el-60-dels-barcelonins-creu-que-la-ciutat-ha-empitjorat/>
- Fuente abierta: sí · Grupo: `barometro`

**91:07 · En diciembre de 2018 casi el 60 % creía que Barcelona había empeorado.** (cifra)

- Cita literal: «el casi 60 % creía que Barcelona había empeorado»
- Qué dicen las fuentes: Barómetro semestral de diciembre de 2018: el 59,9 % creía que la ciudad había empeorado.
- Fuentes: <https://www.vilaweb.cat/noticies/el-60-dels-barcelonins-creu-que-la-ciutat-ha-empitjorat/>
- Fuente abierta: sí · Grupo: `barometro`

**95:00 · Nueve de cada diez detenidos por hurto en Barcelona en 2024 eran extranjeros (el verificador lo confirma en directo: 91 %, El Mundo).** (cifra)

- Cita literal: «Nueve de cada diez detenciones por hurto en 2024 fueron extranjeros.»
- Qué dicen las fuentes: Datos de los Mossos obtenidos por Maldita.es: 4.942 de los 5.442 detenidos por hurto en Barcelona en 2024 eran extranjeros (90,8 %); Maldita califica la afirmación de verdadera. Es el dato que el verificador del programa lee en directo (91 %); no localicé la publicación de El Mundo que menciona. De la página de Maldita solo se pudo leer el titular; las cifras salen del extracto. Son detenciones, no autores.
- Fuentes: <https://maldita.es/buloteca/claim/El-83-de-los-detenidos-por-robos-con-violencia-y-el-91-por-hurtos-en-Barcelona-son-extranjeros> · <https://www.eldebate.com/espana/cataluna/20250512/80-delitos-registrados-ano-pasado-barcelona-cometieron-extranjeros_296145.html>
- Fuente abierta: no (solo extracto) · Grupo: `hurtos`

**101:16 · Casi la mitad de las viviendas vacías están en municipios de menos de 10.000 habitantes.** (cifra)

- Cita literal: «Pero casi la mitad de esas viviendas están en pueblos de menos de 10 .000 habitantes.»
- Qué dicen las fuentes: INE, Censo de 2021: 3.837.328 viviendas vacías (14,4 % del parque), alrededor del 45 % en municipios de menos de 10.000 habitantes.
- Fuentes: <https://valenciaplaza.com/ine-cifra-numero-viviendas-vacias-mas-de-3-8-millones> · <https://ine.es/prensa/censo_2021_jun.pdf> · <https://www.cronista.com/espana/actualidad-es/revelan-que-hay-casi-4-millones-de-viviendas-vacias-en-el-pais-donde-se-encuentran>
- Fuente abierta: no (solo extracto)

**114:53 · Trump acaba de perder unas elecciones.** (hecho)

- Cita literal: «no defiende la democracia. Acaba de perder unas elecciones.»
- Qué dicen las fuentes: Mismo hecho y mismas fuentes que en la comprobación de Feijóo: en las legislativas del 3-11-2026 los demócratas recuperaron la Cámara de Representantes. Trump no era candidato.
- Fuentes: <https://www.elnuevodia.com/corresponsalias/washington-dc/notas/los-democratas-ganaron-la-camara-baja-y-van-al-frente-en-el-senado-en-medio-de-una-reprimenda-al-presidente-trump/> · <https://lapatilla.com/2026/11/05/democratas-superaron-los-250-escanos-y-consolidaron-su-dominio-de-la-camara-baja/>
- Fuente abierta: no (solo extracto) · Grupo: `midterms`

**116:03 · Portugal pidió a sus activistas que pagaran esos gastos.** (hecho)

- Cita literal: «Portugal pidió a esos activistas que sufragaran ese dinero,»
- Qué dicen las fuentes: El Ministerio de Exteriores portugués comunicó que solo había adelantado los gastos de repatriación de los cuatro participantes portugueses, que debían reembolsarlos. Una sola fuente localizada, más otra sobre peticiones similares de Suiza y Países Bajos.
- Fuentes: <https://portuguesejewishnews.com/news/portuguese-government-requests-reimbursement-of-the-trip-for-the-four-participants-of-the-global-samud-flotilla> · <https://www.nysun.com/article/swiss-dutch-governments-bill-showboating-gaza-flotilla-participants-for-their-rescue-return-home>
- Fuente abierta: no (solo extracto) · Grupo: `flotilla`

**127:08 · La Constitución dice que los impuestos no pueden ser confiscatorios.** (hecho)

- Cita literal: «dice que los impuestos no pueden ser confiscatorios, tienen que ser ecuánimes para todos»
- Qué dicen las fuentes: Artículo 31.1 de la Constitución: sistema tributario justo, inspirado en los principios de igualdad y progresividad, que «en ningún caso tendrá alcance confiscatorio». «Ecuánimes para todos» no es literal: el texto habla de igualdad y progresividad según la capacidad económica.
- Fuentes: <https://sede.agenciatributaria.gob.es/Sede/educacion-civico-tributaria/programa-educacion-civico-tributaria/quien-paga-impuestos/contenidos/derechos-responsabilidades-ciudadanos/generalidad-deber-contribuir.html>
- Fuente abierta: no (solo extracto)

### No he podido comprobarlo (4)

**7:49 · Musk tiene inmigrantes en su consejo de administración y en su entorno.** (hecho)

- Cita literal: «Él tiene en su consejo de administración y gente muy cercana que son inmigrantes.»
- Qué dicen las fuentes: Las fuentes localizadas son antiguas (2017-2023): la presidenta del consejo de Tesla, Robyn Denholm, es australiana, y el japonés Hiromichi Mizuno fue consejero. No comprobé la composición actual del consejo ni lo de la «gente muy cercana».
- Fuentes: <https://alexandramerz.substack.com/p/a-deep-dive-into-teslas-board-of> · <https://fortune.com/2017/07/17/tesla-board-james-murdoch/>
- Fuente abierta: no (solo extracto)

**60:25 · Infantino ha estado de vacaciones con el rey de Marruecos.** (hecho)

- Cita literal: «Infantino es muy amigo del rey de Marruecos, ha estado con él de vacaciones.»
- Qué dicen las fuentes: Las fuentes describen buena relación y visitas oficiales (Infantino acudió en julio de 2026 al aniversario de la entronización de Mohamed VI), pero no localicé ninguna que hable de vacaciones juntos.
- Fuentes: <https://www.eldebate.com/deportes/futbol/20260731/infantino-acude-aniversario-coronacion-mohamed-vi-mundial-2030-horizonte_445578.html>
- Fuente abierta: no (solo extracto) · Grupo: `mundial`

**100:30 · De las 1.600 viviendas, solo 6 fueron expropiaciones.** (cifra)

- Cita literal: «y fueron 6 y el resto lo comprasteis,»
- Qué dicen las fuentes: No localicé el número de expropiaciones. Sí constan la primera expropiación del uso de un piso vacío de un banco y expedientes a 14 propietarios con 194 viviendas.
- Fuentes: <https://www.eldiario.es/catalunya/ayuntamiento-barcelona-expropia-primera-banco_1_1496019.html> · <https://www.merca2.es/2021/07/30/ada-colau-fracaso-alquiler/>
- Fuente abierta: no (solo extracto) · Grupo: `viviendas_1600`

**101:09 · Colau dijo en Onda Cero (3 de noviembre) que España es de los países de Europa con más casas vacías per cápita.** (cita_de_tercero)

- Cita literal: «que decías que éramos uno de los países de Europa con más casas vacías por»
- Qué dicen las fuentes: No localicé la entrevista de Onda Cero del 3 de noviembre ni la frase.
- Fuente abierta: no (solo extracto)

## Páginas abiertas de verdad (38)

- <https://www.vozpopuli.com/espana/politica/la-irrelevancia-fuerza-a-colau-a-superar-su-fiebre-woke-y-regresar-a-la-red-social-de-elon-musk.html>
- <https://www.democrata.es/politica/frente-amplio-destina-1-6-millones-a-su-campana-y-colau-prepara-actos-en-una-decena-de-comunidades/>
- <https://www.articulo14.es/politica/quien-encabeza-frente-amplio-en-el-29n-trayectoria-politica-y-personal-de-ada-colau-20261105.html>
- <https://es.ara.cat/sociedad/desahuciada-vecina-87-anos-madrid-le-exigian-alquiler-1-650-euros_1_5858449.html>
- <https://es.ara.cat/politica/empieza-manifestacion-maricarmen-abascal-quiero-cambien-leyes-injustas-han-permitido-desahucio_1_5861515.amp.html>
- <https://es.ara.cat/politica/operacion-retorno-ada-colau_1_5859191.html>
- <https://www.articulo14.es/politica/pp-vox-y-junts-tumban-los-dos-decretos-de-vivienda-y-asestan-una-dura-derrota-al-gobierno-20261002.html>
- <https://www.esdiario.com/nacional/261005/199417/sanchez-adelanta-elecciones-batacazo-decretos-vivienda-congreso.html>
- <https://www.democrata.es/economia/forbes-ricos-amancio-ortega-botin-iglesias-pino/>
- <https://en.ara.cat/politics/ada-colau-says-that-she-will-only-be-candidate-if-joins-the-broad-front-the-citizenry-is-asking-for-one-ballot_1_5873045.html>
- <https://www.articulo14.es/politica/que-partidos-forman-frente-amplio-integrantes-acuerdos-y-diferencias-con-sumar-20261107.html>
- <https://www.democrata.es/elecciones-generales-espana/mapa-alianzas-izquierda-29n-pactos-candidaturas/>
- <https://www.esdiario.com/nacional/261014/200222/colau-ofrece-cabeza-salvar-izquierda-sigue-ponerse-acuerdo_amp.html>
- <https://www.diaridetarragona.com/espana/273314/frente-amplio-concurriran-separado-catalunya-madrid.html>
- <https://www.elsaltodiario.com/elecciones/montero-asegura-frente-amplio-ha-bloqueado-acuerdos-territoriales-alcanzaron-otros-territorios>
- <https://es.ara.cat/sociedad/barcelona/acaba-via-crucis-judicial-gobierno-colau_1_5313128.html>
- <https://es.ara.cat/politica/saldra-oscar-puente_129_5893607.html>
- <https://www.diaridetarragona.com/espana/274809/dimite-oscar-puente.html>
- <https://www.elsaltodiario.com/politica/frente-amplio-pide-comparecencia-puente-accidente-toledo-adelante-andalucia-dimision>
- <https://www.esdiario.com/nacional/261030/201709/ada-colau-dimision-oscar-puente.html>
- <https://es.ara.cat/sociedad/espana-dedica-mitad-presupuesto-francia-alemania-mantenimiento-alta-velocidad_1_5894680.html>
- <https://elfarodeceuta.es/marlaska-niega-cni-avisara-entrada-masiva-ceuta-confirma-72-000-personas-cruzaron-marruecos/>
- <https://es.ara.cat/politica/gobierno-sanchez-rinde-cuentas-26-dias-despues-crisis-ceuta_1_5831446.html>
- <https://www.lamoncloa.gob.es/serviciosdeprensa/notasprensa/igualdad/Paginas/2026/301026-condena-feminicidio-barcelona.aspx>
- <https://www.moncloa.com/2026/10/24/mujeres-asesinadas-madrid-3453844/>
- <https://es.ara.cat/sociedad/nacimientos-remontan-cataluna-primera-vez-17-anos_1_5800185.html>
- <https://ine.es/dyngs/Prensa/PROP20262076.htm>
- <https://ine.es/dyngs/Prensa/PROP20242074.htm>
- <https://es.ara.cat/sociedad/colau-suspende-peor-nota-ganaria-elecciones-barometro_1_4423876.html>
- <https://www.vilaweb.cat/noticies/el-60-dels-barcelonins-creu-que-la-ciutat-ha-empitjorat/>
- <https://orain.eus/es/politica/2025/11/03/mazon-dimite-presidente-la-generalitat-valenciana/>
- <https://www.democrata.es/politica/feijoo-insiste-en-que-la-subida-de-las-pensiones-con-el-ipc-es-innegociable-y-quiere-cerrar-la-polemica-se-acabo/>
- <https://www.elnacional.cat/es/politica/polemica-pensiones-acorrala-pp-feijoo-rectifica-innegociables-basta_1710037_102.html>
- <https://www.moncloa.com/2026/10/23/feijoo-subir-salario-inflacion-3453948/>
- <https://es.ara.cat/politica/elecciones-generales/feijoo-equivoca-gobierno-espanol-no-hecho-buen-negocio-subida-salario-minimo_1_5888276.html>
- <https://www.eldiario.es/1_cfa93a>
- <https://www.infobae.com/espana/2025/06/20/feijoo-muestra-su-rechazo-a-la-subida-del-smi-y-oscar-puente-responde-y-ya-si-restauramos-la-esclavitud/>
- <https://www.elplural.com/opinion/feijoo-contra-salario-minimo-cobra-mas-140000-quiere-congelar-smi_355025102>

Se abrió además el análisis de ARA sobre el impuesto que propone Colau (<https://es.ara.cat/politica/nuevo-impuesto-propone-ada-colau-alto-pagan-ricos_1_5903002.html>), que no contenía el dato buscado sobre Florentino Pérez.
