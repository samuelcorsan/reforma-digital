# Análisis técnico de la entrevista de Jordi Wild a Ada Colau: entrevistado y entrevistador

*Documento descriptivo y medible. Describe qué hace cada persona y cuándo. No atribuye intenciones, rasgos de personalidad ni diagnósticos, y ninguna medida de este documento (pausas, voz, unidades de acción) sirve para saber si alguien dice la verdad. La expresión facial se informa solo en unidades de acción (AU) del sistema FACS, sin etiquetas de emoción. El entrevistado y el entrevistador se analizan **por separado**, cada uno frente a su propia línea base, y después se comparan. Las frases que comparan a los dos se generan a partir de las cifras, con el criterio indicado en cada una.*

## 1. Ficha de la entrevista

| Campo | Valor |
|---|---|
| Medio | YouTube · The Wild Project |
| Título | «The Wild Project #391 - Ada Colau \| Inmigración masiva, Críticas a su alcaldía, Israel y flotilla» |
| Fecha | 13/11/2026 |
| Duración del vídeo | 2 h 14 min 12 s (8052 s) |
| Parte analizada | transcripción y hablantes: todo el vídeo. Todas las medidas de este informe: desde el inicio de la entrevista (1:23) hasta su final (134:11), según `hablantes.json` |
| Personas analizadas | **entrevistado** (Ada Colau) y **entrevistador** (Jordi Wild) |
| Enlace | https://www.youtube.com/watch?v=-ESmAhdixfo |
| Formato | Entrevista larga en estudio, sin público, dos personas sentadas frente a frente; forma parte de una serie con los candidatos a la presidencia; los primeros 1:23 son una introducción común a las tres entrevistas y quedan fuera de las medidas |

Todos los minutos son tiempo del vídeo (m:ss).

## 2. Comparativa entre entrevistado y entrevistador

Las mismas medidas para las dos personas, en el mismo vídeo y con el mismo audio. La **d de Cohen** indica el tamaño de la diferencia (alrededor de 0,2 pequeña, 0,5 media, 0,8 o más grande); con cientos de frases, casi cualquier diferencia sería estadísticamente significativa, así que se informa el tamaño y no un valor p. En las frases de esta sección, una diferencia con |d| menor de 0,2 se da como inapreciable.

### 2.1 Reparto del habla

| Medida | Entrevistado | Entrevistador |
|---|---|---|
| palabras verificadas | 14693 | 8356 |
| % de las palabras verificadas de ambos | 63.7 | 36.3 |
| tiempo de habla verificado (min) | 70.4 | 39.7 |
| turnos verificados | 371 | 302 |
| mediana de palabras por turno | 27.0 | 19.0 |
| turno más largo (s) | 62.6 | 38.0 |
| veces que toma la palabra tras el otro | 96 | 101 |
| latencia mediana al tomar la palabra (s) | 0.18 | 0.04 |
| % de tomas de palabra con hueco < 0,2 s | 54.0 | 77.0 |

La mayor parte de las palabras verificadas son del entrevistado (63,7 % frente a 36,3 %). El 54 % de las veces que el entrevistado toma la palabra y el 77 % de las del entrevistador se producen con menos de 0,2 s de hueco: más de la mitad en ambos sentidos, es decir, habla encadenada o solapada con frecuencia. La medida no distingue quién interrumpe a quién.

### 2.2 Voz

| Medida | Entrevistado | Entrevistador | Tamaño de la diferencia |
|---|---|---|---|
| tono F0 medio (Hz) | 164.0 | 131.0 | d de Cohen entrevistado−entrevistador = +2.11 |
| variación de tono dentro de la frase (semitonos, sd) | 3.19 | 3.55 | d de Cohen entrevistado−entrevistador = -0.41 |
| rango de tono dentro de la frase (semitonos, p5–p95) | 10.3 | 11.4 | d de Cohen entrevistado−entrevistador = -0.35 |
| intensidad media (dB relativos) | 69.7 | 69.5 | d de Cohen entrevistado−entrevistador = +0.04 |
| variación de intensidad dentro de la frase (dB, sd) | 13.0 | 13.4 | d de Cohen entrevistado−entrevistador = -0.07 |
| velocidad (palabras/min) | 224.0 | 234.0 | d de Cohen entrevistado−entrevistador = -0.17 |
| frases medidas | 700 | 532 |  |
| desviación del tono entre frases (Hz, sd) | 15.2 | 17.0 |  |
| desviación de la velocidad entre frases (palabras/min, sd) | 52.0 | 63.0 |  |
| % de frases con cambio claro de tono (\|z\| ≥ 1,5 respecto a su propia media) | 12.3 | 10.9 | sube/baja: entrevistado 55/31 · entrevistador 43/15 |
| % de frases con cambio claro de volumen (\|z\| ≥ 1,5 respecto a su propia media) | 9.4 | 7.1 | sube/baja: entrevistado 10/56 · entrevistador 0/38 |
| % de frases con cambio claro de velocidad (\|z\| ≥ 1,5 respecto a su propia media) | 13.9 | 12.2 | sube/baja: entrevistado 52/45 · entrevistador 44/21 |

- **Tono.** 164 Hz en el entrevistado y 131 Hz en el entrevistador (d = +2,11: diferencia grande, mayor en el entrevistado). El tono medio refleja sobre todo la voz de cada persona, no una conducta.
- **Variación de tono dentro de la frase.** 3,19 semitonos en el entrevistado y 3,55 semitonos en el entrevistador (d = -0,41: diferencia pequeña, mayor en el entrevistador). Frases con el tono claramente fuera de la propia media (|z| ≥ 1,5): en el entrevistado 55 suben y 31 bajan; en el entrevistador 43 suben y 15 bajan.
- **Intensidad.** 69,7 dB en el entrevistado y 69,5 dB en el entrevistador (d = +0,04, |d| < 0,2: diferencia inapreciable). La intensidad depende del micrófono y de la mezcla, así que una diferencia entre los dos no se puede atribuir a la forma de hablar.
- **Velocidad.** 224 palabras/min en el entrevistado y 234 palabras/min en el entrevistador (d = -0,17, |d| < 0,2: diferencia inapreciable). Se mide solo en tramos de habla continua, sin pausas, por lo que las cifras son más altas que una velocidad media de conversación.

![voz](grafica_comparativa_voz.png)

![tono](grafica_tono.png)
![volumen](grafica_volumen.png)
![velocidad](grafica_velocidad.png)

### 2.3 Pausas

| Medida | Entrevistado | Entrevistador |
|---|---|---|
| pausas > 0,4 s | 105 | 87 |
| pausas por 1000 palabras | 7.1 | 10.4 |
| duración media (s) | 0.76 | 0.81 |
| duración mediana (s) | 0.64 | 0.7 |
| pausas de 1 s o más | 19 | 23 |
| pausa máxima (s) | 2.5 | 2.3 |
| pausas antes de frase con carga | 20 | 23 |
| % confirmadas por silencedetect | 4.0 | 7.0 |

El entrevistador hace más pausas por cada 1000 palabras (10,4 frente a 7,1). Las del entrevistador son más largas de media (0,81 s frente a 0,76 s). De 1 s o más: 19 del entrevistado y 23 del entrevistador. `silencedetect` confirma como silencio el 4 % de los huecos del entrevistado y el 7 % de los del entrevistador. Donde ese porcentaje no llega a la mitad, la mayoría de los huecos no son silencio para `ffmpeg`: pueden contener voz de la otra persona, risas, música o ruido (no se ha comprobado uno a uno).

### 2.4 Texto: pronombres, preguntas y patrones

| Medida | Entrevistado | Entrevistador | Nota |
|---|---|---|---|
| pronombre «yo» por 1000 palabras | 10.8 | 8.3 | recuento: entrevistado 158 · entrevistador 71 |
| pronombre «nosotros» por 1000 palabras | 1.6 | 0.1 | recuento: entrevistado 23 · entrevistador 1 |
| pronombre «tú» por 1000 palabras | 1.9 | 8.8 | recuento: entrevistado 28 · entrevistador 75 |
| pronombre «vosotros» por 1000 palabras | 0.0 | 1.2 | recuento: entrevistado 0 · entrevistador 10 |
| pronombre «ellos» por 1000 palabras | 0.3 | 0.6 | recuento: entrevistado 5 · entrevistador 5 |
| frases interrogativas | 32 | 107 | de las frases verificadas: entrevistado 674 · entrevistador 536 |
| contrastes «no X, sino Y» | 14 | 0 | detección automática sin revisar |
| listas de tres (candidatas) | 2 | 4 | detección automática sin revisar |
| preguntas seguidas por el mismo hablante (candidatas a retóricas) | 25 | 57 | detección automática sin revisar |
| frases con léxico de pérdida o riesgo | 14 | 5 | detección automática sin revisar |
| frases con léxico de logro o ganancia | 31 | 5 | detección automática sin revisar |
| relatos o personas concretas (candidatos) | 23 | 4 | detección automática sin revisar |

Lectura generada a partir de la tabla (por 1000 palabras verificadas de cada uno; «parecida» = menos de un 20 % de diferencia; por debajo de 1 por 1000 en los dos no se compara):

- «yo» explícito: más frecuente en el entrevistado (10,8 frente a 8,3).
- «nosotros» explícito: más frecuente en el entrevistado (1,6 frente a 0,1).
- «tú» explícito: más frecuente en el entrevistador (8,8 frente a 1,9).
- «vosotros» explícito: más frecuente en el entrevistador (1,2 frente a 0,0).
- «ellos» explícito: apenas aparece en ninguno de los dos (0,3 y 0,6).
- Frases interrogativas: más frecuente en el entrevistador (12,5 frente a 2,2).
- Frases con léxico de pérdida o riesgo: apenas aparece en ninguno de los dos (1,0 y 0,6).
- Frases con léxico de logro o ganancia: más frecuente en el entrevistado (2,1 frente a 0,6).
- Relatos o personas concretas (candidatos): más frecuente en el entrevistado (1,6 frente a 0,5).

Son recuentos automáticos por patrones, sin revisar uno a uno.

### 2.5 Cara: unidades de acción y postura

| Medida | Entrevistado | Entrevistador |
|---|---|---|
| % de fotogramas muestreados con su cara | 63.0 | 45.0 |
| fotogramas con su cara mientras habla / mientras habla el otro | 19705 / 1780 | 10555 / 3969 |
| giro de cabeza: media (grados) | 43.4 | -37.8 |
| giro de cabeza: variabilidad (sd, grados) | 21.2 | 24.6 |
| cabeceo: media (grados) | -13.9 | -9.2 |
| cabeceo: variabilidad (sd, grados) | 58.6 | 25.6 |
| inclinación: media (grados) | -4.6 | -4.5 |
| inclinación: variabilidad (sd, grados) | 58.2 | 25.3 |
| ventanas de 6 s con alguna AU fuera de lo habitual (\|z\| ≥ 2 respecto a su propia línea base), % | 25.6 | 26.6 |

**Nivel medio de cada AU (0–1, sin calibrar)**

| AU | Entrevistado | Entrevistador | Tamaño de la diferencia |
|---|---|---|---|
| AU1 cejas: parte interna arriba | 0.554 | 0.442 | d (ventanas de 6 s) = +1.74 |
| AU2 cejas: parte externa arriba | 0.35 | 0.267 | d (ventanas de 6 s) = +1.01 |
| AU4 cejas bajan y se juntan | 0.292 | 0.413 | d (ventanas de 6 s) = -1.36 |
| AU5 párpado superior arriba | 0.384 | 0.352 | d (ventanas de 6 s) = +0.76 |
| AU6 mejillas elevadas | 0.138 | 0.16 | d (ventanas de 6 s) = -0.43 |
| AU7 párpados tensos | 0.044 | 0.054 | d (ventanas de 6 s) = -0.18 |
| AU12 comisura labios arriba | 0.128 | 0.086 | d (ventanas de 6 s) = +0.61 |
| AU14 hoyuelo comisura | 0.376 | 0.41 | d (ventanas de 6 s) = -0.34 |
| AU15 comisura labios abajo | 0.354 | 0.55 | d (ventanas de 6 s) = -2.68 |
| AU17 mentón arriba | 0.503 | 0.344 | d (ventanas de 6 s) = +5.74 |
| AU23 labios apretados | 0.477 | 0.659 | d (ventanas de 6 s) = -2.94 |
| AU24 labios presionados | 0.508 | 0.494 | d (ventanas de 6 s) = +0.21 |
| AU25 labios separados (habla) | 0.429 | 0.528 |  |
| AU26 mandíbula baja (habla) | 0.311 | 0.407 |  |
| AU43 ojos cerrados | 0.233 | 0.279 |  |

**Cambio de cada AU al hablar respecto a cuando habla el otro (misma persona)**

| AU | Entrevistado | Entrevistador |
|---|---|---|
| AU1 cejas: parte interna arriba | -0.002 | -0.020 |
| AU2 cejas: parte externa arriba | -0.047 | +0.028 |
| AU4 cejas bajan y se juntan | -0.096 | -0.033 |
| AU5 párpado superior arriba | -0.018 | +0.011 |
| AU6 mejillas elevadas | -0.015 | +0.047 |
| AU7 párpados tensos | -0.032 | +0.008 |
| AU12 comisura labios arriba | -0.007 | +0.040 |
| AU14 hoyuelo comisura | +0.071 | +0.027 |
| AU15 comisura labios abajo | -0.087 | -0.062 |
| AU17 mentón arriba | -0.008 | +0.003 |
| AU23 labios apretados | -0.071 | -0.008 |
| AU24 labios presionados | +0.022 | -0.045 |

- **Niveles absolutos.** Con diferencia grande (|d| ≥ 0,8, en ventanas de 6 s), el modelo da valores más altos al entrevistado en AU17, AU1, AU2 y al entrevistador en AU23, AU15, AU4. **Estas diferencias no se pueden leer como diferencias de expresión**: py-feat no está calibrado por persona, y la forma de la cara, el vello facial, las gafas, el ángulo de cámara (giro medio de cabeza: +43° el entrevistado y -38° el entrevistador) y la iluminación desplazan la línea base de cada cara. Son, en el mejor de los casos, rasgos de cómo el modelo ve cada rostro.
- **Dentro de cada persona** (más fiable). Los tres mayores cambios al hablar respecto a cuando habla el otro: en el entrevistado, AU4 -0,096; AU15 -0,087; AU14 +0,071; en el entrevistador, AU15 -0,062; AU6 +0,047; AU24 -0,045. El habla mueve la boca y contamina estas medidas (ver limitaciones). Fotogramas con su cara mientras habla el otro: 1780 del entrevistado y 3969 del entrevistador.
- **Frecuencia de desviaciones.** La proporción de ventanas de 6 s con alguna AU fuera de lo habitual es parecida (25,6 % el entrevistado y 26,6 % el entrevistador; menos de 5 puntos de diferencia). Cada uno se compara consigo mismo; no indica qué significa cada desviación.
- **Presencia en pantalla.** La cara del entrevistado se detecta en el 63 % de los fotogramas muestreados y la del entrevistador en el 45 %: la del entrevistado aparece 1,4 veces más. Depende de la realización (a quién enfoca la cámara).

![AU comparativa](grafica_comparativa_AU.png)

![AU](grafica_AU.png)

## 3. El entrevistado, por separado

### Pausas

- **105** huecos de más de 0,4 s entre palabras verificadas consecutivas. Duración media **0,76 s**, mediana 0,64 s, máxima 2.5 s. 19 duran 1 s o más y 1 duran 2 s o más.
- **20** van justo antes de una frase con carga: contraste (12), mencion politica (5), cifra (3).
- `ffmpeg silencedetect` confirma el 4%.
- Las cinco más largas: 58:46 (2.5 s, antes de «Barça y Martínenc porque mi hijo pequeño…»); 63:50 (1.9 s, antes de «Otra cosa es que luego puedan haber…»); 30:06 (1.7 s, antes de «Lo que también sé es que en…»); 9:23 (1.6 s, antes de «A mí estos años me ha ido…»); 68:31 (1.5 s, antes de «Aquí conozco de cerca, porque al ser…»).

### Voz

- 700 frases medidas. Tono (F0) medio **164 Hz** (desviación entre frases 15 Hz; variación dentro de la frase 3,19 semitonos).
- Intensidad media 69.7 dB (relativa). Velocidad media **224 palabras/min** (mediana 222).
- Cambios claros respecto a su propia media (|z| ≥ 1,5): tono sube 55 / baja 31; volumen sube 10 / baja 56; velocidad sube 52 / baja 45 (frases).
- Las tres frases con el tono más alto respecto a su media: 128:06 (z = +3.7) «Yo es que creo que las noticias enseñan siempre lo malo y yo conozco…»; 36:05 (z = +3.7) «Con esto ser muy exigente.…»; 77:10 (z = +3.4) «Pues hay que trabajar por eso y que todo el mundo cumpla.…».

### Respuestas a las preguntas clasificadas

Se detectaron automáticamente 97 pares pregunta-respuesta (intervenciones del entrevistador con «?» seguidas de habla del entrevistado). La clasificación de las respuestas se hace aparte, a mano, leyendo la transcripción (`clase_respuestas.json`); aquí entran las **71** cuya cita se ha validado como literal. Distribución: **responde**: 43, **otra_pregunta**: 14, **en_parte**: 12, **sin_respuesta**: 2.

| Minuto de la respuesta | Clasificación | Cita literal de la respuesta | Pregunta |
|---|---|---|---|
| 7:02 | en_parte | «las redes sociales hoy mayoritariamente están en manos de grandes corporaciones» | Es decir, al final es el mismo perro con diferente collar, ¿verdad? ¿Y por qué si una y otra no? |
| 7:19 | responde | «Al dinero sobre todo, pero Elon Musk, ¿te acuerdas que hizo el saludo nazi?» | Yo no creo que sean a la extrema derecha, creo que son al dinero. |
| 10:57 | responde | «Claro, pero yo te digo, cuando dije eso era 100 % sincera.» | A mí estas cosas me descuadran un poco, ¿sabes? Cuando veo estos cambios. |
| 13:40 | en_parte | «sobre la cuestión de fondo, yo no he cambiado de opinión en ningún momento» | ¿quién promete que una de vuestras promesas electorales no cambiéis de opinión en un año? |
| 16:59 | otra_pregunta | «No está Podemos ni tampoco está Gabriel Rufián.» | Podemos no está. ¿Por qué estás tú entonces? |
| 19:22 | en_parte | «los mismos argumentos que daban en público nos los daban en privado» | Vale, pero yo te pregunto a ti, ¿qué os dijeron para decir no queremos hablar con vosotros? |
| 21:07 | en_parte | «son las formaciones políticas las que lo decidían. Me parece bien que se hagan primarias.» | Si hubiera habido tiempo, ¿hubierais hecho primarias? |
| 21:13 | en_parte | «Lo que pasa es que para hacer primarias las formaciones políticas se tienen que sentar» | O sea, si fuera por ti hubierais hecho primarias. |
| 23:21 | otra_pregunta | «tanto yo personalmente en mis redes como Sumar manifestamos tolerancia cero a la corrupción» | ¿hubieras sacado a tu coalición de este gobierno cuando salta lo de Ábalos y Cerdán? |
| 24:59 | otra_pregunta | «por nuestro espacio podemos responder que tenemos cero casos de corrupción» | Ganáis las elecciones, PSOE y Frente os tenéis gobierno, pasa algo similar. ¿Tú qué harías? |
| 27:06 | otra_pregunta | «Yo te puedo decir que tolerancia cero con la corrupción y lo he demostrado siempre.» | Pero eso es lo que la gente de The World Project quiere escuchar, que os mojéis. |
| 27:11 | en_parte | «Habría, o no me habría ido, o habría puesto más exigencias a lo mejor.» | ¿Tú hubieras ido? |
| 30:02 | responde | «no tengo ningún indicio de que sea culpable, no sé, lo están investigando» | ¿Crees entonces que lo de Zapatero tiene pinta de ser loafer? |
| 32:19 | otra_pregunta | «llevábamos décadas gobernados por PP, por PSOE y ambos partidos tenían malas praxis,» | verte en un socio que no es honesto, quiero saber qué pasaría ahí. |
| 33:25 | responde | «Claro, pero para cambiar las cosas tienes que entrar.» | ¿Por qué te quieres juntar con ellos? Si es que tú misma estás diciendo que... |
| 33:40 | responde | «A ver, no es que quiera ser su amiga, ni de unos ni de otros,» | Para mí es amoral. Para ti también, supongo, ¿no? |
| 35:04 | responde | «Si somos decisivos para que haya un gobierno progresista, podemos poner condiciones.» | ¿Eso es darles esa facilidad para tener ese poder? |
| 35:53 | responde | «Tengo que negociar bien aprendiendo de la experiencia, efectivamente, no fiándome,» | Y no hay otra que sería decir, pues no voy a… ¿Sabes qué? Pues que os jodéis. |
| 37:18 | responde | «que no dimitiera porque el problema venía de desinversiones de muchos años antes» | Primero sí o no y luego me justificas. |
| 37:43 | responde | «O sea, el Ministerio tenía toda la responsabilidad de revisar todo,» | ¿no crees que algo de responsabilidad sí tenía el Ministerio? |
| 39:16 | otra_pregunta | «un modelo que desgraciadamente han compartido PP y PSOE, que es el de liberalizar» | A lo mejor, entonces, ¿quién tendría que haber dimitido? ¿Es Pedro Sánchez? |
| 39:38 | responde | «Sí, pero ha habido un proceso de liberalización donde se ha abierto a otras operadoras» | la que tiene que ser encargada de vigilar el estado de las vías, por ejemplo? |
| 40:13 | responde | «desde hace un montón de años que es una vergüenza Todo esto es un problema» | Entonces, al final, esto es cosa pública, no es cosa privada. |
| 40:54 | sin_respuesta | «nan» | ¿Debería entonces dimitir Pedro Sánchez cuando hay un accidente mortal donde decenas de personas fallecen en un tren? |
| 41:01 | otra_pregunta | «Primero tienes que investigar. Si no sabes qué ha pasado, hasta que no tienes una» | ¿Y qué responsabilidades asumieron? |
| 41:29 | responde | «venimos de un modelo que es este que se llama de liberalización, donde se separó» | ¿Y cómo puede ser con la tecnología de hoy en día que estemos un año después sin saber por qué hubo un accidente? |
| 45:14 | responde | «política la asuma quien tiene la responsabilidad de ese tema concreto, de esa cartera,» | ¿Te hubiera parecido descabellado que hubiera dimitido? |
| 48:32 | responde | «creo que hay una responsabilidad indirecta de la Unión Europea porque ha decidido externalizar sus» | ¿Quién crees que es el responsable? |
| 50:51 | responde | «la primera respuesta que se dio por parte del gobierno y en concreto desde la» | ¿Qué te pareció que el presidente se fuera de vacaciones durante la crisis? |
| 51:43 | responde | «Yo ahí, sinceramente, no entendía lo que estaba pasando y por qué no se estaba» | Cuando ves que se va de vacaciones, ¿te indignas como ciudadana? |
| 60:01 | responde | «me gustaría revisar que esa final efectivamente se haga en Marruecos si no se dan» | ¿Tú colaborarías con un país que no respeta los derechos humanos? |
| 60:28 | otra_pregunta | «unas relaciones que son muchas más fuertes que la que pueda tener» | ¿permitirías que en la final del Mundial sean marruecos? |
| 61:56 | responde | «Yo revisaría las relaciones siempre con el enfoque de avanzar en la garantía de derechos» | si tú eres presidenta, ¿Qué harías con Marruecos? Es decir, ¿endurecerías las relaciones? |
| 62:14 | en_parte | «sería imprudente que yo ahora te diga acciones concretas sin estar en el gobierno» | ¿Y eso a nivel práctico en qué se traduce? |
| 75:22 | responde | «De acuerdo, sí, sí, hay discriminaciones que se hacen a la mujer en Marruecos que» | ¿Te imaginas una reina o te imaginas en Marruecos? |
| 75:48 | en_parte | «la sociedad es plural, no es una única. Yo te digo, aquí en España sufrimos» | Te digo Marruecos y te podría decir muchos países árabes donde el |
| 87:11 | responde | «también hay una cosa muy objetiva que le pasa a cualquier político, que gestionar desgasta» | Sí, pero cuando entras tienes casi un seis. Algo ha pasado. |
| 88:14 | otra_pregunta | «creo que es justo decirlo, hubo una campaña de desprestigio increíble» | ¿Cuál es el gran error que cometiste? |
| 94:37 | responde | «desde que si te han robado a ti el móvil o le han robado a» | ¿Y por qué crees entonces estas valoraciones negativas y esta percepción negativa? |
| 94:47 | responde | «eso cómo se resuelve con juzgados que hagan juicios rápidos» | La reincidencia es uno de los grandes problemas. de Barcelona. |
| 95:13 | otra_pregunta | «es que yo recuerdo los datos, claro, no sé si eso ¿Qué fuente es ese» | Nueve de cada diez detenciones por hurto en 2024 fueron extranjeros. |
| 96:25 | responde | «no me acuerdo del porcentaje exacto, pero sé que la mayoría eran de nacionalidad española,» | ¿Y qué porcentaje había en ese momento? |
| 96:56 | otra_pregunta | «lo importante no es dónde se ha nacido, lo importante es que si alguien la» | está habiendo una degeneración en los años y no rema a favor de lo que comentabas |
| 99:15 | responde | «Si la ponen a un alquiler asequible, no.» | ¿tú prohibirías la compra incluso por parte de familias de casas para |
| 100:10 | responde | «Ese precio se marca a través de los índices que se tienen por parte del» | ¿Y quién lo marcaría ese precio? |
| 100:19 | otra_pregunta | «En Barcelona, nosotros, por ejemplo, compramos 1 .600 viviendas a precio inferior» | ¿Y eso en nuestra Constitución está estipulado? |
| 100:36 | responde | «Se llama tanteo y retracto. Es decir, es una normativa que hicimos nosotros.» | pero no es exactamente lo mismo expropiar que comprar barato |
| 101:40 | en_parte | «La solución no es la expulsión, para nada.» | ¿qué le ofreces a un chaval que vive en Madrid o en Barcelona? |
| 102:33 | responde | «hay diferentes maneras de recuperar esas viviendas, por ejemplo, las que están en manos de» | ¿Con el que vive en Madrid o Barcelona o Sevilla? |
| 104:50 | responde | «teníamos servicios de mediación para buscar una solución y realojar» | Pero ¿y si esa persona no quiere alquilar porque a lo mejor la quiere para su hijo, la quiere para su familia? |
| 105:59 | otra_pregunta | «Creo que lo mejor que te puedo explicar es lo que hicimos en Barcelona.» | tú te comprometes a que en uno o dos meses esa nueva familia se ocupa fuera |
| 106:23 | responde | «De una manera o de otra, un ayuntamiento tiene que poder encontrar una solución.» | ¿Y si no encontrabais esa solución? |
| 107:15 | otra_pregunta | «es expropiar los pisos vacíos que tienen bancos y fondos de inversión» | ¿cuánto tiempo echas a esa persona o a ese narcopiso o a esa gente? |
| 107:38 | responde | «yo creo que el ayuntamiento tiene que hacer un servicio de mediación y en pocas» | ¿Cuánto tiempo en tu España ideal, en la que si tú ganas, en cuánto tiempo echas a los ocupas? |
| 108:14 | en_parte | «de una ocupación delincuencial, para mí tiene que ser lo más rápido posible» | ¿en cuánto tiempo unos delincuentes que ocupen una casa vacía de un pequeño propietario salen de ahí? |
| 109:38 | responde | «pues un impuesto del 10 % del valor de esa vivienda para movilizar, pero no para» | Pero una persona que tenga cinco pisos y dice, no, es que yo no quiero, por lo que sea, les |
| 112:06 | responde | «nosotros te garantizamos que cobras el alquiler aunque la persona no» | pero ¿quién paga mientras tanto el alquiler? |
| 114:05 | responde | «Sería cerrarlas, sobre todo con un señor tan peligroso que está provocando guerras por todo» | Pero tu idea sería cerrarlas. |
| 114:45 | en_parte | «Yo soy partidaria de tener buenas relaciones con todos los países que defiendan la democracia,» | Y si Trump en dos años cae, ¿volverías a reabrir las bases? |
| 114:57 | responde | «Yo creo que respeta la democracia formal porque no le queda más remedio.» | no defiende la democracia. Acaba de perder unas elecciones. |
| 118:00 | responde | «Yo creo que fue un elemento más importante, no el único.» | No hubiera pasado sin la flotilla, ¿crees? |
| 119:28 | responde | «Yo creo que el genocidio ha seguido, desgraciadamente, pero creo que bajó la intensidad» | ¿Creéis que Israel ha cambiado algún tipo de política |
| 120:08 | responde | «El PSOE al principio era pro -Israel y ahora mismo es de los gobiernos que» | La ciudadanía es una cosa, pero los gobiernos siguen trabajando con Israel, |
| 120:16 | sin_respuesta | «nan» | lo de Israel es muy mediático pero si empezáramos a observar acuerdos comerciales con países que están metidos en guerras civiles |
| 123:37 | responde | «a mí sí, me parece que te convierte en un fascista, estás poniendo en peligro» | ¿Pero decir eso te convierte en un fascista actual? |
| 123:51 | responde | «Tienes razón que hay que ser cuidadoso con el lenguaje y que no hay que» | ¿Crees que hemos banalizado la palabra fascista por eso que usamos facha ya como una especie de adjetivo rápido |
| 126:20 | responde | «que a lo mejor a veces soy demasiado vehemente» | ¿Qué crítica hacia ti te molesta porque sabes que tiene algo de verdad? |
| 128:28 | responde | «yo creo que la mayoría de la gente es buena, sinceramente» | Creo que eres demasiado idealista. Creo que yo tengo una visión más cínica del mundo, más mala. |
| 129:22 | en_parte | «A ver, intentaría no llevarlo a personal en general,» | que es que sería casi las antípodas de tus rivales. ¿Crees que eres mejor persona? |
| 129:31 | responde | «Y yo desde luego me esfuerzo por no ser cruel en el día a día» | Hombre, le has llamado cruel. |
| 129:43 | responde | «No, lo he escuchado, lo he escuchado y da miedo con muchas de las afirmaciones» | ¿Te arrepientes de lo que has dicho? |

Criterio de cada clase: «responde»: contesta a lo preguntado, aunque sea con matices; «otra_pregunta»: habla del tema pero contesta a una pregunta distinta de la formulada; «en_parte»: contesta una parte y deja otra sin contestar; «sin_respuesta»: el entrevistador sigue hablando o cambia sin dejar contestar. Se clasifica la respuesta inmediata. La clasificación procede de una sola lectura, sin segundo codificador que la contraste; describe si el texto de la respuesta aborda lo preguntado, no por qué.

### Pronombres explícitos

| yo | nosotros/as | tú | vosotros/as | ellos/as |
|---|---|---|---|---|
| 158 | 23 | 28 | 0 | 5 |

A quién se refiere «ellos/ellas» (columna «Referente»: lectura manual del contexto si existe `ref_ellos.json`; «sin clasificar» = no se ha leído; «incierto» = no se puede asegurar):

| Minuto | Referente | Contexto |
|---|---|---|
| 39:08 | sin clasificar | …con los trabajadores porque creo que era muy importante escucharles directamente y ellos llevaban avisando tiempo ellos mismos dicen que… |
| 39:10 | sin clasificar | …creo que era muy importante escucharles directamente y ellos llevaban avisando tiempo ellos mismos dicen que el problema viene de… |
| 49:58 | sin clasificar | …se mueven sin que se dé cuenta el gobierno de marruecos claro ellos lo que están diciendo es que habían… |
| 71:32 | sin clasificar | …que por ejemplo son magrebis que no solo no tienes problemas con ellos sino que además ellos también tienen problemas… |
| 71:33 | sin clasificar | …magrebis que no solo no tienes problemas con ellos sino que además ellos también tienen problemas cuando hay problemas de… |

### Repeticiones principales

| Expresión | Veces | Primer minuto |
|---|---|---|
| mucha gente | 14 | 4:02 |
| creo que es | 14 | 4:05 |
| en ese momento | 7 | 5:06 |
| muchas cosas | 10 | 6:15 |
| hay mucha gente | 7 | 8:18 |
| creo que hay | 8 | 8:25 |
| en el gobierno | 7 | 9:09 |
| tema de la | 8 | 13:14 |
| creo que la | 8 | 14:21 |
| de la gente | 13 | 14:41 |
| a final de mes | 5 | 15:45 |
| derechos humanos | 12 | 53:32 |
| para que la gente | 6 | 55:16 |
| ahora mismo | 10 | 57:14 |
| los derechos humanos | 7 | 57:35 |
| nacido aquí | 11 | 69:52 |
| a los pequeños propietarios | 5 | 98:24 |
| un pequeño propietario | 10 | 98:30 |
| pequeño propietario | 14 | 98:30 |
| de un pequeño propietario | 5 | 104:24 |

La lista es automática y puede mezclar muletillas con términos del tema.

### Otras técnicas detectadas en el texto (candidatas)

**Contrastes «no X, sino Y»: 14** (primeros 5)

- 8:15 «bueno, para hacer una buena política tranquila no sería mi lugar ideal, pero como hoy hay mucha gente que se conecta a la realidad, no por los medios convencionales, sino por las redes, pues creo que »
- 23:40 «Y aparte de apartar a esas personas es si se probara que en algún momento no solo son personas concretas sino que afectan al partido, ¿no?»
- 23:47 «O sea que no son personas concretas que han hecho corrupción sino que es el partido el que ha hecho corrupción.»
- 24:30 «En política lo que decíamos, la palabra es muy importante, el ejemplo concreto de no solo palabras sino hechos es fundamental.»
- 39:10 «Ellos mismos dicen que el problema viene de muchos años atrás, no solo de desinversiones, sino de un modelo que desgraciadamente han compartido PP y PSOE, que es el de liberalizar y, por ejemplo, que »

**Léxico de pérdida o riesgo: 14** (primeros 5)

- 5:05 «que hacer y en ese momento ya Twitter estaba polarizando mucho la política o sea el algoritmo premiaba mucho la polarización entonces yo notaba que Twitter aparte de los insultos, las amenazas el disc»
- 5:20 «pero es que además me hacía perder tiempo, o sea muchas horas de mi tiempo entonces yo como alcaldesa tenía otras cosas que hacer que estar todo el rato respondiendo tweets creo que otra gente está bi»
- 51:56 «Y me sabía peor porque estaba yo de alcaldesa cuando fue la invasión de Rusia en Ucrania, una cosa terrible que nos afectaba mucho a Europa y que nos conmocionó a todos.»
- 56:53 «O sea, tú con un país vecino con el que compartes frontera no puedes romper totalmente relaciones porque estás poniendo en peligro tu país.»
- 92:37 «O sea, en la inseguridad en Barcelona ha tenido unas cifras más o menos estables desde que entramos hasta que salimos.»

**Léxico de logro o ganancia: 31** (primeros 5)

- 4:13 «pues eso, que no se fía de nada y negativo entonces creo que es uno de nuestros trabajos petientes es mejorar eso y»
- 11:48 «ver a una mujer de 87 años que la sacan en camilla de su casa cuando no deja de pagar ni un mes el alquiler, porque un gran propietario quiere subir el precio nos»
- 15:24 «Por ejemplo, yo qué sé, con los últimos gobiernos se ha subido el salario mínimo, ¿no?»
- 19:59 «Yo creo que cada uno tiene que explicar de lo que es responsable y lo que hace y lo que deja de hacer para conseguir un objetivo.»
- 22:25 «Se consiguieron cosas que si no hubieran estado no se habrían conseguido y en ese sentido fue positivo.»

**Listas de tres: 2**

- 52:26 «Ayuntamiento, Generalitat y Estado»
- 104:20 «propietario, íbamos y gestionábamos»

Preguntas seguidas por el mismo hablante (candidatas a retóricas): 25; relatos o personas concretas candidatos: 23 (en `retorica.csv`). Detecciones automáticas **no revisadas una a una**.

### Cara (unidades de acción)

- Su cara se detecta en 25189 de ~39840 fotogramas muestreados a 5 fps (**63%**).
- Valores medios (0–1, sin calibrar a la escala A–E de FACS): AU1 cejas: parte interna arriba 0,55; AU2 cejas: parte externa arriba 0,35; AU4 cejas bajan y se juntan 0,29; AU5 párpado superior arriba 0,38; AU6 mejillas elevadas 0,14; AU7 párpados tensos 0,04; AU12 comisura labios arriba 0,13; AU14 hoyuelo comisura 0,38; AU15 comisura labios abajo 0,35; AU17 mentón arriba 0,50; AU23 labios apretados 0,48; AU24 labios presionados 0,51.
- Máximo de AU12 (comisura de los labios arriba) en la media de 30 s hacia el **2:05** (0,34 frente a una media global de 0,13); AU6 (mejillas elevadas) en ese punto: 0,27 (media 0,14). No se interpreta.
- Cabeza girada de media 43° respecto a la cámara (giro medio +43°), lo que afecta a la fiabilidad de todas las AU.

### Momentos clave del entrevistado

Criterio: se recorre la entrevista en ventanas de ±3 s en las que esa persona está hablando y se cuenta en cuántas **categorías distintas** coinciden señales: voz (cambio de tono, volumen o velocidad con |z| ≥ 1,5 respecto a su propia media; cuentan como una sola categoría), pausa (de 1 s o más, o antes de una frase con carga), pregunta (una respuesta clasificada de la tabla anterior), técnica retórica y AU (alguna AU con |z| ≥ 2 frente a su propia línea base, en ventanas de 6 s). Se toman los que más categorías reúnen (al menos dos), separados al menos 60 s: hasta 15 para el entrevistado y hasta 10 para el entrevistador. **Que dos señales coincidan no demuestra que estén relacionadas**, y de un momento así no se deduce ninguna intención ni estado interno: se listan para poder ir a verlos.

#### Entrevistado · momento 1 · minuto 7:24 · categorías: voz, pregunta, AU

- **Cita literal:** «saludo nazi? A ver, ha manifestado opiniones, digamos,»
- **Qué se mide:** cambio velocidad: baja (z=-2.0); pregunta con respuesta clasificada: responde; AU fuera de lo habitual: AU23 labios apretados z=-2.4; AU14 hoyuelo comisura z=+2.1.
- **Material:** `fotogramas/m01_antes.jpg`, `fotogramas/m01_durante.jpg`, `fotogramas/m01_despues.jpg`; clip con detección facial `clips_cara/m01_7-24.mp4`.

![antes](fotogramas/m01_antes.jpg) ![durante](fotogramas/m01_durante.jpg) ![después](fotogramas/m01_despues.jpg)

#### Entrevistado · momento 2 · minuto 21:07 · categorías: voz, pregunta, AU

- **Cita literal:** «Quiero decir que son las formaciones políticas las que lo decidían. Me parece bien que se hagan primarias.»
- **Qué se mide:** cambio tono: baja (z=-1.6); pregunta con respuesta clasificada: en parte; AU fuera de lo habitual: AU7 párpados tensos z=+2.6; AU2 cejas: parte externa arriba z=+2.3.
- **Material:** `fotogramas/m02_antes.jpg`, `fotogramas/m02_durante.jpg`, `fotogramas/m02_despues.jpg`; clip con detección facial `clips_cara/m02_21-07.mp4`.

![antes](fotogramas/m02_antes.jpg) ![durante](fotogramas/m02_durante.jpg) ![después](fotogramas/m02_despues.jpg)

#### Entrevistado · momento 3 · minuto 24:57 · categorías: voz, pregunta, AU

- **Cita literal:** «tolerancia cero. Hemos puesto todos los mecanismos para que haya tolerancia cero. Así que por nuestro espacio podemos responder que tenemos cero casos de corrupción.»
- **Qué se mide:** cambio tono: sube (z=+1.8); pregunta con respuesta clasificada: otra pregunta; AU fuera de lo habitual: AU1 cejas: parte interna arriba z=-2.2; AU7 párpados tensos z=+2.0.
- **Material:** `fotogramas/m03_antes.jpg`, `fotogramas/m03_durante.jpg`, `fotogramas/m03_despues.jpg`; clip con detección facial `clips_cara/m03_24-57.mp4`.

![antes](fotogramas/m03_antes.jpg) ![durante](fotogramas/m03_durante.jpg) ![después](fotogramas/m03_despues.jpg)

#### Entrevistado · momento 4 · minuto 30:04 · categorías: voz, pausa, pregunta

- **Cita literal:** «no tengo ningún indicio de que sea culpable, no sé, lo están investigando. Lo que también sé es que en el caso de Zapatero»
- **Qué se mide:** pausa larga: 1.7 s; cambio volumen: baja (z=-3.3); cambio velocidad: baja (z=-1.5); pregunta con respuesta clasificada: responde.
- **Material:** `fotogramas/m04_antes.jpg`, `fotogramas/m04_durante.jpg`, `fotogramas/m04_despues.jpg`; clip con detección facial `clips_cara/m04_30-04.mp4`.

![antes](fotogramas/m04_antes.jpg) ![durante](fotogramas/m04_durante.jpg) ![después](fotogramas/m04_despues.jpg)

#### Entrevistado · momento 5 · minuto 35:13 · categorías: voz, pregunta, AU

- **Cita literal:** «radicalmente. O sea, ya no valen promesas. A mí recordaré siempre que siendo alcaldesa, Pedro Sánchez me prometió en el 2019 regular»
- **Qué se mide:** cambio tono: sube (z=+2.0); cambio volumen: sube (z=+1.7); cambio velocidad: baja (z=-1.6); pregunta con respuesta clasificada: responde; AU fuera de lo habitual: AU7 párpados tensos z=+2.4.
- **Material:** `fotogramas/m05_antes.jpg`, `fotogramas/m05_durante.jpg`, `fotogramas/m05_despues.jpg`; clip con detección facial `clips_cara/m05_35-13.mp4`.

![antes](fotogramas/m05_antes.jpg) ![durante](fotogramas/m05_durante.jpg) ![después](fotogramas/m05_despues.jpg)

#### Entrevistado · momento 6 · minuto 40:59 · categorías: voz, pregunta, AU

- **Cita literal:** «Primero tienes que investigar. Si no sabes qué ha pasado, hasta que no tienes una investigación y sabes exactamente»
- **Qué se mide:** cambio tono: sube (z=+1.6); cambio velocidad: baja (z=-1.5); pregunta con respuesta clasificada: sin respuesta; AU fuera de lo habitual: AU24 labios presionados z=+2.4.
- **Material:** `fotogramas/m06_antes.jpg`, `fotogramas/m06_durante.jpg`, `fotogramas/m06_despues.jpg`; clip con detección facial `clips_cara/m06_40-59.mp4`.

![antes](fotogramas/m06_antes.jpg) ![durante](fotogramas/m06_durante.jpg) ![después](fotogramas/m06_despues.jpg)

#### Entrevistado · momento 7 · minuto 52:24 · categorías: voz, retorica, AU

- **Cita literal:** «recuerdo la respuesta rápida, ágil, coordinada de todas las administraciones. Me acuerdo que Ayuntamiento, Generalitat y Estado, en»
- **Qué se mide:** cambio velocidad: baja (z=-1.9); tecnica retorica: lista de tres candidata; AU fuera de lo habitual: AU7 párpados tensos z=+2.5; AU17 mentón arriba z=+2.4; AU15 comisura labios abajo z=+2.2.
- **Material:** `fotogramas/m07_antes.jpg`, `fotogramas/m07_durante.jpg`, `fotogramas/m07_despues.jpg`; clip con detección facial `clips_cara/m07_52-24.mp4`.

![antes](fotogramas/m07_antes.jpg) ![durante](fotogramas/m07_durante.jpg) ![después](fotogramas/m07_despues.jpg)

#### Entrevistado · momento 8 · minuto 55:01 · categorías: voz, pausa, retorica

- **Cita literal:** «con las vivencias de la gente. Entonces, ir allí para mí es lo primero. Ir allí evidentemente no sola, sino con los responsables de»
- **Qué se mide:** pausa larga: 1.1 s; cambio tono: sube (z=+1.5); cambio volumen: baja (z=-2.6); tecnica retorica: contraste no X sino Y.
- **Material:** `fotogramas/m08_antes.jpg`, `fotogramas/m08_durante.jpg`, `fotogramas/m08_despues.jpg`; clip con detección facial `clips_cara/m08_55-01.mp4`.

![antes](fotogramas/m08_antes.jpg) ![durante](fotogramas/m08_durante.jpg) ![después](fotogramas/m08_despues.jpg)

#### Entrevistado · momento 9 · minuto 62:20 · categorías: voz, pregunta, AU

- **Cita literal:** «el gobierno con todos los informes que has de tener de quien relaciones diplomáticas, quien lleva defensa, quien lleva, ¿sabes?»
- **Qué se mide:** cambio tono: baja (z=-2.1); cambio velocidad: baja (z=-1.7); pregunta con respuesta clasificada: en parte; AU fuera de lo habitual: AU12 comisura labios arriba z=+2.7; AU7 párpados tensos z=+2.1; AU1 cejas: parte interna arriba z=-2.1.
- **Material:** `fotogramas/m09_antes.jpg`, `fotogramas/m09_durante.jpg`, `fotogramas/m09_despues.jpg`; clip con detección facial `clips_cara/m09_62-20.mp4`.

![antes](fotogramas/m09_antes.jpg) ![durante](fotogramas/m09_durante.jpg) ![después](fotogramas/m09_despues.jpg)

#### Entrevistado · momento 10 · minuto 75:57 · categorías: voz, pregunta, AU

- **Cita literal:** «todavía, creo que se va mejorando como sociedad, pero seguimos sufriendo el Hay este año 44 asesinatos»
- **Qué se mide:** cambio volumen: baja (z=-2.4); cambio velocidad: baja (z=-1.6); pregunta con respuesta clasificada: en parte; AU fuera de lo habitual: AU5 párpado superior arriba z=+2.4.
- **Material:** `fotogramas/m10_antes.jpg`, `fotogramas/m10_durante.jpg`, `fotogramas/m10_despues.jpg`; clip con detección facial `clips_cara/m10_75-57.mp4`.

![antes](fotogramas/m10_antes.jpg) ![durante](fotogramas/m10_durante.jpg) ![después](fotogramas/m10_despues.jpg)

#### Entrevistado · momento 11 · minuto 92:07 · categorías: voz, retorica, AU

- **Cita literal:** «solo que no me atracan Sino que también me encuentro con mucha gente que está muy contenta con la política de vivienda que se ha hecho, con las»
- **Qué se mide:** cambio volumen: baja (z=-2.0); tecnica retorica: contraste no X sino Y; AU fuera de lo habitual: AU23 labios apretados z=+2.1; AU7 párpados tensos z=+2.0; AU14 hoyuelo comisura z=-2.0.
- **Material:** `fotogramas/m11_antes.jpg`, `fotogramas/m11_durante.jpg`, `fotogramas/m11_despues.jpg`; clip con detección facial `clips_cara/m11_92-07.mp4`.

![antes](fotogramas/m11_antes.jpg) ![durante](fotogramas/m11_durante.jpg) ![después](fotogramas/m11_despues.jpg)

#### Entrevistado · momento 12 · minuto 100:49 · categorías: voz, pausa, pregunta, AU

- **Cita literal:** «En ese sentido sí que es expropiar. No le dejas al propietario que lo venda a quien quiera. Hicimos una norma que es cada vez que se vende un edificio en Barcelona, la»
- **Qué se mide:** pausa larga: 1.1 s; cambio tono: sube (z=+1.5); cambio velocidad: sube (z=+2.0); pregunta con respuesta clasificada: responde; AU fuera de lo habitual: AU6 mejillas elevadas z=+2.9; AU12 comisura labios arriba z=+2.1.
- **Material:** `fotogramas/m12_antes.jpg`, `fotogramas/m12_durante.jpg`, `fotogramas/m12_despues.jpg`; clip con detección facial `clips_cara/m12_100-49.mp4`.

![antes](fotogramas/m12_antes.jpg) ![durante](fotogramas/m12_durante.jpg) ![después](fotogramas/m12_despues.jpg)

#### Entrevistado · momento 13 · minuto 106:25 · categorías: voz, pregunta, AU

- **Cita literal:** «De una manera o de otra, un ayuntamiento tiene que poder encontrar una solución. Puede tardar una semana, dos semanas, tres o un mes, pero encuentra...»
- **Qué se mide:** cambio tono: baja (z=-1.5); cambio volumen: sube (z=+1.7); cambio velocidad: sube (z=+2.9); pregunta con respuesta clasificada: responde; AU fuera de lo habitual: AU1 cejas: parte interna arriba z=-2.1.
- **Material:** `fotogramas/m13_antes.jpg`, `fotogramas/m13_durante.jpg`, `fotogramas/m13_despues.jpg`; clip con detección facial `clips_cara/m13_106-25.mp4`.

![antes](fotogramas/m13_antes.jpg) ![durante](fotogramas/m13_durante.jpg) ![después](fotogramas/m13_despues.jpg)

#### Entrevistado · momento 14 · minuto 126:33 · categorías: voz, pregunta, AU

- **Cita literal:** «día, pues estaba en un meeting, que también es verdad que te vienes un poco más arriba, Y en un meeting critiqué a Caetana.»
- **Qué se mide:** cambio tono: sube (z=+2.1); cambio velocidad: baja (z=-2.4); pregunta con respuesta clasificada: responde; AU fuera de lo habitual: AU23 labios apretados z=+2.4.
- **Material:** `fotogramas/m14_antes.jpg`, `fotogramas/m14_durante.jpg`, `fotogramas/m14_despues.jpg`; clip con detección facial `clips_cara/m14_126-33.mp4`.

![antes](fotogramas/m14_antes.jpg) ![durante](fotogramas/m14_durante.jpg) ![después](fotogramas/m14_despues.jpg)

#### Entrevistado · momento 15 · minuto 129:20 · categorías: voz, pregunta, AU

- **Cita literal:** «A ver, intentaría no llevarlo a personal en general,»
- **Qué se mide:** cambio volumen: baja (z=-3.7); cambio velocidad: baja (z=-1.6); pregunta con respuesta clasificada: en parte; AU fuera de lo habitual: AU6 mejillas elevadas z=+5.3; AU12 comisura labios arriba z=+4.7; AU23 labios apretados z=+3.3.
- **Material:** `fotogramas/m15_antes.jpg`, `fotogramas/m15_durante.jpg`, `fotogramas/m15_despues.jpg`; clip con detección facial `clips_cara/m15_129-20.mp4`.

![antes](fotogramas/m15_antes.jpg) ![durante](fotogramas/m15_durante.jpg) ![después](fotogramas/m15_despues.jpg)

## 4. El entrevistador, por separado

### Pausas

- **87** huecos de más de 0,4 s entre palabras verificadas consecutivas. Duración media **0,81 s**, mediana 0,70 s, máxima 2.3 s. 23 duran 1 s o más y 2 duran 2 s o más.
- **23** van justo antes de una frase con carga: contraste (6), cifra (6), mencion politica (6), promesa (3), mencion politica+contraste (2).
- `ffmpeg silencedetect` confirma el 7%.
- Las cinco más largas: 22:57 (2.3 s, antes de «que afectan directamente al gobierno. Persona, un…»); 55:37 (2.1 s, antes de «Imagínate si tú vivieras en Ceuta, es…»); 30:51 (1.5 s, antes de «A lo mejor es loafer, como dices.…»); 58:35 (1.4 s, antes de «¿tú tienes esa misma sensación de que…»); 91:11 (1.4 s, antes de «Desde 2018 -19 la inseguridad es el…»).

### Voz

- 532 frases medidas. Tono (F0) medio **131 Hz** (desviación entre frases 17 Hz; variación dentro de la frase 3,55 semitonos).
- Intensidad media 69.5 dB (relativa). Velocidad media **234 palabras/min** (mediana 225).
- Cambios claros respecto a su propia media (|z| ≥ 1,5): tono sube 43 / baja 15; volumen sube 0 / baja 38; velocidad sube 44 / baja 21 (frases).
- Las tres frases con el tono más alto respecto a su media: 131:02 (z = +5.7) «Bueno, sí, por ahí por la cara, ¿no?…»; 105:33 (z = +3.9) «porque hay gente que tiene casas que están vacías……»; 8:50 (z = +3.8) «Y un año después estás aquí.…».

### Preguntas

- 107 frases interrogativas verificadas; 97 intervenciones con pregunta seguidas de respuesta del entrevistado; **71** preguntas cuya respuesta está clasificada en la tabla de la sección 3.

### Pronombres explícitos

| yo | nosotros/as | tú | vosotros/as | ellos/as |
|---|---|---|---|---|
| 71 | 1 | 75 | 10 | 5 |

A quién se refiere «ellos/ellas» (columna «Referente»: lectura manual del contexto si existe `ref_ellos.json`; «sin clasificar» = no se ha leído; «incierto» = no se puede asegurar):

| Minuto | Referente | Contexto |
|---|---|---|
| 33:18 | sin clasificar | …con la de casos y casos de relaciones entre grandes empresas y ellos por qué te quieres juntar con ellos… |
| 33:20 | sin clasificar | …relaciones entre grandes empresas y ellos por qué te quieres juntar con ellos si es que tú misma estás diciendo… |
| 55:54 | sin clasificar | …y diría bueno qué es esto que no tendrían que haberlo hecho ellos hay muchos indicios falta demostrarlo pero hay… |
| 56:31 | sin clasificar | …que hacer con marruecos ada si tú eres presidenta qué harías con ellos cómo nos tomamos esto como una especie… |
| 71:02 | sin clasificar | …forma de ser muy abierta que a mí me encanta pero incluso ellos lo que está pasando en los últimos… |

### Repeticiones principales

| Expresión | Veces | Primer minuto |
|---|---|---|
| es una cosa | 5 | 2:09 |
| que la gente | 6 | 10:07 |
| a la gente | 4 | 10:43 |
| a lo mejor | 5 | 15:40 |
| que yo creo | 5 | 23:05 |
| lo que pasa | 7 | 27:41 |
| porque al final | 6 | 30:39 |
| en ese momento | 6 | 37:00 |
| pasa es que | 5 | 41:59 |
| si tú eres presidenta | 5 | 56:29 |
| eres presidenta qué harías | 3 | 56:30 |
| mucha gente | 10 | 63:16 |
| de una forma | 4 | 64:15 |
| no es un tema | 3 | 67:08 |
| es un tema | 7 | 67:08 |
| es negar una realidad | 3 | 70:05 |
| casi la mitad | 4 | 79:33 |
| casi la mitad de | 3 | 79:36 |
| cuánto tiempo | 7 | 103:49 |
| en tu españa ideal | 3 | 105:20 |

La lista es automática y puede mezclar muletillas con términos del tema.

### Otras técnicas detectadas en el texto (candidatas)

**Contrastes «no X, sino Y»: 0**


**Léxico de pérdida o riesgo: 5**

- 15:06 «Cuando escuchas que gente, vamos a decir, de clase media -alta, tiene miedo de que podáis tener poder,»
- 67:39 «hay una razón y yo creo que es importante entender esa razón, porque la idea que dices tú es muy bonita y de verdad me parece súper bonita, que es muy idílica, que vengan y todo bien, y eso es precios»
- 91:12 «Desde 2018 -19 la inseguridad es el primer problema que percibe la gente y el segundo la limpieza.»
- 111:49 «porque ese propietario no tiene culpa de que haya perdido el trabajo por ejemplo la persona»
- 114:55 «Acaba de perder unas elecciones.»

**Léxico de logro o ganancia: 5**

- 14:38 «Sí, en general, cómo mejorar el país, digamos.»
- 29:29 «avanzar, porque igual que se dice y presunción de inocencia, que ok, lo contrario también tendría que ser aplicable.»
- 57:27 «¿Para ti Marruecos es un país que respeta los derechos humanos?»
- 59:40 «¿Tú colaborarías con un país que no respeta los derechos humanos?»
- 85:14 «y que sea lo que tenga que ser cómo va a ser, madre mía, las demás me voy a pegar un tiro, dale por favor el dato y avanzamos»

**Listas de tres: 4**

- 23:01 «Persona, un exministro y un entramado»
- 24:15 «las elecciones, PSOE y Frente»
- 47:17 «el Bataclan, imagínate, y muchas»
- 104:06 «vacío, punto y final»

Preguntas seguidas por el mismo hablante (candidatas a retóricas): 57; relatos o personas concretas candidatos: 4 (en `retorica.csv`). Detecciones automáticas **no revisadas una a una**.

### Cara (unidades de acción)

- Su cara se detecta en 18122 de ~39840 fotogramas muestreados a 5 fps (**45%**).
- Valores medios (0–1, sin calibrar a la escala A–E de FACS): AU1 cejas: parte interna arriba 0,44; AU2 cejas: parte externa arriba 0,27; AU4 cejas bajan y se juntan 0,41; AU5 párpado superior arriba 0,35; AU6 mejillas elevadas 0,16; AU7 párpados tensos 0,05; AU12 comisura labios arriba 0,09; AU14 hoyuelo comisura 0,41; AU15 comisura labios abajo 0,55; AU17 mentón arriba 0,34; AU23 labios apretados 0,66; AU24 labios presionados 0,49.
- Máximo de AU12 (comisura de los labios arriba) en la media de 30 s hacia el **84:34** (0,35 frente a una media global de 0,09); AU6 (mejillas elevadas) en ese punto: 0,34 (media 0,16). No se interpreta.
- Cabeza girada de media 38° respecto a la cámara (giro medio -38°), lo que afecta a la fiabilidad de todas las AU.

### Momentos clave del entrevistador

Mismo criterio. En el entrevistador, la categoría «pregunta» indica que en ese momento formula una de las preguntas cuya respuesta está clasificada.

#### Entrevistador · momento 1 · minuto 6:57 · categorías: voz, pregunta, AU

- **Cita literal:** «al final es el mismo perro con diferente collar, ¿Y por qué si una y otra no?»
- **Qué se mide:** cambio tono: sube (z=+2.0); cambio volumen: baja (z=-3.1); cambio velocidad: sube (z=+1.7); pregunta con respuesta clasificada: formula la pregunta; AU fuera de lo habitual: AU2 cejas: parte externa arriba z=+5.7; AU1 cejas: parte interna arriba z=+4.4; AU5 párpado superior arriba z=+4.1.
- **Material:** `fotogramas/e01_antes.jpg`, `fotogramas/e01_durante.jpg`, `fotogramas/e01_despues.jpg`; clip con detección facial `clips_cara/e01_6-57.mp4`.

![antes](fotogramas/e01_antes.jpg) ![durante](fotogramas/e01_durante.jpg) ![después](fotogramas/e01_despues.jpg)

#### Entrevistador · momento 2 · minuto 10:52 · categorías: voz, pregunta, AU

- **Cita literal:** «machacar mucho con esto de la palabra. A mí estas cosas me descuadran un poco, ¿sabes?»
- **Qué se mide:** cambio volumen: baja (z=-2.3); pregunta con respuesta clasificada: formula la pregunta; AU fuera de lo habitual: AU2 cejas: parte externa arriba z=+3.2; AU5 párpado superior arriba z=+2.9; AU17 mentón arriba z=+2.9.
- **Material:** `fotogramas/e02_antes.jpg`, `fotogramas/e02_durante.jpg`, `fotogramas/e02_despues.jpg`; clip con detección facial `clips_cara/e02_10-52.mp4`.

![antes](fotogramas/e02_antes.jpg) ![durante](fotogramas/e02_durante.jpg) ![después](fotogramas/e02_despues.jpg)

#### Entrevistador · momento 3 · minuto 16:55 · categorías: voz, pausa, pregunta, AU

- **Cita literal:** «si estamos todas, yo también estaré. Pero tenemos que estar todas.»
- **Qué se mide:** pausa antes de frase con carga: mencion politica+contraste; cambio tono: sube (z=+2.0); pregunta con respuesta clasificada: formula la pregunta; AU fuera de lo habitual: AU14 hoyuelo comisura z=+2.9; AU15 comisura labios abajo z=-2.1.
- **Material:** `fotogramas/e03_antes.jpg`, `fotogramas/e03_durante.jpg`, `fotogramas/e03_despues.jpg`; clip con detección facial `clips_cara/e03_16-55.mp4`.

![antes](fotogramas/e03_antes.jpg) ![durante](fotogramas/e03_durante.jpg) ![después](fotogramas/e03_despues.jpg)

#### Entrevistador · momento 4 · minuto 22:59 · categorías: voz, pausa, pregunta, retorica

- **Cita literal:** «firme, que afectan directamente al gobierno. Persona, un exministro y un entramado»
- **Qué se mide:** pausa larga: 2.3 s; cambio tono: baja (z=-1.6); pregunta con respuesta clasificada: formula la pregunta; tecnica retorica: lista de tres candidata.
- **Material:** `fotogramas/e04_antes.jpg`, `fotogramas/e04_durante.jpg`, `fotogramas/e04_despues.jpg`; clip con detección facial `clips_cara/e04_22-59.mp4`.

![antes](fotogramas/e04_antes.jpg) ![durante](fotogramas/e04_durante.jpg) ![después](fotogramas/e04_despues.jpg)

#### Entrevistador · momento 5 · minuto 41:13 · categorías: voz, pregunta, AU

- **Cita literal:** «después sin saber por qué hubo un accidente? Tampoco es física cuántica.»
- **Qué se mide:** cambio velocidad: sube (z=+1.7); pregunta con respuesta clasificada: formula la pregunta; AU fuera de lo habitual: AU5 párpado superior arriba z=+3.6; AU4 cejas bajan y se juntan z=-2.6; AU2 cejas: parte externa arriba z=+2.5.
- **Material:** `fotogramas/e05_antes.jpg`, `fotogramas/e05_durante.jpg`, `fotogramas/e05_despues.jpg`; clip con detección facial `clips_cara/e05_41-13.mp4`.

![antes](fotogramas/e05_antes.jpg) ![durante](fotogramas/e05_durante.jpg) ![después](fotogramas/e05_despues.jpg)

#### Entrevistador · momento 6 · minuto 61:53 · categorías: voz, pregunta, AU

- **Cita literal:** «harías con Marruecos? Es decir, ¿endurecerías las relaciones?»
- **Qué se mide:** cambio volumen: baja (z=-1.7); pregunta con respuesta clasificada: formula la pregunta; AU fuera de lo habitual: AU2 cejas: parte externa arriba z=+4.9; AU5 párpado superior arriba z=+4.1; AU1 cejas: parte interna arriba z=+4.0.
- **Material:** `fotogramas/e06_antes.jpg`, `fotogramas/e06_durante.jpg`, `fotogramas/e06_despues.jpg`; clip con detección facial `clips_cara/e06_61-53.mp4`.

![antes](fotogramas/e06_antes.jpg) ![durante](fotogramas/e06_durante.jpg) ![después](fotogramas/e06_despues.jpg)

#### Entrevistador · momento 7 · minuto 84:59 · categorías: voz, pausa, AU

- **Cita literal:** «la regla creo que voy a hacer dos horas aquí, que pase lo que Dios quiera y que Dios me perdone es que no puedo cortar ahora, bueno, vamos»
- **Qué se mide:** pausa antes de frase con carga: promesa; cambio tono: baja (z=-1.6); AU fuera de lo habitual: AU7 párpados tensos z=+3.6; AU12 comisura labios arriba z=+3.3; AU6 mejillas elevadas z=+3.0.
- **Material:** `fotogramas/e07_antes.jpg`, `fotogramas/e07_durante.jpg`, `fotogramas/e07_despues.jpg`; clip con detección facial `clips_cara/e07_84-59.mp4`.

![antes](fotogramas/e07_antes.jpg) ![durante](fotogramas/e07_durante.jpg) ![después](fotogramas/e07_despues.jpg)

#### Entrevistador · momento 8 · minuto 95:20 · categorías: voz, pregunta, AU

- **Cita literal:** «hurtos, 9 de cada 10. Lo que pasa es que no lo tengo linkado»
- **Qué se mide:** cambio tono: sube (z=+1.8); pregunta con respuesta clasificada: formula la pregunta; AU fuera de lo habitual: AU2 cejas: parte externa arriba z=+3.5; AU23 labios apretados z=-2.8; AU1 cejas: parte interna arriba z=+2.6.
- **Material:** `fotogramas/e08_antes.jpg`, `fotogramas/e08_durante.jpg`, `fotogramas/e08_despues.jpg`; clip con detección facial `clips_cara/e08_95-20.mp4`.

![antes](fotogramas/e08_antes.jpg) ![durante](fotogramas/e08_durante.jpg) ![después](fotogramas/e08_despues.jpg)

#### Entrevistador · momento 9 · minuto 96:25 · categorías: voz, pregunta, AU

- **Cita literal:** «¿Y qué porcentaje había en ese momento?»
- **Qué se mide:** cambio velocidad: sube (z=+1.9); pregunta con respuesta clasificada: formula la pregunta; AU fuera de lo habitual: AU24 labios presionados z=+3.2; AU15 comisura labios abajo z=-2.6; AU17 mentón arriba z=+2.2.
- **Material:** `fotogramas/e09_antes.jpg`, `fotogramas/e09_durante.jpg`, `fotogramas/e09_despues.jpg`; clip con detección facial `clips_cara/e09_96-25.mp4`.

![antes](fotogramas/e09_antes.jpg) ![durante](fotogramas/e09_durante.jpg) ![después](fotogramas/e09_despues.jpg)

#### Entrevistador · momento 10 · minuto 113:43 · categorías: voz, pausa, AU

- **Cita literal:** «comentar contigo, pero ya no me dan tiempo. Quiero que me des, son preguntas rápidas. Una es, ya sé que tú opinas»
- **Qué se mide:** pausa larga: 1.4 s; cambio tono: sube (z=+2.4); cambio volumen: baja (z=-2.0); AU fuera de lo habitual: AU7 párpados tensos z=+3.2; AU4 cejas bajan y se juntan z=-2.5; AU15 comisura labios abajo z=-2.3.
- **Material:** `fotogramas/e10_antes.jpg`, `fotogramas/e10_durante.jpg`, `fotogramas/e10_despues.jpg`; clip con detección facial `clips_cara/e10_113-43.mp4`.

![antes](fotogramas/e10_antes.jpg) ![durante](fotogramas/e10_durante.jpg) ![después](fotogramas/e10_despues.jpg)

## 5. Limitaciones

**Emociones.** Las secciones de este documento no usan modelos de emociones: en la extracción de AU el de py-feat está sustituido por una función que devuelve NaN (`scripts/face_detector.py`). Si se ejecutan aparte clasificadores de expresión o de emoción en la voz, sus resultados y sus límites van en sus propios anexos.

**Qué no mide.** Pausas, cambios de voz, unidades de acción y postura son conductas observables. No existe base para leerlas como señales de sinceridad o de engaño, y este informe no lo hace. No se mide la mirada, y el parpadeo no se analiza.

**Comparación entre personas.** Las AU de py-feat no están calibradas por persona: la forma de la cara, el vello facial, las gafas, el ángulo de cámara y la iluminación cambian el valor base. La comparación de niveles absolutos de AU entre entrevistado y entrevistador es, por eso, la parte más débil del informe; las comparaciones dentro de cada persona (hablar frente a escuchar, desviaciones frente a su propia línea base) son más fiables. En la voz, el tono medio refleja sobre todo la voz de cada uno, y la intensidad depende del micrófono y de la mezcla.

**Transcripción.** Whisper `large-v3` comete errores, sobre todo en nombres propios y en el habla solapada. Las cifras escritas con dígitos las genera el modelo. No se ha revisado la transcripción completa a mano.

**Separación de hablantes.** pyannote 3.1 separó 3 voces en todo el vídeo; las dos con más tiempo suman el 99% del habla detectada. La asignación de papeles se decidió para este vídeo y está en `hablantes.json`. Una verificación por huella de voz (wespeaker) comprobó cada tramo de 1 s o más: se verificó el 87% de las palabras; el 90% de las del entrevistado (14693 de 16343) y el 83% de las del entrevistador (8559 de 10301). **Solo las palabras verificadas se usan** en pausas, voz, retórica y cara. Las frases cortas dichas encima de la otra persona tienden a quedar sin verificar, de modo que las réplicas breves y las interrupciones de ambos están infrarrepresentadas. Tramos limpios usados como huella de referencia: entrevistado 51, entrevistador 86.

**Pausas.** Se miden entre palabras consecutivas verificadas de la misma persona; los huecos pueden contener voz de la otra persona, risas, música o habla no transcrita. `silencedetect` confirma el 4% de las del entrevistado y el 7% de las del entrevistador.

**Voz.** F0 e intensidad se miden con Praat sobre el audio publicado (mezcla y compresión incluidas). Los cambios se definen respecto a la media de cada persona en este vídeo. Tono, volumen y velocidad están correlacionados entre sí.

**Cara.** py-feat (RetinaFace + modelo de AU) es un modelo estadístico: sus intensidades no son una codificación FACS manual. El giro de la cabeza, el habla y los cambios de plano alteran las AU sin que cambie el gesto. Con media de 0,40 o más en las dos personas (valor base alto, poco margen para subir): AU1, AU23, AU24. Muestreo a 5 fps. La realización decide a quién se ve: hay 25189 fotogramas con la cara del entrevistado y 18122 con la del entrevistador.

**Identidad de la cara.** Las caras se agruparon por similitud (k-means, 10 grupos): 5 grupos se asignaron al entrevistado, 5 al entrevistador y 0 se descartaron. El script propone la asignación por el acoplamiento entre el movimiento de la boca y el habla verificada de cada uno; en esta entrevista la asignación final se fijó a mano en `hablantes.json` (`grupos_cara`). Nota del analista: «Grupos asignados tras revisar tmp/montaje_grupos.jpg y la coincidencia con quién habla en cada plano. Los grupos 2 y 3 incluyen algún recorte suelto de otra persona o de imagen de archivo.» No se usó reconocimiento facial contra ninguna base de datos. Solo entran caras detectadas con confianza alta y de 50 px de ancho o más, y puede haber fotogramas mal asignados.

**Retórica y preguntas.** Los patrones son expresiones regulares (listas en `scripts/08_retorica.py`): no son exhaustivos y tienen falsos positivos, por ejemplo un verbo de la lista de «pérdida» usado en otro sentido. Las preguntas formuladas como afirmación, sin «?», no se detectan automáticamente. La clasificación de las respuestas procede de una sola lectura; al ser el contenido político, otra persona podría clasificar distinto algunos casos.

**Momentos clave.** Umbrales fijados por el analista (±3 s, |z| ≥ 1,5 en voz, |z| ≥ 2 en AU). Con 25 momentos y varias señales posibles, alguna coincidencia será casual.

**Alcance.** Es una sola entrevista de unos 134 minutos. Nada de lo medido permite concluir sobre intenciones, estados internos, sinceridad o rasgos de ninguna de las dos personas; solo describe conductas observables y cuándo ocurren.

## 6. Archivos

Presentes en la carpeta al generar este informe: `informe.md`, `informe_tonalidad.md`, `informe_expresiones.md`, `informe_movimiento.md`, `verificacion_datos.md`, `verificacion_datos.csv`, `comparativa.csv`, `pausas_entrevistado.csv`, `pausas_entrevistador.csv`, `voz_entrevistado.csv`, `voz_entrevistador.csv`, `cara_entrevistado.csv`, `cara_entrevistador.csv`, `momentos_entrevistado.csv`, `momentos_entrevistador.csv`, `centroides_entrevistado.npz`, `centroides_entrevistador.npz`, `transcripcion.csv`, `palabras.csv`, `palabras_verificadas.csv`, `retorica.csv`, `qa_pares.csv`, `clase_respuestas.json`, `diarizacion.csv`, `cara_grupos_identidad.csv`, `cambios_tema_aprox.csv`, `hablantes.json`, `grafica_tono.png`, `grafica_volumen.png`, `grafica_velocidad.png`, `grafica_AU.png`, `grafica_comparativa_voz.png`, `grafica_comparativa_AU.png`, `fotogramas/`, `clips_cara/`, `scripts/`. En los nombres por persona, `_entrevistado` y `_entrevistador`; en `fotogramas/`, m = entrevistado y e = entrevistador.
