# Colau ante Jordi Wild: 156 preguntas duras en 133 minutos, y seis de cada diez contestadas a lo preguntado

*Análisis de la entrevista de Jordi Wild a Ada Colau en* The Wild Project *(YouTube, 13-nov-2026, https://www.youtube.com/watch?v=-ESmAhdixfo). Los minutos son los del vídeo (m:ss).*

De las 187 intervenciones de Jordi Wild que pedían respuesta, 156 (83 %) fueron incómodas, repreguntas o insistencias. La invitada contestó a lo preguntado en 94 de esas 156 (60 %), contestó en parte en 30 y no contestó a lo preguntado en 27 (en 5 más, Jordi no dejó contestar). Su voz apenas cambia cuando la pregunta aprieta: lo que cambia es que se traba más y habla algo más deprisa. Este informe cuenta lo que se puede medir y qué dice la investigación sobre su efecto probable en quien escucha. No valora ideas ni dice quién estuvo mejor.

Un aviso que vale para todo el texto: **ni las pausas, ni la voz, ni los gestos, ni las trabas sirven para saber si alguien dice la verdad**. La revisión de 158 señales de DePaulo y colaboradores (***Cues to deception*, 2003**) encontró que la mayoría no distingue a quien miente y que las pocas que lo hacen tienen efectos pequeños. Aquí describen esfuerzo o tensión al hablar, nada más.

## 2. Lo que dicen los datos

| Medida | La invitada | Jordi Wild |
|---|---|---|
| Palabras verificadas | 14.693 (63,7 %) | 8.356 (36,3 %) |
| Tiempo de habla verificado | 70,4 min | 39,7 min |
| Turnos | 371 | 302 |
| Mediana de palabras por turno | 27 | 19 |
| Turno más largo | 62,6 s | 38,0 s |
| Velocidad en tramos de habla continua | 224 palabras/min | 234 palabras/min |
| Frases interrogativas | 32 | 107 |
| *yo* explícito por 1.000 palabras | 10,8 | 8,3 |
| *nosotros* explícito por 1.000 palabras | 1,6 | 0,1 |
| *tú* explícito por 1.000 palabras | 1,9 | 8,8 |
| Tomas de palabra con menos de 0,2 s de hueco | 54 % | 77 % |

La invitada habla casi dos tercios del tiempo. Es un reparto parecido al de Sánchez con el mismo entrevistador (63,4 %) y menor que el de Feijóo (72,8 %); con Broncano, Abascal se quedó en el 53,5 %. La velocidad de los dos es casi igual (diferencia inapreciable, d = −0,17).

**Quién corta a quién.** Tres de cada cuatro veces que Jordi toma la palabra lo hace sin dejar hueco (77 %). En la comparación entre entrevistas, Jordi corta el 50,7 % de las respuestas de la invitada, frente al 22,0 % con Feijóo y el 36,8 % con Sánchez, e inicia 459 solapes de voz frente a 258 de ella. La lectura manual recoge cinco interrupciones notables, todas de Jordi; un ejemplo: «Primero sí o no y luego me justificas.» (37:10). La conversación se organiza por turnos que los hablantes se reparten sobre la marcha (**Sacks, Schegloff y Jefferson, 1974**). Cortar un turno altera ese reparto; que el espectador lea el corte según a quién apoye es una lectura de este informe, no de ese estudio (ver sección 10).

**A quién nombra.** La invitada: Gobierno 26 veces, Podemos 14, Sánchez 10, PP 9, Vox 8, Trump 7, PSOE 6, Sumar 5. Jordi: Gobierno 16, PSOE 9, Israel 7, Trump 5. Ella da pocas cifras (0,67 por cada 100 palabras, frente a 2,61 de Feijóo y 1,62 de Sánchez) y usa frases largas (29,3 palabras por frase).

## 3. Trabas contadas una a una

Una traba es una repetición o una frase que se corta. Se contaron 41 en la invitada (0,28 por cada 100 palabras) y 38 en Jordi (0,45). Las dos cifras son bajas: Abascal tuvo 0,41 y Sánchez 0,98 en *La Revuelta*.

| Tipo | La invitada | Jordi Wild |
|---|---|---|
| Se corta (y reformula o no continúa) | 22 | 16 |
| Repite un grupo de palabras | 11 | 9 |
| Repite una palabra | 8 | 13 |
| Total | 41 | 38 |
| En las 8 primeras palabras del turno, por 100 palabras | 0,24 | 0,35 |

Dónde se concentran las de la invitada (cálculo propio): 40 de las 41 caen en tramos que siguen a una pregunta dura (0,33 por 100 palabras, frente a 0,04 tras preguntas neutras o cómodas), y 9 en los diez minutos que van del 120 al 130 (rivales y asuntos personales), el bloque con más densidad (0,80 por 100). Con 41 casos, es solo una pista.

Ejemplos:

- 45:50, sobre la dimisión del ministro: «que la responsabilidad política había que asumirla y...».
- 89:05–89:14, cuando Jordi pide un error propio: «de que todo era culpa de Colau, porque...» y «no sé si grave, pero... Cada uno tienes...».
- 90:43, al admitir un fallo: «nos hemos equivocado, nos hemos equivocado».
- 129:43, sobre haber llamado cruel a Abascal: «lo he escuchado, lo he escuchado».
- Jordi, 46:22: «No hay nada ya que... O sea, por desgracia...»; y 63:15: «a mucha, mucha, mucha gente,».

Parte de las repeticiones son énfasis («han subido, han subido,», 35:27). Los cortes sin continuación suelen coincidir con la otra voz entrando. La psicolingüística clásica asocia las vacilaciones del habla espontánea, sobre todo las pausas, a la **planificación sobre la marcha (Goldman-Eisler, 1968)**; ese trabajo no estudió en concreto repeticiones ni cortes, que es lo que aquí se cuenta. No indican nada sobre el contenido de lo dicho.

## 4. Silencios

| Medida | La invitada | Jordi Wild |
|---|---|---|
| Pausas de más de 0,4 s | 105 | 87 |
| Por 1.000 palabras | 7,1 | 10,4 |
| Duración media | 0,76 s | 0,81 s |
| De 1 s o más | 19 | 23 |
| Máxima | 2,5 s | 2,3 s |
| Antes de frase con carga (cifra, rival, contraste) | 20 | 23 |
| Confirmadas por el detector acústico | 4 de 105 (3,8 %) | 6 de 87 (6,9 %) |

Dos advertencias. La transcripción tiene cuatro huecos sin texto (5:32–5:59, 71:45–71:56, 93:21–93:48 y 110:44–111:13); ninguna pausa de la tabla cae en ellos (lo comprobé: la más larga dura 2,5 s), así que no hubo que excluir ninguna. Y el detector acústico de silencios confirma menos del 7 % de las pausas: casi todas son huecos entre palabras de una misma persona, que pueden contener la voz de la otra, una risa o ruido.

La pausa más larga de la invitada (2,5 s, 58:46) está en una broma sobre fútbol. Las que preceden a frases con carga:

- 30:06 (1,7 s), tras «no tengo ningún indicio de que sea culpable, no sé, lo están investigando.» y antes de «Lo que también sé es que en el caso de Zapatero».
- 28:22 (0,5 s), antes de la cifra «a mí me han puesto más de 22 querellas».
- 94:04 (0,7 s), antes de nombrar a un rival: «nos sentimos bastante abandonados por la Consellería de Junts,».
- Jordi, 22:57 (2,3 s, la más larga suya), entre «tenemos condenados en firme,» y «que afectan directamente al gobierno.».

Tras preguntas duras la invitada no hace más pausas, sino menos: 6,6 por 1.000 palabras frente a 9,8 en el resto (cálculo propio).

## 5. Voz

| Medida | La invitada | Jordi Wild |
|---|---|---|
| Tono medio (F0) | 164 Hz | 131 Hz |
| Variación del tono dentro de la frase | 3,19 semitonos | 3,55 semitonos |
| Volumen medio (relativo) | 69,7 dB | 69,5 dB |
| Frases con el tono claramente fuera de su media (suben / bajan) | 55 / 31 | 43 / 15 |
| Frases con el volumen claramente fuera de su media (suben / bajan) | 10 / 56 | 0 / 38 |
| Frases que acaban hacia abajo | 25 % | 49 % |

El tono medio es el de cada voz, no una conducta. Dentro de cada uno, lo que más se repite es bajar el volumen, no subirlo. La frase con el tono más alto de la invitada llega en el cruce sobre machismo: «Pues hay que trabajar por eso y que todo el mundo cumpla.» (77:10, z = +3,4). La más apagada: «Pero, te digo, tenemos casos de lawfare.» (28:19, z = −3,9). La de Jordi con el tono más alto es una broma al final: «Bueno, sí, por ahí por la cara, ¿no?» (131:02, z = +5,7).

**El arco por temas** (cálculo propio con las frases de cada tramo). El tono de la invitada sube en inmigración (170 Hz, 102 frases) y baja en rivales (156 Hz, 41 frases), gestión pasada (159 Hz) y trenes (159 Hz). Habla más deprisa en vivienda (234 palabras/min) y más despacio en fronteras y Marruecos (212). El bloque de diez minutos con la voz más intensa es el 100–110 (ocupación) y el más apagado el 40–50 (accidentes ferroviarios).

**Voz bajo presión** (cálculo propio: cada frase se asigna a la última pregunta de Jordi que la precede):

| | Tras pregunta dura (577 frases) | Resto (123 frases) | Tamaño del efecto |
|---|---|---|---|
| Tono | 164,7 Hz | 162,6 Hz | d = 0,14 (inapreciable) |
| Volumen | 69,7 dB | 69,5 dB | d = 0,08 (inapreciable) |
| Velocidad | 226,5 palabras/min | 214,4 palabras/min | d = 0,23 (pequeño) |
| Trabas por 100 palabras | 0,33 (40 trabas) | 0,04 (1 traba) | — |

La voz de la invitada es prácticamente la misma con pregunta dura que sin ella; solo acelera un poco y se traba más. La investigación sobre voz y emoción (**Scherer, 2003**) asocia la activación alta con subidas de tono y volumen: aquí no se observan. Límite: como el 83 % de las preguntas son duras, el grupo de comparación es pequeño.

## 6. Cara

La cara se describe con unidades de acción (AU) del sistema **FACS (Ekman y Friesen, 1978)**: movimientos de músculos, sin etiquetas de emoción. Cada persona se compara con su propia cara de base.

La cámara enseña más a la invitada: 84,0 minutos con su cara en pantalla frente a 60,4 de Jordi (1,4 veces más). A ella casi no se la ve escuchar (5,9 minutos); a Jordi, 13,2.

| Gesto (episodios por cada 10 min en pantalla) | La invitada | Jordi Wild |
|---|---|---|
| AU6 + AU12 (sonrisa: mejillas y comisuras arriba) | 30,5 | 25,7 |
| AU5 (párpado superior arriba, ojos más abiertos) | 32,8 | 22,2 |
| AU4 (cejas bajan y se juntan) | 10,6 | 0,5 |
| AU1 + AU2 (cejas arriba) | 1,0 | 12,7 |
| AU17 (mentón arriba) | 0,0 | 7,6 |

Cada uno tiene un gesto propio. En la invitada es AU4: 89 episodios, todos mientras habla (12,3 por 10 min hablando, 0 escuchando), 21 de ellos en el bloque de fronteras y Marruecos (cálculo propio). En Jordi es AU1 + AU2: 77 episodios, sobre todo al hablar (15,9 frente a 3,0 al escuchar), es decir, al preguntar. La AU6 + AU12 aparece con frecuencia parecida en los dos; en ella igual al hablar que al escuchar (30,8 y 27,0), en él más al hablar (27,0 frente a 15,1).

Al hablar, las cejas de la invitada quedan un 11 % más altas que cuando escucha, y las de Jordi un 3 %. La cabeza de ambos gira más rápido al hablar (14,5 frente a 9,4 grados por segundo en ella; 12,8 frente a 8,8 en él). La cara acompaña poco a la voz: ninguna correlación entre rasgos faciales e intensidad vocal pasa de 0,25.

![40:59, la invitada](fotogramas/m06_durante.jpg)
*40:59. La invitada mientras dice «Primero tienes que investigar.». El sistema marca AU24 (labios presionados) por encima de su base.*

![61:53, Jordi Wild](fotogramas/e06_durante.jpg)
*61:53. Jordi Wild al preguntar «¿endurecerías las relaciones?». AU1, AU2 y AU5 muy por encima de su base (z de +4,0 a +4,9).*

Una AU4 o una AU12 se pueden medir; su significado, no. Además, la base de cada cara se calcula con esta misma entrevista, y los dos están grabados con la cabeza girada unos 40 grados, lo que resta precisión.

## 7. Las preguntas y cómo se responden

### Cómo pregunta Jordi

| Dureza | Intervenciones | % |
|---|---|---|
| Repregunta | 70 | 37 % |
| Incómoda | 43 | 23 % |
| Insistencia (tercera vez o más) | 43 | 23 % |
| Neutra | 29 | 16 % |
| Cómoda | 2 | 1 % |

Son 14,1 intervenciones por cada 10 minutos, 11,7 de ellas duras (con Feijóo, 12,8 y 9,9). La premisa va en contra de la invitada en 95 (51 %), es neutra en 89 y a favor en 3. Es un patrón parecido al que **Clayman y Heritage (2002)** midieron en ruedas de prensa presidenciales de Estados Unidos, no en entrevistas: preguntas con iniciativa, directas, asertivas y hostiles. Jordi se queda con la última palabra en 11 intercambios; ella, en 176.

### Cómo responde la invitada

| Clase de respuesta | Todas (187) | Solo a duras (156) |
|---|---|---|
| Responde a lo preguntado | 121 (65 %) | 94 (60 %) |
| Responde en parte | 33 (18 %) | 30 (19 %) |
| Contesta a otra pregunta | 27 (14 %) | 26 (17 %) |
| Ataca la pregunta | 1 (1 %) | 1 (1 %) |
| Jordi no deja contestar | 5 (3 %) | 5 (3 %) |

No cambia de tema ninguna vez. Las cifras de Feijóo con el mismo criterio son casi iguales (64 % y 60 %). Por tipo de pregunta: a las incómodas responde 21 de 43; a las repreguntas, 50 de 70; a las insistencias, 23 de 43.

Los políticos dejan sin respuesta directa una parte grande de las preguntas (más de la mitad en el estudio clásico de **Bull y Mayer, 1993**, sobre Thatcher y Kinnock), y los oyentes a menudo no lo notan cuando la respuesta trata un asunto parecido (**Rogers y Norton, 2011**, en experimentos con vídeos de debates).

**Temas donde menos contesta a lo preguntado:** corrupción (6 de 14 intervenciones, 43 %), partido interno (4 de 15, 27 %), inmigración (4 de 19, 21 %) y vivienda (5 de 24, 21 %). En rivales, política internacional, feminismo, pactos y defensa, 0.

### Las cinco secuencias de más tensión

1. **Corrupción (22:45–27:21).** Jordi pregunta siete veces lo mismo: «¿hubieras sacado a tu coalición de este gobierno cuando salta lo de Ábalos y Cerdán?». Respuestas sucesivas: «tanto yo personalmente en mis redes como Sumar manifestamos tolerancia cero a la corrupción»; «A ver, es difícil decirlo siempre desde fuera, ¿no?». Jordi: «¿Sí o no la respuesta?» y «Pero eso es lo que la gente de The World Project [The Wild Project] quiere escuchar, que os mojéis.». Al final: «Habría, o no me habría ido, o habría puesto más exigencias a lo mejor.» (27:11).
2. **Machismo e inmigración (75:31–78:20).** Ella: «Hay este año 44 asesinatos de mujeres por parte de hombres» y «Hombre, díselo a las familias de estas 44 asesinadas, que son pocas.». Jordi: «Eso es demagogia. Lo estoy diciendo con pena, ojalá fueran cero.». Es el único cruce de reproches directo.
3. **Autocrítica (87:40–90:52).** Pregunta: «¿Cuál es el gran error que cometiste?». Respuesta: «creo que es justo decirlo, hubo una campaña de desprestigio increíble». Jordi: «Pero te he pedido autocrítica y no me has dicho ni una.». Entonces da dos: «A finales del segundo mandato aceptar la Copa América» y, sobre la recogida selectiva, «nos hemos equivocado porque esto en otro momento era buena idea,».
4. **Hurtos y extranjeros (94:53–97:39).** Jordi: «Nueve de cada diez detenciones por hurto en 2024 fueron extranjeros.». Ella: «¿Qué fuente es ese dato?». Un verificador del programa lee en directo: «El 91 % de los detenidos por hurto en Barcelona son extranjeros.». Ella acepta el dato y contesta a otra cosa: «lo importante no es dónde se ha nacido, lo importante es que si alguien la hace,».
5. **Ocupación (102:55–108:18).** Ocho intervenciones seguidas pidiendo un plazo: «¿Cuánto tiempo en tu España ideal, en la que si tú ganas, en cuánto tiempo echas a los ocupas?». Respuestas: «Creo que lo mejor que te puedo explicar es lo que hicimos en Barcelona.»; «es expropiar los pisos vacíos que tienen bancos y fondos de inversión»; para la mediación, «en pocas semanas realojar»; para la ocupación delictiva, «para mí tiene que ser lo más rápido posible», sin plazo.

**Preguntas devueltas.** Seis veces contesta preguntando, por ejemplo «Y entonces, ¿quién gobierna España?» (35:45) y «¿Y cuál me harías tú?» (127:38). Feijóo lo hizo 18 veces.

### Temas

| Tema | Minutos | % |
|---|---|---|
| Inmigración | 20,3 | 15 % |
| Vivienda | 17,3 | 13 % |
| Fronteras y Marruecos | 15,2 | 11 % |
| Trayectoria y gestión pasada | 14,4 | 11 % |
| Infraestructuras (trenes) | 10,0 | 8 % |
| Corrupción | 9,9 | 8 % |
| Rivales | 6,0 | 4 % |
| Política internacional | 5,7 | 4 % |
| Partido interno | 5,0 | 4 % |
| Resto (9 temas) | 29,0 | 22 % |

Jordi abre 26 de los 32 tramos; la invitada, 6 (10,7 minutos, el 8 % del tiempo): el desahucio de Mari Carmen, la reforma fiscal, el *lawfare*, el atentado de la Rambla, los verificadores y la aportación de los inmigrantes a la Seguridad Social. No aparecen pensiones, deuda y gasto, Cataluña y modelo territorial, juventud, ni clima y energía; tampoco sanidad ni educación. Quien elige los temas influye en qué asuntos considera importantes la audiencia (**fijación de agenda, McCombs y Shaw, 1972**), y los partidos procuran llevar el debate a los temas en que el público los percibe como más competentes (**propiedad de los temas, Petrocik, 1996**): aquí los dos temas más largos son uno que saca Jordi con premisa adversa (inmigración) y otro asociado a la invitada (vivienda).

### Ataque frente a propuesta, mérito y culpa

En 71 respuestas (38 %) habla de rivales o terceros; en 39 (21 %) dice qué hizo o haría; en 31 (17 %), las dos cosas; en 46, ninguna. Los más nombrados al hablar de terceros: Pedro Sánchez 11, PSOE 11, Vox 10, PP 9, Podemos 8.

| De qué habla | yo | nosotros | ellos | el Gobierno | impersonal |
|---|---|---|---|---|---|
| Logros (16) | 2 | 8 | 4 | 2 | 0 |
| Fracasos (13) | 0 | 3 | 7 | 3 | 0 |
| Problemas (21) | 0 | 0 | 15 | 0 | 6 |

Los logros van con *nosotros* («compramos 1 .600 viviendas a precio inferior», 100:20; «podemos responder que tenemos cero casos de corrupción», 25:00) y los fracasos y problemas, sobre todo con *ellos* o en impersonal («PP, Junts y Vox tumbaron esos decretos», 12:52). Ningún fracaso lleva *yo*; los tres propios van en plural, como «uno de los errores que hemos cometido las izquierdas en los últimos años es, sí, ser demasiado moralistas» (132:10). Atribuirse los éxitos es un patrón bien documentado; que además se sitúen fuera los fracasos lo está menos (el trabajo clásico de **Miller y Ross, 1975**, lo puso en duda; revisiones posteriores, como **Zuckerman, 1979**, sí lo encuentran). En política se ha descrito además que se tiende a priorizar evitar la culpa sobre reclamar el mérito (**Weaver, 1986**). Aquí solo se cuenta con qué sujeto se dice cada cosa. Pasado frente a futuro no se pudo medir con una herramienta fiable.

### Promesas verificables

Se recogieron 29 compromisos; 8 tienen un objeto que se podrá comprobar (0,6 por cada 10 minutos; Feijóo, 2,3).

| Minuto | Cita | Compromiso |
|---|---|---|
| 6:21 | «yo personalmente no voy a volver a Twitter respondiendo a tu pregunta» | No volver a usar Twitter a título personal |
| 98:20 | «no solo congele sino baje los precios de los alquileres y también ayude a los pequeños propietarios» | Regulación que congele y baje alquileres |
| 99:53 | «yo creo que esas 100 .000 viviendas de esos 13 fondos hay que recuperarlas y pasarlas al parque público» | Pasar al parque público las viviendas de 13 fondos |
| 109:37 | «pues un impuesto del 10 % del valor de esa vivienda para movilizar, pero no para recaudar,» | Impuesto del 10 % a grandes propietarios con vivienda vacía o precio abusivo |
| 110:01 | «entra la administración pública para garantizar que se pague ese alquiler» | Garantía pública de cobro al pequeño propietario |
| 114:00 | «Me gustaría hacerlo y evidentemente sé que no lo podría hacer de la noche a la mañana.» | Cerrar las bases militares de EE. UU. (como deseo) |
| 120:24 | «Sobre todo romper las relaciones comerciales.» | Romper relaciones comerciales con Israel |
| 120:34 | «Totalmente romper todo tráfico de armas.» | Romper el tráfico de armas con Israel |

Ninguno lleva fecha. Los 21 restantes son intenciones generales o condicionadas, como «sería imprudente que yo ahora te diga acciones concretas sin estar en el gobierno» (62:14).

### Sintonía

La transcripción automática no recoge risas, así que este apartado sale de la lectura manual: 61 momentos de relación. Hay 15 bromas (10 las inicia Jordi), 12 roces (10 de Jordi), 9 halagos, 8 acuerdos explícitos y 5 anécdotas personales. Jordi mezcla el halago con la objeción: «Yo creo que tú crees lo que predicas.» (32:58) y, más tarde, «es que me parecen casi unos excursionistas que van de excursión,» (118:38). Ella: «soy tu conejilla de indias para las próximas entrevistas» (84:52) y, al cierre, «habías dicho que sería duro ha sido muy duro» (130:19).

## 8. Comprobación de datos

Se comprobaron 118 afirmaciones factuales (77 de la invitada y 41 de Jordi) con buscador web el mismo 13-nov-2026.

| Veredicto | La invitada | Jordi Wild |
|---|---|---|
| Se sostiene (respaldada) | 43 | 30 |
| Verdad a medias (respaldada en parte o imprecisa) | 21 | 7 |
| No se sostiene (sin respaldo) | 2 | 0 |
| No verificable | 3 | 0 |
| No se pudo comprobar | 8 | 4 |
| Total comprobadas | 77 | 41 |

**Esto no es una nota, y comparar porcentajes entre los dos no es válido:** hablan de cosas distintas (ella, de su gestión y de terceros; él lee datos preparados) y varias filas repiten un mismo dato. Además, **solo 40 de las 118 filas (27 de ella y 13 de él) tienen la fuente abierta de verdad**; el resto se apoya en extractos del buscador y hay que abrir el enlace antes de citarlo. Los dos veredictos negativos pasaron una segunda revisión con las fuentes abiertas.

**No se sostienen (2, de la invitada):**

- 45:35 — «no han dimitido nunca cuando les han pasado cosas incluso más graves como lo de la DANA». Carlos Mazón (PP) anunció su dimisión el 3-11-2025 vinculándola a la DANA; lo hizo un año después y conservó el escaño. [Fuente](https://orain.eus/es/politica/2025/11/03/mazon-dimite-presidente-la-generalitat-valenciana/).
- 122:06 — «O sea, ha dicho que bajara las pensiones, que bajara el salario mínimo.» (sobre Feijóo). No se localizó ninguna declaración así y sí en sentido contrario. [Fuente](https://www.democrata.es/politica/feijoo-insiste-en-que-la-subida-de-las-pensiones-con-el-ipc-es-innegociable-y-quiere-cerrar-la-polemica-se-acabo/).

**Verdades a medias (ejemplos):**

- La invitada, 88:48 — «O sea, aumentamos miles de agentes de Guardia Urbana.». Hubo aumento, de unos 2.800–3.000 a unos 3.400–3.500 agentes, no de miles (solo extracto). [Fuente](https://www.csif.es/es/articulo/cataluna/general/93888).
- La invitada, 28:22 — «a mí me han puesto más de 22 querellas». Son 22 causas archivadas contra ella y su gobierno en conjunto. [Fuente](https://es.ara.cat/sociedad/barcelona/acaba-via-crucis-judicial-gobierno-colau_1_5313128.html).
- La invitada, 105:29 — «Si es tu vivienda, ahora mismo, con la ley, desaloja en el mismo día.». Solo si el delito es flagrante; si no, hace falta juez (solo extracto). [Fuente](https://www.idealista.com/news/node/825725).
- Jordi, 38:31 — «Ábalos llegó a ser ministro de Transportes, poco tiempo, pero lo fue.». Lo fue tres años (solo extracto). [Fuente](https://es.ara.cat/politica/supremo-condena-exministro-abalos-24-anos-prision_1_5776792.html).
- Jordi, 25:24 — «tenemos el caso del expresidente de Portugal que dimitió por un caso». António Costa era primer ministro y él mismo estaba investigado (solo extracto). [Fuente](https://maldita.es/malditateexplica/20231107/dimite-antonio-costa-preguntas-respuestas/).
- Jordi, 115:59 — «ha habido una fragata que os ha acompañado». Fue un patrullero, el Furor (solo extracto). [Fuente](https://www.menorca.info/actualidad/nacional/2025/09/25/2477393/buque-furor-patrullero-enviado-por-gobierno-para-apoyar-flotilla-dirige-gaza.html).

**Se sostienen (ejemplos):**

- La invitada, 75:59 — «Hay este año 44 asesinatos de mujeres por parte de hombres». [Fuente](https://www.lamoncloa.gob.es/serviciosdeprensa/notasprensa/igualdad/Paginas/2026/301026-condena-feminicidio-barcelona.aspx).
- La invitada, 49:14 — «70 .000 personas no se mueven sin que se dé cuenta el gobierno de Marruecos» (la cifra). [Fuente](https://elfarodeceuta.es/marlaska-niega-cni-avisara-entrada-masiva-ceuta-confirma-72-000-personas-cruzaron-marruecos/).
- Jordi, 95:00 — «Nueve de cada diez detenciones por hurto en 2024 fueron extranjeros.» (en Barcelona; solo extracto). [Fuente](https://maldita.es/buloteca/claim/El-83-de-los-detenidos-por-robos-con-violencia-y-el-91-por-hurtos-en-Barcelona-son-extranjeros).
- Jordi, 86:28 — «Llegaste al punto más bajo en julio de 2022 de 4 ,1 de valoraciones,». [Fuente](https://es.ara.cat/sociedad/colau-suspende-peor-nota-ganaria-elecciones-barometro_1_4423876.html).

## 9. Momentos clave

Momentos en que coinciden varias señales a la vez. Que coincidan no demuestra que estén relacionadas, y de ninguno se deduce una intención.

**30:04 — Zapatero.** Pregunta incómoda; ella dice «no tengo ningún indicio de que sea culpable, no sé, lo están investigando.», hace una pausa de 1,7 s y sigue. El volumen baja mucho (z = −3,3) y la velocidad también (z = −1,5).

![30:04](fotogramas/m04_durante.jpg)

**35:13 — La promesa incumplida.** «Pedro Sánchez me prometió en el 2019 regular los alquileres.». Suben el tono (z = +2,0) y el volumen (z = +1,7), baja la velocidad (z = −1,6) y AU7 (párpados tensos) queda por encima de su base.

**40:59 — Responsabilidades por el accidente.** A «¿Y qué responsabilidades asumieron?» contesta «Primero tienes que investigar.». Tono arriba (z = +1,6), velocidad abajo (z = −1,5), AU24 por encima de su base. Fotograma en la sección 6.

**100:49 — Expropiar.** «En ese sentido sí que es expropiar.». Pausa de 1,1 s, tono y velocidad arriba (z = +1,5 y +2,0), AU6 y AU12 por encima de su base (z = +2,9 y +2,1).

**106:25 — El plazo de la ocupación.** «Puede tardar una semana, dos semanas, tres o un mes, pero encuentra...». Es la frase más rápida de las seleccionadas (z = +2,9), con el volumen arriba (z = +1,7), y acaba cortada.

![106:25](fotogramas/m13_durante.jpg)

**129:20 — Si es mejor persona que sus rivales.** A «¿Crees que eres mejor persona?» responde «A ver, intentaría no llevarlo a personal en general,». Es la bajada de volumen más fuerte de sus momentos (z = −3,7) y la AU6 + AU12 más marcada (z = +5,3 y +4,7). En ese instante la realización enfoca a Jordi; el fotograma es de unos segundos después.

![129:20, segundos después](fotogramas/m15_despues.jpg)

**Jordi, 22:59 — La pregunta sobre Ábalos.** La pausa más larga de su entrevista (2,3 s), el tono baja (z = −1,6) y enumera en tres: «Persona, un exministro y un entramado». Las listas de tres son un recurso clásico para que una frase suene completa (**Atkinson, 1984**).

**Jordi, 95:20 — El dato sin enlace.** «hurtos, 9 de cada 10.» y «Lo que pasa es que no lo tengo linkado». Tono arriba (z = +1,8) y AU1 + AU2 por encima de su base (z = +2,6 y +3,5).

## 10. Por qué cada espectador vio una entrevista distinta

Dos personas que ven lo mismo no ven lo mismo. Tres mecanismos bien documentados lo explican, y esta entrevista da material a ambos lados.

**Sesgo de confirmación (Nickerson, 1998) y asimilación sesgada (Lord, Ross y Lepper, 1979).** Tendemos a quedarnos con el dato que encaja con lo que ya pensábamos. Un votante afín a la invitada citará que responde al 65 % de las intervenciones, que no cambia de tema ni una vez y que 43 de sus afirmaciones se sostienen. Uno contrario citará que en corrupción no contesta a lo preguntado 6 de 14 veces, las siete repreguntas sobre Ábalos y las dos afirmaciones sin respaldo.

**Razonamiento motivado (Kunda, 1990).** Exigimos más pruebas a lo que nos contradice. El mismo intercambio del minuto 77 será, para unos, una defensa de las víctimas («Hombre, díselo a las familias de estas 44 asesinadas, que son pocas.») y, para otros, lo que dijo Jordi: «Eso es demagogia.». Y el dato de los hurtos (95:00) será para unos la prueba de un problema y para otros un dato que ella aceptó sin que cambie el fondo.

**Efecto de medio hostil (Vallone, Ross y Lepper, 1985).** Los partidarios de cada bando perciben la misma cobertura informativa como sesgada contra el suyo; aplicarlo a un entrevistador es una extensión. Quien simpatice con la invitada verá hostilidad en que el 83 % de las preguntas fueran duras y en que Jordi cortara la mitad de sus respuestas. Quien no, verá complacencia en los nueve halagos, en que ella cerrara 176 de 187 intercambios y en que hablara el 63,7 % del tiempo. La comparación disponible dice que la proporción de preguntas duras fue algo mayor que con Feijóo (83 % frente a 77 %).

También influye el **encuadre (Entman, 1993)**: la propia invitada lo nombra cuando dice «Yo creo que es un error comprar el marco de la derecha» (64:23). Quien acepte el marco de Jordi (la inmigración como preocupación) oirá evasivas; quien acepte el de ella (la convivencia), oirá respuestas.

## 11. Lo que este análisis no puede decir

- **Transcripción automática.** Tiene cuatro huecos sin texto (unos 95 segundos en total), nombres mal escritos («loafer» por *lawfare*, «Caetana», «The World Project») y más de 20 frases cortas de Jordi atribuidas a la invitada donde se pisan las voces. El recuento de repreguntas de Jordi queda, por eso, algo por debajo del real. Solo se usa el 87 % de las palabras, las verificadas por huella de voz.
- **Pausas.** El detector acústico confirma menos del 7 %. Son huecos entre palabras, no silencios comprobados.
- **Caras.** El programa no está calibrado por persona, los dos salen con la cabeza girada unos 40 grados y la realización decide a quién se ve. La asignación de caras se hizo a mano sobre 10 grupos, y dos de ellos incluyen algún recorte suelto de otra persona. A la invitada casi no se la ve escuchar.
- **Lectura de preguntas y respuestas.** La hizo un solo codificador, con la regla de elegir la clase más favorable al invitado en caso de duda. Otra persona clasificaría distinto algunos casos.
- **Comprobación de datos.** Dos tercios de las filas descansan en extractos, no en la fuente abierta, y varios hechos de 2026 dependen de uno o dos medios.
- **Referencias.** Los estudios citados describen efectos medios, muchos medidos en laboratorio y en inglés; no predicen lo que hará o pensará un espectador concreto.
- **Verdad.** Nada de lo medido sirve para saber si alguien dice la verdad, qué siente o cómo es. Es una sola entrevista.

## 12. Para llevarte a casa

1. **Fue una entrevista de repreguntas.** 156 de 187 intervenciones de Jordi fueron duras (83 %), con 70 repreguntas y 43 insistencias.
2. **La invitada contestó a lo preguntado seis de cada diez veces** ante preguntas duras (94 de 156) y nunca cambió de tema; cuando no contestó, respondió a una pregunta vecina (27 veces).
3. **Donde menos contestó fue en corrupción** (6 de 14) y en los plazos de la ocupación (ocho peticiones de plazo seguidas).
4. **Su voz no cambia bajo presión** (tono d = 0,14; volumen d = 0,08); sí se traba más (0,33 frente a 0,04 por 100 palabras) y acelera un poco (d = 0,23).
5. **Logros en *nosotros*, problemas en *ellos*.** 8 de 16 logros con *nosotros*; 22 de 34 fracasos y problemas con *ellos*; ningún fracaso con *yo*.
6. **Pocas promesas comprobables:** 8 de 29, ninguna con fecha.
7. **En los datos, más aciertos que fallos en los dos,** con dos afirmaciones de la invitada sin respaldo y ninguna de Jordi; pero solo 40 de 118 filas tienen la fuente abierta, y no es una nota.

## 13. Fuentes

**Vídeo.** *The Wild Project #391 - Ada Colau*, YouTube, 13-nov-2026: https://www.youtube.com/watch?v=-ESmAhdixfo

**Referencias académicas.**

- Atkinson, M. (1984). *Our Masters' Voices: The Language and Body Language of Politics*. Methuen.
- Bull, P. y Mayer, K. (1993). How not to answer questions in political interviews. *Political Psychology*, 14(4), 651-666.
- Clayman, S. y Heritage, J. (2002). Questioning presidents: Journalistic deference and adversarialness in the press conferences of U.S. Presidents Eisenhower and Reagan. *Journal of Communication*, 52(4), 749-775.
- DePaulo, B. M. et al. (2003). Cues to deception. *Psychological Bulletin*, 129(1), 74-118.
- Ekman, P. y Friesen, W. V. (1978). *Facial Action Coding System*. Consulting Psychologists Press.
- Entman, R. M. (1993). Framing: Toward clarification of a fractured paradigm. *Journal of Communication*, 43(4), 51-58.
- Goldman-Eisler, F. (1968). *Psycholinguistics: Experiments in Spontaneous Speech*. Academic Press (editorial no confirmada).
- Kunda, Z. (1990). The case for motivated reasoning. *Psychological Bulletin*, 108(3), 480-498.
- Lord, C. G., Ross, L. y Lepper, M. R. (1979). Biased assimilation and attitude polarization: The effects of prior theories on subsequently considered evidence. *Journal of Personality and Social Psychology*, 37(11), 2098-2109.
- McCombs, M. E. y Shaw, D. L. (1972). The agenda-setting function of mass media. *Public Opinion Quarterly*, 36(2), 176-187.
- Miller, D. T. y Ross, M. (1975). Self-serving biases in the attribution of causality: Fact or fiction? *Psychological Bulletin*, 82(2), 213-225.
- Nickerson, R. S. (1998). Confirmation bias: A ubiquitous phenomenon in many guises. *Review of General Psychology*, 2(2), 175-220.
- Petrocik, J. R. (1996). Issue ownership in presidential elections, with a 1980 case study. *American Journal of Political Science*, 40(3), 825-850.
- Rogers, T. y Norton, M. I. (2011). The artful dodger: Answering the wrong question the right way. *Journal of Experimental Psychology: Applied*, 17(2), 139-147.
- Sacks, H., Schegloff, E. A. y Jefferson, G. (1974). A simplest systematics for the organization of turn-taking for conversation. *Language*, 50(4), 696-735.
- Scherer, K. R. (2003). Vocal communication of emotion: A review of research paradigms. *Speech Communication*, 40(1-2), 227-256.
- Vallone, R. P., Ross, L. y Lepper, M. R. (1985). The hostile media phenomenon: Biased perception and perceptions of media bias in coverage of the Beirut massacre. *Journal of Personality and Social Psychology*, 49(3), 577-585.
- Weaver, R. K. (1986). The politics of blame avoidance. *Journal of Public Policy*, 6(4), 371-398.
- Zuckerman, M. (1979). Attribution of success and failure revisited, or: The motivational bias is alive and well in attribution theory. *Journal of Personality*, 47(2), 245-287.

**Archivos de datos (carpeta de la entrevista).** `informe.md`, `informe_tonalidad.md`, `informe_expresiones.md`, `informe_movimiento.md`; `transcripcion.csv`, `palabras.csv`, `qa_pares.csv`, `hablantes.json`; `disfluencias_resumen.csv`, `disfluencias_eventos.csv`; `pausas_entrevistado.csv`, `pausas_entrevistador.csv`; `voz_entrevistado.csv`, `voz_entrevistador.csv`, `tonalidad_entrevistado.csv`, `tonalidad_entrevistador.csv`; `retorica.csv`; `cara_entrevistado.csv`, `cara_entrevistador.csv`, `expresiones_resumen.csv`, `expresiones_eventos.csv`, `movimiento_resumen.csv`; `comparativa.csv`, `momentos_entrevistado.csv`, `momentos_entrevistador.csv`, `fotogramas/`; `lectura/` (`preguntas.json`, `temas.json`, `afirmaciones.json`, `promesas.json`, `merito_culpa.json`, `sintonia.json`, `resumen.md`); `verificacion_datos.md` y `verificacion_datos.csv` (versión revisada); comparación con otras entrevistas en `comparacion/v3/` y `comparacion/lectura/`.
