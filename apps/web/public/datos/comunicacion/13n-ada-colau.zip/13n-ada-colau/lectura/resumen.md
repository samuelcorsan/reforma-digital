# Lectura de la entrevista a Ada Colau (The Wild Project, 13-nov-2026)

Entrevista clasificada: 1:23-134:11 (la introducción común 0:00-1:23 no se clasifica). 187 intervenciones de Jordi que piden respuesta.

## Recuentos
- **Dureza:** repregunta 70 · incómoda 43 · insistencia 43 · neutra 29 · cómoda 2.
- **Premisa:** en contra 95 · neutra 89 · a favor 3.
- **Respuesta:** responde 121 · en_parte 33 · otra_pregunta 27 · sin_respuesta 5 · ataca_pregunta 1 · cambia_tema 0.
- **Respuesta a las 156 duras:** incómodas: responde 21, otra_pregunta 14, en_parte 8 · repreguntas: responde 50, en_parte 10, otra_pregunta 5, sin_respuesta 5 · insistencias: responde 23, en_parte 12, otra_pregunta 7, ataca_pregunta 1.
- **Orientación:** critica 71 · ninguna 46 · propone 39 · ambas 31. Devuelve la pregunta 6 veces. Cierra el intercambio: invitada 176, Jordi 11.
- **Otros archivos:** 126 afirmaciones, 29 promesas (8 verificables), 50 atribuciones de mérito o culpa, 61 momentos de sintonía.
- **Tiempo por tema (s):** inmigración 1219 · vivienda 1039 · fronteras y Marruecos 911 · trayectoria y gestión pasada 862 · servicios (trenes) 600 · corrupción 595 · rivales 359 · internacional 342 · partido interno 300 · pactos 288 · formato 288 · feminismo 278 · cierre 241 · medios y redes 235 · personales 189 · defensa 105 · economía 70 · impuestos 47.

## Los cinco momentos de más tensión
1. **22:45-27:21, corrupción.** Jordi vuelve siete veces sobre si habría sacado a su coalición del gobierno por el caso Ábalos-Cerdán ("¿Sí o no la respuesta?", "que os mojéis"). Respuestas: tolerancia cero, "depende", "es difícil decirlo desde fuera"; al final, "o no me habría ido, o habría puesto más exigencias".
2. **75:31-78:20, machismo e inmigración.** Ella cita 44 asesinatos machistas y dice "díselo a las familias"; Jordi contesta "Eso es demagogia". Único cruce de reproches directo.
3. **87:40-90:52, autocrítica como alcaldesa.** Al "gran error" responde con la pandemia y una "campaña de desprestigio"; Jordi: "te he pedido autocrítica y no me has dicho ni una". Da después dos errores (Copa América, recogida selectiva).
4. **94:53-97:39, hurtos y extranjeros.** Al dato de "nueve de cada diez" ella pregunta año y fuente; el verificador lo confirma en directo; ella lo acepta y no contesta al porqué.
5. **102:55-108:18, ocupación.** Ocho intervenciones seguidas pidiendo un plazo de desalojo; ella contesta varias veces con lo que hizo en Barcelona y da "un mes o dos meses" y "pocas semanas" solo para el caso de mediación.
También: 19:11-19:59 (por qué Podemos no quiso sentarse: "tendrías que preguntar a ellos") y 115:30-119:54 (flotilla: "unos excursionistas").

## Temas que la invitada introduce por su cuenta
Desahucio de Mari Carmen y decretos de vivienda tumbados (11:21) · reforma fiscal y Florentino Pérez (15:56) · lawfare y sus 22 querellas archivadas (27:44) · 15M, bipartidismo y puertas giratorias (32:01) · modelo de liberalización ferroviaria (38:46) · atentado de la Rambla (46:26) · acogida de refugiados ucranianos (51:49) · aportación de los inmigrantes a la Seguridad Social y llamada a los verificadores (84:04) · autocrítica de "las izquierdas moralistas" en el alegato (131:58).

## Temas de la lista que no aparecen
`pensiones`, `deuda_y_gasto`, `cataluna_y_territorial`, `juventud`, `clima_y_energia` (y `otros`). Pensiones, jóvenes y procés solo se mencionan de pasada; `sanidad_educacion_servicios` se usa para el bloque ferroviario, no hay sanidad ni educación.

## Convenciones aplicadas (para comparar con las otras dos lecturas)
- Evasiva sin contenido ("pregúntales a ellos", "es difícil decirlo desde fuera", devolver la pregunta) = `otra_pregunta`, con nota.
- `sin_respuesta` (5): tres objeciones de Jordi que cambia de tema él mismo y dos cortes a media frase.
- `critica` incluye menciones no negativas a terceros (anotado). El bloque sobre el trato a la mujer (74:49-79:27) va como `feminismo_e_igualdad`.

## Problemas de la transcripción
- **Cuatro huecos sin texto:** tres de 27-29 s (5:32-5:59, 93:21-93:48, 110:44-111:13) y uno de 11 s (71:45-71:56). Cuatro preguntas quedan marcadas `dudoso`.
- **Voces pisadas:** más de 20 frases cortas de Jordi figuran en líneas de la invitada ("¿Y se quedan?", "¿Tipo?", "¿Y por qué quieres contarte con ellos?", "tienes que vender un poco el alma al diablo", "Lo marcaría el gobierno el precio", "O sea, expropiarlas", "¿Pero tú te podrías haber negado?", "Pero al final Israel no hizo nada"...) y alguna de ella en líneas de Jordi ("No, no me arrepiento", "Sí"). No se han usado como cita; se indican en `nota`.
- **Verificador:** su intervención (95:54-96:02, "El 91 %...") figura como hablante `otros`, mezclada con el inicio de la respuesta de ella.
- **Nombres mal transcritos:** "Adam Woods" (lugar del primer accidente), "Ada Polau", "Caetana", "Milley"/"Mi ley", "Abasal"/"a Pascal", "Feijo", "Nucleonacional", "Desocupa", "Vizcal"/"Marcia y Martínez" (por Martinenc), "Javier Goyado" (antes Collado), "jueza Ayala", "The World Project", "loafer" (lawfare), "La Habana" (por la DANA), "BP y Vox" (PP), "Rodalías", "San Andreu", "15M del 2015".
