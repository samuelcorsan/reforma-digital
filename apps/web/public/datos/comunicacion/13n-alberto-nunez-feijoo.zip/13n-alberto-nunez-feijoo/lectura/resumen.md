# Lectura: Jordi Wild entrevista a Alberto Núñez Feijóo (88 min; entrevista de 1:23 a 88:19)

## Recuentos (111 intervenciones de Jordi que piden respuesta; 18 marcadas `dudoso`)
- **Dureza**: repregunta 38 · incomoda 26 · neutra 23 · insistencia 22 · comoda 2.
- **Premisa**: neutra 54 · en_contra 53 · a_favor 4.
- **Respuesta**: responde 71 · en_parte 18 · otra_pregunta 16 · cambia_tema 3 · sin_respuesta 2 · ataca_pregunta 1.
- En las 86 duras (incomoda + repregunta + insistencia): responde 52 · en_parte 15 · otra_pregunta 13 · cambia_tema 3 · sin_respuesta 2 · ataca_pregunta 1.
- **Orientación**: ninguna 36 · critica 30 · propone 27 · ambas 18. Más nombrados: Pedro Sánchez 28, Gobierno 15, PSOE 6, Marruecos 4, Vox 3.
- Devuelve la pregunta a Jordi en 18 intercambios. Cierra el invitado 96 y Jordi 15 (solo se cuenta `jordi` si corta la respuesta o añade un comentario que no es la siguiente pregunta).
- Otros archivos: 171 afirmaciones (22 de Jordi), 40 promesas (20 verificables), 60 frases de mérito/culpa, 60 momentos de sintonía, 37 tramos de tema.
- En 7 clasificaciones había duda entre dos clases y se aplicó la regla de elegir la más favorable (anotado en `nota`). Tres respuestas son `otra_pregunta` por "evasiva sin contenido" (4:50, 75:40, 76:14).

## Cinco momentos de más tensión
1. **61:22-63:55, Sánchez y la prostitución.** Jordi plantea "La misma foto, y él explica lo mismo"; el invitado pregunta si las primarias de Sánchez se pagaron con dinero de la prostitución. Jordi: "A mí no me lo tienes que preguntar", "aquí habéis jugado sucio todos", "es una acusación muy grave", "¿eso es una pregunta o es una afirmación?". Habla solapada todo el tramo.
2. **75:40-77:50, piso de 6,7 millones.** Siete intervenciones seguidas sobre el precio (5 de insistencia): "yo no entro de precio", "Yo no quiero hablar de eso porque no quiero mentir", pregunta por la sede de la Generalitat y por los lectores de DNI. Lo corta el aviso de su equipo.
3. **24:07-25:17, edad de jubilación.** Tras "no tenemos previsto ampliar", Jordi insiste ("no tener previsto no [es] asegurarlo"); el invitado protesta ("primero me haces unas preguntas...") y acaba en "no vamos a ampliar la edad de jubilación".
4. **59:22-61:15, Marcial Dorado.** "¿Erais amigos?" y "un meeting es una cosa y una foto en yate o barco es otra"; contesta "yo soy responsable de mi biografía" y "Yo no sé lo que vas a hacer dentro de 5 años"; la explicación completa llega en 60:33.
5. **63:55-67:30, Gürtel.** "¿Tú ahí también habrías pedido la dimisión?" no recibe un sí o un no en tres intentos; el invitado pasa a Filesa, Ábalos y Cerdán. Parte del intercambio se pierde en un hueco.
- También: 43:58 "¿Das orden de si hace falta disparar?" ("eso es una trampa") y 49:16, la pregunta sobre prioridad nacional contestada con "La prioridad nacional es cambiar el gobierno".

## Temas
- **Tiempo (s)**: rivales 747 · corrupcion 509 · fronteras_y_marruecos 497 · inmigracion 466 · asuntos_personales 345 · pensiones 329 · deuda_y_gasto 328 · pactos_y_gobernabilidad 324 · partido_interno 313 · defensa_y_seguridad 291 · impuestos_y_autonomos 258 · formato_y_presentacion 225 · cierre_y_alegato 193 · economia_y_empleo 189 · feminismo_e_igualdad 144 · politica_internacional 58.
- **Los introduce el invitado**: Pedro Sánchez y la investidura de 2023 (8:29); desconfianza en las cuentas públicas (22:11); absentismo y fraude laboral (25:44); deuda y superávit cuando se le pregunta por defensa (36:02); ingreso mínimo vital (52:10); cifras de población extranjera y regularización (55:18); fotos de Sánchez y financiación de sus primarias (61:15). Dentro de otras respuestas: Filesa (64:58), sede de la Generalitat en Madrid (76:27), lectores de DNI (77:40), frontera sur de Europa (80:30).
- **Sin tramo propio**: vivienda (solo menciones: un millón de viviendas, sin ministerio), cataluna_y_territorial (menciones: autonomías, Lleida), sanidad_educacion_servicios, medios_y_redes, juventud, clima_y_energia, trayectoria_y_gestion_pasada (Galicia y Correos aparecen como argumento dentro de deuda y absentismo), otros.

## Problemas de la transcripción que afectan a la lectura
- **Tres huecos sin texto**: 9:54-10:22 (28 s, respuesta a "¿A la inversa no habríais hecho vosotros lo mismo?"), 67:01-67:24 (23 s, repregunta sobre la dimisión de Rajoy) y 78:49-79:05 (15 s, inglés). Las preguntas 10, 85 y 105 quedan dudosas.
- **Turnos mal atribuidos** cuando se pisan: preguntas cortas de Jordi dentro de turnos del invitado ("¿Erais amigos?", "¿Te cae bien?", "¿El precio te parece normal?", "¿Y por qué el de Coldo?", "Vale, Abascal.", "¿Qué hubieras hecho tú...?") y respuestas del invitado dentro de turnos de Jordi ("No pagarán IVA.", "Es una invasión... Para mí lo es", "Debería de saber inglés."). Peores tramos: 24:07-25:17 y 61:22-63:50. "Yo no pertenezco a ningún bando" sale duplicado (6:33-6:35).
- **Nombres y palabras mal transcritos**: World Project (Wild), Sainz y Pérez Castajón (Sánchez), Ceijo y Fijó (Feijóo), box (Vox), Zerdán (Cerdán), Coldo y Cordó (Koldo), Casadón (Casado), Calao y Adacolau (Colau), Villa de Rosa (A Illa de Arousa), morreros y Marrocos (Marruecos), asentismo (absentismo), IPP (PPE), papel (PP), "error de prensa" (rueda), "brindar/despegar" (blindar/desplegar), "Secretos Sociales" (Oficiales), "vándalos" (mándalos), "falcoyete" (Falcon), "instalación de leche" (eléctrica).
- **Cifras dudosas por transcripción**: "revisarlo en el año 2021" (antes dijo 2029), "personas que vienen a trabajar" (por contexto, que no van), "menores de 20 años". "Vox es un partido en el que yo no / tengo discrepancias" es ilegible en su sentido.
- Las citas se copian tal cual, con estos errores. Cuatro preguntas y una respuesta tienen menos de 6 palabras porque no hay más texto.
