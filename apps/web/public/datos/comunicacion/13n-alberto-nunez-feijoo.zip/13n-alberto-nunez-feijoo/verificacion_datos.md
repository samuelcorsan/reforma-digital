# Comprobación de los datos citados en la entrevista

*Entrevista de Jordi Wild a Alberto Núñez Feijóo en The Wild Project, publicada el 13/11/2026. Se comprueban las afirmaciones factuales (cifras, hechos, atribuciones, normas) de las dos personas; no las opiniones ni las promesas. El veredicto dice si el dato tiene respaldo en las fuentes localizadas, no si la persona actuó de buena o mala fe.*

## Cómo leerlo

| Veredicto | Significado |
|---|---|
| respaldada | las fuentes coinciden con lo dicho |
| respaldada en parte / imprecisa | el dato de fondo existe, pero la cifra, la fecha o la formulación no coinciden |
| engañosa por contexto | dato real presentado omitiendo algo que cambia su sentido |
| sin respaldo | las fuentes localizadas lo contradicen |
| no verificable | no hay fuente pública suficiente, o es una relación causal o una interpretación |
| no he podido comprobarlo | no se encontraron fuentes suficientes |

**Límites que conviene tener presentes antes de citar nada de aquí:**

- La búsqueda se hizo el 13/11/2026 con buscador web. **La mayoría de las fuentes se consultaron a través de extractos del buscador y de prensa, no abriendo el documento oficial**: solo se abrieron 49 páginas completas, que sostienen 37 de las 143 filas comprobadas. Cada fila indica «Fuente abierta: sí/no»; donde pone «no», hay que abrir la fuente enlazada antes de publicar el veredicto.
- No se pudieron abrir varias fuentes primarias (Ministerio de Inclusión, revista de la Seguridad Social, dos verificaciones de Maldita.es, Deia, Noticias de Navarra); sus datos proceden del extracto.
- Muchos hechos de 2026 (Ceuta, sentencia del caso mascarillas, ático de la Comunidad de Madrid, reunión del abogado del PP con Koldo García, elecciones en EE. UU.) descansan en uno o dos medios, a veces de un solo signo político. Las fuentes de cada fila lo dejan ver.
- La transcripción es automática: hay errores en cifras y nombres («Coldo», «Zerdán», «asentismo», «vienen a trabajar») y frases cortadas. Las citas se copian tal cual. Cuando el dato depende de una frase cortada o dudosa, se indica en la fila.
- El recuento no es una «nota»: los dos hablan de cosas distintas (el invitado da muchas más cifras; el entrevistador hace sobre todo atribuciones y preguntas con dato), y varias afirmaciones repiten el mismo dato (columna `grupo` del CSV). **Comparar porcentajes entre los dos no es válido.**
- De las 171 afirmaciones extraídas, 28 venían marcadas como no comprobables (experiencias personales, intenciones, causas). No se buscaron; figuran al final y en el CSV como «no verificable», y se cuentan aparte.
- Algunas cifras son cálculos propios a partir de datos de la fuente (porcentajes de población, incremento de deuda, coste del 3,5 % en defensa); se indica en la fila.
- Los veredictos negativos («sin respaldo» y «engañosa por contexto») pasaron el 13/11/2026 una segunda revisión independiente abriendo las fuentes; dos se suavizaron a «respaldada en parte / imprecisa» (29:41, directiva del IVA; 53:55, inmigración irregular) y los demás se mantienen con la explicación ampliada. Esas filas llevan la marca «Revisión independiente 13/11/2026».

## Recuento

| Veredicto | Invitado (Feijóo) | Entrevistador (Jordi Wild) |
|---|---|---|
| sin respaldo | 2 | 0 |
| engañosa por contexto | 1 | 0 |
| respaldada en parte / imprecisa | 45 | 5 |
| respaldada | 53 | 15 |
| no verificable | 2 | 0 |
| no he podido comprobarlo | 20 | 0 |
| **Total comprobadas** | **123** | **20** |
| no comprobables según la extracción (no buscadas; «no verificable» en el CSV) | 26 | 2 |
| **Total filas** | **149** | **22** |

Fuente abierta en 33 filas del invitado y 4 del entrevistador; en el resto solo se vio el extracto.

## Alberto Núñez Feijóo (invitado)

### Sin respaldo (2)

**44:45 · La ministra de Defensa no permite que la directora del CNI comparezca en la Comisión de Secretos Oficiales.** (voto_o_decision)

- Cita literal: «Y la ministra de Defensa no deja comparecer a la directora del CNI en la Comisión de»
- Qué dicen las fuentes: Ninguna fuente abierta recoge una negativa de Robles o de Defensa. Cronología: en agosto la Mesa del Senado (mayoría del PP) no tramitó la petición de Vox porque la directora solo puede comparecer ante la comisión de secretos del Congreso; el 15-9-2026 Robles dijo que la directora «no tiene obstáculo» y que «en cuanto se la convoque, va a ir»; el 22-9 el PSOE dijo que bastaba con la ministra; el 23-9 Robles pidió a la presidenta del Congreso que la Junta de Portavoces «autorice» la comparecencia; el 1-10 Armengol citó solo a Robles para el 6-10, y el 5-10 la sesión se desconvocó por la convocatoria electoral, sin que compareciera ninguna de las dos. El bloqueo existió (el PP acusa al Ejecutivo de vetarla y algunos medios lo atribuyen a Moncloa y al PSOE), pero las fuentes no lo atribuyen a la ministra. Revisión independiente 13/11/2026
- Fuentes: <https://www.democrata.es/politica/congreso-y-senado/armengol-cita-a-robles-ante-la-comision-de-secretos-el-dia-6-y-deja-fuera-a-la-directora-del-cni/> · <https://www.democrata.es/politica/ampliacion-robles-reclama-a-armengol-que-permita-la-comparecencia-de-la-jefa-del-cni-en-la-comision-de-secretos/amp/> · <https://theobjective.com/espana/politica/2026-10-05/sanchez-robles-avisos-cni-ceuta-secretos/> · <https://www.esdiario.com/nacional/260915/197848/robles-despeja-camino-directora-cni-dispuesta-dar-cara-gobierno-guarda-documentos.html> · <https://www.infobae.com/espana/agencias/2026/09/22/robles-estara-en-la-comision-de-secretos-del-congreso-pero-no-la-directora-del-cni/> · <https://www.moncloa.com/2026/08/30/comparecencia-directora-cni-pp-vox-3423305/> · <https://www.diariodeleon.es/nacional/260905/2096410/feijoo-pide-robles-deje-comparecer-directora-cni-comision-secretos-verdad-ceuta.html>
- Fuente abierta: sí

**66:07 · La condena al PP como responsable a título lucrativo fue anulada después por falta de prueba.** (hecho)

- Cita literal: «con una sentencia que hablaba de que el PP era responsable del título lucrativo que posteriormente fue anulada por»
- Qué dicen las fuentes: La nota del CGPJ (14-10-2020) dice que el Supremo «confirma lo establecido por la Audiencia Nacional en cuanto a las responsabilidades civiles» del PP como partícipe a título lucrativo: 133.628,48 euros por Majadahonda y 111.864,32 por Pozuelo. Lo único que corrigió fue una «estimación parcial del recurso del PP sin efectos prácticos», referida a las afirmaciones sobre la caja B; no anuló la condena. En noviembre de 2023 el Supremo confirmó la segunda condena al PP a título lucrativo (Boadilla, 204.198,64 euros), que el partido no había recurrido. No localicé ninguna resolución del Constitucional o del TEDH que la anulara (búsqueda en prensa, no consulta de sus registros). Revisión independiente 13/11/2026
- Fuentes: <https://www.poderjudicial.es/cgpj/en/Judiciary/Supreme-Court/Pressroom/Press-Archive/El-Tribunal-Supremo-confirma-penas-de-hasta-51-anos-de-prision-para-los-procesados-en-el--caso-Gurtel-> · <https://www.que.es/2020/10/14/ts-confirma-pp-lucro-gurtel/> · <https://okdiario.com/espana/supremo-anula-parte-sentencia-gurtel-que-motivo-mocion-censura-mariano-rajoy-6280733/amp> · <https://www.vozpopuli.com/espana/supremo-caja-b-pp_0_1400861295.html> · <https://www.eldiario.es/politica/supremo-confirma-pp-financio-gurtel-boadilla-dicta-sexta-sentencia-firme-trama_1_10680051.html>
- Fuente abierta: sí

### Engañosa por contexto (1)

**58:43 · Cuando lo conoció, Dorado no tenía relación con el narcotráfico.** (hecho)

- Cita literal: «conocí a esta persona cuando no tenía nada que ver con el narcotráfico»
- Qué dicen las fuentes: Dorado no tenía entonces condena ni cargos por narcotráfico: su primera detención por drogas es de 2003 y la condena, de 2009 (10 años). Pero había sido detenido en 1983 por contrabando de tabaco y el 12-6-1990 en la Operación Nécora; el Telediario de TVE del 25-6-1990 (transcrito por El Plural) lo presentaba «como presunto miembro de una red de narcotraficantes» y señalado por jueces franceses y suizos por blanqueo. Quedó en libertad y fuera del sumario principal de los 49 procesados; según Wikipedia, el fiscal abrió una pieza separada por blanqueo, cuyo desenlace no localicé. La amistad empezó en 1995 según El País (citado por Maldita). Revisión independiente 13/11/2026
- Fuentes: <https://maldita.es/malditahemeroteca/20230719/feijoo-marcial-dorado-relacion-cronologia/> · <https://www.elplural.com/extratele/malas-lenguas-encuentra-archivo-tve-prueba-clave-fulmina-version-feijoo-relacion-marcial-dorado_400310102> · <https://es.wikipedia.org/wiki/Operación_Nécora> · <https://es.ara.cat/politica/elecciones-generales/marcial-dorado-relacion-tenia-feijoo_1_4757899.html> · <https://www.eldiario.es/galicia/marcial-dorado-pleno-congreso-anos-amistad-narco-nunez-feijoo-vuelven_1_10021515.html> · <https://www.eldiario.es/galicia/politica/marcial-dorado-narco-discreto_1_1027066.html>
- Fuente abierta: sí · Grupo: `dorado`

### Respaldada en parte / imprecisa (45)

**10:51 · A Sánchez lo echaron de su partido.** (hecho)

- Cita literal: «Si a ti te han tenido que echar de tu partido, te echan de tu partido»
- Qué dicen las fuentes: Sánchez dimitió como secretario general el 1-10-2016 tras perder una votación en el Comité Federal (132/133 en contra y 107 a favor). Formalmente fue una dimisión forzada por esa derrota, no una expulsión del partido.
- Fuentes: <https://orain.eus/es/politica/2016/10/01/pedro-sanchez-dimite-secretario-general-psoe/> · <https://theobjective.com/espana/2016-10-01/pedro-sanchez-dimite-como-secretario-general-del-psoe/>
- Fuente abierta: no (solo extracto)

**12:05 · Vox tiene más votos y expectativa electoral que toda la izquierda sin contar al PSOE.** (comparacion)

- Cita literal: «tiene muchos más votos y mucha más expectativa electoral que toda la izquierda junta»
- Qué dicen las fuentes: En expectativa de voto, sí: las encuestas de noviembre de 2026 dan a Vox 19-20 % frente a 5,4-6,9 % del Frente Amplio y 2,4 % de Podemos. En votos reales (2023) no hay «muchos más»: Vox logró 33 escaños y Sumar 31, sin contar ERC (7) ni EH Bildu (6).
- Fuentes: <https://www.democrata.es/encuestas/elecciones-generales/nc-report-9-noviembre-2026-pp-retrocede-psoe-100-escanos-vox/> · <https://www.democrata.es/encuestas/elecciones-generales/encuesta-hamalgama-pp-pierde-nueve-escanos-vox-70-psoe-106/> · <https://www.noticiasdenavarra.com/elecciones-generales/2023/07/24/23j-elecciones-resultados-analisis-victoria-pirrica-feijoo-7083606.html>
- Fuente abierta: no (solo extracto)

**16:13 · Suscribió con Sánchez la renovación del pacto de Estado hace unos meses.** (voto_o_decision)

- Cita literal: «Y yo a Sánchez le he suscrito el pacto al que hemos llegado hace unos meses»
- Qué dicen las fuentes: La renovación del pacto se aprobó en el Congreso el 26-2-2025 con el voto de todos los grupos salvo Vox: unos veinte meses antes de la entrevista, no «unos meses».
- Fuentes: <https://www.lamoncloa.gob.es/serviciosdeprensa/notasprensa/igualdad/Paginas/2025/260225-redondo-renovacion-pacto-violencia-genero.aspx> · <https://www.infocop.es/el-congreso-de-los-diputados-renueva-el-pacto-de-estado-contra-la-violencia-de-genero/>
- Fuente abierta: no (solo extracto) · Grupo: `pacto_vg`

**17:35 · El de Sánchez es el Gobierno con más ministerios de la democracia.** (comparacion)

- Cita literal: «Es decir, el gobierno más mastodóntico de la democracia es»
- Qué dicen las fuentes: Maldita.es: 22 carteras no es el máximo en solitario; iguala al último gabinete de Suárez (1980-81) y al de Sánchez de 2020, y el Gobierno de Suárez de 1979 tuvo 24 miembros. Sí es récord en vicepresidencias (cuatro, en 2020).
- Fuentes: <https://maldita.es/malditodato/20200112/el-nuevo-gobierno-paritario-y-el-tercero-mas-numeroso-de-la-historia/> · <https://theobjective.com/espana/politica/2023-11-25/ministerios-italia-chipre-espana/> · <https://www.moncloa.com/suarez-sanchez-gobiernos-numerosos>
- Fuente abierta: no (solo extracto) · Grupo: `ministerios`

**18:07 · España es el Estado más descentralizado de Europa.** (comparacion)

- Cita literal: «estamos ante el estado más descentralizado de Europa y probablemente del mundo»
- Qué dicen las fuentes: Funcas sitúa a España a la cabeza de la UE-27 en autonomía tributaria regional, por delante de Alemania, Austria y Bélgica; otros índices (autoridad regional) la colocan entre las más descentralizadas junto a esos países federales, sin un ranking único que la ponga primera. «Del mundo» no lo comprobé.
- Fuentes: <https://www.funcas.es/wp-content/uploads/2025/07/La-gobernanza-fiscal-multinivel-en-Espana-Analisis-y-propuestas-de-reforma.pdf> · <https://elordenmundial.com/mapas-y-graficos/regiones-mayor-autonomia-europa/>
- Fuente abierta: no (solo extracto)

**18:25 · En Galicia la Secretaría General de Igualdad dependía de la presidencia y luego se unió a Trabajo.** (hecho)

- Cita literal: «la Secretaría General de Igualdad dependía del presidente de la comunidad autónoma»
- Qué dicen las fuentes: En septiembre de 2020 la Secretaría Xeral da Igualdade pasó a la nueva Consellería de Emprego e Igualdade (respaldado). Antes estaba en la Vicepresidencia y Consellería de Presidencia, según el decreto; no comprobé que dependiera directamente del presidente.
- Fuentes: <https://www.xunta.gal/hemeroteca/-/nova/109766/feijoo-avanza-nueva-estructura-organica-xunta-enfocada-lucha-contra-covid-reactivacion> · <https://www.xunta.gal/hemeroteca/-/nova/111150/susana-lopez-abella-toma-posesion-como-secretaria-xeral-igualdade>
- Fuente abierta: no (solo extracto)

**19:13 · El Gobierno de Asturias no tiene Consejería de Igualdad.** (hecho)

- Cita literal: «verás que en el Principado de Asturias no hay una Consejería de Igualdad»
- Qué dicen las fuentes: No hay una consejería dedicada solo a igualdad, pero la nota oficial del Principado (29-7-2023) llama a la primera consejería «de la Presidencia, Reto Demográfico, Igualdad y Turismo». No comprobé cambios posteriores hasta 2026.
- Fuentes: <https://actualidad.asturias.es/documents/533407/0/2023_07_29+NP+Composicion+nuevo+gobierno.pdf>
- Fuente abierta: sí

**20:19 · La productividad y la competitividad de España han bajado.** (hecho)

- Cita literal: «la productividad en España ha bajado la competitividad en nuestra economía ha bajado»
- Qué dicen las fuentes: BBVA Research: la productividad por hora ha subido alrededor de un 3 % desde 2019; la productividad por ocupado está estancada o por debajo del nivel prepandemia. «Ha bajado» solo encaja con la segunda medida. La competitividad no la comprobé.
- Fuentes: <https://www.bbvaresearch.com/publicaciones/espana-que-sectores-explican-el-aumento-de-la-productividad-en-el-pais/> · <https://www.elindependiente.com/economia/2025/11/10/empleo-sube-productividad-no-freno-retraso-recuperacion-espanola-cinco-anos-crisis-sanitaria/amp/>
- Fuente abierta: no (solo extracto)

**20:23 · La población ha aumentado en más de 4 millones de personas, inmigrantes.** (cifra)

- Cita literal: «lo que se ha incrementado son más de 4 millones de ciudadanos, mayoritariamente inmigrantes»
- Qué dicen las fuentes: No dice desde cuándo. Desde 2018 la población total ha subido unos 3,1 millones (de 46,66 a 49,80 millones, INE) y la nacida en el extranjero unos 4,1 millones (de algo más de 6,2 a 10,29 millones). «Más de 4 millones» encaja con la segunda cifra, no con la primera.
- Fuentes: <https://www.ine.es/dyngs/Prensa/ECP2T26.htm> · <https://www.ine.es/prensa/cp_e2019_p.pdf> · <https://raco.cat/index.php/AnuarioCIDOBInmigracion/article/download/10.24241-AnuarioCIDOBInmi.2018.80/441907>
- Fuente abierta: sí · Grupo: `poblacion_extranjera`

**20:38 · La deuda ha aumentado más de un 40 %.** (cifra)

- Cita literal: «se ha incrementado un 40 y pico por ciento la deuda»
- Qué dicen las fuentes: La deuda pública pasó de unos 1,174 billones al cierre de 2018 a 1,763 billones en el segundo trimestre de 2026 (Banco de España): alrededor de un 50 % más, por encima del «40 y pico». En porcentaje del PIB sube de ~97 % a 101,4 %.
- Fuentes: <https://www.bde.es/wbe/es/noticias-eventos/actualidad-banco-espana/deuda-aapp-2026t2.html> · <https://www.publico.es/economia/deuda-publica-cierra-2018-97-2-pib-encima-objetivo-gobierno.html>
- Fuente abierta: sí

**24:14 · La edad de jubilación llega hoy a los 67 años.** (hecho)

- Cita literal: «de jubilación en este momento llega hasta los 67 años»
- Qué dicen las fuentes: En 2026 la edad ordinaria es de 66 años y 10 meses (65 con 38 años y 3 meses cotizados); los 67 años se alcanzan en 2027.
- Fuentes: <https://www.bbvamijubilacion.es/blog/la-edad-de-jubilacion-ordinaria-sube-de-nuevo-en-2026-66-anos-y-10-meses/>
- Fuente abierta: no (solo extracto)

**27:02 · Lunes y viernes son los días con más absentismo.** (hecho)

- Cita literal: «¿Por qué lunes y viernes son los días de la semana con mayor asentismo?»
- Qué dicen las fuentes: En inicios de baja, el lunes concentra el 30,73 % y el viernes el 12,44 %, el que menos (barómetro de mutuas, 2025); parte del pico del lunes es administrativo (bajas del fin de semana). El dato respalda el lunes, no el viernes.
- Fuentes: <https://www.infocop.es/wp-content/uploads/2025/04/BAROMETRO-ABSENTISMO-MN-2025.pdf> · <https://www.genbeta.com/a-fondo/gente-se-pide-muchas-bajas-laborales-espana-lunes-que-viernes-hay-factores-que-explican-este-fenomeno>
- Fuente abierta: no (solo extracto)

**29:41 · Hay una directiva europea de exención de IVA para autónomos de baja facturación que el Gobierno no ha transpuesto.** (voto_o_decision)

- Cita literal: «Y es que no lo pagan en Europa. Es que eso es una directiva que el gobierno se ha negado a transponer.»
- Qué dicen las fuentes: La no transposición y la demanda están respaldadas: el 11-3-2026 la Comisión Europea llevó a España ante el TJUE por no haber transpuesto dos directivas de IVA (2020/285 y 2022/542); dice que es el único Estado miembro que no lo ha hecho y que España ha indicado que no tiene intención de aplicar la exención para pymes (carta de emplazamiento el 31-1-2025, dictamen motivado el 17-7-2025). Lo impreciso es presentarla como respuesta sobre la exención interna: aplicar la franquicia de hasta 85.000 euros dentro del país es opcional para cada Estado; lo obligatorio es el mecanismo para que las pymes españolas se acojan a ella en otros Estados, que el Gobierno decía tramitar en una enmienda a la ley DAC 8 (no comprobé su estado tras la disolución de las Cortes). La nota original de la Comisión no se pudo abrir; sus frases se toman de Maldita, ARA y fiscal-impuestos, que coinciden. Revisión independiente 13/11/2026
- Fuentes: <https://maldita.es/desinfo/20260316/bruselas-lleva-a-espana-a-los-tribunales-por-ser-el-unico-pais-de-la-ue-que-no-exime-de-iva-a-los-autonomos/> · <https://es.ara.cat/economia/bruselas-denuncia-espana-justicia-europea-no-eximir-pymes-autonomos-declarar-iva_1_5674902.html> · <https://www.fiscal-impuestos.com/comision-europea-tjue-espana-no-transponer-normas-iva> · <https://www.supercontable.com/boletin/H/articulos/espana_tribunales_europa_tjue_franquicia_iva_exencion_autonomos_pequenas_empresas.html>
- Fuente abierta: sí

**31:36 · Es el Gobierno que más impuestos y cotizaciones ha cobrado a los trabajadores.** (comparacion)

- Cita literal: «es el gobierno que más impuestos y más cuotas le ha cobrado a los trabajadores en la historia de nuestro país»
- Qué dicen las fuentes: La recaudación tributaria marcó récord en euros en 2025 (325.356 millones, Hacienda). Que sea el Gobierno que «más ha cobrado a los trabajadores» depende de la medida (euros corrientes, presión fiscal, por trabajador), que no precisa.
- Fuentes: <https://www.hacienda.gob.es/es-ES/Prensa/Noticias/Paginas/2026/20260331-NP-CIERRE-DEFICIT.aspx> · <https://www.articulo14.es/economia/los-impuestos-en-espana-baten-record-con-sanchez-hacienda-recauda-ya-mas-de-325-000-millones-20260409.html>
- Fuente abierta: sí · Grupo: `recaudacion`

**32:53 · El Gobierno le ha criticado por proponer luchar contra el fraude laboral.** (hecho)

- Cita literal: «A mí me han criticado por decir que hay que luchar contra el fraude laboral.»
- Qué dicen las fuentes: El Gobierno y el PSOE le criticaron en julio de 2026, pero por llamar «cáncer» al absentismo, por decir que por encima del 4-5 % hay «un enorme porcentaje de fraude» y por proponer que algunas bajas se cobren menos; la crítica no fue a la lucha contra el fraude en sí.
- Fuentes: <https://www.elindependiente.com/espana/2026/07/09/gobierno-medidas-bajas-enfermedad-barbaridad-plan-feijoo/> · <https://orain.eus/es/politica/2026/07/08/el-psoe-los-sindicatos-cargan-contra-feijoo-llamar-cancer-al-absentismo-laboral/> · <https://www.eldebate.com/economia/20260707/feijoo-denuncia-grave-problema-absentismo-laboral-izquierda-le-echa-encima_437170.html>
- Fuente abierta: no (solo extracto)

**34:05 · Galicia fue de las tres o cuatro comunidades con menor aumento de deuda (los verificadores: la tercera, tras Madrid y Baleares).** (comparacion)

- Cita literal: «Galicia estuvo entre las tres o las cuatro comunidades autónomas de menor incremento de deuda pública»
- Qué dicen las fuentes: Maldita.es: Galicia fue la cuarta comunidad con menor aumento de deuda en puntos de PIB (+10,3, tras Madrid, Canarias y Navarra), pero la novena en euros (+7.541 millones). La referencia a «tercera tras Madrid y Baleares» no coincide con ese recuento.
- Fuentes: <https://maldita.es/malditodato/20230711/verificacion-deuda-cara-sanchez-feijoo/>
- Fuente abierta: no (solo extracto) · Grupo: `deuda_galicia`

**36:13 · La recaudación ha subido un 69 %: más de 220.000 millones más en 2026 que en 2018.** (cifra)

- Cita literal: «incrementa la recaudación fiscal un 69%, más de 220 .000 millones de impuestos en el año 2026 que en el año 2018»
- Qué dicen las fuentes: Los ingresos tributarios pasaron de 208.685 millones (2018) a 325.356 millones (2025): +116.671 millones y +56 %; 2026 no está cerrado. Ni el 69 % ni los 220.000 millones coinciden con esa serie (el IRPF solo sí subió un 71,9 %); podrían incluir cotizaciones, pero no lo dice.
- Fuentes: <https://www.hacienda.gob.es/es-ES/Prensa/Noticias/Paginas/2026/20260331-NP-CIERRE-DEFICIT.aspx> · <https://www.articulo14.es/economia/los-impuestos-en-espana-baten-record-con-sanchez-hacienda-recauda-ya-mas-de-325-000-millones-20260409.html>
- Fuente abierta: sí · Grupo: `recaudacion`

**36:26 · España ha recibido 80.000 millones de fondos europeos a fondo perdido.** (cifra)

- Cita literal: «Cuando además recibe 80 .000 millones de euros a fondo perdido de Europa»
- Qué dicen las fuentes: España tiene asignados 79.854 millones en transferencias no reembolsables; hasta abril de 2026 había recibido 55.090 millones y el 30-9-2026 pidió el séptimo y último desembolso (21.463 millones). Asignado, no recibido todavía.
- Fuentes: <https://www.caixabankresearch.com/es/economia-y-mercados/sector-publico/ngeu-ejecucion-va-avanzando-llega-hora-verdad> · <https://www.hacienda.gob.es/es-ES/Prensa/Noticias/Paginas/2026/20260930-NP-SOLICITUD-SEPTIMO-DESEMBOLSO-PRTR.aspx>
- Fuente abierta: no (solo extracto)

**37:24 · La deuda de Perú es del 35-37 % del PIB.** (cifra)

- Cita literal: «Pues está una deuda del 35 -37 % del PIB.»
- Qué dicen las fuentes: La deuda pública de Perú cerró 2025 en el 30,2 % del PIB (Gestión); otra medida (deuda bruta del sector público no financiero) da 33,3 %. Por debajo del 35-37 % citado.
- Fuentes: <https://gestion.pe/tu-dinero/chile-peru-o-mexico-cual-es-el-pais-menos-endeudado-de-latinoamerica-noticia/> · <https://www.bbvaresearch.com/wp-content/uploads/2026/10/Situacion_Peru_Octubre_2026-2.pdf>
- Fuente abierta: no (solo extracto)

**37:38 · Cerró con superávit sus últimos presupuestos en Galicia.** (hecho)

- Cita literal: «Es que yo he conseguido un superávit en los últimos presupuestos de Galicia.»
- Qué dicen las fuentes: Galicia cerró 2018 con superávit (0,17 % del PIB), pero no sus últimos ejercicios: un documento presupuestario de la Xunta indica que en el periodo revisado solo 2018 y 2024 cerraron en superávit, y en 2020 hubo déficit del 0,1 %.
- Fuentes: <https://ficheiros-web.xunta.gal/transparencia/orzamentos/deficit-superavit-publico-2026.pdf> · <https://www.publico.es/economia/deficit-publico-cierra-2018-y.html> · <https://www.xunta.gal/hemeroteca/-/nova/132772/feijoo-destaca-que-2020-galicia-gasto-todo-necesario-para-luchar-contra-pandemia>
- Fuente abierta: no (solo extracto)

**38:49 · Sánchez calló en la cumbre de la OTAN y después dijo en rueda de prensa que no pasaría del 2 %.** (hecho)

- Cita literal: «dices que tú no vas a subir el gasto en defensa superior»
- Qué dicen las fuentes: Sánchez firmó la declaración de La Haya (5 % en 2035) y sostuvo en rueda de prensa que España no pasaría del 2,1 %. Pero no «calló»: antes de la cumbre había enviado una carta a Rutte con esa posición.
- Fuentes: <https://www.diaridetarragona.com/espana/233697/sanchez-comunica-carta-otan-gasto-defensa-ve-razonable-5.html> · <https://maldita.es/malditateexplica/20250624/espana-gasto-otan-defensa/> · <https://theobjective.com/directo/internacional/2025-06-25/cubre-otan-directo-gasto-defensa/>
- Fuente abierta: no (solo extracto)

**43:11 · En 2021 entraron 15.000 personas en Ceuta.** (cifra)

- Cita literal: «en el año 21 ya nos invadieron 15 .000 personas en Ceuta»
- Qué dicen las fuentes: Las cifras de mayo de 2021 van de 8.000 (Gobierno) a 10.000 (Interior, junio de 2021) y 12.000 (fuentes policiales); ninguna fuente localizada da 15.000 e Interior no las incluyó en su estadística.
- Fuentes: <https://elfarodeceuta.es/interior-no-incluye-balance-oficial-llegadas-ceuta/> · <https://www.eldebate.com/espana/20260804/estadisticas-marlaska-no-incluiran-llegada-masiva-inmigrantes-ceuta_446341.html>
- Fuente abierta: no (solo extracto)

**47:11 · El Gobierno (su partido) votó en contra de esa declaración.** (voto_o_decision)

- Cita literal: «la oposición le pide al Parlamento Europeo solidaridad y el gobierno de España vota en contra»
- Qué dicen las fuentes: Quienes votaron en contra fueron los eurodiputados socialistas (grupo S&D, con el PSOE); el Gobierno como tal no vota en el Parlamento Europeo.
- Fuentes: <https://es.euronews.com/my-europe/2026/09/17/eurocamara-responsabiliza-marruecos-asalto-masivo-ceuta-rechazo-socialistas> · <https://www.esdiario.com/nacional/260917/197996/eurocamara-sanchez-ceuta-psoe.html>
- Fuente abierta: sí · Grupo: `pe_ceuta`

**52:14 · Unos 2,5 millones de personas cobran el ingreso mínimo vital.** (cifra)

- Cita literal: «en España aproximadamente hay dos millones y medio de personas que cobran el ingreso mínimo vital»
- Qué dicen las fuentes: El IMV llegaba en octubre de 2026 a cerca de 2,8 millones de personas en 911.274 hogares; los 2,4-2,5 millones corresponden a un año antes.
- Fuentes: <https://revista.seg-social.es/-/el-ingreso-m%C3%ADnimo-vital-protege-en-octubre-a-cerca-de-2-8-millones-de-personas-que-viven-en-911.274-hogares> · <https://www.lamoncloa.gob.es/serviciosdeprensa/notasprensa/inclusion/paginas/2025/071125-imv-alcance-octubre.aspx>
- Fuente abierta: no (solo extracto) · Grupo: `imv`

**53:42 · El acuerdo de Italia (con Albania) ha funcionado, al menos parcialmente.** (hecho)

- Cita literal: «Yo creo que en Italia ha funcionado.»
- Qué dicen las fuentes: Los jueces italianos rechazaron validar las retenciones en los tres primeros traslados y los centros quedaron vacíos; reconvertidos en centros de retorno, en julio de 2026 recibieron 49 migrantes. Coste estimado: 653 millones.
- Fuentes: <https://www.ultimahora.com/llegan-a-albania-otros-49-migrantes-interceptados-cuando-trataban-de-llegar-a-italia> · <https://www.ilpost.it/2026/06/11/centri-migranti-albania-nuove-regole-europee/> · <https://es.ara.cat/internacional/meloni-envia-ahora-albania-inmigrantes-situacion-irregular-pretende-deportar_1_5562956.html>
- Fuente abierta: no (solo extracto)

**53:55 · España es el país europeo con más inmigración irregular desde hace años.** (comparacion)

- Cita literal: «España es el país donde hay más inmigración irregular desde hace algunos años de»
- Qué dicen las fuentes: La frase termina en la línea siguiente de la transcripción («toda Europa»). Llegadas irregulares, España frente a Italia: 2023, 56.852 (Interior) frente a unas 157.000 (dato italiano no abierto); 2024, 63.970 frente a 66.317 (dato italiano solo por extracto), casi empate; 2025, unas 36.700 (Frontex: 19.403 por el Mediterráneo occidental y 17.280 por Canarias) frente a 66.328 por el Mediterráneo central; 2026, enero-agosto, unas 21.000 (15.900 y 5.100) frente a 19.400, y 24.200 por el Mediterráneo oriental, sin contar la entrada de Ceuta del 30 y 31 de julio (unas 80.000 personas), que Frontex no computa; contándola, España es la primera en 2026. Eurostat 2025, personas halladas en situación irregular: España es quinta (8,2 % del total de la UE), tras Alemania (23,4 %), Francia (22,2 %), Italia (11,5 %) y Grecia (8,5 %). Hay respaldo para 2026 si se cuenta Ceuta y un casi empate en 2024, no para «desde hace algunos años». No localicé una comparativa europea homogénea de población residente en situación irregular. Revisión independiente 13/11/2026
- Fuentes: <https://www.eunews.it/2026/01/15/nel-2025-gli-ingressi-irregolari-nellue-sono-diminuiti-del-26-per-cento-ma-non-dal-mediterraneo/> · <https://www.menorca.info/balears/noticias/2026/01/20/2552807/bajan-entradas-irregulares-menos-mediterraneo-occidental.html> · <https://www.vozpopuli.com/espana/el-informe-de-frontex-evidencia-un-repunte-del-34-en-la-ruta-del-estrecho-sin-sumar-las-entradas-a-ceuta.html> · <https://www.moncloa.com/2026/10/19/frontex-estrecho-inmigracion-llegadas-3451660/> · <https://www.elobservador.com.uy/espana/actualidad/record-inmigrantes-ilegales-espana-63970-todo-2024-y-mas-10000-murieron-el-mar-n5977681> · <https://ec.europa.eu/eurostat/statistics-explained/index.php?title=Enforcement_of_immigration_legislation_statistics>
- Fuente abierta: sí

**55:37 · Más del 30 % del censo de Lleida es inmigrante.** (cifra)

- Cita literal: «Aproximadamente el censo de la ciudad de Lleida, más del 30 % son inmigrantes.»
- Qué dicen las fuentes: Idescat, 2025: de 147.369 habitantes de Lleida, 34.274 tienen nacionalidad extranjera (23,3 %) y 40.916 nacieron en el extranjero (27,8 %). Por debajo del 30 %.
- Fuentes: <https://www.idescat.cat/emex/?id=251207&f=ssv&lang=es>
- Fuente abierta: sí

**56:24 · Uno de cada tres inmigrantes que salen en cayuco hacia España muere en el mar (dice haberlo leído).** (cifra)

- Cita literal: «uno de cada tres inmigrantes que llegan a un cayucón a costa española»
- Qué dicen las fuentes: Caminando Fronteras estima para 2026 que «muere una persona por cada seis que consiguen llegar» (1.317 muertes de enero a mayo, 635 en la ruta canaria). La letalidad es alta, pero la proporción localizada es la mitad de la citada.
- Fuentes: <https://es.ara.cat/sociedad/inmigracion/rutas-migratorias-letales-1-317-muertos-intentando-llegar-espana-cinco-meses_1_5765186.amp.html> · <https://rtvc.es/personas-murieron-2025-intentando-llegar-espana-caminando-fronteras-29-diciembre-2025/>
- Fuente abierta: sí

**56:34 · España es el único país de la UE que está regularizando a 1,3 millones de inmigrantes.** (cifra)

- Cita literal: «regularizando de forma indiscriminada a 1 ,3 millones de inmigrantes»
- Qué dicen las fuentes: El proceso cerró el 30-6-2026 con 1.174.978 solicitudes, no 1,3 millones, y son solicitudes: una fuente posterior habla de 609.737 expedientes tramitados. Que sea el único país de la UE no lo comprobé.
- Fuentes: <https://www.lamoncloa.gob.es/serviciosdeprensa/notasprensa/inclusion/paginas/2026/020726-balance-regularizacion-extraordinaria.aspx> · <https://www.inclusion.gob.es/w/el-plazo-de-presentacion-de-solicitud-para-la-regularizacion-extraordinaria-concluye-con-1.174.978-solicitudes-recibidas>
- Fuente abierta: no (solo extracto)

**58:38 · Compareció a petición propia en rueda de prensa y en el pleno del Parlamento gallego.** (hecho)

- Cita literal: «Comparecí en una rueda de prensa en el Parlamento, comparecí en el Pleno del Parlamento»
- Qué dicen las fuentes: La rueda de prensa y la comparecencia en el pleno existieron; sobre la segunda, eldiario.es tituló que «la oposición arrastra a Feijóo a comparecer», lo que no encaja con «a petición propia».
- Fuentes: <https://www.eldiario.es/galicia/oposicion-arrastra-feijoo-comparecer-narcotraficante_1_5626221.html> · <https://www.legaltoday.com/rincon-de-reuters/nunez-feijoo-descarta-dimitir-por-unas-fotos-antiguas-con-un-narco-2013-04-02/>
- Fuente abierta: no (solo extracto) · Grupo: `dorado_2013`

**59:02 · Lo que constaba de Dorado era contrabando de tabaco.** (hecho)

- Cita literal: «Lo que había es que se había dedicado en su momento y había»
- Qué dicen las fuentes: Feijóo ha reconocido que Dorado era contrabandista cuando se conocieron (Maldita recoge su frase de julio de 2023: «nunca narcotraficante»); a eso se añade la detención de 1990 en la Operación Nécora, tras la que quedó en libertad y fuera del sumario principal. Revisión independiente 13/11/2026
- Fuentes: <https://maldita.es/malditahemeroteca/20230719/feijoo-marcial-dorado-relacion-cronologia/> · <https://www.elplural.com/extratele/malas-lenguas-encuentra-archivo-tve-prueba-clave-fulmina-version-feijoo-relacion-marcial-dorado_400310102> · <https://es.wikipedia.org/wiki/Operación_Nécora> · <https://www.lamarea.com/2023/07/21/feijoo-reconoce-que-marcial-dorado-era-contrabandista-cuando-se-conocieron>
- Fuente abierta: sí · Grupo: `dorado`

**61:39 · Ganó con mayoría absoluta ampliada las elecciones gallegas de 2016 y 2020.** (hecho)

- Cita literal: «Volvió a haber elecciones en el 16. Mayoría absoluta ampliada. Volvió a haber elecciones en el 20. Mayoría absoluta ampliada.»
- Qué dicen las fuentes: En 2016 el PP revalidó los mismos 41 escaños de 2012 (no amplió en escaños); en 2020 subió a 42, su mejor resultado.
- Fuentes: <https://maldita.es/malditodato/20200712/feijoo-consigue-su-mejor-resultado-electoral-y-renueva-su-mayoria-absoluta-la-octava-del-pp-en-galicia-en-11-elecciones>
- Fuente abierta: no (solo extracto) · Grupo: `galicia_mayorias`

**62:39 · Sánchez fue quien empezó a usar las fotos con Dorado.** (hecho)

- Cita literal: «El señor Sánchez fue el que empezó a utilizar esas fotos.»
- Qué dicen las fuentes: Las fotos las publicó El País el 30-3-2013 y las usó entonces la oposición gallega, antes de que Sánchez liderase el PSOE. Sánchez las sacó en el debate electoral de julio de 2023 (El Debate: solo las había mencionado una vez antes).
- Fuentes: <https://www.eldebate.com/espana/20230711/feijoo-apabulla-sanchez-irreconocible-hiere-muerte-campana_127290.html> · <https://www.eldiario.es/galicia/oposicion-arrastra-feijoo-comparecer-narcotraficante_1_5626221.html>
- Fuente abierta: no (solo extracto) · Grupo: `dorado`

**64:39 · La Gürtel ha sido juzgada por completo.** (hecho)

- Cita literal: «El caso Gürtel se ha juzgado por arriba, por abajo»
- Qué dicen las fuentes: El duodécimo y último juicio de la macrocausa quedó visto para sentencia en noviembre de 2025; a julio de 2026 seguían piezas pendientes de resolución definitiva.
- Fuentes: <https://www.noticiasdenavarra.com/politica/2025/11/12/visto-sentencia-ultimo-juicio-caso-10339452.amp.html> · <https://es.ara.cat/politica/kitchen-punica-gurtel-frentes-judiciales-pp-abiertos-curso-politico_1_5488616.html>
- Fuente abierta: no (solo extracto)

**65:22 · Dijo en su día que le repugnaba la actitud del tesorero del PP, que fue quien más se enriqueció y estuvo en la cárcel.** (hecho)

- Cita literal: «la actitud del tesorero de mi partido. Que fue, por cierto, el que más enriqueció.»
- Qué dicen las fuentes: La Marea recoge que en febrero de 2013 Feijóo dijo que Bárcenas le repugnaba y pidió explicaciones al PP. Que fuera «el que más se enriqueció» no lo comprobé.
- Fuentes: <https://lamarea.com/2013/04/07/alberto-nunez-feijoo> · <https://www.publico.es/actualidad/feijoo-insta-pp-pedir-perdon-caso-barcenas.html>
- Fuente abierta: no (solo extracto) · Grupo: `gurtel_critica`

**66:43 · Cerdán tiene el 46 % de una constructora con contratos públicos.** (cifra)

- Cita literal: «tenga un 46 % de una empresa constructora que tiene contratos con la administración»
- Qué dicen las fuentes: La UCO halló un contrato privado de 2016 que atribuye a Cerdán el 45 % de Servinabar (no el 46 %); su defensa le niega validez y la empresa niega que fuera socio.
- Fuentes: <https://orain.eus/en/politics/2025/06/18/uco-has-found-document-indicating-that-cerdan-owned-45-of-servinabar/> · <https://rtvc.es/cerdan-obras-acciona-segun-uco-19-noviembre-2025/>
- Fuente abierta: no (solo extracto)

**66:47 · Uno (Ábalos) está en la cárcel con 25 años de condena y otro (Cerdán) investigado tras pasar por la cárcel.** (cifra)

- Cita literal: «Por eso uno está en la cárcel con 25 años y otro está investigado.»
- Qué dicen las fuentes: El Supremo condenó a Ábalos a 24 años y 3 meses (22-6-2026), no 25. Cerdán sigue investigado; las fuentes localizadas mencionan su paso por prisión preventiva sin precisar fechas.
- Fuentes: <https://www.poderjudicial.es/cgpj/es/Poder-Judicial/Tribunal-Supremo/Noticias-Judiciales/El-Tribunal-Supremo-condena-al-exministro-Jose-Luis-Abalos-y-a-su-exasesor-Koldo-Garcia-a-24-anos-y-19-anos-de-prision--respectivamente--por-delitos-de-organizacion-criminal--cohecho--malversacion-y-trafico-de-influencias> · <https://www.elindependiente.com/espana/2026/06/22/supremo-condena-abalos-koldo-prision-por-mordidas-contratos-mascarillas/> · <https://rtvc.es/cerdan-obras-acciona-segun-uco-19-noviembre-2025/>
- Fuente abierta: sí

**67:35 · El PSOE está investigado en dos juzgados por financiación ilegal.** (cifra)

- Cita literal: «el Partido Socialista está investigado en dos juzgados por financiación»
- Qué dicen las fuentes: Hay dos investigaciones en la Audiencia Nacional sobre las cuentas del PSOE (juez Moreno, pagos en metálico; juez Pedraz, caso Leire Díez), pero no consta que el partido esté imputado: el PP lo pidió el 6-10-2026 y la citada como investigada es la gerente.
- Fuentes: <https://www.diariodeleon.es/nacional/260831/2095650/psoe-afronta-vuelta-cuentas-ferraz-dos-lupas-judiciales.html> · <https://www.articulo14.es/politica/el-pp-pide-a-la-audiencia-nacional-la-imputacion-del-psoe-por-financiacion-ilegal-20261006.html> · <https://www.moncloa.com/2026/02/18/juez-secreta-financiacion-psoe-3361835/>
- Fuente abierta: no (solo extracto)

**74:14 · Durante la Gürtel criticó que su partido no lo detectó antes y reaccionó tarde.** (hecho)

- Cita literal: «cuando dije que había que haberlo detectado con anterioridad, que probablemente habríamos reaccionado»
- Qué dicen las fuentes: En 2013 pidió explicaciones al partido y que pidiera perdón por el caso Bárcenas (Público, La Marea); no localicé la frase sobre haberlo detectado antes o haber reaccionado tarde.
- Fuentes: <https://www.publico.es/actualidad/feijoo-insta-pp-pedir-perdon-caso-barcenas.html> · <https://lamarea.com/2013/04/07/alberto-nunez-feijoo>
- Fuente abierta: no (solo extracto) · Grupo: `gurtel_critica`

**74:46 · Ayuso ganó con mayoría absoluta en Madrid y entonces él apoyó que presidiera el partido (en Madrid).** (hecho)

- Cita literal: «Ayuso ha ganado con mayoría absoluta en Madrid»
- Qué dicen las fuentes: Ayuso fue elegida presidenta del PP de Madrid el 20-5-2022 con el respaldo de Feijóo, que ese día habló de poner «la primera piedra» de la mayoría absoluta de 2023: la presidencia del partido llegó antes que la mayoría absoluta, no después.
- Fuentes: <https://theobjective.com/espana/2022-05-20/isabel-diaz-ayuso-se-hace-con-la-presidencia-del-pp-de-madrid-con-el-9912-de-los-votos/> · <https://www.elespanol.com/espana/20220521/congreso-pp-madrid-alberto-nunez-feijoo-isabel/674282567_10.html>
- Fuente abierta: no (solo extracto)

**76:57 · Vivió 13 años en la residencia oficial de la Xunta, que no construyó él.** (hecho)

- Cita literal: «Yo viví en una residencia oficial 13 años, que no hice yo.»
- Qué dicen las fuentes: Presidió la Xunta trece años (2009-2022) y la residencia de Monte Pío se encargó con Fraga; según eldiario.es dejó de frecuentarla tras sus primeros años.
- Fuentes: <https://www.eldiario.es/galicia/moncloa-gallega-residencia-presidencial-10-millones-euros-camino-casa-fantasma_1_9031243.html>
- Fuente abierta: no (solo extracto) · Grupo: `monte_pio`

**77:14 · La residencia oficial se hizo en el año 2000.** (hecho)

- Cita literal: «En el momento en el que se hizo, que fue en el año 2000, no estábamos mal.»
- Qué dicen las fuentes: La residencia se construyó por empeño de Fraga; el DOG publicó en 2001 la licitación de la urbanización de la finca. No localicé el año exacto de la obra.
- Fuentes: <https://www.eldiario.es/galicia/moncloa-gallega-residencia-presidencial-10-millones-euros-camino-casa-fantasma_1_9031243.html> · <https://www.xunta.gal/dog/Publicados/2001/20010924/AnuncioF2B2_gl.html>
- Fuente abierta: no (solo extracto) · Grupo: `monte_pio`

**83:01 · Abascal convirtió a Vox en tercera fuerza en 8-10 años.** (hecho)

- Cita literal: «y en 10 años, 8 años, convertirse en la tercera fuerza política del país»
- Qué dicen las fuentes: Vox se fundó en 2013 y fue tercera fuerza en noviembre de 2019: unos seis años, no ocho o diez.
- Fuentes: <https://www.vozpopuli.com/espana/politica/2019-vox-congreso-abascal_0_1310569141.html>
- Fuente abierta: no (solo extracto) · Grupo: `vox_tercera`

**83:34 · Vox no tiene ningún concejal, alcalde ni diputado en Galicia.** (hecho)

- Cita literal: «No tienes un solo concejal de Vox en Galicia.»
- Qué dicen las fuentes: Vox no tiene diputados en el Parlamento gallego; en 2024 su única representación era una concejal en Avión (Ourense). No localicé su salida del partido.
- Fuentes: <https://www.publico.es/politica/galicia-consolida-territorio-hostil-vox.html> · <https://www.elespanol.com/quincemil/actualidad/galicia/20230426/lugar-galicia-no-puede-votar-partido-popular/759174638_0.html>
- Fuente abierta: no (solo extracto) · Grupo: `vox_galicia`

**84:44 · Once ministros dijeron en el verano de 2022 que actuaba por "ignorancia o mala fe".** (cita_de_tercero)

- Cita literal: «Salieron 11 ministros del gobierno de España a decir que el jefe de la oposición o era un ignorante o tenía mala fe.»
- Qué dicen las fuentes: La fórmula fue «insolvencia o mala fe» y la usó Sánchez en el Senado el 6-9-2022 (una veintena de veces, según las crónicas); no localicé un recuento de once ministros repitiéndola en julio y agosto.
- Fuentes: <https://www.eldebate.com/espana/20220908/gobierno-delata-no-capaz-explicar-teoria-feijoo-nombro-ibex_58740.html> · <https://naciodigital.cat/politica/sanchez-converteix-el-debat-sobre-la-crisi-en-un-atac-contra-la-insolvencia-de-feijoo.html>
- Fuente abierta: no (solo extracto)

### Respaldada (53)

**6:01 · Sánchez habló de "muros" en su discurso de investidura de 2023.** (cita_de_tercero)

- Cita literal: «es una expresión que él lo refirió en Muros, del discurso de investidura de Sánchez del año 23»
- Qué dicen las fuentes: En el discurso de investidura del 15-11-2023 (texto de La Moncloa): «O bien alzamos un muro ante estos ataques recurrentes a los valores de la España democrática…» y «El único muro eficaz contra las políticas de la ultraderecha…».
- Fuentes: <https://www.lamoncloa.gob.es/presidente/intervenciones/paginas/2023/prsp15112023.aspx> · <https://www.noticiasdenavarra.com/politica/2023/11/15/pedro-sanchez-frases-discurso-investidura-7519929.html>
- Fuente abierta: sí

**7:16 · Vox no cree en el Estado de las autonomías.** (hecho)

- Cita literal: «El estado de las autonomías en la que ellos no creen, yo sí creo»
- Qué dicen las fuentes: El manifiesto fundacional de Vox pedía convertir el Estado autonómico en un Estado unitario y su programa del 23-J habla de un Estado unitario administrativamente descentralizado; desde 2019 el partido ha rebajado el énfasis en la supresión, según eldiario.es.
- Fuentes: <https://www.eldiario.es/piedrasdepapel/Organizacion_territorial-Estado_Autonomico-VOX-CIS_6_850474963.html> · <https://theobjective.com/wp-content/uploads/2023/07/programa-vox-23j.pdf>
- Fuente abierta: no (solo extracto)

**9:16 · En las generales de 2023 el PP obtuvo mayoría absoluta en el Senado y 16 diputados más que el segundo en el Congreso.** (cifra)

- Cita literal: «hay un partido que saca un resultado que le da mayoría absoluta en el Senado, que hay 16 diputados de diferencia en el Congreso»
- Qué dicen las fuentes: El 23-J de 2023 el PP obtuvo 137 escaños frente a 121 del PSOE (16 de diferencia, tras el voto exterior) y mayoría absoluta en el Senado.
- Fuentes: <https://www.elindependiente.com/espana/2023/07/23/resultados-del-23-j/amp/> · <https://www.noticiasdenavarra.com/elecciones-generales/2023/07/24/23j-elecciones-resultados-analisis-victoria-pirrica-feijoo-7083606.html>
- Fuente abierta: no (solo extracto)

**12:00 · Vox es la tercera fuerza política de España.** (hecho)

- Cita literal: «Vox es la tercera fuerza política de nuestro país»
- Qué dicen las fuentes: Vox es tercera fuerza en el Congreso desde noviembre de 2019 (52 escaños) y lo siguió siendo en 2023 (33 escaños, por delante de Sumar con 31).
- Fuentes: <https://www.vozpopuli.com/espana/politica/2019-vox-congreso-abascal_0_1310569141.html> · <https://www.elindependiente.com/espana/2023/07/23/resultados-del-23-j/amp/>
- Fuente abierta: no (solo extracto) · Grupo: `vox_tercera`

**12:27 · En la legislatura anterior al PP le faltaron cuatro diputados para la investidura.** (cifra)

- Cita literal: «nos faltaron cuatro diputados para la mayoría suficiente para investir a presidente de gobierno»
- Qué dicen las fuentes: Feijóo reunió 172 apoyos (PP, Vox, UPN y CC) en 2023; la mayoría absoluta son 176.
- Fuentes: <https://www.cronista.com/espana/actualidad-es/elecciones-2023-alberto-nunez-feijoo-es-el-candidato-del-rey-para-formar-nuevo-gobierno>
- Fuente abierta: no (solo extracto)

**15:08 · El PP ha cerrado en los últimos meses cuatro pactos autonómicos con Vox.** (hecho)

- Cita literal: «Ha habido cuatro pactos en los últimos meses. Andalucía, Castilla y León, Aragón y Extremadura con Vox.»
- Qué dicen las fuentes: PP y Vox firmaron el acuerdo de gobierno de Andalucía el 2-7-2026; la prensa lo describe como continuación de los firmados en Extremadura, Aragón y Castilla y León. No comprobé la fecha de cada uno de los tres anteriores.
- Fuentes: <https://theobjective.com/espana/andalucia/2026-07-02/pp-vox-un-acuerdo-investidura-juanma-moreno/> · <https://es.ara.cat/politica/pp-vox-cierran-acuerdo-permitira-investir-juanma-moreno-andalucia_1_5787166.html> · <https://es.euronews.com/my-europe/2026/07/02/juanma-moreno-introduce-a-la-extrema-derecha-en-el-gobierno-andaluz-y-acepta-la-prioridad->
- Fuente abierta: no (solo extracto)

**16:10 · El primer pacto de Estado (contra la violencia de género) es de la etapa de Rajoy.** (hecho)

- Cita literal: «el primer pacto de Estado es en la época de Rajoy»
- Qué dicen las fuentes: El primer Pacto de Estado contra la Violencia de Género es de 2017, con Rajoy como presidente (el BOE de 2025 se refiere al «pacto original de 2017»).
- Fuentes: <https://boe.es/boe/dias/2025/05/02/pdfs/BOE-A-2025-8785.pdf> · <https://www.lamoncloa.gob.es/serviciosdeprensa/notasprensa/igualdad/Paginas/2025/260225-redondo-renovacion-pacto-violencia-genero.aspx>
- Fuente abierta: no (solo extracto) · Grupo: `pacto_vg`

**17:08 · El Gobierno actual tiene 22 ministerios.** (cifra)

- Cita literal: «Hay 22 ministerios. Hay 22 actualmente, son muchos.»
- Qué dicen las fuentes: El Gobierno formado en noviembre de 2023 tiene 22 ministerios. No comprobé cambios de estructura posteriores hasta 2026.
- Fuentes: <https://www.menorca.info/actualidad/nacional/2023/11/20/2053493/nuevo-gobierno-pedro-sanchez-mantendra-ministerios-ellos-para-sumar-habra-mujeres.html>
- Fuente abierta: no (solo extracto) · Grupo: `ministerios`

**18:43 · La vivienda es la primera preocupación de la mayoría en España.** (hecho)

- Cita literal: «la vivienda es la primera prioridad para la mayoría de la gente en España»
- Qué dicen las fuentes: Barómetro del CIS de octubre de 2026: la vivienda supera por primera vez el 55 % de menciones y es el primer problema desde hace 21 meses.
- Fuentes: <https://www.democrata.es/politica/la-inquietud-por-la-vivienda-se-dispara-18-puntos-y-bate-record-como-principal-problema-al-superar-el-55-de-menciones/>
- Fuente abierta: no (solo extracto)

**20:08 · La economía española ha crecido más que la media de la UE.** (comparacion)

- Cita literal: «¿Por qué ha crecido la economía española más que la media de la Unión Europea?»
- Qué dicen las fuentes: El PIB español creció un 2,8 % en 2025 (INE) frente al 1,5 % de la UE y el 1,4 % de la eurozona (Eurostat).
- Fuentes: <https://www.vozpopuli.com/economia/macroeconomia/la-economia-se-frena-el-pib-crecio-un-28-en-2025-cuatro-decimas-menos-que-en-2024.html> · <https://www.cronista.com/espana/economia-finanzas/el-crecimiento-del-pib-de-la-eurozona-en-2025-queda-en-14-tras-la-revision-de-eurostat>
- Fuente abierta: no (solo extracto)

**20:29 · El saldo vegetativo de España es negativo.** (hecho)

- Cita literal: «porque el saldo vegetativo de España es negativo»
- Qué dicen las fuentes: INE (provisional): saldo vegetativo de -122.167 personas en 2025; 2024 fue el octavo año consecutivo en negativo (-116.056).
- Fuentes: <https://www.ine.es/dyngs/Prensa/EDES_EMN2025.htm>
- Fuente abierta: no (solo extracto)

**22:44 · El Gobierno termina la legislatura sin haber aprobado ningún presupuesto, por primera vez en democracia.** (voto_o_decision)

- Cita literal: «Que tenemos un gobierno que finaliza la legislatura Sin aprobar ni un solo año las cuentas»
- Qué dicen las fuentes: La legislatura termina con los Presupuestos de 2023 prorrogados tres veces y sin ningún proyecto nuevo aprobado, algo inédito desde 1978 según Demócrata y Euronews.
- Fuentes: <https://www.democrata.es/economia/fin-de-la-legislatura-sin-nuevos-presupuestos-por-primera-vez-en-democracia/> · <https://es.euronews.com/2026/09/27/espana-cumple-1000-dias-sin-nuevos-presupuestos-es-un-hurto-a-los-ciudadanos>
- Fuente abierta: sí

**26:00 · En 2025 el gasto por absentismo superó los 30.000 millones.** (cifra)

- Cita literal: «Año 2025, más de 30 .000 millones.»
- Qué dicen las fuentes: AMAT (mutuas) cifra en unos 32.000 millones y la CEOE en 33.000 millones el coste de 2025 por contingencias comunes. Otras metodologías dan entre 26.800 y 59.109 millones (Adecco), así que la cifra depende de qué se cuente.
- Fuentes: <https://cepyme.es/storage/2026/06/260616-NP-CEOE_Encuentro-Empresarial-Absentismo.pdf> · <https://elderecho.com/el-absentismo-laboral-alcanza-un-maximo-historico-del-76-en-2025>
- Fuente abierta: no (solo extracto) · Grupo: `absentismo_coste`

**26:11 · En 2025 más de un millón de personas faltan cada día al trabajo.** (cifra)

- Cita literal: «Año 2025, más de un millón de personas diarias no acuden a su puesto de trabajo.»
- Qué dicen las fuentes: Randstad Research: unos 1,5-1,6 millones de personas no acudieron de media cada día a su puesto en 2025, de ellas alrededor de 1,2 millones de baja médica.
- Fuentes: <https://www.bolsamania.com/noticias/economia/absentismo-laboral-roza-maximos-historicos-espana-71-2025--22160214.html> · <https://www.articulo14.es/economia/espana-bate-records-de-absentismo-laboral-16-millones-de-ausencias-diarias-y-bajas-medicas-duplicadas-20260602.html>
- Fuente abierta: sí · Grupo: `absentismo_personas`

**28:12 · Tras la pandemia han aumentado las patologías de salud mental.** (hecho)

- Cita literal: «Después de la pandemia hemos advertido un incremento a la patología de salud»
- Qué dicen las fuentes: INSST: los trastornos mentales son la segunda causa de baja por incapacidad temporal; en 2025 hubo 729.072 procesos, más del doble que en 2018.
- Fuentes: <https://www.insst.es/documents/d/portal-insst/los-trastornos-mentales-suponen-la-segunda-causa-de-baja-por-it-en-espana-nota-de-prensa> · <https://www.que.es/2026/08/02/bajas-salud-mental-jovenes/>
- Fuente abierta: no (solo extracto)

**30:54 · Hay tres millones y medio de autónomos.** (cifra)

- Cita literal: «Son tres millones y medio el número de personas que como tú son autónomos.»
- Qué dicen las fuentes: El RETA superó por primera vez los 3,5 millones de afiliados en octubre de 2026.
- Fuentes: <https://revista.seg-social.es/-/afiliacion-octubre-2026> · <https://www.democrata.es/economia/el-empleo-logra-su-mejor-octubre-historico-por-el-tiron-del-curso-escolar-y-la-regularizacion/>
- Fuente abierta: no (solo extracto)

**31:44 · El Gobierno no ha actualizado la tarifa del IRPF con la inflación.** (voto_o_decision)

- Cita literal: «que es no actualizar la tarifa del impuesto de la renta con la inflación»
- Qué dicen las fuentes: El Estado no ha deflactado la tarifa general del IRPF; el Banco de España atribuye a ello 11.000 millones de recaudación extra en 2019-2023 y en mayo de 2026 el Gobierno comunicó a Bruselas que no la ajustará.
- Fuentes: <https://forbes.es/economia/454362/el-banco-de-espana-atribuye-a-la-inflacion-una-recaudacion-extra-en-el-irpf-de-11-000-millones-en-2019-2023/> · <https://www.elespanol.com/invertia/economia/macroeconomia/20260502/gobierno-avanza-bruselas-no-ajustara-irpf-inflacion-ingresara-anuales-extra-via/1003744230492_0.html>
- Fuente abierta: no (solo extracto)

**32:27 · Con un cáncer en tratamiento no se cobra el 100 % de baja salvo que lo cubra el convenio.** (hecho)

- Cita literal: «salvo que el convenio te proteja, no cobras el 100%»
- Qué dicen las fuentes: El cáncer es contingencia común: no se cobra los tres primeros días, 60 % de la base reguladora del día 4 al 20 y 75 % desde el 21; muchos convenios lo complementan hasta el 100 %.
- Fuentes: <https://selectra.es/seguros/noticias/baja-medica-2026-enfermedad-comun-cuanto-cobras> · <https://www.vidacaixa.es/articulos/seguros-e-imprevistos/baja-laboral-cuanto-se-cobra>
- Fuente abierta: no (solo extracto)

**34:37 · Redujo un 50 % los altos cargos de la Xunta.** (cifra)

- Cita literal: «Y reducimos el 50 % los altos cargos.»
- Qué dicen las fuentes: El decreto de estructura de 2009 redujo los altos cargos de 125 a 66, un 47 % (agencias, en Libertad Digital).
- Fuentes: <https://www.libertaddigital.com/nacional/feijoo-reduce-a-la-mitad-los-altos-cargos-de-la-xunta-1276357021/>
- Fuente abierta: no (solo extracto)

**36:04 · Portugal, Irlanda y Grecia han tenido superávit estos años.** (hecho)

- Cita literal: «Durante estos años, Portugal, Irlanda, Grecia han tenido un superávit.»
- Qué dicen las fuentes: Eurostat (abril de 2026): Grecia (+1,7 % del PIB) y Portugal (+0,7 %) cerraron 2025 con superávit; un medio incluye también a Irlanda entre los cinco países sin déficit y otro no la menciona.
- Fuentes: <https://lisboeta.news/article/679382fa-3f49-43a3-9ce9-39d8ce65e9b2> · <https://www.cronista.com/espana/economia-finanzas/oficial-espana-logra-bajar-el-deficit-al-24-aunque-la-deuda-sigue-superando-el-100-del-pib/>
- Fuente abierta: no (solo extracto)

**36:45 · España paga unos 40.000-42.000 millones al año en intereses.** (cifra)

- Cita literal: «Nosotros tenemos aproximadamente 40 -42 .000 millones de gastos»
- Qué dicen las fuentes: Los intereses de la deuda fueron 40.314 millones en 2025; el Gobierno prevé 42.059 millones en 2026.
- Fuentes: <https://www.vozpopuli.com/economia/macroeconomia/el-gasto-en-intereses-de-la-deuda-rompe-en-espana-la-barrera-de-los-40000-millones-por-primera-vez.html>
- Fuente abierta: no (solo extracto)

**37:59 · Varias comunidades autónomas están en superávit.** (hecho)

- Cita literal: «Las comunidades autónomas en este momento hay varias que están en superávit.»
- Qué dicen las fuentes: Ocho comunidades cerraron 2025 con superávit (Navarra 2,04 %, Asturias 0,51 %), aunque el conjunto del subsector tuvo déficit del 0,3 % del PIB.
- Fuentes: <https://www.noticiasdenavarra.com/economia/2026/03/31/navarra-cierra-2025-superavit-2-10892057.amp.html> · <https://www.hacienda.gob.es/es-ES/Prensa/Noticias/Paginas/2026/20260331-NP-CIERRE-DEFICIT.aspx>
- Fuente abierta: no (solo extracto)

**39:03 · El gasto español en defensa estaba entonces en el 1,2-1,3 %.** (cifra)

- Cita literal: «en este momento el gobierno español está en el 1 .2, en el 1 .3»
- Qué dicen las fuentes: La OTAN estimaba el gasto español de 2024 en el 1,24-1,28 % del PIB (el Gobierno defendía un 1,43 %).
- Fuentes: <https://www.newtral.es/espana-otan-contribucion-2024/20250123/> · <https://www.elindependiente.com/economia/2025/04/24/espana-otan-gasto-militar/amp/>
- Fuente abierta: no (solo extracto)

**44:25 · Una jueza de la Audiencia Nacional ha pedido desclasificar los informes.** (hecho)

- Cita literal: «Y por eso la jueza te los ha pedido y te ha dicho desclasifícalos»
- Qué dicen las fuentes: La jueza María Tardón (Audiencia Nacional) dio el 27-10-2026 quince días al Gobierno para desclasificar todos los informes del CNI; el Consejo de Ministros lo aprobó el 10-11-2026.
- Fuentes: <https://es.euronews.com/2026/11/10/gobierno-desclasifica-los-informes-del-cni-sobre-ceuta-que-pidio-la-jueza-tardon> · <https://www.articulo14.es/politica/jueza-entrada-masiva-ceuta-15-dias-gobierno-informes-cni-20261027.html>
- Fuente abierta: sí

**44:34 · Dimitieron el jefe de gabinete del delegado del Gobierno en Ceuta y luego el delegado.** (hecho)

- Cita literal: «Ha dimitido el jefe de gabinete del delegado del gobierno porque estaba avisado, Ha dimitido el delegado del gobierno después.»
- Qué dicen las fuentes: El jefe de gabinete del delegado dimitió el 11-9-2026 (dice que transmitió el aviso del CNI del 29 de julio) y el delegado, Miguel Ángel Pérez Triano, el 28-9-2026.
- Fuentes: <https://es.euronews.com/2026/09/11/dimite-el-jefe-de-gabinete-del-delegado-del-gobierno-en-ceuta-por-el-aviso-del-cni-del-29-> · <https://es.euronews.com/2026/09/28/dimite-delegado-gobierno-ceuta-senalado-por-ignorar-avisos-del-cni-entrada-masiva> · <https://es.ara.cat/politica/cesan-delegado-gobierno-ceuta_1_5862822.html>
- Fuente abierta: no (solo extracto)

**46:13 · Tras visitar Ceuta el presidente se fue 25 días de vacaciones y publicó su lista de canciones.** (hecho)

- Cita literal: «la respuesta es volverte a Madrid, cogerte el falcoyete de vacaciones 25 días y sacar tu lista de Spoti»
- Qué dicen las fuentes: Sánchez publicó el 1-8-2026 una lista de 31 canciones y ese día voló en un Falcon a La Mareta (Lanzarote). La duración sale de prensa internacional citada por Vozpópuli («cuatro semanas»); un medio sitúa justo antes su viaje a Ceuta para comparecer.
- Fuentes: <https://www.elespanol.com/espana/politica/20260801/sanchez-comparte-playlist-verano-plena-crisis-ceuta-seguro-dan-idea-voy/1003744341448_0.html> · <https://www.esdiario.com/nacional/260801/194612/ceuta-mareta-sanchez-arranca-vacaciones-semana-incendios-crisis-migratoria.html> · <https://www.vozpopuli.com/internacional/la-prensa-internacional-retrata-al-presidente-espana-se-hunde-en-el-caos-sanchez-se-va-de-vacaciones.html>
- Fuente abierta: sí

**47:02 · El PP promovió en el Parlamento Europeo una declaración de condena.** (hecho)

- Cita literal: «los que hemos convencido al resto de europarlamentarios que hagan una declaración para condenar la invasión de Ceuta»
- Qué dicen las fuentes: La resolución del Parlamento Europeo del 17-9-2026 fue promovida por el PPE y aprobada por 339 votos a favor, 225 en contra y 16 abstenciones.
- Fuentes: <https://es.euronews.com/my-europe/2026/09/17/eurocamara-responsabiliza-marruecos-asalto-masivo-ceuta-rechazo-socialistas> · <https://www.diariodeleon.es/nacional/260918/2097724/pe-incluye-invasion-resolucion-sobre-ceuta-votos-derecha.html>
- Fuente abierta: sí · Grupo: `pe_ceuta`

**51:17 · Exigir la nacionalidad como único requisito de una ayuda social es ilegal según los tratados de la UE.** (hecho)

- Cita literal: «decir que la nacionalidad es el único requisito para una ayuda social»
- Qué dicen las fuentes: El derecho de la UE exige igualdad de trato en prestaciones para ciudadanos de la UE y residentes de larga duración (Directiva 2003/109; TJUE, asunto C-112/22, que incluso tumba un requisito de diez años de residencia).
- Fuentes: <https://diarioconstitucional.cl/wp-content/uploads/2024/07/Vea-sentencia-Tribunal-de-Justicia-de-la-Union-Europea-C-112_22-CU.pdf> · <https://www.cidob.org/en/publications/prioridad-nacional-politica-equivocada-problema-europeo> · <https://www.eldebate.com/espana/20260718/prioridad-nacional-necesita-cambiar-ley-marco-ue_440198_amp.html>
- Fuente abierta: no (solo extracto)

**53:11 · El reglamento europeo de retorno se aprobó por amplia mayoría con el voto en contra de España.** (voto_o_decision)

- Cita literal: «Esto es el reglamento de retorno aprobado en la Unión Europea por la inmensa mayoría de los países con el voto en contra de Sánchez»
- Qué dicen las fuentes: El Consejo aprobó definitivamente el Reglamento de Retorno el 1-10-2026 con el único voto en contra de España y la abstención de Bélgica.
- Fuentes: <https://www.articulo14.es/internacional/espana-el-unico-pais-de-la-ue-que-rechaza-acelerar-las-expulsiones-de-migrantes-20261001.html> · <https://es.euronews.com/2026/10/01/espana-ue-reglamento-retornos-inmigrantes-deportaciones-ceuta>
- Fuente abierta: sí

**55:24 · El 20 % de la población es de origen extranjero.** (cifra)

- Cita literal: «El 20 % de la población española es de origen extranjero.»
- Qué dicen las fuentes: INE, 1-7-2026: 10.291.807 nacidos en el extranjero sobre 49.801.559 habitantes (20,7 %).
- Fuentes: <https://www.ine.es/dyngs/Prensa/ECP2T26.htm>
- Fuente abierta: sí · Grupo: `poblacion_extranjera`

**55:48 · De ese 20 %, un 6 % está nacionalizado y un 14 % no.** (cifra)

- Cita literal: «que ya están nacionalizados pero hay otro 14 % que persiste que no se ha nacionalizado»
- Qué dicen las fuentes: INE, 1-7-2026: 7.437.543 residentes de nacionalidad extranjera (14,9 %); la diferencia con los nacidos fuera (20,7 %) es de unos 5,7 puntos.
- Fuentes: <https://www.ine.es/dyngs/Prensa/ECP2T26.htm>
- Fuente abierta: sí · Grupo: `poblacion_extranjera`

**55:58 · Desde 2018 la población de origen extranjero ha crecido un 60 %.** (cifra)

- Cita literal: «se ha incrementado el número de personas que viven en España de origen extranjero un 60 %»
- Qué dicen las fuentes: Los nacidos en el extranjero pasaron de algo más de 6,2 millones a inicios de 2018 (Anuario CIDOB, datos INE) a 10,29 millones en julio de 2026: alrededor de un 65 % más.
- Fuentes: <https://www.ine.es/dyngs/Prensa/ECP2T26.htm> · <https://raco.cat/index.php/AnuarioCIDOBInmigracion/article/download/10.24241-AnuarioCIDOBInmi.2018.80/441907>
- Fuente abierta: sí · Grupo: `poblacion_extranjera`

**56:06 · En 2018 había unos 6 millones de personas de origen extranjero y hoy más de 10.** (cifra)

- Cita literal: «éramos aproximadamente 6 millones de personas de origen extranjero viviendo en España y hoy superamos los»
- Qué dicen las fuentes: Algo más de 6,2 millones de nacidos en el extranjero a inicios de 2018 y 10,29 millones en julio de 2026 (INE).
- Fuentes: <https://www.ine.es/dyngs/Prensa/ECP2T26.htm> · <https://raco.cat/index.php/AnuarioCIDOBInmigracion/article/download/10.24241-AnuarioCIDOBInmi.2018.80/441907>
- Fuente abierta: sí · Grupo: `poblacion_extranjera`

**58:27 · Lo explicó a los gallegos en 2013.** (hecho)

- Cita literal: «Solo conté a los gallegos en el año 13»
- Qué dicen las fuentes: Las fotos se publicaron el 30-3-2013; Feijóo dio una rueda de prensa a principios de abril y compareció en el Parlamento gallego el 10-4-2013.
- Fuentes: <https://www.legaltoday.com/rincon-de-reuters/nunez-feijoo-descarta-dimitir-por-unas-fotos-antiguas-con-un-narco-2013-04-02/> · <https://www.eldiario.es/galicia/oposicion-arrastra-feijoo-comparecer-narcotraficante_1_5626221.html>
- Fuente abierta: no (solo extracto) · Grupo: `dorado_2013`

**64:48 · La Gürtel le costó el Gobierno al PP.** (hecho)

- Cita literal: «Pero si es que nos costó el gobierno»
- Qué dicen las fuentes: La moción de censura de 2018 se presentó tras la sentencia de Gürtel y desalojó al Gobierno de Rajoy.
- Fuentes: <https://maldita.es/control-del-poder/20260623/abalos-condenado-mocion-censura-corrupcion/> · <https://www.elsaltodiario.com/partidos-politicos/abecedario-mocion-censura-presentada-sanchez-contra-rajoy-mayo-2018>
- Fuente abierta: no (solo extracto) · Grupo: `mocion`

**65:39 · Lleva cuatro años y medio presidiendo el PP.** (hecho)

- Cita literal: «Yo llevo cuatro años y medio de presidente en mi partido.»
- Qué dicen las fuentes: Fue elegido presidente del PP el 2-4-2022: cuatro años y siete meses antes de la entrevista.
- Fuentes: <https://rtvc.es/feijoo-elegido-nuevo-presidente-del-pp-con-el-98-por-ciento-de-los-votos/>
- Fuente abierta: no (solo extracto)

**66:19 · Ábalos fue el ponente de la moción de censura.** (hecho)

- Cita literal: «el ponente de esa moción de censura sea el señor Ábalos»
- Qué dicen las fuentes: Ábalos defendió en la tribuna la moción de censura del PSOE el 31-5-2018.
- Fuentes: <https://maldita.es/control-del-poder/20260623/abalos-condenado-mocion-censura-corrupcion/>
- Fuente abierta: no (solo extracto) · Grupo: `mocion`

**67:29 · Nadie pudo implicar a Rajoy en la financiación irregular.** (hecho)

- Cita literal: «al final el señor Rajoy nadie le pudo implicar en la financiación irregular del partido»
- Qué dicen las fuentes: Rajoy no fue imputado ni condenado; declaró como testigo en Gürtel (2017) y en Kitchen (2026), donde Bárcenas volvió a señalarle.
- Fuentes: <https://www.diaridetarragona.com/internacional/114381/testimonio-historico-rajoy-comienza-a-declarar-en-el-macrojuicio-de-la-gurtel-20170726-0013-yldt201707260013.html> · <https://www.diaridetarragona.com/espana/263175/tormenta-judicial-acorrala-gobierno-cinco-frentes-pedro-sanchez.html>
- Fuente abierta: no (solo extracto) · Grupo: `rajoy`

**68:15 · La foto es de 1994-1996.** (hecho)

- Cita literal: «Pues del 94, del 95, del 96, bien, mal, ok.»
- Qué dicen las fuentes: Las fotos son del verano de 1995, dentro del margen 1994-1996 que da.
- Fuentes: <https://es.ara.cat/politica/elecciones-generales/marcial-dorado-relacion-tenia-feijoo_1_4757899.html> · <https://maldita.es/malditahemeroteca/20230719/feijoo-marcial-dorado-relacion-cronologia/>
- Fuente abierta: no (solo extracto) · Grupo: `foto`

**70:33 · El abogado sigue en el PP.** (hecho)

- Cita literal: «No, está con nosotros. ¿Sigue con vosotros? Sí, sí, es un abogado del partido»
- Qué dicen las fuentes: Génova sostiene que Durán sigue vinculado al partido; fue apartado de las causas más relevantes unas seis semanas antes de las declaraciones de Koldo.
- Fuentes: <https://www.articulo14.es/politica/el-pp-rechaza-que-el-paso-a-un-lado-de-alberto-duran-tenga-relacion-con-su-reunion-con-koldo-garcia-20261107.html>
- Fuente abierta: sí

**71:39 · Koldo está condenado a 19 años.** (cifra)

- Cita literal: «¿Tu fuente es lo que dice un señor condenado a 19 años de cárcel por ser un delincuente»
- Qué dicen las fuentes: El Supremo condenó a Koldo García a 19 años y 8 meses de prisión el 22-6-2026.
- Fuentes: <https://www.poderjudicial.es/cgpj/es/Poder-Judicial/Tribunal-Supremo/Noticias-Judiciales/El-Tribunal-Supremo-condena-al-exministro-Jose-Luis-Abalos-y-a-su-exasesor-Koldo-Garcia-a-24-anos-y-19-anos-de-prision--respectivamente--por-delitos-de-organizacion-criminal--cohecho--malversacion-y-trafico-de-influencias>
- Fuente abierta: sí · Grupo: `koldo_19`

**71:56 · El PP pidió 30 años para Koldo y el fiscal 19.** (cifra)

- Cita literal: «El PP pide 30 años de cárcel para el señor Cordó.»
- Qué dicen las fuentes: La acusación popular dirigida por el PP pidió 30 años para Koldo García (y para Ábalos); la Fiscalía, 19 años y medio.
- Fuentes: <https://www.elindependiente.com/espana/2025/11/20/las-acusaciones-populares-piden-30-anos-de-prision-para-abalos-y-koldo-y-revisar-si-deben-permanecer-en-libertad/amp/>
- Fuente abierta: sí · Grupo: `koldo_19`

**72:06 · La sentencia a Koldo fue de 19 años.** (cifra)

- Cita literal: «Y al final tiene una sentencia de prisión de 19 años.»
- Qué dicen las fuentes: Sentencia del Tribunal Supremo de 22-6-2026: 19 años, 8 meses y un día.
- Fuentes: <https://www.poderjudicial.es/cgpj/es/Poder-Judicial/Tribunal-Supremo/Noticias-Judiciales/El-Tribunal-Supremo-condena-al-exministro-Jose-Luis-Abalos-y-a-su-exasesor-Koldo-Garcia-a-24-anos-y-19-anos-de-prision--respectivamente--por-delitos-de-organizacion-criminal--cohecho--malversacion-y-trafico-de-influencias>
- Fuente abierta: sí · Grupo: `koldo_19`

**75:32 · El inmueble se adquirió como sede provisional de la presidencia por obras en la actual.** (hecho)

- Cita literal: «cuando veo que la comunidad adquiere un inmueble para provisionalmente ser la sede de la zona de presidencia»
- Qué dicen las fuentes: Es la explicación de la Comunidad: oficina temporal de Presidencia durante las obras de la Real Casa de Correos.
- Fuentes: <https://www.ultimahora.es/noticias/nacional/2026/07/29/2679311/psoe-pide-explicaciones-por-compra-atico-chamberi-para-oficina-ayuso.html> · <https://www.elespanol.com/madrid/comunidad/20260729/ayuso-criticas-comprar-atico-oficinas-comunidad-no-trata-desprestigiarme/1003744337867_0.html>
- Fuente abierta: no (solo extracto) · Grupo: `atico`

**79:05 · Es de la primera generación de la EGB y el BUP.** (hecho)

- Cita literal: «yo he sido de la primera generación de la EGB y del BUP»
- Qué dicen las fuentes: Nació en 1961; la primera promoción de la EGB (Ley General de Educación de 1970) pasó a 1.º de BUP en el curso 1975-76, cuando él tenía 14 años.
- Fuentes: <https://educacionfpydeportes.gob.es/revista-de-educacion/ca/dam/jcr:e29614f0-3d6d-463d-bddf-bc5dc227a1cd/1971re218informacion01-pdf.pdf> · <https://www.eldiario.es/politica/alberto-nunez-feijoo-breve-biografia-no-gallegos_1_8901349.html>
- Fuente abierta: no (solo extracto)

**80:04 · Polonia vive una situación de gran tensión en su frontera con Rusia.** (hecho)

- Cita literal: «nuestros colegas polacos, pues están con la frontera con Rusia en una situación de enorme tensión»
- Qué dicen las fuentes: En noviembre de 2026 Polonia desplegó fuerzas especiales en la frontera con Kaliningrado (Rusia) ante posibles sabotajes.
- Fuentes: <https://es.euronews.com/2026/11/03/polonia-despliega-a-sus-fuerzas-especiales-en-la-frontera-con-rusia-ante-la-amenaza-de-sab> · <https://es.euronews.com/2026/09/25/rusia-podria-estar-preparando-algo-grande-este-ano-advierte-el-ministro-de-exteriores-pola>
- Fuente abierta: no (solo extracto)

**80:50 · Ucrania no es miembro de la UE.** (hecho)

- Cita literal: «Ucrania todavía no es un país de la Unión Europea, pero ha sido invadido»
- Qué dicen las fuentes: Ucrania es país candidato; las negociaciones de adhesión siguen abiertas en 2026.
- Fuentes: <https://www.consilium.europa.eu/es/policies/eu-ukraine-relations/> · <https://es.euronews.com/2026/11/03/ucrania-asegura-que-hungria-no-bloquea-las-negociaciones-de-adhesion-a-la-union-europea>
- Fuente abierta: no (solo extracto)

**81:29 · Trump acaba de sufrir un revés electoral.** (hecho)

- Cita literal: «Pues acaba de llegarse un buen varapalo.»
- Qué dicen las fuentes: En las legislativas del 3-11-2026 los demócratas recuperaron la Cámara de Representantes; la prensa lo lee como reprimenda a Trump.
- Fuentes: <https://www.elnuevodia.com/corresponsalias/washington-dc/notas/los-democratas-ganaron-la-camara-baja-y-van-al-frente-en-el-senado-en-medio-de-una-reprimenda-al-presidente-trump/> · <https://lapatilla.com/2026/11/05/democratas-superaron-los-250-escanos-y-consolidaron-su-dominio-de-la-camara-baja/>
- Fuente abierta: no (solo extracto) · Grupo: `midterms`

**81:42 · Los demócratas han ganado con claridad las últimas elecciones en EE. UU.** (hecho)

- Cita literal: «Y los demócratas le han pegado un baño en estas últimas elecciones enorme.»
- Qué dicen las fuentes: Las proyecciones dan a los demócratas entre 244 y más de 250 de los 435 escaños de la Cámara; el control del Senado varía según la fuente.
- Fuentes: <https://lapatilla.com/2026/11/05/democratas-superaron-los-250-escanos-y-consolidaron-su-dominio-de-la-camara-baja/> · <https://www.telemundo.com/noticias/noticias-telemundo/elecciones-estados-unidos-2026/6-claves-de-las-elecciones-de-medio-termino-los-democratas-dominaran-e-rcna607368>
- Fuente abierta: no (solo extracto) · Grupo: `midterms`

**84:30 · En las andaluzas de junio de 2022 el PP logró su primera mayoría absoluta.** (hecho)

- Cita literal: «Perdón, el PP consigue la mayoría absoluta, la primera vez en la historia.»
- Qué dicen las fuentes: El PP andaluz gobernó con mayoría absoluta la legislatura 2022-2026. Que fuera la primera de su historia no figura en los extractos consultados.
- Fuentes: <https://es.ara.cat/politica/pp-vox-cierran-acuerdo-permitira-investir-juanma-moreno-andalucia_1_5787166.html>
- Fuente abierta: no (solo extracto)

**86:52 · La campaña electoral empieza esa medianoche (la entrevista se grabó el día anterior).** (hecho)

- Cita literal: «hasta las 12 de la noche no empieza la campaña»
- Qué dicen las fuentes: La campaña del 29-N empezó a las 00:00 del viernes 13 de noviembre de 2026.
- Fuentes: <https://www.democrata.es/elecciones-generales-espana/cuando-empieza-campana-electoral-29n-dia/>
- Fuente abierta: sí

**87:31 · Lleva 30 años en puestos de gestión.** (hecho)

- Cita literal: «soy un político que ha gestionado durante los últimos 30 años de su vida»
- Qué dicen las fuentes: Ocupa cargos de gestión al menos desde 1996 (secretario general en Sanidad/Insalud), después Correos (2000-2003) y la Xunta (2009-2022).
- Fuentes: <https://www.buscabiografias.com/biografia/verDetalle/11707/Alberto%20Nunez%20Feijoo> · <https://www.eldiario.es/politica/alberto-nunez-feijoo-breve-biografia-no-gallegos_1_8901349.html>
- Fuente abierta: no (solo extracto)

**87:41 · Ganó mayorías absolutas consecutivas.** (hecho)

- Cita literal: «allá donde me conocen me votaban y me votaban además con mayorías absolutas consecutivas»
- Qué dicen las fuentes: Ganó con mayoría absoluta las elecciones gallegas de 2009, 2012, 2016 y 2020.
- Fuentes: <https://maldita.es/malditodato/20200712/feijoo-consigue-su-mejor-resultado-electoral-y-renueva-su-mayoria-absoluta-la-octava-del-pp-en-galicia-en-11-elecciones> · <https://www.eldiario.es/politica/alberto-nunez-feijoo-breve-biografia-no-gallegos_1_8901349.html>
- Fuente abierta: no (solo extracto) · Grupo: `galicia_mayorias`

### No verificable (2)

**59:12 · A Dorado se le imputó narcotráfico tres o cuatro años después de terminar la relación.** (hecho)

- Cita literal: «a este señor se le imputa asuntos de narcotráfico pues no sé si tres o cuatro años después»
- Qué dicen las fuentes: Dorado fue detenido por narcotráfico en 2003; la fecha en que terminó la relación solo consta por la versión de Feijóo, y eldiario.es publicó en 2013 que hubo una felicitación navideña posterior a la supuesta ruptura.
- Fuentes: <https://www.eldiario.es/galicia/tain-revela-feijoo-hablo-narco_1_5627704.amp.html> · <https://www.eldiario.es/galicia/marcial-dorado-pleno-congreso-anos-amistad-narco-nunez-feijoo-vuelven_1_10021515.amp.html>
- Fuente abierta: no (solo extracto) · Grupo: `dorado`

**76:05 · Le dijeron que no está claro y que creen que sí puede usarse como oficina.** (hecho)

- Cita literal: «Y de hecho, creemos que sí se puede utilizar como oficina.»
- Qué dicen las fuentes: Lo que le dijeron no es comprobable. eldiario.es sostiene que la norma zonal impide el uso de oficinas; la Comunidad defendió el uso para oficina o reuniones.
- Fuentes: <https://www.eldiario.es/madrid/somos/atico-comprado-gobierno-ayuso-reuniones-no-oficina-destinarse-vivienda_1_13414404.amp.html>
- Fuente abierta: sí · Grupo: `atico`

### No he podido comprobarlo (20)

**3:14 · En esta campaña ha dado entrevistas en la SER, El País, La Sexta, Mediaset y Atresmedia.** (hecho)

- Cita literal: «estuve en la SER, en una entrevista en El País, en La Sexta»
- Qué dicen las fuentes: Localicé entrevistas recientes en El País (vía Europa Press), La Vanguardia y Telecinco (Mediaset); no localicé las de la SER, laSexta ni Atresmedia en campaña, lo que no significa que no existan.
- Fuentes: <https://www.democrata.es/elecciones-generales-espana/feijoo-gobierno-pp-vox-ministros-entrevista/> · <https://www.democrata.es/elecciones-generales-espana/feijoo-catalunya-inversiones-vox-entrevista-la-vanguardia-29n/>
- Fuente abierta: no (solo extracto)

**20:34 · El gasto público ha aumentado un 22 %.** (cifra)

- Cita literal: «porque se ha incrementado un 22 % el gasto público»
- Qué dicen las fuentes: No indica periodo ni si es en euros o en peso sobre el PIB. Localicé gasto público de 725.001 millones en 2024 y un aumento del 5,5 % en 2025, pero no la cifra de 2018 en fuente abierta, así que no puedo confirmar ni descartar el 22 %.
- Fuentes: <https://www.vozpopuli.com/espana/politica/sanchez-pulveriza-record-gasto-gobierno-espana-182-000-millones-euros.html> · <https://www.caixabankresearch.com/es/publicaciones/notas-breves-actualidad-economica-y-financiera/espana/deficit-publico-se-situo-2025>
- Fuente abierta: no (solo extracto)

**22:30 · El Gobierno ha adjudicado en los últimos consejos de ministros entre 18.000 y 19.000 millones en defensa.** (cifra)

- Cita literal: «el gobierno lleva adjudicado en los últimos consejos de ministros unos 18 .000, 19 .000 millones en gasto de defensa»
- Qué dicen las fuentes: No localicé la información de prensa que cita. Sí hay noticias de unos 14.000 millones en nuevos programas (21-10-2026), más de 2.500 millones para la Armada y helicópteros (2-11) y 2.196 millones en préstamos a Navantia; son prefinanciaciones y habilitaciones de gasto, no adjudicaciones, y la suma es mía, no de una fuente.
- Fuentes: <https://www.vozpopuli.com/espana/politica/robles-y-hereu-decididos-a-sacar-en-los-proximos-dias-14000-millones-para-el-sector-de-defensa-a-pesar-de-las-elecciones-y-las-dudas-del-pp.html> · <https://www.articulo14.es/defensa/el-ejecutivo-aprueba-mas-de-2-500-millones-para-la-modernizacion-de-la-armada-y-la-compra-de-helicopteros-h135-y-h160-20261102.html> · <https://www.hacienda.gob.es/en-GB/Prensa/Noticias/Paginas/2026/20261103-NP-CM-REPROGRAMACION-DEFENSA.aspx>
- Fuente abierta: sí

**23:35 · Se transfieren unos 50.000 millones de impuestos a pensiones.** (cifra)

- Cita literal: «Aproximadamente estamos hablando de unos 50 .000 millones, más o menos. que se transfieren de impuestos a pensiones.»
- Qué dicen las fuentes: No localicé el total anual. Datos parciales: las transferencias del Estado a la Seguridad Social sumaban 14.749 millones hasta mayo de 2026 (+10,4 %) y la prórroga presupuestaria prevé 19.888 millones más una transferencia adicional de 2.984 millones.
- Fuentes: <https://finantresnoticias.com/jubilacion/transferencias-estado-seguridad-social-crecen-revela-sobre-pensiones/> · <https://www.hacienda.gob.es/en-GB/Prensa/Noticias/Paginas/2026/20260707-NP-CM-TRANSFERENCIA-CREDITO.aspx>
- Fuente abierta: no (solo extracto)

**25:54 · En 2018 el gasto por absentismo fue de 13.000 millones.** (cifra)

- Cita literal: «Año 2018, gasto en asentismo, empresa de administración pública, 13 .000 millones.»
- Qué dicen las fuentes: No localicé ninguna fuente que dé 13.000 millones para 2018. Datos de otra naturaleza: el gasto de la Seguridad Social en incapacidad temporal fue de 4.337 millones en 2018 (El Debate) y Adecco cifra el coste total del absentismo de 2019 en 30.171 millones.
- Fuentes: <https://www.eldebate.com/economia/20251107/absentismo-hasta-242-millones-jornadas-perdidas-siete-meses-2025_352672.html> · <https://elderecho.com/el-absentismo-laboral-alcanza-un-maximo-historico-del-76-en-2025>
- Fuente abierta: no (solo extracto) · Grupo: `absentismo_coste`

**26:05 · En 2018 faltaban al trabajo cada día unas 450.000-470.000 personas (la transcripción dice "vienen").** (cifra)

- Cita literal: «número de personas que vienen a trabajar de media diaria, unas 450 -470 .000 personas»
- Qué dicen las fuentes: No localicé el dato de 2018. La transcripción dice «vienen a trabajar», que parece un error por «no vienen»; se interpreta como ausencias diarias.
- Fuentes: <https://www.amat.es/wp-content/uploads/2025/11/Informe-sobre-el-Absentismo-Laboral-por-Contingencias-Comunes-CC-en-Espana-de-2018-a-2024.pdf>
- Fuente abierta: no (solo extracto) · Grupo: `absentismo_personas`

**26:43 · El absentismo de los autónomos ronda el 4 %.** (cifra)

- Cita literal: «Si no recuerdo mal, está en el entorno del 4%.»
- Qué dicen las fuentes: No localicé una tasa de absentismo de autónomos del 4 % (él mismo dice «si no recuerdo mal»). Lo que hay es otra medida: la incidencia media mensual de bajas en 2025 fue de 10,06 por mil autónomos frente a 37,92 por mil asalariados.
- Fuentes: <https://www.infocop.es/la-incapacidad-temporal-en-trabajadores-por-cuenta-ajena-aumenta-en-espana-mientras-los-autonomos-presentan-cifras-muy-inferiores/>
- Fuente abierta: no (solo extracto) · Grupo: `bajas_autonomos`

**27:32 · En Correos bajó el absentismo del 8 % al 4 % hacia el año 2000.** (cifra)

- Cita literal: «Teníamos un absentismo del 8, te estoy hablando del año 2000 y lo bajamos al 4»
- Qué dicen las fuentes: Feijóo presidió Correos entre 2000 y 2003; las cifras del 8 % y el 4 % solo aparecen en sus propias declaraciones y en las del PP, sin contraste con memorias de la empresa.
- Fuentes: <https://www.eldiario.es/1_cbe758> · <https://www.newtral.es/feijoo-plantilla-correos-carteros/20230713/>
- Fuente abierta: no (solo extracto)

**27:54 · Los servicios autonómicos de salud tienen un 13-14 % de absentismo.** (cifra)

- Cita literal: «los servicios de salud tienen un 13, un 14 % de absentismo»
- Qué dicen las fuentes: No localicé una tasa del 13-14 % para los servicios autonómicos de salud. El dato más próximo es del sindicato SATSE: la sanidad pierde en torno al 10,5 % de sus horas por absentismo.
- Fuentes: <https://www.redaccionmedica.com/politica/20251027/el-efecto-de-las-guardias-en-bajas-del-sns-objeto-un-triple-estudio/252420_0.html>
- Fuente abierta: no (solo extracto)

**33:40 · El presupuesto gallego de 2009 preveía 10.000 millones de ingresos y fueron 8.000.** (cifra)

- Cita literal: «En el año 2009 había un presupuesto aprobado que decía que los ingresos serían 10 .000 millones.»
- Qué dicen las fuentes: No localicé los ingresos previstos y liquidados del presupuesto gallego de 2009.
- Fuente abierta: no (solo extracto)

**34:47 · Galicia tiene la población más dispersa de España, con 35.000 núcleos.** (cifra)

- Cita literal: «con la población más dispersa de España, 35 .000 núcleos de población»
- Qué dicen las fuentes: No localicé en esta búsqueda el número de núcleos o entidades de población de Galicia ni la comparación de dispersión con otras comunidades.
- Fuente abierta: no (solo extracto)

**42:16 · La fiesta del trono se celebraba a 25 km de la frontera.** (hecho)

- Cita literal: «la fiesta nacional de Marruecos se estaba celebrando a 25 kilómetros de la frontera»
- Qué dicen las fuentes: Mohamed VI presidió los actos en Tetuán (El Español: «a kilómetros del caos»); no localicé la distancia exacta a la frontera.
- Fuentes: <https://www.elespanol.com/corazon/casas-reales/20260801/fasto-militar-kilometros-caos-mohammed-vi-preside-acto-multitudinario-tetuan-plena-crisis-ceuta/1003744341343_0.html>
- Fuente abierta: no (solo extracto)

**52:20 · Medio millón de inmigrantes cobran el IMV sin haber trabajado en el último año ("la información que nos han trasladado").** (cifra)

- Cita literal: «hay medio millón de inmigrantes cobrándolo sin haber trabajado una sola hora en el último año»
- Qué dicen las fuentes: No localicé ningún dato oficial que respalde la cifra, que él atribuye a «información que nos han trasladado» y repite desde octubre de 2025. El Gobierno responde que el 83 % de los hogares perceptores son españoles; no hay desglose público por historial laboral.
- Fuentes: <https://es.ara.cat/politica/feijoo-presenta-barcelona-plan-migratorio-pp_1_5528143.html> · <https://www.eldiario.es/politica/feijoo-presenta-plan-inmigracion-no-convertir-barrios-enteros-lugares-irreconocibles_1_12681927.amp.html> · <https://maldita.es/malditobulo/20250930/inmigrantes-ilegales-ingreso-minimo-vital/>
- Fuente abierta: no (solo extracto) · Grupo: `imv`

**59:48 · Dorado iba a mítines de otros partidos y hay fotos con sus líderes.** (hecho)

- Cita literal: «Este señor iba a mítines de otros partidos políticos.»
- Qué dicen las fuentes: Solo localicé la propia afirmación de Feijóo (que el sumario recoge fotos de Dorado con personas de todos los partidos), sin verificación independiente.
- Fuentes: <https://dev.metropolitano.gal/enfoque/feijoo-sobre-marcial-dorado-cuando-le-conoci-habia-sido-contrabandista-nunca-narcotraficante>
- Fuente abierta: no (solo extracto) · Grupo: `dorado`

**61:10 · Dorado fue absuelto en ese juicio por contrabando.** (hecho)

- Cita literal: «por cierto, después creo que fue absuelto por ese juicio»
- Qué dicen las fuentes: No localicé la sentencia. Un titular de El Salto alude a una absolución de Dorado recurrida por la Fiscalía, pero no pude confirmar que sea el juicio por contrabando al que se refiere.
- Fuentes: <https://www.elsaltodiario.com/corrupcion/grande-marlaska-desestimo-recurso-fiscalia-absolucion-narco-relacionado-feijoo>
- Fuente abierta: no (solo extracto) · Grupo: `dorado`

**66:29 · A los 18 días de ser ministro Ábalos hubo un primer contrato de obra pública hoy investigado.** (cifra)

- Cita literal: «le nombra ministro de Fomento y a los 18 días hay un primer contrato de obra pública que ya está investigado»
- Qué dicen las fuentes: No localicé ninguna fuente con ese plazo de 18 días ni con la identificación del contrato. Lo investigado son adjudicaciones a Acciona y otras constructoras durante su etapa de ministro.
- Fuentes: <https://www.eldiario.es/politica/son-adjudicaciones-alianza-acciona-empresa-vinculada-cerdan-lupa-justicia_1_12779315.amp.html>
- Fuente abierta: no (solo extracto)

**70:46 · El PP está personado en 17 sumarios.** (cifra)

- Cita literal: «Pero es que hay 17 sumarios donde estamos personados.»
- Qué dicen las fuentes: No localicé la cifra de 17. La web que el PP lanzó en junio de 2026 habla de 15 causas judiciales (y de 17 procesados).
- Fuentes: <https://www.vozpopuli.com/espana/politica/el-pp-crea-una-web-con-el-mapa-de-la-corrupcion-ligada-al-psoe-15-causas-judiciales-94-investigados-y-1817-anos-de-carcel.html>
- Fuente abierta: no (solo extracto)

**71:15 · El PP ha pedido acto de conciliación con el periodista que publicó la oferta de un millón a Koldo y ha denunciado a la televisión.** (hecho)

- Cita literal: «hemos tenido que pedir un acto de conciliación con el periodista que ha dicho que el PP le había ofrecido un millón de euros»
- Qué dicen las fuentes: No localicé noticias del acto de conciliación ni de la denuncia a una televisión; sí la negativa del PP a la supuesta oferta (difundida por la Cadena SER).
- Fuentes: <https://rtvc.es/koldo-garcia-asegura-pp-ofrecio-millon-euros-mentir-sanchez-6-de-noviembre-de-2026/> · <https://www.eldiario.es/1_d0461b>
- Fuente abierta: no (solo extracto)

**79:28 · Felipe González dijo hace poco que se puede ser tonto en varios idiomas.** (cita_de_tercero)

- Cita literal: «pero decía que uno puede ser tonto en varios idiomas»
- Qué dicen las fuentes: No localicé esa frase de Felipe González.
- Fuentes: <https://es.ara.cat/politica/feijoo-renuncia-ingles-confia-movil-traduce-directamente_1_5773294.html>
- Fuente abierta: no (solo extracto)

**83:37 · El único concejal de Vox en Galicia (Avión, Ourense) se pasó al PP.** (hecho)

- Cita literal: «Tenías uno en un ayuntamiento de Avión, que es un pueblo de ahí de la provincia de Orense»
- Qué dicen las fuentes: Respaldado que Vox tenía una concejal en Avión (lista encabezada en 2023 por Lilian Cerdeira); no localicé noticias de su paso al PP.
- Fuentes: <https://www.publico.es/politica/galicia-consolida-territorio-hostil-vox.html> · <https://www.elespanol.com/quincemil/actualidad/galicia/20230426/lugar-galicia-no-puede-votar-partido-popular/759174638_0.html>
- Fuente abierta: no (solo extracto) · Grupo: `vox_galicia`

### No comprobables según la extracción, no buscadas (26)

- **9:23** · Tras las elecciones de 2023 se intentó durante semanas que no pronunciara el discurso de investidura. — «se pasaron semanas intentando que yo no pudiera hacer el discurso»
- **10:21** · Votó a Felipe González en 1982. — «Yo he votado a Felipe González en 1982»
- **11:08** · Sánchez pactó con Susana Díaz que él sería secretario general y ella candidata a la presidencia, y no lo cumplió. — «Yo es una persona que dice y que pacta, por ejemplo, con Susana Díaz»
- **15:47** · En los gobiernos autonómicos compartidos con Vox no ha habido problemas en esta etapa. — «en los gobiernos donde está Vox, en estas comunidades autónomas, no hemos tenido ningún problema en esta nueva etapa»
- **25:36** · Construir un millón de viviendas crearía 500.000 empleos. — «Si hacemos un millón de viviendas, crearemos 500 .000 puestos de trabajo.»
- **26:23** · Atribuye 20.000 millones a la diferencia de gasto por absentismo. — «Pero entramos en la salud mental. 20 .000 millones hay aquí.»
- **27:07** · En Correos faltaban 5.000 personas al día, y 8.000-10.000 lunes y viernes. — «yo cuando estaba en correos faltaban 5 .000 personas a trabajar todos los días»
- **28:00** · Reducir el absentismo liberaría 10.000-12.000 millones para pensiones. — «10 .000, 12 .000 millones para las pensiones»
- **28:42** · Sus datos de bajas de autónomos estaban entre el 3,5 % y el 4 %. — «Mis datos estaban entre el 3 ,5 y 4%»
- **36:59** · Los bancos ganan más con gobiernos de izquierda porque aumenta la deuda. — «Si los bancos nunca ganan tanto dinero cuando viene un gobierno de izquierda, se incrementa la deuda.»
- **40:06** · No se conoce el gasto real en defensa ni los adjudicatarios de los contratos. — «¿Tú sabes exactamente cuál es el gasto en defensa en nuestro país?»
- **41:49** · El CNI advirtió el 26 y 27 de julio de un movimiento en redes para entrar en Ceuta. — «que ya el 26 y 27 de julio ya estaban advirtiendo que se estaba habiendo un movimiento en redes» — No se buscó de forma específica. Contexto: los documentos desclasificados citan una alerta del CNI del 29 de julio y notas del 27 y el 30; no localicé avisos del día 26.
- **41:55** · El movimiento en redes tenía más de 180.000 seguidores. — «con un seguimiento de más de 180 .000 personas para invadir Ceuta» — No se buscó de forma específica. Contexto: ARA recoge un WhatsApp de los documentos desclasificados que habla de convocatorias de hasta 180.000 personas.
- **42:10** · La Comisaría de Extranjería de la Policía Nacional avisó de lo mismo. — «sino también al de la Comisaría de Extranjería de la Policía Nacional, que venía a decir lo mismo»
- **44:20** · El presidente entregó incompletos los informes del CNI. — «Tú diste los informes del CNI capados.»
- **45:35** · Está acreditado que los gendarmes marroquíes ordenaban el paso. — «Al final se acredita que los gendarmes marroquíes estaban ordenando y circulando.»
- **57:47** · La crema de la foto era por un herpes zóster. — «tenía un herpes zóster por si te interesa»
- **60:35** · Se lo presentó un compañero de la Xunta amigo de Dorado. — «yo a esta persona me la presentó un compañero de la Junta de Galicia»
- **60:53** · Cortó la relación al saber que Dorado tenía un juicio pendiente por contrabando. — «cuando observo que tenía todavía un juicio pendiente por contrabando»
- **61:18** · Alude a que otros tienen fotos con prostitutas pagadas con fondos públicos. — «lo que no tengo fotos, es con prostitutas financiadas con fondos públicos»
- **62:51** · Sánchez dice que abolirá la prostitución mientras su familia ha vivido de ella (frase cortada en la transcripción). — «Si yo digo que voy a derogar la prostitución y resulta que mi familia»
- **67:48** · Las elecciones se adelantaron en parte para evitar responsabilidades penales del PSOE. — «una de las razones por las que se han adelantado las elecciones es para evitar las responsabilidades penales»
- **69:36** · Cuca Gamarra lleva en el PP los asuntos judiciales y sabía que el abogado hablaba con otros abogados. — «Cuca es la que lleva en el partido los asuntos relacionados con tribunales»
- **70:59** · El PP no ha ofrecido dinero a nadie. — «No hay ningún ofrecimiento de dinero de mi partido a nadie.»
- **78:19** · No sabe inglés. — «Pues mira, yo no sé inglés, pero sé gobernar.»
- **84:09** · Llegó a la presidencia del PP en 2022 e intentó entenderse con Sánchez. — «Porque cuando llegué en el año Año 2022 intenté entenderme con él»

## Jordi Wild (entrevistador)

### Respaldada en parte / imprecisa (5)

**29:28 · El programa del PP quita el IVA y da cuota cero a los nuevos autónomos.** (hecho)

- Cita literal: «tu programa dice que les quitas el IVA a los nuevos y das cuota cero»
- Qué dicen las fuentes: El programa del PP (10-11-2026) incluye cuota cero el primer año para nuevos autónomos; la exención de IVA es para quienes facturen menos de 85.000 euros, no específicamente para los nuevos.
- Fuentes: <https://www.moncloa.com/2026/11/10/pp-plan-reconstruccion-3465233/>
- Fuente abierta: no (solo extracto)

**35:38 · El invitado ha criticado a Sánchez por no comprometerse al 3,5 % en defensa.** (hecho)

- Cita literal: «tú has criticado a Sánchez por no comprometerse al 3 ,5 % en defensa»
- Qué dicen las fuentes: Feijóo criticó en junio de 2025 el acuerdo de Sánchez en la OTAN (dijo que había «mentido» y que no tenía «legitimidad»); no localicé una cita en la que le reproche expresamente no comprometerse al 3,5 %, aunque en esta entrevista dice que él habría pedido «mayor plazo para conseguir el 3,5».
- Fuentes: <https://theobjective.com/espana/politica/2025-06-24/feijoo-ridiculo-desmentido-rutte-sanchez-defensa/> · <https://www.newtral.es/gasto-defensa-feijoo-factcheck/20260327/>
- Fuente abierta: no (solo extracto)

**53:28 · El plan del Reino Unido con Ruanda no funcionó por su coste.** (hecho)

- Cita literal: «El Reino Unido con Ruanda no salió bien porque era muy caro»
- Qué dicen las fuentes: El plan no llegó a funcionar (solo cuatro traslados voluntarios) y costó unos 700 millones de libras, pero además el Tribunal Supremo británico lo declaró ilegal en 2023 y el Gobierno de Starmer lo canceló en 2024.
- Fuentes: <https://www.africanews.com/amp/2026/06/02/court-rules-uk-does-not-have-to-pay-rwanda-over-failed-asylum-plan/> · <https://www.rte.ie/news/2026/0601/1576196-migration-uk-rwanda/>
- Fuente abierta: no (solo extracto)

**68:15 · La foto es de 1996.** (hecho)

- Cita literal: «lo sabes bien que es del 96»
- Qué dicen las fuentes: Las fotos se sitúan en el verano de 1995, no en 1996.
- Fuentes: <https://es.ara.cat/politica/elecciones-generales/marcial-dorado-relacion-tenia-feijoo_1_4757899.html> · <https://maldita.es/malditahemeroteca/20230719/feijoo-marcial-dorado-relacion-cronologia/>
- Fuente abierta: no (solo extracto) · Grupo: `foto`

**75:10 · La Comunidad de Madrid compró un piso de 6,7 millones que no puede usarse como oficinas.** (cifra)

- Cita literal: «cuando te enteras del tema del piso de 6 ,7 millones, que no puede ser oficinas»
- Qué dicen las fuentes: La compra costó 6,3 millones según El País (6,7 millones es el precio al que después se puso en venta). Según eldiario.es, la norma urbanística de la zona no permite oficinas en esa planta.
- Fuentes: <https://www.eldiario.es/madrid/somos/atico-comprado-gobierno-ayuso-reuniones-no-oficina-destinarse-vivienda_1_13414404.amp.html> · <https://es.ara.cat/politica/gobierno-ayuso-pago-6-3-millones-atico-lujo-madrid_1_5817231.html> · <https://www.canal26.com/internacionales/2026/09/18/el-atico-millonario-que-compro-el-gobierno-de-ayuso-con-fondos-publicos-no-encuentra-comprador-en-madrid/>
- Fuente abierta: sí · Grupo: `atico`

### Respaldada (15)

**1:38 · Las encuestas dan al invitado como favorito para ser presidente.** (hecho)

- Cita literal: «Hoy tengo, pues, según las encuestas, el máximo favorito para serlo»
- Qué dicen las fuentes: La media de 13 institutos a 9-11-2026 (Demócrata) da PP 31,2 %, PSOE 27,1 % y Vox 19,0 %; NC Report da al PP 136-138 escaños y a PP+Vox 203-207 (mayoría absoluta: 176).
- Fuentes: <https://www.democrata.es/encuestas/elecciones-generales/nc-report-9-noviembre-2026-pp-retrocede-psoe-100-escanos-vox/> · <https://es.euronews.com/2026/10/09/encuesta-preve-cambio-gobierno-espana-pp-vox-consolidarian-mayoria-frente-psoe>
- Fuente abierta: sí

**19:46 · La portavoz de campaña del PP dijo que el sistema de pensiones "va a petar".** (cita_de_tercero)

- Cita literal: «Esther Muñoz, tu portavoz de campaña, dijo que el sistema de pensiones, tal y como está, va a petar»
- Qué dicen las fuentes: Ester Muñoz dijo en un pódcast en octubre de 2026 que el sistema de pensiones «tal y como está, va a petar»; después lo matizó («podía petar»). La cita la escribe «Esther»; la portavoz se llama Ester.
- Fuentes: <https://diariodeavisos.elespanol.com/2026/10/pp-reforma-pensiones-ester-munoz-sistema-petara/> · <https://es.ara.cat/politica/pp-vuelve-liar-pensiones-esther-munoz-dice-sistema-colapsara_1_5879033.html> · <https://www.diariodeleon.es/nacional/261014/2100262/ester-munoz-estalla-tve-palabras-sobre-pensiones-izquierda-quiere-callados-conseguir.html>
- Fuente abierta: no (solo extracto)

**21:19 · Se está jubilando la generación más numerosa.** (hecho)

- Cita literal: «estamos ahora ante la mayor generación que se jubila»
- Qué dicen las fuentes: La generación del baby boom (más de nueve millones de nacidos entre 1958 y 1975-77) empezó a cumplir 65 años en 2023 y se jubilará progresivamente hasta alrededor de 2040, según AIReF, Banco de España y Fundación MAPFRE citados en prensa.
- Fuentes: <https://www.que.es/2025/08/28/jubilaciones-masivas-pensiones-cesta/> · <https://theobjective.com/economia/2026-06-09/jubilados-pension-20-anos-retraso-edad-retiro/>
- Fuente abierta: no (solo extracto)

**28:33 · La incidencia de bajas médicas entre autónomos ronda el 1 % (dato de los verificadores).** (cifra)

- Cita literal: «la incidencia de bajas médicas entre los trabajadores autónomos está en torno al 1%, aproximadamente»
- Qué dicen las fuentes: La incidencia media mensual de bajas por incapacidad temporal en 2025 fue de 10,06 por mil autónomos (≈1 %), frente a 37,92 por mil asalariados.
- Fuentes: <https://www.infocop.es/la-incapacidad-temporal-en-trabajadores-por-cuenta-ajena-aumenta-en-espana-mientras-los-autonomos-presentan-cifras-muy-inferiores/>
- Fuente abierta: no (solo extracto) · Grupo: `bajas_autonomos`

**33:22 · Durante su presidencia la deuda de Galicia pasó de 4.000 a 12.000 millones.** (cifra)

- Cita literal: «cuando fuiste el presidente de la Junta la deuda pasó de 4 .000 millones a 12»
- Qué dicen las fuentes: Maldita.es (Banco de España): la deuda de Galicia pasó de 4.282 millones en el segundo trimestre de 2009 a 11.823 millones en el de 2022.
- Fuentes: <https://maldita.es/malditodato/20230711/verificacion-deuda-cara-sanchez-feijoo/> · <https://www.publico.es/politica/rueda-endeuda-xunta-500-millones-euros-2031.html>
- Fuente abierta: no (solo extracto) · Grupo: `deuda_galicia`

**35:43 · Llegar al 3,5 % supondría unos 25.000 millones más de gasto.** (cifra)

- Cita literal: «Esto serían unos 25 .000 millones más de»
- Qué dicen las fuentes: Cálculo propio con datos del Banco de España: el PIB implícito es de ~1,74 billones (deuda de 1,763 billones = 101,4 %); pasar del 2,1 % al 3,5 % son unos 24.000 millones más al año.
- Fuentes: <https://www.bde.es/wbe/es/noticias-eventos/actualidad-banco-espana/deuda-aapp-2026t2.html> · <https://maldita.es/malditateexplica/20250624/espana-gasto-otan-defensa/>
- Fuente abierta: sí

**41:08 · La inmigración es una de las principales preocupaciones según el CIS.** (hecho)

- Cita literal: «es una de las mayores causas de preocupación en el CIS, que es la inmigración»
- Qué dicen las fuentes: En los barómetros del CIS la inmigración figura entre los primeros problemas (20,5 % en octubre de 2025; tercer puesto en mayo de 2026), por detrás de la vivienda.
- Fuentes: <https://www.infobae.com/espana/2026/05/29/la-dificultad-de-acceso-a-la-vivienda-se-cronifica-marca-record-como-el-problema-que-mas-preocupa-a-los-espanoles/> · <https://www.democrata.es/politica/la-inquietud-por-la-vivienda-se-dispara-18-puntos-y-bate-record-como-principal-problema-al-superar-el-55-de-menciones/>
- Fuente abierta: no (solo extracto)

**49:18 · El invitado defiende una "prioridad nacional" basada en arraigo, residencia y cotización.** (hecho)

- Cita literal: «Te he escuchado lo de la prioridad nacional, que es priorizar ayudas según arraigo, residencia, cotización»
- Qué dicen las fuentes: El PP ha definido la «prioridad nacional» como ayudas basadas en el arraigo: periodo mínimo de residencia, empadronamiento o cotización, «con independencia de la nacionalidad».
- Fuentes: <https://www.menorca.info/actualidad/nacional/2026/04/22/2614427/prioridad-nacional-desata-discrepancias-entre-vox-arraigo-espanoles-primero.html> · <https://www.elespanol.com/espana/politica/20260421/pp-corrige-mocion-vox-prioridad-nacional-ayudas-pide-otorgarlas-inspirandose-principio/1003744216189_0.html>
- Fuente abierta: no (solo extracto)

**56:47 · La proyección a 50 años es que el 40 % de la población sea de origen extranjero.** (cifra)

- Cita literal: «Y la proyección es que en 50 años sea un 40 % y no un 20%»
- Qué dicen las fuentes: Según las proyecciones del INE 2024-2074, el 39 % de la población habría nacido en el extranjero en 2074 (Vozpópuli). El INE publicó en junio de 2026 nuevas proyecciones 2026-2076 que las sustituyen; no localicé el porcentaje actualizado.
- Fuentes: <https://www.vozpopuli.com/economia/un-extranjero-por-cada-tres-nativos-asi-sera-la-espana-de-los-50-millones-de-habitantes.html> · <https://ine.es/dyngs/Prensa/PROP20262076.htm?print=1>
- Fuente abierta: no (solo extracto)

**58:08 · El invitado tuvo relación con una persona (Marcial Dorado) que es un delincuente.** (hecho)

- Cita literal: «tenga en algún momento una relación con una persona que es un criminal»
- Qué dicen las fuentes: Marcial Dorado fue detenido en 2003 y condenado por narcotráfico y blanqueo.
- Fuentes: <https://www.eldiario.es/galicia/marcial-dorado-pleno-congreso-anos-amistad-narco-nunez-feijoo-vuelven_1_10021515.amp.html> · <https://es.ara.cat/politica/elecciones-generales/marcial-dorado-relacion-tenia-feijoo_1_4757899.html>
- Fuente abierta: no (solo extracto) · Grupo: `dorado`

**64:21 · En la Gürtel Rajoy no estuvo imputado, como tampoco lo está Sánchez en los casos de su entorno.** (hecho)

- Cita literal: «en el que el presidente no está imputado, evidentemente como Sánchez, pero está cerca de»
- Qué dicen las fuentes: Rajoy declaró como testigo en el juicio de Gürtel en 2017, sin estar imputado; tampoco consta imputación de Sánchez en las causas de su entorno.
- Fuentes: <https://www.diaridetarragona.com/internacional/114381/testimonio-historico-rajoy-comienza-a-declarar-en-el-macrojuicio-de-la-gurtel-20170726-0013-yldt201707260013.html> · <https://www.diaridetarragona.com/espana/263175/tormenta-judicial-acorrala-gobierno-cinco-frentes-pedro-sanchez.html>
- Fuente abierta: no (solo extracto) · Grupo: `rajoy`

**65:04 · El caso ERE es uno de los mayores casos de corrupción de España.** (comparacion)

- Cita literal: «No, si los socialistas tienen también el caso ERE, que es uno de los más terribles»
- Qué dicen las fuentes: Se describe como el mayor caso de corrupción de Andalucía; hubo condenas a Griñán y Chaves (2019, confirmadas por el Supremo en 2022), parcialmente anuladas por el Tribunal Constitucional en 2024. «Terrible» es una valoración.
- Fuentes: <https://lamarea.com/2019/11/19/sentencia-del-caso-ere-grinan-seis-anos-de-carcel-chaves-nueve-anos-de-inhabilitacion> · <https://maldita.es/malditateexplica/20240722/sentencias-constitucional-caso-ere-andalucia-penas/>
- Fuente abierta: no (solo extracto)

**68:54 · Cuca Gamarra reconoció una reunión del abogado del PP (con el entorno de Koldo) que el partido había negado.** (hecho)

- Cita literal: «Cuca Gamarra reconoció una reunión del abogado del PP después de que vuestro partido negara esta reunión con Coldo»
- Qué dicen las fuentes: El 9-11-2026 Gamarra admitió que hubo una reunión entre el abogado Alberto Durán y Koldo García (negando la oferta de dinero), después de que Ester Muñoz dijera que «no ha habido ninguna reunión».
- Fuentes: <https://www.eldiario.es/1_d0461b> · <https://www.articulo14.es/politica/el-pp-rechaza-que-el-paso-a-un-lado-de-alberto-duran-tenga-relacion-con-su-reunion-con-koldo-garcia-20261107.html>
- Fuente abierta: sí

**73:27 · Casado cayó en una guerra interna del PP.** (hecho)

- Cita literal: «Bueno, Casadón sí que fue uno de los que cayó.»
- Qué dicen las fuentes: Casado dejó la presidencia del PP tras la crisis interna de febrero de 2022, con la mayoría de los barones pidiendo su dimisión.
- Fuentes: <https://es.ara.cat/politica/pp-entierra-casado-llamamiento-recuperar-unidad_1_4324309.html> · <https://www.periodicodeibiza.es/noticias/nacional/2022/04/01/1717413/congreso-del-gamarra-estamos-ante-momento-historico-del.html>
- Fuente abierta: no (solo extracto)

**79:47 · Algunos países europeos plantean volver al servicio militar obligatorio.** (hecho)

- Cita literal: «De que algunos países quieren volver Al servicio militar obligatorio»
- Qué dicen las fuentes: Croacia aprobó en 2025 reinstaurar el servicio obligatorio, Letonia lo recuperó en 2023 y Alemania tiene desde 2026 un modelo que puede volverse obligatorio.
- Fuentes: <https://www.statista.com/chart/35551/military-services-compulsory-and-voluntary-in-european-countries> · <https://es.ara.cat/internacional/europa/europa-encamina-recuperacion-servicio-militar_1_5576043.amp.html>
- Fuente abierta: no (solo extracto)

### No comprobables según la extracción, no buscadas (2)

- **4:53** · Vox avisó el día antes de que quería disponer de las grabaciones de las entrevistas. — «Que el día antes me avisaran de que a partir de ahora van a querer tener las grabaciones de cualquier tipo de entrevista»
- **29:12** · Hay autónomos poco más que mileuristas cuya cuota supone en torno al 20 % de sus ingresos. — «están pagando una cuota que les quita a lo mejor el 20 % de su sueldo»

## Páginas abiertas de verdad (49)

- <https://www.poderjudicial.es/cgpj/es/Poder-Judicial/Tribunal-Supremo/Noticias-Judiciales/El-Tribunal-Supremo-condena-al-exministro-Jose-Luis-Abalos-y-a-su-exasesor-Koldo-Garcia-a-24-anos-y-19-anos-de-prision--respectivamente--por-delitos-de-organizacion-criminal--cohecho--malversacion-y-trafico-de-influencias>
- <https://www.ine.es/dyngs/Prensa/ECP2T26.htm>
- <https://es.euronews.com/my-europe/2026/09/17/eurocamara-responsabiliza-marruecos-asalto-masivo-ceuta-rechazo-socialistas>
- <https://es.euronews.com/2026/11/10/gobierno-desclasifica-los-informes-del-cni-sobre-ceuta-que-pidio-la-jueza-tardon>
- <https://www.articulo14.es/politica/el-pp-rechaza-que-el-paso-a-un-lado-de-alberto-duran-tenga-relacion-con-su-reunion-con-koldo-garcia-20261107.html>
- <https://www.eldiario.es/madrid/somos/atico-comprado-gobierno-ayuso-reuniones-no-oficina-destinarse-vivienda_1_13414404.amp.html>
- <https://www.hacienda.gob.es/es-ES/Prensa/Noticias/Paginas/2026/20260331-NP-CIERRE-DEFICIT.aspx>
- <https://www.democrata.es/encuestas/elecciones-generales/nc-report-9-noviembre-2026-pp-retrocede-psoe-100-escanos-vox/>
- <https://www.bde.es/wbe/es/noticias-eventos/actualidad-banco-espana/deuda-aapp-2026t2.html>
- <https://www.articulo14.es/internacional/espana-el-unico-pais-de-la-ue-que-rechaza-acelerar-las-expulsiones-de-migrantes-20261001.html>
- <https://www.democrata.es/politica/congreso-y-senado/armengol-cita-a-robles-ante-la-comision-de-secretos-el-dia-6-y-deja-fuera-a-la-directora-del-cni/>
- <https://www.lamoncloa.gob.es/presidente/intervenciones/paginas/2023/prsp15112023.aspx>
- <https://www.esdiario.com/nacional/260801/194612/ceuta-mareta-sanchez-arranca-vacaciones-semana-incendios-crisis-migratoria.html>
- <https://es.ara.cat/sociedad/inmigracion/rutas-migratorias-letales-1-317-muertos-intentando-llegar-espana-cinco-meses_1_5765186.amp.html>
- <https://www.eldiario.es/1_d0461b>
- <https://www.vozpopuli.com/espana/politica/robles-y-hereu-decididos-a-sacar-en-los-proximos-dias-14000-millones-para-el-sector-de-defensa-a-pesar-de-las-elecciones-y-las-dudas-del-pp.html>
- <https://www.idescat.cat/emex/?id=251207&f=ssv&lang=es>
- <https://www.democrata.es/economia/fin-de-la-legislatura-sin-nuevos-presupuestos-por-primera-vez-en-democracia/>
- <https://www.elindependiente.com/espana/2025/11/20/las-acusaciones-populares-piden-30-anos-de-prision-para-abalos-y-koldo-y-revisar-si-deben-permanecer-en-libertad/amp/>
- <https://www.bolsamania.com/noticias/economia/absentismo-laboral-roza-maximos-historicos-espana-71-2025--22160214.html>
- <https://www.democrata.es/elecciones-generales-espana/cuando-empieza-campana-electoral-29n-dia/>
- <https://actualidad.asturias.es/documents/533407/0/2023_07_29+NP+Composicion+nuevo+gobierno.pdf>
- <https://www.poderjudicial.es/cgpj/en/Judiciary/Supreme-Court/Pressroom/Press-Archive/El-Tribunal-Supremo-confirma-penas-de-hasta-51-anos-de-prision-para-los-procesados-en-el--caso-Gurtel->
- <https://www.que.es/2020/10/14/ts-confirma-pp-lucro-gurtel/>
- <https://okdiario.com/espana/supremo-anula-parte-sentencia-gurtel-que-motivo-mocion-censura-mariano-rajoy-6280733/amp>
- <https://www.vozpopuli.com/espana/supremo-caja-b-pp_0_1400861295.html>
- <https://www.eldiario.es/politica/supremo-confirma-pp-financio-gurtel-boadilla-dicta-sexta-sentencia-firme-trama_1_10680051.html>
- <https://www.democrata.es/politica/ampliacion-robles-reclama-a-armengol-que-permita-la-comparecencia-de-la-jefa-del-cni-en-la-comision-de-secretos/amp/>
- <https://theobjective.com/espana/politica/2026-10-05/sanchez-robles-avisos-cni-ceuta-secretos/>
- <https://www.esdiario.com/nacional/260915/197848/robles-despeja-camino-directora-cni-dispuesta-dar-cara-gobierno-guarda-documentos.html>
- <https://www.infobae.com/espana/agencias/2026/09/22/robles-estara-en-la-comision-de-secretos-del-congreso-pero-no-la-directora-del-cni/>
- <https://www.moncloa.com/2026/08/30/comparecencia-directora-cni-pp-vox-3423305/>
- <https://www.diariodeleon.es/nacional/260905/2096410/feijoo-pide-robles-deje-comparecer-directora-cni-comision-secretos-verdad-ceuta.html>
- <https://www.eunews.it/2026/01/15/nel-2025-gli-ingressi-irregolari-nellue-sono-diminuiti-del-26-per-cento-ma-non-dal-mediterraneo/>
- <https://www.menorca.info/balears/noticias/2026/01/20/2552807/bajan-entradas-irregulares-menos-mediterraneo-occidental.html>
- <https://www.vozpopuli.com/espana/el-informe-de-frontex-evidencia-un-repunte-del-34-en-la-ruta-del-estrecho-sin-sumar-las-entradas-a-ceuta.html>
- <https://www.moncloa.com/2026/10/19/frontex-estrecho-inmigracion-llegadas-3451660/>
- <https://www.elobservador.com.uy/espana/actualidad/record-inmigrantes-ilegales-espana-63970-todo-2024-y-mas-10000-murieron-el-mar-n5977681>
- <https://ec.europa.eu/eurostat/statistics-explained/index.php?title=Enforcement_of_immigration_legislation_statistics>
- <https://maldita.es/desinfo/20260316/bruselas-lleva-a-espana-a-los-tribunales-por-ser-el-unico-pais-de-la-ue-que-no-exime-de-iva-a-los-autonomos/>
- <https://es.ara.cat/economia/bruselas-denuncia-espana-justicia-europea-no-eximir-pymes-autonomos-declarar-iva_1_5674902.html>
- <https://www.fiscal-impuestos.com/comision-europea-tjue-espana-no-transponer-normas-iva>
- <https://www.supercontable.com/boletin/H/articulos/espana_tribunales_europa_tjue_franquicia_iva_exencion_autonomos_pequenas_empresas.html>
- <https://maldita.es/malditahemeroteca/20230719/feijoo-marcial-dorado-relacion-cronologia/>
- <https://www.elplural.com/extratele/malas-lenguas-encuentra-archivo-tve-prueba-clave-fulmina-version-feijoo-relacion-marcial-dorado_400310102>
- <https://es.wikipedia.org/wiki/Operación_Nécora>
- <https://es.ara.cat/politica/elecciones-generales/marcial-dorado-relacion-tenia-feijoo_1_4757899.html>
- <https://www.eldiario.es/galicia/marcial-dorado-pleno-congreso-anos-amistad-narco-nunez-feijoo-vuelven_1_10021515.html>
- <https://www.eldiario.es/galicia/politica/marcial-dorado-narco-discreto_1_1027066.html>
