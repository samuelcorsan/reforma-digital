# Análisis técnico de la entrevista de Jordi Wild a Alberto Núñez Feijóo: entrevistado y entrevistador

*Documento descriptivo y medible. Describe qué hace cada persona y cuándo. No atribuye intenciones, rasgos de personalidad ni diagnósticos, y ninguna medida de este documento (pausas, voz, unidades de acción) sirve para saber si alguien dice la verdad. La expresión facial se informa solo en unidades de acción (AU) del sistema FACS, sin etiquetas de emoción. El entrevistado y el entrevistador se analizan **por separado**, cada uno frente a su propia línea base, y después se comparan. Las frases que comparan a los dos se generan a partir de las cifras, con el criterio indicado en cada una.*

## 1. Ficha de la entrevista

| Campo | Valor |
|---|---|
| Medio | YouTube · The Wild Project |
| Título | «The Wild Project #392 - Alberto Núñez Feijóo \| Su foto con el narco, Pensiones, Ayuso y Corrupción» |
| Fecha | 13/11/2026 |
| Duración del vídeo | 1 h 28 min 20 s (5300 s) |
| Parte analizada | transcripción y hablantes: todo el vídeo. Todas las medidas de este informe: desde el inicio de la entrevista (1:23) hasta su final (88:19), según `hablantes.json` |
| Personas analizadas | **entrevistado** (Alberto Núñez Feijóo) y **entrevistador** (Jordi Wild) |
| Enlace | https://www.youtube.com/watch?v=1YlGArMx_N4 |
| Formato | Entrevista larga en estudio, sin público, dos personas sentadas frente a frente; forma parte de una serie con los candidatos a la presidencia; los primeros 1:23 son una introducción común a las tres entrevistas y quedan fuera de las medidas |

Todos los minutos son tiempo del vídeo (m:ss).

## 2. Comparativa entre entrevistado y entrevistador

Las mismas medidas para las dos personas, en el mismo vídeo y con el mismo audio. La **d de Cohen** indica el tamaño de la diferencia (alrededor de 0,2 pequeña, 0,5 media, 0,8 o más grande); con cientos de frases, casi cualquier diferencia sería estadísticamente significativa, así que se informa el tamaño y no un valor p. En las frases de esta sección, una diferencia con |d| menor de 0,2 se da como inapreciable.

### 2.1 Reparto del habla

| Medida | Entrevistado | Entrevistador |
|---|---|---|
| palabras verificadas | 9256 | 3463 |
| % de las palabras verificadas de ambos | 72.8 | 27.2 |
| tiempo de habla verificado (min) | 53.0 | 17.7 |
| turnos verificados | 276 | 144 |
| mediana de palabras por turno | 23.0 | 15.0 |
| turno más largo (s) | 98.7 | 43.8 |
| veces que toma la palabra tras el otro | 59 | 54 |
| latencia mediana al tomar la palabra (s) | 0.04 | 0.14 |
| % de tomas de palabra con hueco < 0,2 s | 64.0 | 57.0 |

La mayor parte de las palabras verificadas son del entrevistado (72,8 % frente a 27,2 %). El 64 % de las veces que el entrevistado toma la palabra y el 57 % de las del entrevistador se producen con menos de 0,2 s de hueco: más de la mitad en ambos sentidos, es decir, habla encadenada o solapada con frecuencia. La medida no distingue quién interrumpe a quién.

### 2.2 Voz

| Medida | Entrevistado | Entrevistador | Tamaño de la diferencia |
|---|---|---|---|
| tono F0 medio (Hz) | 126.0 | 122.0 | d de Cohen entrevistado−entrevistador = +0.20 |
| variación de tono dentro de la frase (semitonos, sd) | 3.67 | 3.52 | d de Cohen entrevistado−entrevistador = +0.16 |
| rango de tono dentro de la frase (semitonos, p5–p95) | 11.7 | 11.4 | d de Cohen entrevistado−entrevistador = +0.09 |
| intensidad media (dB relativos) | 65.7 | 65.4 | d de Cohen entrevistado−entrevistador = +0.04 |
| variación de intensidad dentro de la frase (dB, sd) | 15.4 | 15.7 | d de Cohen entrevistado−entrevistador = -0.04 |
| velocidad (palabras/min) | 201.0 | 216.0 | d de Cohen entrevistado−entrevistador = -0.25 |
| frases medidas | 556 | 237 |  |
| desviación del tono entre frases (Hz, sd) | 15.8 | 15.0 |  |
| desviación de la velocidad entre frases (palabras/min, sd) | 59.0 | 62.0 |  |
| % de frases con cambio claro de tono (\|z\| ≥ 1,5 respecto a su propia media) | 11.2 | 12.2 | sube/baja: entrevistado 43/19 · entrevistador 19/10 |
| % de frases con cambio claro de volumen (\|z\| ≥ 1,5 respecto a su propia media) | 9.0 | 10.1 | sube/baja: entrevistado 3/47 · entrevistador 0/24 |
| % de frases con cambio claro de velocidad (\|z\| ≥ 1,5 respecto a su propia media) | 12.1 | 12.2 | sube/baja: entrevistado 46/21 · entrevistador 19/10 |

- **Tono.** 126 Hz en el entrevistado y 122 Hz en el entrevistador (d = +0,20: diferencia pequeña, mayor en el entrevistado). El tono medio refleja sobre todo la voz de cada persona, no una conducta.
- **Variación de tono dentro de la frase.** 3,67 semitonos en el entrevistado y 3,52 semitonos en el entrevistador (d = +0,16, |d| < 0,2: diferencia inapreciable). Frases con el tono claramente fuera de la propia media (|z| ≥ 1,5): en el entrevistado 43 suben y 19 bajan; en el entrevistador 19 suben y 10 bajan.
- **Intensidad.** 65,7 dB en el entrevistado y 65,4 dB en el entrevistador (d = +0,04, |d| < 0,2: diferencia inapreciable). La intensidad depende del micrófono y de la mezcla, así que una diferencia entre los dos no se puede atribuir a la forma de hablar.
- **Velocidad.** 201 palabras/min en el entrevistado y 216 palabras/min en el entrevistador (d = -0,25: diferencia pequeña, mayor en el entrevistador). Se mide solo en tramos de habla continua, sin pausas, por lo que las cifras son más altas que una velocidad media de conversación.

![voz](grafica_comparativa_voz.png)

![tono](grafica_tono.png)
![volumen](grafica_volumen.png)
![velocidad](grafica_velocidad.png)

### 2.3 Pausas

| Medida | Entrevistado | Entrevistador |
|---|---|---|
| pausas > 0,4 s | 119 | 34 |
| pausas por 1000 palabras | 12.9 | 9.8 |
| duración media (s) | 0.91 | 0.76 |
| duración mediana (s) | 0.72 | 0.63 |
| pausas de 1 s o más | 24 | 7 |
| pausa máxima (s) | 15.4 | 1.7 |
| pausas antes de frase con carga | 36 | 8 |
| % confirmadas por silencedetect | 21.0 | 9.0 |

El entrevistado hace más pausas por cada 1000 palabras (12,9 frente a 9,8). Las del entrevistado son más largas de media (0,91 s frente a 0,76 s). De 1 s o más: 24 del entrevistado y 7 del entrevistador. `silencedetect` confirma como silencio el 21 % de los huecos del entrevistado y el 9 % de los del entrevistador. Donde ese porcentaje no llega a la mitad, la mayoría de los huecos no son silencio para `ffmpeg`: pueden contener voz de la otra persona, risas, música o ruido (no se ha comprobado uno a uno).

### 2.4 Texto: pronombres, preguntas y patrones

| Medida | Entrevistado | Entrevistador | Nota |
|---|---|---|---|
| pronombre «yo» por 1000 palabras | 13.5 | 6.5 | recuento: entrevistado 125 · entrevistador 24 |
| pronombre «nosotros» por 1000 palabras | 0.3 | 0.3 | recuento: entrevistado 3 · entrevistador 1 |
| pronombre «tú» por 1000 palabras | 2.6 | 8.7 | recuento: entrevistado 24 · entrevistador 32 |
| pronombre «vosotros» por 1000 palabras | 0.0 | 1.9 | recuento: entrevistado 0 · entrevistador 7 |
| pronombre «ellos» por 1000 palabras | 0.2 | 0.3 | recuento: entrevistado 2 · entrevistador 1 |
| frases interrogativas | 46 | 60 | de las frases verificadas: entrevistado 552 · entrevistador 245 |
| contrastes «no X, sino Y» | 5 | 3 | detección automática sin revisar |
| listas de tres (candidatas) | 4 | 3 | detección automática sin revisar |
| preguntas seguidas por el mismo hablante (candidatas a retóricas) | 36 | 25 | detección automática sin revisar |
| frases con léxico de pérdida o riesgo | 10 | 1 | detección automática sin revisar |
| frases con léxico de logro o ganancia | 17 | 5 | detección automática sin revisar |
| relatos o personas concretas (candidatos) | 13 | 0 | detección automática sin revisar |

Lectura generada a partir de la tabla (por 1000 palabras verificadas de cada uno; «parecida» = menos de un 20 % de diferencia; por debajo de 1 por 1000 en los dos no se compara):

- «yo» explícito: más frecuente en el entrevistado (13,5 frente a 6,5).
- «nosotros» explícito: apenas aparece en ninguno de los dos (0,3 y 0,3).
- «tú» explícito: más frecuente en el entrevistador (8,7 frente a 2,6).
- «vosotros» explícito: más frecuente en el entrevistador (1,9 frente a 0,0).
- «ellos» explícito: apenas aparece en ninguno de los dos (0,2 y 0,3).
- Frases interrogativas: más frecuente en el entrevistador (16,4 frente a 5,0).
- Frases con léxico de pérdida o riesgo: más frecuente en el entrevistado (1,1 frente a 0,3).
- Frases con léxico de logro o ganancia: más frecuente en el entrevistado (1,8 frente a 1,4).
- Relatos o personas concretas (candidatos): más frecuente en el entrevistado (1,4 frente a 0,0).

Son recuentos automáticos por patrones, sin revisar uno a uno.

### 2.5 Cara: unidades de acción y postura

| Medida | Entrevistado | Entrevistador |
|---|---|---|
| % de fotogramas muestreados con su cara | 71.0 | 31.0 |
| fotogramas con su cara mientras habla / mientras habla el otro | 14482 / 938 | 4376 / 1762 |
| giro de cabeza: media (grados) | 29.2 | -40.2 |
| giro de cabeza: variabilidad (sd, grados) | 19.9 | 21.2 |
| cabeceo: media (grados) | -27.8 | -9.4 |
| cabeceo: variabilidad (sd, grados) | 20.9 | 25.7 |
| inclinación: media (grados) | -10.2 | -3.5 |
| inclinación: variabilidad (sd, grados) | 21.4 | 25.3 |
| ventanas de 6 s con alguna AU fuera de lo habitual (\|z\| ≥ 2 respecto a su propia línea base), % | 32.5 | 24.5 |

**Nivel medio de cada AU (0–1, sin calibrar)**

| AU | Entrevistado | Entrevistador | Tamaño de la diferencia |
|---|---|---|---|
| AU1 cejas: parte interna arriba | 0.449 | 0.443 | d (ventanas de 6 s) = +0.09 |
| AU2 cejas: parte externa arriba | 0.248 | 0.272 | d (ventanas de 6 s) = -0.38 |
| AU4 cejas bajan y se juntan | 0.517 | 0.398 | d (ventanas de 6 s) = +0.96 |
| AU5 párpado superior arriba | 0.33 | 0.358 | d (ventanas de 6 s) = -0.87 |
| AU6 mejillas elevadas | 0.17 | 0.163 | d (ventanas de 6 s) = +0.03 |
| AU7 párpados tensos | 0.08 | 0.069 | d (ventanas de 6 s) = +0.10 |
| AU12 comisura labios arriba | 0.102 | 0.098 | d (ventanas de 6 s) = -0.01 |
| AU14 hoyuelo comisura | 0.396 | 0.438 | d (ventanas de 6 s) = -0.54 |
| AU15 comisura labios abajo | 0.408 | 0.53 | d (ventanas de 6 s) = -1.60 |
| AU17 mentón arriba | 0.487 | 0.342 | d (ventanas de 6 s) = +5.26 |
| AU23 labios apretados | 0.507 | 0.645 | d (ventanas de 6 s) = -2.56 |
| AU24 labios presionados | 0.53 | 0.504 | d (ventanas de 6 s) = +0.50 |
| AU25 labios separados (habla) | 0.355 | 0.528 |  |
| AU26 mandíbula baja (habla) | 0.237 | 0.388 |  |
| AU43 ojos cerrados | 0.332 | 0.265 |  |

**Cambio de cada AU al hablar respecto a cuando habla el otro (misma persona)**

| AU | Entrevistado | Entrevistador |
|---|---|---|
| AU1 cejas: parte interna arriba | -0.021 | -0.014 |
| AU2 cejas: parte externa arriba | +0.053 | +0.018 |
| AU4 cejas bajan y se juntan | -0.086 | -0.041 |
| AU5 párpado superior arriba | +0.017 | +0.010 |
| AU6 mejillas elevadas | +0.052 | +0.032 |
| AU7 párpados tensos | +0.015 | -0.016 |
| AU12 comisura labios arriba | +0.030 | +0.019 |
| AU14 hoyuelo comisura | +0.023 | +0.029 |
| AU15 comisura labios abajo | -0.006 | -0.059 |
| AU17 mentón arriba | -0.014 | +0.002 |
| AU23 labios apretados | -0.026 | -0.023 |
| AU24 labios presionados | -0.024 | -0.019 |

- **Niveles absolutos.** Con diferencia grande (|d| ≥ 0,8, en ventanas de 6 s), el modelo da valores más altos al entrevistado en AU17, AU4 y al entrevistador en AU23, AU15, AU5. **Estas diferencias no se pueden leer como diferencias de expresión**: py-feat no está calibrado por persona, y la forma de la cara, el vello facial, las gafas, el ángulo de cámara (giro medio de cabeza: +29° el entrevistado y -40° el entrevistador) y la iluminación desplazan la línea base de cada cara. Son, en el mejor de los casos, rasgos de cómo el modelo ve cada rostro.
- **Dentro de cada persona** (más fiable). Los tres mayores cambios al hablar respecto a cuando habla el otro: en el entrevistado, AU4 -0,086; AU2 +0,053; AU6 +0,052; en el entrevistador, AU15 -0,059; AU4 -0,041; AU6 +0,032. El habla mueve la boca y contamina estas medidas (ver limitaciones). Fotogramas con su cara mientras habla el otro: 938 del entrevistado y 1762 del entrevistador; con menos de 1500 (5 minutos a 5 fps), la comparación hablar/escuchar del entrevistado es poco sólida.
- **Frecuencia de desviaciones.** El entrevistado tiene más ventanas de 6 s con alguna AU fuera de su propia línea base (32,5 % frente a 24,5 %; 5 puntos o más de diferencia). Cada uno se compara consigo mismo; no indica qué significa cada desviación.
- **Presencia en pantalla.** La cara del entrevistado se detecta en el 71 % de los fotogramas muestreados y la del entrevistador en el 31 %: la del entrevistado aparece 2,3 veces más. Depende de la realización (a quién enfoca la cámara).

![AU comparativa](grafica_comparativa_AU.png)

![AU](grafica_AU.png)

## 3. El entrevistado, por separado

### Pausas

- **119** huecos de más de 0,4 s entre palabras verificadas consecutivas. Duración media **0,91 s**, mediana 0,72 s, máxima 15.4 s. 24 duran 1 s o más y 2 duran 2 s o más.
- **36** van justo antes de una frase con carga: cifra (20), mencion politica (9), promesa (4), promesa+contraste (1), cifra+contraste (1), cifra+mencion politica (1).
- `ffmpeg silencedetect` confirma el 21%.
- Las cinco más largas: 78:49 (15.4 s, antes de «No, yo he sido de la primera…»); 84:19 (2.4 s, antes de «Las cosas fueron en mayo normales. En…»); 44:52 (2.0 s, antes de «¿Nos remontamos a la Ándalus? ¿Cuándo fue…»); 7:20 (1.9 s, antes de «algunos planteamientos que fueron modulando porque el…»); 11:24 (1.6 s, antes de «Claro, una vez que sale de secretario…»).

### Voz

- 556 frases medidas. Tono (F0) medio **126 Hz** (desviación entre frases 16 Hz; variación dentro de la frase 3,67 semitonos).
- Intensidad media 65.7 dB (relativa). Velocidad media **201 palabras/min** (mediana 192).
- Cambios claros respecto a su propia media (|z| ≥ 1,5): tono sube 43 / baja 19; volumen sube 3 / baja 47; velocidad sube 46 / baja 21 (frases).
- Las tres frases con el tono más alto respecto a su media: 74:22 (z = +3.4) «¿Ayuso es un activo de mi partido?…»; 13:48 (z = +3.4) «No, porque creo que no es el momento.…»; 54:15 (z = +3.3) «¿Usted tiene un contrato de trabajo?…».

### Respuestas a las preguntas clasificadas

Se detectaron automáticamente 60 pares pregunta-respuesta (intervenciones del entrevistador con «?» seguidas de habla del entrevistado). La clasificación de las respuestas se hace aparte, a mano, leyendo la transcripción (`clase_respuestas.json`); aquí entran las **38** cuya cita se ha validado como literal. Distribución: **responde**: 22, **en_parte**: 7, **otra_pregunta**: 6, **cambia_tema**: 2, **ataca_pregunta**: 1.

| Minuto de la respuesta | Clasificación | Cita literal de la respuesta | Pregunta |
|---|---|---|---|
| 7:00 | responde | «No, vamos a ver, Vox es un partido en el que yo no» | ¿No te sientes afín a Vox? |
| 7:13 | responde | «la idea de Europa yo no la comparto» | ¿Cuál sería la más grande que tengas? |
| 10:21 | otra_pregunta | «Yo he votado a Felipe González en 1982» | ¿A la inversa no habríais hecho vosotros lo mismo? |
| 13:05 | en_parte | «yo no voy a concretar, te lo digo honradamente, mi estrategia de negociación» | ¿Hay algún, por ejemplo, interior y exterior serán vuestros sí o sí? |
| 13:43 | en_parte | «Con la misma sinceridad que me preguntas, pues con la misma sinceridad intento responderte» | Y supongo que tendrás alguno que dirás, es que este es innegociable. |
| 13:48 | responde | «No, porque creo que no es el momento» | ¿Y por qué no? ¿Para no quitarte fuerte a la negociadora? |
| 15:43 | responde | «Yo puedo entender perfectamente la preocupación» | Es un tema que hay mucha gente que le preocupa. ¿Lo entiendes, la preocupación? |
| 18:39 | responde | «No va a haber un Ministerio de Igualdad» | el ministerio no va a existir como tal, sino que va a estar en otros lados, ¿no? |
| 19:59 | en_parte | «si la economía no crece de forma sana» | Yo te pregunto directamente, ¿va a petar el sistema de pensiones? ¿Esto es asumible a largo plazo? |
| 21:58 | en_parte | «Yo he dicho que tenemos que bajar los impuestos» | Entiendo que recaudar impuestos no, porque tú has dicho que los vas a bajar, ¿no? |
| 22:21 | responde | «Creo que hay una ocultación de gasto, creo que hay una serie de compromisos preanuales» | O sea, ¿crees que hay una falsificación de datos públicos? |
| 23:10 | en_parte | «Yo me comprometo a la actualización de las pensiones» | Entonces, ¿para ti cuál es la solución? |
| 23:29 | responde | «Con un crecimiento sano de la economía. Claro que hay un agujero.» | ¿Y cómo lo pensáis hacer cuando hay un agujero? |
| 24:44 | responde | «no tenemos previsto te contesto, no tenemos previsto ampliar» | quiere saber lo que vais a hacer |
| 26:28 | responde | «Yo no digo que todo sea fraude» | ¿Y eso no crees que puede ser también debido a la crisis de salud mental que está sufriendo la sociedad moderna? |
| 29:53 | responde | «No facturarán IVA y por tanto tendrán un 21 % de margen» | O sea, literalmente aquí afirmas que no pagarán IVA. |
| 34:06 | responde | «entre las tres o las cuatro comunidades autónomas de menor incremento de deuda pública» | que en tu caso personal cuando fuiste el gestor máximo de una comunidad pasó eso y ahora criticas al gestor actual? |
| 37:12 | responde | «Para determinados países sí, sin duda. Hay otros países que están saneados.» | no está llegando a unos extremos que empieza a ser inasumible en la economía global? |
| 37:38 | responde | «Es que yo he conseguido un superávit en los últimos presupuestos de Galicia» | O sea, si hubierais sido vosotros, podrías haber conseguido un superávit. |
| 39:44 | responde | «diré exactamente a qué gasto en defensa podemos llegar» | ¿Lo pedirás? Si eres presidente, ¿esto va a volver a pasar? |
| 46:00 | otra_pregunta | «¿No ha investigado el gobierno qué ha pasado?» | desde el gobierno dicen que esperemos, esperemos a la investigación |
| 49:41 | cambia_tema | «La prioridad nacional es cambiar el gobierno» | ¿Un español que nunca ha cotizado o un extranjero que lleva 20 años haciéndolo? |
| 51:05 | en_parte | «Las prioridades tienen que ser objetivas y legales» | Bueno, pero llevado a la inmigración |
| 51:28 | responde | «La conclusión es que es ilegal» | ¿Pero qué pesa más, la nacionalidad o la cotización? |
| 53:42 | responde | «Yo creo que en Italia ha funcionado» | El Reino Unido con Ruanda no salió bien porque era muy caro y al final no funcionó. |
| 55:04 | responde | «Yo soy partido de legalizar a un señor que tiene un contrato» | ¿Y en este caso sería justo que el inmigrante pague por el maltrato que le está dando su empleador? |
| 62:51 | ataca_pregunta | «Si yo digo que voy a derogar la prostitución y resulta que mi familia» | A ver, aquí habéis jugado sucio todos. |
| 63:17 | responde | «financiación de sus primarias ha habido dinero de la prostitución» | pero esto está certificado, o sea, tú aseguras aquí 100 % |
| 64:39 | otra_pregunta | «El caso Gürtel se ha juzgado por arriba, por abajo» | ¿Tú ahí también habrías pedido la dimisión? |
| 65:00 | otra_pregunta | «¿tú te acuerdas de la financiación de Filesa, Timesport, etcétera, etcétera?» | hay un tema de confianza y de ética y de moral en la política |
| 69:41 | en_parte | «Cuca tenía conocimiento de que nuestro abogado» | Entonces, ¿qué sabes de esto? Esto es una orden de alguien que tú puedas saber. ¿Qué ha pasado con esto? |
| 70:39 | responde | «que este abogado con carácter general no llevaba los asuntos que afectaban» | ¿Y por qué no está ya con vosotros este abogado? |
| 75:36 | responde | «ser la sede de la zona de presidencia, me parece normal» | que no puede ser oficinas, que es un poco un pifostio, ¿qué es lo que piensas? |
| 75:57 | otra_pregunta | «Pues evidentemente que pregunto, oye, ¿es verdad que esto no se puede utilizar» | ¿Y en el momento que te dicen casi 7 kilos? |
| 76:23 | cambia_tema | «Yo no quiero hablar de eso porque no quiero mentir» | ¿Te parece que 7 millones de euros para unas oficinas es algo asumible? |
| 76:43 | otra_pregunta | «de la presidencia de una comunidad autónoma, pues siempre nos parece caro» | Yo te pregunto por el tema del piso de ayuso. |
| 78:19 | responde | «Pues mira, yo no sé inglés, pero sé gobernar» | A ver. ¿Qué tal llevas el inglés? |
| 78:33 | responde | «De forma fluida, no de boca en la ceja.» | 2026, ¿tú crees que el presidente de un país de Europa tiene que saber inglés? |

Criterio de cada clase: «responde»: contesta a lo preguntado, aunque sea con matices; «en_parte»: contesta una parte y deja otra sin contestar; «otra_pregunta»: habla del tema pero contesta a una pregunta distinta de la formulada; «cambia_tema»: pasa a otro asunto; «ataca_pregunta»: cuestiona la premisa o la pregunta sin contestarla. Se clasifica la respuesta inmediata. La clasificación procede de una sola lectura, sin segundo codificador que la contraste; describe si el texto de la respuesta aborda lo preguntado, no por qué.

### Pronombres explícitos

| yo | nosotros/as | tú | vosotros/as | ellos/as |
|---|---|---|---|---|
| 125 | 3 | 24 | 0 | 2 |

A quién se refiere «ellos/ellas» (columna «Referente»: lectura manual del contexto si existe `ref_ellos.json`; «sin clasificar» = no se ha leído; «incierto» = no se puede asegurar):

| Minuto | Referente | Contexto |
|---|---|---|
| 7:18 | sin clasificar | …yo no la comparto el estado de las autonomías en la que ellos no creen yo sí creo algunos planteamientos… |
| 69:29 | sin clasificar | …causa la vista oral dura semanas o meses pues hay contactos entre ellos lo normal contactos de los abogados entre… |

### Repeticiones principales

| Expresión | Veces | Primer minuto |
|---|---|---|
| mayoría absoluta | 7 | 9:18 |
| caso de que | 4 | 13:56 |
| de mi partido | 5 | 15:17 |
| comunidades autónomas | 7 | 15:49 |
| de la unión europea | 9 | 20:10 |
| la unión europea | 14 | 20:10 |
| crecimiento sano de la | 3 | 20:42 |
| 000 millones | 11 | 22:35 |
| en este momento | 7 | 24:15 |
| a la gente | 4 | 26:55 |
| en el año 2018 | 4 | 36:24 |
| el gasto en defensa | 4 | 38:38 |
| gasto en defensa | 6 | 38:38 |
| de mi país | 5 | 41:48 |
| contrato de trabajo | 4 | 54:16 |
| 30 años | 6 | 60:06 |
| años de cárcel | 4 | 71:41 |
| 30 años de | 4 | 71:57 |
| 30 años de cárcel | 3 | 71:57 |
| cuando está en riesgo | 4 | 80:20 |

La lista es automática y puede mezclar muletillas con términos del tema.

### Otras técnicas detectadas en el texto (candidatas)

**Contrastes «no X, sino Y»: 5**

- 20:11 «por un incremento masivo de población y por lo tanto se produce más no de productividad, sino de población la productividad en España ha bajado la competitividad en nuestra economía ha bajado lo que s»
- 42:08 «Hacerle caso no solamente a sus informes, sino también al de la Comisaría de Extranjería de la Policía Nacional, que venía a decir lo mismo.»
- 49:11 «No solo España como Estado miembro, sino la Unión Europea.»
- 71:05 «No tiene autorización nadie para ofrecer, no un millón, sino un euro del PP.»
- 73:34 «Bueno, pero es que probablemente no solamente ocurría con una tensión en Madrid, sino que probablemente hubiese tensión con muchos otros equipos de otras comunidades autónomas.»

**Léxico de pérdida o riesgo: 10** (primeros 5)

- 12:35 «Vox se consolida como tercera fuerza política, el Partido Socialista vuelve a perder y...»
- 32:06 «Y con una inflación de un 4%, evidentemente has perdido tres puntos de poder adquisitivo.»
- 32:32 «Y quizás, no digo quizás, mi objetivo es que en esas patologías absolutamente invalidantes, patologías que ponen en riesgo la vida»
- 36:26 «Cuando además recibe 80 .000 millones de euros a fondo perdido de Europa, que por cierto es deuda, Jordi, tenemos que pagarla.»
- 45:27 «Ahora pregúntale a un musulmán ceutí qué opina de la invasión.»

**Léxico de logro o ganancia: 17** (primeros 5)

- 7:21 «algunos planteamientos que fueron modulando porque el box de hace cinco años seis años ahora ya ha ido modulando y ajustando no pero es que yo le doy mucha importancia a esto de los bandos lo que ha c»
- 12:15 «pues es una realidad incontestable el Partido Popular es un partido que es probable que vuelva a ganar»
- 12:24 «lo que pasó en la legislatura anterior es que nos faltaron cuatro diputados para la mayoría suficiente para investir a presidente de gobierno ¿qué ocurrirá si el Partido Popular vuelve a ganar?»
- 15:16 «Hemos hecho un documento marco dentro de mi partido y ese documento se ha respetado.»
- 20:43 «El crecimiento sano de la economía es conseguir mayor inversión pública, sobre todo inversión privada, traer inversión extranjera y hacer una economía tractora, que crea empleo de verdad.»

**Listas de tres: 4**

- 15:12 «Andalucía, Castilla y León»
- 60:33 «punto, pelota, y cuando»
- 68:35 «los partidos, la responsabilidad y la coherencia»
- 84:33 «un campañón, julio y agosto»

Preguntas seguidas por el mismo hablante (candidatas a retóricas): 36; relatos o personas concretas candidatos: 13 (en `retorica.csv`). Detecciones automáticas **no revisadas una a una**.

### Cara (unidades de acción)

- Su cara se detecta en 18534 de ~26080 fotogramas muestreados a 5 fps (**71%**).
- Valores medios (0–1, sin calibrar a la escala A–E de FACS): AU1 cejas: parte interna arriba 0,45; AU2 cejas: parte externa arriba 0,25; AU4 cejas bajan y se juntan 0,52; AU5 párpado superior arriba 0,33; AU6 mejillas elevadas 0,17; AU7 párpados tensos 0,08; AU12 comisura labios arriba 0,10; AU14 hoyuelo comisura 0,40; AU15 comisura labios abajo 0,41; AU17 mentón arriba 0,49; AU23 labios apretados 0,51; AU24 labios presionados 0,53.
- Máximo de AU12 (comisura de los labios arriba) en la media de 30 s hacia el **78:34** (0,22 frente a una media global de 0,10); AU6 (mejillas elevadas) en ese punto: 0,30 (media 0,17). No se interpreta.
- Cabeza girada de media 29° respecto a la cámara (giro medio +29°), lo que afecta a la fiabilidad de todas las AU.

### Momentos clave del entrevistado

Criterio: se recorre la entrevista en ventanas de ±3 s en las que esa persona está hablando y se cuenta en cuántas **categorías distintas** coinciden señales: voz (cambio de tono, volumen o velocidad con |z| ≥ 1,5 respecto a su propia media; cuentan como una sola categoría), pausa (de 1 s o más, o antes de una frase con carga), pregunta (una respuesta clasificada de la tabla anterior), técnica retórica y AU (alguna AU con |z| ≥ 2 frente a su propia línea base, en ventanas de 6 s). Se toman los que más categorías reúnen (al menos dos), separados al menos 60 s: hasta 15 para el entrevistado y hasta 10 para el entrevistador. **Que dos señales coincidan no demuestra que estén relacionadas**, y de un momento así no se deduce ninguna intención ni estado interno: se listan para poder ir a verlos.

#### Entrevistado · momento 1 · minuto 7:19 · categorías: voz, pausa, pregunta, retorica

- **Cita literal:** «estado de las autonomías en la que ellos no creen, yo sí creo. algunos planteamientos que fueron modulando porque el box»
- **Qué se mide:** pausa larga: 1.9 s; cambio tono: baja (z=-1.8); pregunta con respuesta clasificada: responde; tecnica retorica: encuadre ganancia.
- **Material:** `fotogramas/m01_antes.jpg`, `fotogramas/m01_durante.jpg`, `fotogramas/m01_despues.jpg`; clip con detección facial `clips_cara/m01_7-19.mp4`.

![antes](fotogramas/m01_antes.jpg) ![durante](fotogramas/m01_durante.jpg) ![después](fotogramas/m01_despues.jpg)

#### Entrevistado · momento 2 · minuto 10:24 · categorías: voz, pregunta, AU

- **Cita literal:** «González en 1982, Mire, y en mi partido a mí nunca me dijeron, no, no, como tú votaste a González, pues entonces no vas a ser»
- **Qué se mide:** cambio tono: sube (z=+1.5); cambio volumen: sube (z=+1.6); cambio velocidad: sube (z=+2.1); pregunta con respuesta clasificada: otra pregunta; AU fuera de lo habitual: AU23 labios apretados z=-2.4.
- **Material:** `fotogramas/m02_antes.jpg`, `fotogramas/m02_durante.jpg`, `fotogramas/m02_despues.jpg`; clip con detección facial `clips_cara/m02_10-24.mp4`.

![antes](fotogramas/m02_antes.jpg) ![durante](fotogramas/m02_durante.jpg) ![después](fotogramas/m02_despues.jpg)

#### Entrevistado · momento 3 · minuto 13:46 · categorías: voz, pregunta, AU

- **Cita literal:** «que me preguntas, pues con la misma sinceridad intento responderte. No, porque creo que no es el momento. Y en segundo lugar, yo no»
- **Qué se mide:** cambio tono: sube (z=+3.4); pregunta con respuesta clasificada: en parte; AU fuera de lo habitual: AU12 comisura labios arriba z=+4.0; AU14 hoyuelo comisura z=+2.5.
- **Material:** `fotogramas/m03_antes.jpg`, `fotogramas/m03_durante.jpg`, `fotogramas/m03_despues.jpg`; clip con detección facial `clips_cara/m03_13-46.mp4`.

![antes](fotogramas/m03_antes.jpg) ![durante](fotogramas/m03_durante.jpg) ![después](fotogramas/m03_despues.jpg)

#### Entrevistado · momento 4 · minuto 20:09 · categorías: voz, pregunta, retorica

- **Cita literal:** «crecido ¿Por qué ha crecido la economía española más que la media de la Unión Europea? por un incremento masivo de población y por lo tanto se»
- **Qué se mide:** cambio volumen: baja (z=-1.7); cambio velocidad: sube (z=+2.3); pregunta con respuesta clasificada: en parte; tecnica retorica: contraste no X sino Y.
- **Material:** `fotogramas/m04_antes.jpg`, `fotogramas/m04_durante.jpg`, `fotogramas/m04_despues.jpg`; clip con detección facial `clips_cara/m04_20-09.mp4`.

![antes](fotogramas/m04_antes.jpg) ![durante](fotogramas/m04_durante.jpg) ![después](fotogramas/m04_despues.jpg)

#### Entrevistado · momento 5 · minuto 36:10 · categorías: voz, pausa, AU

- **Cita literal:** «han tenido un superávit. Porque cuando un presidente de gobierno incrementa»
- **Qué se mide:** pausa larga: 1.4 s; cambio volumen: baja (z=-4.0); cambio velocidad: baja (z=-1.6); AU fuera de lo habitual: AU2 cejas: parte externa arriba z=+2.7; AU5 párpado superior arriba z=+2.1.
- **Material:** `fotogramas/m05_antes.jpg`, `fotogramas/m05_durante.jpg`, `fotogramas/m05_despues.jpg`; clip con detección facial `clips_cara/m05_36-10.mp4`.

![antes](fotogramas/m05_antes.jpg) ![durante](fotogramas/m05_durante.jpg) ![después](fotogramas/m05_despues.jpg)

#### Entrevistado · momento 6 · minuto 39:49 · categorías: voz, pregunta, AU

- **Cita literal:** «podemos llegar. No me voy a enfrentar con los aliados. Le voy a explicar cuáles son los problemas de España. Y si no puedo llegar al 2 .4, pues me»
- **Qué se mide:** cambio tono: sube (z=+1.6); cambio velocidad: sube (z=+1.7); pregunta con respuesta clasificada: responde; AU fuera de lo habitual: AU5 párpado superior arriba z=+2.1.
- **Material:** `fotogramas/m06_antes.jpg`, `fotogramas/m06_durante.jpg`, `fotogramas/m06_despues.jpg`; clip con detección facial `clips_cara/m06_39-49.mp4`.

![antes](fotogramas/m06_antes.jpg) ![durante](fotogramas/m06_durante.jpg) ![después](fotogramas/m06_despues.jpg)

#### Entrevistado · momento 7 · minuto 46:02 · categorías: voz, pregunta, retorica

- **Cita literal:** «¿No ha investigado el gobierno qué ha pasado? O sea, que desde el mes de julio… Mira, si tú tienes un presidente que acude a Ceuta y dice que ha habido una»
- **Qué se mide:** cambio tono: sube (z=+3.0); cambio volumen: baja (z=-3.1); pregunta con respuesta clasificada: otra pregunta; tecnica retorica: encuadre perdida.
- **Material:** `fotogramas/m07_antes.jpg`, `fotogramas/m07_durante.jpg`, `fotogramas/m07_despues.jpg`; clip con detección facial `clips_cara/m07_46-02.mp4`.

![antes](fotogramas/m07_antes.jpg) ![durante](fotogramas/m07_durante.jpg) ![después](fotogramas/m07_despues.jpg)

#### Entrevistado · momento 8 · minuto 48:51 · categorías: voz, pausa, retorica, AU

- **Cita literal:** «Que quede claro, no lo voy a consentir. Por lo tanto, si volvemos otra vez a facilitar el acceso y la invasión»
- **Qué se mide:** pausa antes de frase con carga: promesa; cambio volumen: baja (z=-3.4); tecnica retorica: encuadre perdida; AU fuera de lo habitual: AU4 cejas bajan y se juntan z=-2.0.
- **Material:** `fotogramas/m08_antes.jpg`, `fotogramas/m08_durante.jpg`, `fotogramas/m08_despues.jpg`; clip con detección facial `clips_cara/m08_48-51.mp4`.

![antes](fotogramas/m08_antes.jpg) ![durante](fotogramas/m08_durante.jpg) ![después](fotogramas/m08_despues.jpg)

#### Entrevistado · momento 9 · minuto 51:25 · categorías: voz, pregunta, AU

- **Cita literal:** «una ayuda social, La conclusión es que es ilegal. Dentro de»
- **Qué se mide:** cambio volumen: baja (z=-2.5); cambio velocidad: baja (z=-1.6); pregunta con respuesta clasificada: responde; AU fuera de lo habitual: AU5 párpado superior arriba z=+2.3.
- **Material:** `fotogramas/m09_antes.jpg`, `fotogramas/m09_durante.jpg`, `fotogramas/m09_despues.jpg`; clip con detección facial `clips_cara/m09_51-25.mp4`.

![antes](fotogramas/m09_antes.jpg) ![durante](fotogramas/m09_durante.jpg) ![después](fotogramas/m09_despues.jpg)

#### Entrevistado · momento 10 · minuto 62:49 · categorías: voz, pregunta, AU

- **Cita literal:** «no, no, perdona. ¿Pero cómo que si la sauna? Si yo digo que voy a derogar la prostitución y resulta que mi»
- **Qué se mide:** cambio tono: sube (z=+2.1); cambio velocidad: sube (z=+2.6); pregunta con respuesta clasificada: ataca pregunta; AU fuera de lo habitual: AU5 párpado superior arriba z=-2.2.
- **Material:** `fotogramas/m10_antes.jpg`, `fotogramas/m10_durante.jpg`, `fotogramas/m10_despues.jpg`; clip con detección facial `clips_cara/m10_62-49.mp4`.

![antes](fotogramas/m10_antes.jpg) ![durante](fotogramas/m10_durante.jpg) ![después](fotogramas/m10_despues.jpg)

#### Entrevistado · momento 11 · minuto 69:16 · categorías: voz, pausa, AU

- **Cita literal:** «Pues mira, te cuento lo que sé. Es evidente que los abogados,»
- **Qué se mide:** pausa larga: 1.2 s; cambio velocidad: sube (z=+2.8); AU fuera de lo habitual: AU24 labios presionados z=+2.3; AU17 mentón arriba z=+2.3; AU14 hoyuelo comisura z=-2.2.
- **Material:** `fotogramas/m11_antes.jpg`, `fotogramas/m11_durante.jpg`, `fotogramas/m11_despues.jpg`; clip con detección facial `clips_cara/m11_69-16.mp4`.

![antes](fotogramas/m11_antes.jpg) ![durante](fotogramas/m11_durante.jpg) ![después](fotogramas/m11_despues.jpg)

#### Entrevistado · momento 12 · minuto 78:36 · categorías: voz, pregunta, AU

- **Cita literal:** «forma fluida, no de boca en la ceja.»
- **Qué se mide:** cambio velocidad: baja (z=-2.8); pregunta con respuesta clasificada: responde; AU fuera de lo habitual: AU7 párpados tensos z=+5.2; AU14 hoyuelo comisura z=+4.3; AU6 mejillas elevadas z=+4.1.
- **Material:** `fotogramas/m12_antes.jpg`, `fotogramas/m12_durante.jpg`, `fotogramas/m12_despues.jpg`; clip con detección facial `clips_cara/m12_78-36.mp4`.

![antes](fotogramas/m12_antes.jpg) ![durante](fotogramas/m12_durante.jpg) ![después](fotogramas/m12_despues.jpg)

#### Entrevistado · momento 13 · minuto 80:29 · categorías: voz, pausa, AU

- **Cita literal:** «está en riesgo toda tu civilización, ¿qué has de hacer? ¿Has de dejar que te invadan? ¿Has de dejar ciudadanos»
- **Qué se mide:** pausa antes de frase con carga: mencion politica; cambio volumen: baja (z=-2.1); AU fuera de lo habitual: AU7 párpados tensos z=+4.3; AU24 labios presionados z=-2.1; AU17 mentón arriba z=-2.0.
- **Material:** `fotogramas/m13_antes.jpg`, `fotogramas/m13_durante.jpg`, `fotogramas/m13_despues.jpg`; clip con detección facial `clips_cara/m13_80-29.mp4`.

![antes](fotogramas/m13_antes.jpg) ![durante](fotogramas/m13_durante.jpg) ![después](fotogramas/m13_despues.jpg)

#### Entrevistado · momento 14 · minuto 85:26 · categorías: voz, pausa, AU

- **Cita literal:** «Dirá mi equipo, no, es que has hablado mucho de esto y no deberías de dar tantas explicaciones.»
- **Qué se mide:** pausa larga: 1.0 s; cambio velocidad: sube (z=+2.5); AU fuera de lo habitual: AU17 mentón arriba z=-2.9; AU7 párpados tensos z=+2.7; AU6 mejillas elevadas z=+2.5.
- **Material:** `fotogramas/m14_antes.jpg`, `fotogramas/m14_durante.jpg`, `fotogramas/m14_despues.jpg`; clip con detección facial `clips_cara/m14_85-26.mp4`.

![antes](fotogramas/m14_antes.jpg) ![durante](fotogramas/m14_durante.jpg) ![después](fotogramas/m14_despues.jpg)

#### Entrevistado · momento 15 · minuto 87:31 · categorías: voz, pausa, AU

- **Cita literal:** «que es imprescindible soy un político que ha gestionado durante los últimos 30 años de su vida es decir, toda su vida»
- **Qué se mide:** pausa antes de frase con carga: cifra; cambio volumen: baja (z=-3.8); cambio velocidad: baja (z=-1.6); AU fuera de lo habitual: AU5 párpado superior arriba z=+3.7; AU1 cejas: parte interna arriba z=+2.7.
- **Material:** `fotogramas/m15_antes.jpg`, `fotogramas/m15_durante.jpg`, `fotogramas/m15_despues.jpg`; clip con detección facial `clips_cara/m15_87-31.mp4`.

![antes](fotogramas/m15_antes.jpg) ![durante](fotogramas/m15_durante.jpg) ![después](fotogramas/m15_despues.jpg)

## 4. El entrevistador, por separado

### Pausas

- **34** huecos de más de 0,4 s entre palabras verificadas consecutivas. Duración media **0,76 s**, mediana 0,63 s, máxima 1.7 s. 7 duran 1 s o más y 0 duran 2 s o más.
- **8** van justo antes de una frase con carga: contraste (3), promesa (2), cifra (2), mencion politica (1).
- `ffmpeg silencedetect` confirma el 9%.
- Las cinco más largas: 43:27 (1.7 s, antes de «Tú imagínate que ya están entrando, los…»); 69:12 (1.3 s, antes de «Esto es una orden de alguien que…»); 69:00 (1.3 s, antes de «¿Qué sabes tú de esto? ¿Cuándo te…»); 58:09 (1.2 s, antes de «en algún momento una relación con una…»); 17:04 (1.1 s, antes de «¿Ministerio de Igualdad lo quitas si tú…»).

### Voz

- 237 frases medidas. Tono (F0) medio **122 Hz** (desviación entre frases 15 Hz; variación dentro de la frase 3,52 semitonos).
- Intensidad media 65.4 dB (relativa). Velocidad media **216 palabras/min** (mediana 211).
- Cambios claros respecto a su propia media (|z| ≥ 1,5): tono sube 19 / baja 10; volumen sube 0 / baja 24; velocidad sube 19 / baja 10 (frases).
- Las tres frases con el tono más alto respecto a su media: 34:43 (z = +3.9) «Una población más envejecida…»; 63:31 (z = +2.9) «del PP ¿Pero eso es una pregunta o es una afirmación?…»; 4:12 (z = +2.7) «Los de la lotería Ellos están para ayudarnos a los dos en caso…».

### Preguntas

- 60 frases interrogativas verificadas; 60 intervenciones con pregunta seguidas de respuesta del entrevistado; **38** preguntas cuya respuesta está clasificada en la tabla de la sección 3.

### Pronombres explícitos

| yo | nosotros/as | tú | vosotros/as | ellos/as |
|---|---|---|---|---|
| 24 | 1 | 32 | 7 | 1 |

A quién se refiere «ellos/ellas» (columna «Referente»: lectura manual del contexto si existe `ref_ellos.json`; «sin clasificar» = no se ha leído; «incierto» = no se puede asegurar):

| Minuto | Referente | Contexto |
|---|---|---|
| 4:13 | sin clasificar | …y javier collado mis dos niños de ildefonso los de la lotería ellos están para ayudarnos a los dos en… |

### Repeticiones principales

| Expresión | Veces | Primer minuto |
|---|---|---|
| hay mucha gente | 3 | 5:45 |
| mucha gente | 9 | 5:45 |
| mucha gente que | 3 | 5:45 |
| a lo mejor | 4 | 14:48 |
| es un tema | 4 | 15:39 |
| es una cosa | 3 | 16:52 |
| empieza a ser | 3 | 19:45 |
| has criticado | 3 | 21:38 |
| has dicho | 3 | 21:56 |
| porque al final | 3 | 43:41 |
| 7 millones | 3 | 75:12 |
| casi 7 kilos | 3 | 75:56 |

La lista es automática y puede mezclar muletillas con términos del tema.

### Otras técnicas detectadas en el texto (candidatas)

**Contrastes «no X, sino Y»: 3**

- 18:29 «Yo no te digo que tú no creas en la igualdad, digo, el ministerio no va a existir como tal, sino que va a estar en otros lados, ¿no?»
- 21:31 «tensión no tan solo para ahora, sino para el corto medio plazo.»
- 41:16 «no tan solo por un tema económico, sino también por un tema de choque cultural, o sea, algo está pasando y es evidente que está pasando en muchos sitios de España Cataluña, por ejemplo, yo creo que es»

**Léxico de pérdida o riesgo: 1**

- 43:46 «al mando mayor del ejército si la invasión, o como cada uno le llama diferente, supongo que tú le llamas una invasión, ¿no?»

**Léxico de logro o ganancia: 5**

- 28:05 «determinar que ese absentismo que ha subido es falso.»
- 33:10 «pero como tenemos poco tiempo, me sabe mal vamos a avanzar, vamos a seguir con economía pero vamos a avanzar has criticado mucho a Sánchez por la deuda la española que es elevadísima y que va creciend»
- 35:51 «Cuando tú seas presidente o si tú eres presidente, tú vas a, cuando puedas ya subir el 3 ,5%, lo vas a acabar haciendo.»
- 37:27 «¿Tú crees que en España puedes conseguir un superávit?»
- 37:34 «O sea, si hubierais sido vosotros, podrías haber conseguido un superávit.»

**Listas de tres: 3**

- 7:44 «sinceramente, Alberto, y esto»
- 12:51 «ejemplo, interior y exterior»
- 43:29 «entrando, los tenemos, y sacas»

Preguntas seguidas por el mismo hablante (candidatas a retóricas): 25; relatos o personas concretas candidatos: 0 (en `retorica.csv`). Detecciones automáticas **no revisadas una a una**.

### Cara (unidades de acción)

- Su cara se detecta en 7971 de ~26080 fotogramas muestreados a 5 fps (**31%**).
- Valores medios (0–1, sin calibrar a la escala A–E de FACS): AU1 cejas: parte interna arriba 0,44; AU2 cejas: parte externa arriba 0,27; AU4 cejas bajan y se juntan 0,40; AU5 párpado superior arriba 0,36; AU6 mejillas elevadas 0,16; AU7 párpados tensos 0,07; AU12 comisura labios arriba 0,10; AU14 hoyuelo comisura 0,44; AU15 comisura labios abajo 0,53; AU17 mentón arriba 0,34; AU23 labios apretados 0,64; AU24 labios presionados 0,50.
- Máximo de AU12 (comisura de los labios arriba) en la media de 30 s hacia el **4:20** (0,32 frente a una media global de 0,10); AU6 (mejillas elevadas) en ese punto: 0,32 (media 0,16). No se interpreta.
- Cabeza girada de media 40° respecto a la cámara (giro medio -40°), lo que afecta a la fiabilidad de todas las AU.

### Momentos clave del entrevistador

Mismo criterio. En el entrevistador, la categoría «pregunta» indica que en ese momento formula una de las preguntas cuya respuesta está clasificada.

#### Entrevistador · momento 1 · minuto 4:42 · categorías: voz, pausa

- **Cita literal:** «que se puede dar. Y quiero comenzar hablando de Vox, los que pueden ser tus socios. Mira, te era una pregunta que no pensaba hacer,»
- **Qué se mide:** pausa antes de frase con carga: contraste; cambio volumen: baja (z=-3.1); cambio velocidad: baja (z=-1.5).
- **Material:** `fotogramas/e01_antes.jpg`, `fotogramas/e01_durante.jpg`, `fotogramas/e01_despues.jpg`; clip con detección facial `clips_cara/e01_4-42.mp4`.

![antes](fotogramas/e01_antes.jpg) ![durante](fotogramas/e01_durante.jpg) ![después](fotogramas/e01_despues.jpg)

#### Entrevistador · momento 2 · minuto 35:52 · categorías: voz, pausa, retorica

- **Cita literal:** «potente. Cuando tú seas presidente o si tú eres presidente, tú vas a, cuando puedas ya»
- **Qué se mide:** pausa antes de frase con carga: cifra; cambio volumen: baja (z=-2.8); tecnica retorica: encuadre ganancia.
- **Material:** `fotogramas/e02_antes.jpg`, `fotogramas/e02_durante.jpg`, `fotogramas/e02_despues.jpg`; clip con detección facial `clips_cara/e02_35-52.mp4`.

![antes](fotogramas/e02_antes.jpg) ![durante](fotogramas/e02_durante.jpg) ![después](fotogramas/e02_despues.jpg)

#### Entrevistador · momento 3 · minuto 37:25 · categorías: voz, pregunta, retorica

- **Cita literal:** «¿Tú crees que en España puedes conseguir un superávit?»
- **Qué se mide:** cambio velocidad: sube (z=+1.7); pregunta con respuesta clasificada: formula la pregunta; tecnica retorica: encuadre ganancia.
- **Material:** `fotogramas/e03_antes.jpg`, `fotogramas/e03_durante.jpg`, `fotogramas/e03_despues.jpg`; clip con detección facial `clips_cara/e03_37-25.mp4`.

![antes](fotogramas/e03_antes.jpg) ![durante](fotogramas/e03_durante.jpg) ![después](fotogramas/e03_despues.jpg)

#### Entrevistador · momento 4 · minuto 43:27 · categorías: voz, pausa, retorica, AU

- **Cita literal:** «y además compararlo con lo que dijo Sánchez. Tú imagínate que ya están entrando, los tenemos,»
- **Qué se mide:** pausa larga: 1.7 s; cambio volumen: baja (z=-2.3); tecnica retorica: lista de tres candidata; AU fuera de lo habitual: AU7 párpados tensos z=+2.7; AU2 cejas: parte externa arriba z=+2.3.
- **Material:** `fotogramas/e04_antes.jpg`, `fotogramas/e04_durante.jpg`, `fotogramas/e04_despues.jpg`; clip con detección facial `clips_cara/e04_43-27.mp4`.

![antes](fotogramas/e04_antes.jpg) ![durante](fotogramas/e04_durante.jpg) ![después](fotogramas/e04_despues.jpg)

#### Entrevistador · momento 5 · minuto 50:05 · categorías: voz, pregunta, AU

- **Cita literal:** «Lo malo es que, fíjate una cosa, es que ya parece que no... Es Es que, claro, las otras han sido más largas. Ya no»
- **Qué se mide:** cambio tono: sube (z=+2.6); cambio volumen: baja (z=-2.9); pregunta con respuesta clasificada: formula la pregunta; AU fuera de lo habitual: AU23 labios apretados z=-2.0.
- **Material:** `fotogramas/e05_antes.jpg`, `fotogramas/e05_durante.jpg`, `fotogramas/e05_despues.jpg`; clip con detección facial `clips_cara/e05_50-05.mp4`.

![antes](fotogramas/e05_antes.jpg) ![durante](fotogramas/e05_durante.jpg) ![después](fotogramas/e05_despues.jpg)

#### Entrevistador · momento 6 · minuto 64:13 · categorías: voz, pregunta, AU

- **Cita literal:** «Yo te pregunto lo mismo cuando pasó el caso Gürtel y Rajoy, un caso también gravísimo de tu partido,»
- **Qué se mide:** cambio volumen: baja (z=-2.7); cambio velocidad: baja (z=-1.9); pregunta con respuesta clasificada: formula la pregunta; AU fuera de lo habitual: AU5 párpado superior arriba z=+2.9.
- **Material:** `fotogramas/e06_antes.jpg`, `fotogramas/e06_durante.jpg`, `fotogramas/e06_despues.jpg`; clip con detección facial `clips_cara/e06_64-13.mp4`.

![antes](fotogramas/e06_antes.jpg) ![durante](fotogramas/e06_durante.jpg) ![después](fotogramas/e06_despues.jpg)

#### Entrevistador · momento 7 · minuto 69:00 · categorías: voz, pausa, AU

- **Cita literal:** «después de que vuestro partido negara esta reunión con Coldo. ¿Qué sabes tú de esto? ¿Cuándo te enteras de esto? Creo que este abogado»
- **Qué se mide:** pausa larga: 1.3 s; cambio tono: sube (z=+2.2); AU fuera de lo habitual: AU23 labios apretados z=-2.2; AU15 comisura labios abajo z=-2.0.
- **Material:** `fotogramas/e07_antes.jpg`, `fotogramas/e07_durante.jpg`, `fotogramas/e07_despues.jpg`; clip con detección facial `clips_cara/e07_69-00.mp4`.

![antes](fotogramas/e07_antes.jpg) ![durante](fotogramas/e07_durante.jpg) ![después](fotogramas/e07_despues.jpg)

#### Entrevistador · momento 8 · minuto 78:19 · categorías: voz, pregunta, AU

- **Cita literal:** «¿Qué tal llevas el inglés? Y ahora es pregunta»
- **Qué se mide:** cambio volumen: baja (z=-2.8); pregunta con respuesta clasificada: formula la pregunta; AU fuera de lo habitual: AU7 párpados tensos z=+4.0; AU12 comisura labios arriba z=+3.9; AU6 mejillas elevadas z=+3.8.
- **Material:** `fotogramas/e08_antes.jpg`, `fotogramas/e08_durante.jpg`, `fotogramas/e08_despues.jpg`; clip con detección facial `clips_cara/e08_78-19.mp4`.

![antes](fotogramas/e08_antes.jpg) ![durante](fotogramas/e08_durante.jpg) ![después](fotogramas/e08_despues.jpg)

#### Entrevistador · momento 9 · minuto 84:02 · categorías: voz, pausa, AU

- **Cita literal:** «Pues mira, ya hablamos de lo último. Ya es la última cosa que te pido. Defíneme a Pedro Sánchez.»
- **Qué se mide:** pausa antes de frase con carga: mencion politica; cambio tono: baja (z=-1.6); cambio velocidad: sube (z=+2.4); AU fuera de lo habitual: AU17 mentón arriba z=+2.3.
- **Material:** `fotogramas/e09_antes.jpg`, `fotogramas/e09_durante.jpg`, `fotogramas/e09_despues.jpg`; clip con detección facial `clips_cara/e09_84-02.mp4`.

![antes](fotogramas/e09_antes.jpg) ![durante](fotogramas/e09_durante.jpg) ![después](fotogramas/e09_despues.jpg)

#### Entrevistador · momento 10 · minuto 86:43 · categorías: voz, AU

- **Cita literal:** «aquí ahora mismo te despido y hay un alegato final y estamos en campaña tienes la cámara esa para decir lo que te dé la real gana ha sido un placer así»
- **Qué se mide:** cambio tono: sube (z=+1.7); cambio velocidad: sube (z=+1.5); AU fuera de lo habitual: AU5 párpado superior arriba z=+6.3; AU2 cejas: parte externa arriba z=+5.1; AU1 cejas: parte interna arriba z=+4.0.
- **Material:** `fotogramas/e10_antes.jpg`, `fotogramas/e10_durante.jpg`, `fotogramas/e10_despues.jpg`; clip con detección facial `clips_cara/e10_86-43.mp4`.

![antes](fotogramas/e10_antes.jpg) ![durante](fotogramas/e10_durante.jpg) ![después](fotogramas/e10_despues.jpg)

## 5. Limitaciones

**Emociones.** Las secciones de este documento no usan modelos de emociones: en la extracción de AU el de py-feat está sustituido por una función que devuelve NaN (`scripts/face_detector.py`). Si se ejecutan aparte clasificadores de expresión o de emoción en la voz, sus resultados y sus límites van en sus propios anexos.

**Qué no mide.** Pausas, cambios de voz, unidades de acción y postura son conductas observables. No existe base para leerlas como señales de sinceridad o de engaño, y este informe no lo hace. No se mide la mirada, y el parpadeo no se analiza.

**Comparación entre personas.** Las AU de py-feat no están calibradas por persona: la forma de la cara, el vello facial, las gafas, el ángulo de cámara y la iluminación cambian el valor base. La comparación de niveles absolutos de AU entre entrevistado y entrevistador es, por eso, la parte más débil del informe; las comparaciones dentro de cada persona (hablar frente a escuchar, desviaciones frente a su propia línea base) son más fiables. En la voz, el tono medio refleja sobre todo la voz de cada uno, y la intensidad depende del micrófono y de la mezcla.

**Transcripción.** Whisper `large-v3` comete errores, sobre todo en nombres propios y en el habla solapada. Las cifras escritas con dígitos las genera el modelo. No se ha revisado la transcripción completa a mano.

**Separación de hablantes.** pyannote 3.1 separó 2 voces en todo el vídeo; las dos con más tiempo suman el 100% del habla detectada. La asignación de papeles se decidió para este vídeo y está en `hablantes.json`. Una verificación por huella de voz (wespeaker) comprobó cada tramo de 1 s o más: se verificó el 85% de las palabras; el 87% de las del entrevistado (9256 de 10685) y el 81% de las del entrevistador (3667 de 4501). **Solo las palabras verificadas se usan** en pausas, voz, retórica y cara. Las frases cortas dichas encima de la otra persona tienden a quedar sin verificar, de modo que las réplicas breves y las interrupciones de ambos están infrarrepresentadas. Tramos limpios usados como huella de referencia: entrevistado 137, entrevistador 43.

**Pausas.** Se miden entre palabras consecutivas verificadas de la misma persona; los huecos pueden contener voz de la otra persona, risas, música o habla no transcrita. `silencedetect` confirma el 21% de las del entrevistado y el 9% de las del entrevistador.

**Voz.** F0 e intensidad se miden con Praat sobre el audio publicado (mezcla y compresión incluidas). Los cambios se definen respecto a la media de cada persona en este vídeo. Tono, volumen y velocidad están correlacionados entre sí.

**Cara.** py-feat (RetinaFace + modelo de AU) es un modelo estadístico: sus intensidades no son una codificación FACS manual. El giro de la cabeza, el habla y los cambios de plano alteran las AU sin que cambie el gesto. Con media de 0,40 o más en las dos personas (valor base alto, poco margen para subir): AU1, AU15, AU23, AU24. Muestreo a 5 fps. La realización decide a quién se ve: hay 18534 fotogramas con la cara del entrevistado y 7971 con la del entrevistador.

**Identidad de la cara.** Las caras se agruparon por similitud (k-means, 10 grupos): 5 grupos se asignaron al entrevistado, 4 al entrevistador y 1 se descartaron. El script propone la asignación por el acoplamiento entre el movimiento de la boca y el habla verificada de cada uno; en esta entrevista la asignación final se fijó a mano en `hablantes.json` (`grupos_cara`). Nota del analista: «Grupos asignados tras revisar tmp/montaje_grupos.jpg y la coincidencia con quién habla en cada plano; el grupo 4 son imágenes de archivo y se descarta. El grupo 1 incluye algún recorte suelto de otra persona.» No se usó reconocimiento facial contra ninguna base de datos. Solo entran caras detectadas con confianza alta y de 50 px de ancho o más, y puede haber fotogramas mal asignados.

**Retórica y preguntas.** Los patrones son expresiones regulares (listas en `scripts/08_retorica.py`): no son exhaustivos y tienen falsos positivos, por ejemplo un verbo de la lista de «pérdida» usado en otro sentido. Las preguntas formuladas como afirmación, sin «?», no se detectan automáticamente. La clasificación de las respuestas procede de una sola lectura; al ser el contenido político, otra persona podría clasificar distinto algunos casos.

**Momentos clave.** Umbrales fijados por el analista (±3 s, |z| ≥ 1,5 en voz, |z| ≥ 2 en AU). Con 25 momentos y varias señales posibles, alguna coincidencia será casual.

**Alcance.** Es una sola entrevista de unos 88 minutos. Nada de lo medido permite concluir sobre intenciones, estados internos, sinceridad o rasgos de ninguna de las dos personas; solo describe conductas observables y cuándo ocurren.

## 6. Archivos

Presentes en la carpeta al generar este informe: `informe.md`, `informe_tonalidad.md`, `informe_expresiones.md`, `informe_movimiento.md`, `verificacion_datos.md`, `verificacion_datos.csv`, `comparativa.csv`, `pausas_entrevistado.csv`, `pausas_entrevistador.csv`, `voz_entrevistado.csv`, `voz_entrevistador.csv`, `cara_entrevistado.csv`, `cara_entrevistador.csv`, `momentos_entrevistado.csv`, `momentos_entrevistador.csv`, `centroides_entrevistado.npz`, `centroides_entrevistador.npz`, `transcripcion.csv`, `palabras.csv`, `palabras_verificadas.csv`, `retorica.csv`, `qa_pares.csv`, `clase_respuestas.json`, `diarizacion.csv`, `cara_grupos_identidad.csv`, `cambios_tema_aprox.csv`, `hablantes.json`, `grafica_tono.png`, `grafica_volumen.png`, `grafica_velocidad.png`, `grafica_AU.png`, `grafica_comparativa_voz.png`, `grafica_comparativa_AU.png`, `fotogramas/`, `clips_cara/`, `scripts/`. En los nombres por persona, `_entrevistado` y `_entrevistador`; en `fotogramas/`, m = entrevistado y e = entrevistador.
