# Cómo mueve cada uno sus rasgos al hablar, partiendo de su cara de base: Alberto Núñez Feijóo y Jordi Wild (YouTube · The Wild Project, 13/11/2026)

*Anexo. Mide cuánto y cómo se aparta la cara de cada uno, mientras habla, de su propia cara mientras escucha: cejas, ojos, boca y cabeza. Las cifras salen del vídeo de la entrevista. Es una aproximación y describe movimiento, no emociones, intenciones ni rasgos de carácter; tampoco sirve para saber si alguien dice la verdad. Las frases que comparan se generan a partir de las cifras, con el criterio indicado en cada una.*

## 1. Lo esencial

- **Cejas al hablar** (altura respecto a su base al escuchar): -3 % el entrevistado y -1 % el entrevistador; parecido en los dos (menos de 2 puntos de diferencia).
- **Apertura de la boca al hablar** (en % de la anchura de su boca, respecto a su base): habitual 0,3 % el entrevistado y 0,9 % el entrevistador; en las aperturas amplias (percentil 95), 6,4 % y 19,6 %. La habitual es mayor en el entrevistador.
- **Ojos al hablar** (apertura respecto a su base): -2 % el entrevistado y 0 % el entrevistador; parecido en los dos (menos de 2 puntos de diferencia).
- **Giro de cabeza:** el entrevistado, 8,0°/s al hablar y 5,0°/s al escuchar (más al hablar); el entrevistador, 12,1°/s al hablar y 9,6°/s al escuchar (más al hablar).
- **Qué rasgos acompañan a la intensidad de la voz** (correlación frase a frase de 0,10 o más en valor absoluto): en el entrevistado, ojos: apertura (-0,16), boca: apertura (+0,15), cabeza: movimiento (+0,14), boca: anchura (+0,10); en el entrevistador, comisuras: altura (+0,24), boca: apertura (+0,20), ojos: apertura (-0,16), cejas: altura (-0,14), boca: anchura (+0,13).

## 2. Tabla: dónde queda cada rasgo al hablar

Cambio respecto a la cara de cada uno mientras escucha. Cejas, ojos y anchura de boca, en % de su propio valor de base; apertura de boca y comisuras, en % de la anchura de su boca.

| Rasgo | Entrevistado: habitual | recorrido (del 5 % al 95 % de los fotogramas) | Entrevistador: habitual | recorrido |
|---|---|---|---|---|
| cejas: altura | -3 % | de -17 % a +30 % | -1 % | de -29 % a +38 % |
| ojos: apertura | -2 % | de -51 % a +30 % | 0 % | de -63 % a +42 % |
| boca: apertura | 0 % | de -3 % a +6 % | +1 % | de -6 % a +20 % |
| boca: anchura | 0 % | de -7 % a +8 % | -2 % | de -13 % a +11 % |
| comisuras: altura | 0 % | de -5 % a +6 % | +1 % | de -7 % a +12 % |

| Cabeza | Entrevistado hablando | Entrevistado escuchando | Entrevistador hablando | Entrevistador escuchando |
|---|---|---|---|---|
| velocidad de giro (°/s) | 8,0 | 5,0 | 12,1 | 9,6 |
| velocidad de cabeceo (°/s) | 10,3 | 6,7 | 16,6 | 10,3 |
| velocidad de inclinación (°/s) | 5,5 | 4,4 | 10,6 | 8,1 |
| amplitud de giro (desviación, °) | 8,6 | 7,0 | 10,5 | 9,2 |
| amplitud de cabeceo (desviación, °) | 8,9 | 9,1 | 11,9 | 10,7 |

El «recorrido» incluye el ruido de la medida (ver límites), así que es más fiable comparar los valores habituales que los extremos.

## 3. Qué hace la cara cuando sube la voz

Para cada frase se compara el movimiento medio de cada rasgo con la intensidad de la voz en esa frase (tono, volumen y tensión, del anexo de tonalidad). «Más intensas» y «más apagadas» son el 20 % de frases de cada extremo.

| Rasgo | Entrevistado: frases más intensas | más apagadas | correlación | Entrevistador: frases más intensas | más apagadas | correlación |
|---|---|---|---|---|---|---|
| cejas: altura | 0 % | +1 % | +0,00 | 0 % | +5 % | -0,14 |
| ojos: apertura | -8 % | -2 % | -0,16 | -8 % | +3 % | -0,16 |
| boca: apertura | +1 % | +1 % | +0,15 | +3 % | +2 % | +0,20 |
| boca: anchura | 0 % | 0 % | +0,10 | -1 % | -3 % | +0,13 |
| comisuras: altura | 0 % | 0 % | +0,07 | +3 % | +1 % | +0,24 |
| cabeza: movimiento (°/s) | 13,2 | 11,8 | +0,14 | 27,6 | 24,7 | +0,07 |

- La correlación más alta en valor absoluto es 0,24: todas quedan por debajo de 0,30, así que la cara acompaña a la voz poco y no siempre.
- Cejas al preguntar (entrevistado): 0 % en sus 37 frases interrogativas con la cara en pantalla y 0 % en las demás (parecido: menos de 2 puntos de diferencia).
- Cejas al preguntar (entrevistador): +1 % en sus 43 frases interrogativas con la cara en pantalla y +2 % en las demás (parecido: menos de 2 puntos de diferencia).

![grafica](grafica_movimiento.png)

## 4. Relación con el anexo de expresiones

En `informe_expresiones.md` un gesto es un pico por encima del nivel habitual de esa persona en el mismo estado (hablando o escuchando). Aquí se mide el nivel mientras habla respecto a su cara mientras escucha. Un rasgo que se mantiene alto todo el tiempo que la persona habla aparece aquí y no como gesto allí, de modo que las dos medidas pueden no coincidir sin contradecirse.

## 5. Límites

- **Precisión.** A la distancia habitual de estos planos, una ceja se mueve unos pocos píxeles. Los puntos faciales tiemblan de un fotograma a otro, y por eso el «recorrido» sale amplio incluso cuando escuchan. Los valores habituales (medianas) son más fiables que los extremos; las cifras exactas son aproximadas.
- **Ángulo de cámara.** Se corrige el efecto del giro de cabeza, pero la corrección es aproximada, y se descartan los planos lejanos y las posturas muy distintas de la habitual.
- **5 fotogramas por segundo.** Los movimientos muy rápidos (un parpadeo, un golpe de ceja breve) se pierden, y las velocidades de cabeza están suavizadas.
- **La base es la cara de cada uno mientras escucha en esta entrevista.** Si alguien escucha con un gesto mantenido, su base lo incluye.
- **El vello facial** afecta a los puntos de la boca y la mandíbula.
- **La realización.** Fotogramas usados: entrevistado, 12021 hablando y 357 escuchando; entrevistador, 3585 y 475. Con menos de 1500 fotogramas escuchando (5 minutos), la base de esa persona es poco sólida.
- Son maneras de mover la cara al hablar, no estados de ánimo, y no dicen nada sobre la sinceridad de nadie.

## 6. Archivos

`movimiento_resumen.csv`, `movimiento_frases_entrevistado.csv`, `movimiento_frases_entrevistador.csv`, `movimiento_fotogramas_*.csv`; `grafica_movimiento.png`; scripts `26_movimiento_rasgos.py` y `27_informe_movimiento.py`.
