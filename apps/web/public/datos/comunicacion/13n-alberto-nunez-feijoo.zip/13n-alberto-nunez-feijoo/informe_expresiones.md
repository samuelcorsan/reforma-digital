# Expresiones respecto a la cara de base de cada uno: Alberto Núñez Feijóo y Jordi Wild (YouTube · The Wild Project, 13/11/2026)

*Anexo. Cada persona tiene unas facciones de partida distintas, y un programa que compara una cara con un patrón universal confunde esas facciones con gestos. Aquí se hace al revés: se calcula la **cara de base** de cada uno y se mide solo lo que se aparta de ella. Las facciones dejan de contar; cuenta el movimiento. Un gesto medido no dice qué siente la persona ni si dice la verdad. Las frases que comparan se generan a partir de las cifras, con el criterio indicado en cada una.*

## 1. Cómo se ha hecho

1. **Se quita el efecto de la cámara.** Cada persona puede estar grabada desde un ángulo distinto. Para cada unidad de acción facial (AU) se resta la parte que depende del giro, el cabeceo y la inclinación de la cabeza de esa persona.
2. **Se calcula la cara de base de cada uno**: el valor central (mediana) de cada AU en sus propios fotogramas, por separado cuando habla y cuando escucha, porque hablar mueve la boca.
3. **Cada fotograma se mide en desviaciones respecto a esa base**, con una escala robusta propia de cada persona. Un valor de 0 es «su cara de siempre», tenga las facciones que tenga.
4. **Un gesto** es un tramo de al menos 0,6 s en el que una zona de la cara se aparta claramente de su base (2,5 desviaciones). Se cuentan por cada 10 minutos en pantalla, porque la cámara no enfoca a los dos el mismo tiempo.

No se usa ninguna etiqueta de emoción: los gestos se nombran por lo que hace la cara.

## 2. Lo esencial

Criterios: «parecida» = menos de un 20 % de diferencia; con menos de 5 minutos en pantalla en un estado, el dato se marca como frágil.

- **Ceño y labios apretados.** Episodios por encima de la base en toda la entrevista: ceño, 0 en el entrevistado y 0 en el entrevistador; labios apretados, 0 y 0. Con el umbral usado no hay ningún episodio claro de ninguno de los dos gestos (ver límites).
- **Gesto más frecuente de cada uno** (por 10 minutos en pantalla): en el entrevistado, sonrisa (21,7); en el entrevistador, sonrisa (32,7).
- **Sonrisa.** 21,7 por 10 minutos en pantalla el entrevistado y 32,7 el entrevistador (más frecuente en el entrevistador). Dentro de cada uno: el entrevistado, 22,8 por 10 min al hablar y 22,4 al escuchar (parecida); solo hay 3,1 min de su cara mientras escucha, menos de 5, y el dato es frágil; el entrevistador, 26,7 por 10 min al hablar y 30,6 al escuchar (parecida).
- **Cejas arriba.** 6,6 por 10 minutos en pantalla el entrevistado y 10,5 el entrevistador (más frecuente en el entrevistador). Dentro de cada uno: el entrevistado, 7,3 por 10 min al hablar y 3,2 al escuchar (más al hablar); solo hay 3,1 min de su cara mientras escucha, menos de 5, y el dato es frágil; el entrevistador, 13,0 por 10 min al hablar y 6,8 al escuchar (más al hablar).
- **Ojos más abiertos.** 11,7 por 10 minutos en pantalla el entrevistado y 23,3 el entrevistador (más frecuente en el entrevistador). Dentro de cada uno: el entrevistado, 12,8 por 10 min al hablar y 3,2 al escuchar (más al hablar); solo hay 3,1 min de su cara mientras escucha, menos de 5, y el dato es frágil; el entrevistador, 26,1 por 10 min al hablar y 11,9 al escuchar (más al hablar).
- **Mentón arriba.** 1,6 por 10 minutos en pantalla el entrevistado y 4,5 el entrevistador (más frecuente en el entrevistador). Dentro de cada uno: el entrevistado, 1,2 por 10 min al hablar y 0,0 al escuchar (más al hablar); solo hay 3,1 min de su cara mientras escucha, menos de 5, y el dato es frágil; el entrevistador, 4,8 por 10 min al hablar y 5,1 al escuchar (parecida).

## 3. Tabla completa

Tiempo con la cara en pantalla: entrevistado 61,8 min (de ellos 3,1 mientras habla el otro); entrevistador 26,6 min (5,9 mientras habla el otro).

| Gesto | Entrevistado: nº | por 10 min | hablando | escuchando | duración media | Entrevistador: nº | por 10 min | hablando | escuchando | duración media |
|---|---|---|---|---|---|---|---|---|---|---|
| sonrisa (comisuras arriba + mejillas) | 134 | 21,7 | 22,8 | 22,4 | 0,9 s | 87 | 32,7 | 26,7 | 30,6 | 1,2 s |
| cejas arriba | 41 | 6,6 | 7,3 | 3,2 | 0,9 s | 28 | 10,5 | 13,0 | 6,8 | 1,0 s |
| ojos más abiertos | 72 | 11,7 | 12,8 | 3,2 | 0,9 s | 62 | 23,3 | 26,1 | 11,9 | 1,0 s |
| mentón arriba | 10 | 1,6 | 1,2 | 0,0 | 1,0 s | 12 | 4,5 | 4,8 | 5,1 | 0,9 s |
| ceño (cejas bajan y se juntan) | 0 | 0,0 | 0,0 | 0,0 | 0,0 s | 0 | 0,0 | 0,0 | 0,0 | 0,0 s |
| labios apretados | 0 | 0,0 | 0,0 | 0,0 | 0,0 s | 0 | 0,0 | 0,0 | 0,0 | 0,0 s |
| comisuras hacia abajo | 1 | 0,2 | 0,2 | 0,0 | 1,6 s | 0 | 0,0 | 0,0 | 0,0 | 0,0 s |

«Hablando» y «escuchando» son gestos por cada 10 minutos en pantalla en ese estado.

![expresiones](grafica_expresiones.png)

## 4. Los gestos más marcados de cada uno

**Entrevistado**

- Sonrisa: 26:52, mientras dice «no, yo no le pido a nadie que trabaje enfermo. Yo lo…»; 59:04, mientras dice «que había es que se había dedicado en su momento y…»; 70:21, mientras dice «sé si hay conversaciones que las hay entre abogados siempre…»; 77:42, mientras dice «de los lectores de los…»
- Cejas arriba: 3:07, mientras dice «he ido, fíjate, esta campaña he ido, pues, Yo…»; 12:32, mientras dice «investir a presidente de gobierno ¿qué ocurrirá si el Partido Popular…»; 12:56, mientras dice «que, primero, venir a vender…»; 87:00, mientras dice «le digo a los españoles, les hago una pregunta.…»
- Ojos más abiertos: 19:02, mientras dice «Porque hay un problema de equiparación,…»; 29:54, mientras dice «No facturarán IVA y por tanto tendrán un 21 % de…»; 51:54, mientras dice «que acordemos. Y por tanto, el español tendrá muchas más…»; 75:31, mientras dice «vamos a tener que cambiar de aquí. Y cuando veo que la comunidad…»

**Entrevistador**

- Sonrisa: 68:10, mientras el otro dice «30 años. No, claro, esa foto, tú la has dicho, ¿no es del…»; 68:16, mientras el otro dice «Pues del 94, del 95, del 96, bien, mal, ok. Entonces,…»; 85:07, mientras el otro dice «Pero lo que sí sé es que, oye, mira, Jordi, ojalá que dentro…»; 85:18, mientras el otro dice «Yo no sé qué va a salir de aquí, no tengo ni…»
- Cejas arriba: 64:20, mientras dice «partido, vergonzoso para mí, en el…»; 77:55, mientras el otro dice «Oye, ¿quién manda aquí?…»; 86:44, mientras dice «te despido y hay un alegato final y estamos en campaña tienes la…»; 86:46, mientras dice «y estamos en campaña tienes la cámara esa para decir lo que te…»
- Ojos más abiertos: 9:01, mientras dice «Pero él podría decir lo mismo de vosotros.…»; 22:02, mientras el otro dice «Mi planteamiento es clarísimo, bajar…»; 76:42, mientras el otro dice «que quiero decir es que el precio de las instituciones públicas, de la…»; 77:55, mientras el otro dice «Oye, ¿quién manda aquí?…»

Son los momentos en que cada cara más se aparta de su propia base, no los más «emocionales»: una sonrisa puede ser de cortesía, de ironía o de incomodidad, y unas cejas arriba pueden ser énfasis o sorpresa. El gesto se puede medir; su significado, no.

## 5. Límites

- **La cara de base se calcula con la propia entrevista.** Si alguien mantuviera un gesto toda la entrevista, ese gesto pasaría a ser su «base» y no se detectaría. Para saberlo haría falta material suyo de otro día.
- **Gestos con valor de base alto.** Cuando una AU tiene en una persona un valor de base alto y variable, un gesto leve puede no superar el umbral. Que no haya episodios significa que no hay ninguno claro, no que la cara esté inmóvil.
- **El umbral lo fija el analista** (2,5 desviaciones, 0,6 s). Con otro umbral cambian las cifras.
- **Facciones, gafas y giros.** El vello facial y las gafas afectan a las medidas de la boca, el mentón y los ojos; la corrección por ángulo de cámara es aproximada.
- **La realización decide a quién se ve.** Hay 61,8 min de la cara del entrevistado y 26,6 min de la del entrevistador; mientras escuchan, 3,1 y 5,9 min.
- Hablar mueve la boca: por eso la base se calcula aparte al hablar y al escuchar, pero la sonrisa mientras se habla sigue siendo más difícil de medir que en silencio.
- Ningún gesto de este anexo permite saber qué siente una persona, qué pretende o si dice la verdad.

## 6. Archivos

`expresiones_eventos.csv` (cada gesto: quién, cuál, minuto, duración, intensidad, si hablaba o escuchaba y qué se decía), `expresiones_resumen.csv`, `grafica_expresiones.png`; scripts `22_expresiones_base.py` y `23_informe_expresiones.py`.
