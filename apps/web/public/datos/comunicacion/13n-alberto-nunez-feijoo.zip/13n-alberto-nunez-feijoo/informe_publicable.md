# Feijóo en *The Wild Project*: 86 de las 111 preguntas fueron duras, respondió a 52 y dejó 20 compromisos comprobables

*Análisis de la entrevista de Jordi Wild a Alberto Núñez Feijóo (YouTube, 13 de noviembre de 2026, 1 h 28 min). Vídeo: <https://www.youtube.com/watch?v=1YlGArMx_N4>.*

Durante 87 minutos de entrevista, casi tres de cada cuatro palabras fueron del invitado (72,8 %). Jordi Wild hizo 111 intervenciones que pedían respuesta y 86 de ellas (77 %) fueron incómodas, repreguntas o insistencias. A esas 86, Feijóo contestó a lo preguntado en 52, contestó en parte en 15 y en 17 habló de otra cosa. Este informe cuenta qué hizo cada uno y en qué minuto, y qué dice la investigación sobre el efecto que eso suele tener en quien escucha.

Tres avisos. Se describe conducta, no intenciones ni formas de ser. La cara se describe solo con unidades de acción (AU) del sistema FACS, que nombra movimientos musculares y no emociones (**Ekman y Friesen, 1978**). Y, dicho una sola vez: **ni las pausas, ni la voz, ni los gestos, ni ninguna otra medida de este informe sirve para saber si alguien dice la verdad**. La mayoría de estos indicios no distingue a quien miente, los que lo hacen tienen efectos pequeños y las personas detectan mentiras poco mejor que al azar (**DePaulo y otros, 2003; Bond y DePaulo, 2006**). Como mucho, indican esfuerzo o tensión al hablar.

## 1. La entrevista, en una frase

Jordi pregunta corto y repregunta mucho; Feijóo contesta largo y con muchas cifras, y la fricción se concentra en el partido, los rivales y la corrupción, no en la economía.

## 2. Lo que dicen los datos

| Medida | Feijóo | Jordi Wild |
|---|---|---|
| Palabras (verificadas por huella de voz) | 9.256 | 3.463 |
| Reparto de palabras | 72,8 % | 27,2 % |
| Tiempo de habla | 53,0 min | 17,7 min |
| Turnos | 276 | 144 |
| Mediana de palabras por turno | 23 | 15 |
| Turno más largo | 98,7 s | 43,8 s |
| Velocidad en habla continua | 201 palabras/min | 216 palabras/min |
| Tomas de palabra con menos de 0,2 s de hueco | 64 % | 57 % |
| Frases interrogativas | 46 | 60 |
| Pronombre *yo* explícito por cada 1.000 palabras | 13,5 (125 veces) | 6,5 (24 veces) |
| Pronombre *tú* explícito por cada 1.000 palabras | 2,6 (24 veces) | 8,7 (32 veces) |
| Solapes de voz que inicia cada uno | 133 | 187 |

Esta tabla sale del informe técnico de esta entrevista. Las comparaciones con otras entrevistas usan otro archivo, calculado igual para las cinco pero con definiciones algo distintas de turno, velocidad y latencia; por eso algunas cifras no coinciden (por ejemplo, 201 y 179 palabras por minuto).

**Reparto.** El 72,8 % de las palabras son del invitado, la proporción más alta de las cinco entrevistas medidas con el mismo método: con Jordi Wild, Colau tuvo el 63,7 % y Sánchez el 63,4 %; en *La Revuelta*, Abascal el 53,5 % y Sánchez el 60,1 %. En la entrevista periodística los papeles están repartidos de antemano: el entrevistador pregunta y el entrevistado desarrolla la respuesta (**Clayman y Heritage, 2002**).

**Quién corta a quién.** Más de la mitad de los cambios de turno se producen sin hueco, en los dos sentidos. Jordi inicia 187 solapes de voz y Feijóo 133. Jordi cierra con un corte o comentario propio 15 de los 111 intercambios (14 %; con Colau, 6 %) y, en el recuento automático, cortó el 22 % de las respuestas (a Colau, 50,7 %; a Sánchez, 36,8 %). La lectura anota cinco interrupciones notables: tres del invitado, como «Perdona un momento, Jordi.» (62:38), y dos de Jordi.

**Velocidad.** Jordi habla algo más deprisa (216 frente a 201 palabras por minuto en tramos sin pausas; diferencia pequeña, d = −0,25). Contando las pausas, el ritmo global de Feijóo es de 179 palabras por minuto, el más lento de los cinco invitados comparados (Abascal 228, Colau 212). En estudios clásicos en inglés, hablar más rápido se asoció con parecer más competente (**Miller y otros, 1976**), pero trabajos posteriores muestran que el efecto depende del mensaje y del oyente (**Smith y Shaffer, 1995**); aquí el dato solo describe el ritmo.

**Cifras.** Feijóo dice 2,61 cifras por cada 100 palabras, la tasa más alta de las cinco entrevistas (Sánchez con Jordi, 1,62; Colau, 0,67). Un número dicho pronto puede funcionar como punto de referencia para lo que se discute después: es el **efecto ancla (Tversky y Kahneman, 1974)**, demostrado en estimaciones numéricas de laboratorio. La sección 8 comprueba esas cifras.

**A quién nombra.** En el recuento de palabras, Feijóo nombra al Gobierno 39 veces, a Sánchez 13, al PP 13, a Vox 9 y a Ayuso 5. Jordi nombra a Sánchez 9 veces, a Vox 5 y al PP 5. En la lectura por intercambios, Pedro Sánchez aparece como objeto de crítica en 28 de las 111 respuestas y el Gobierno en 15.

## 3. Trabas contadas una a una

Una traba es un tropiezo al hablar: repetir una palabra o un grupo de palabras, o cortarse a media frase.

| | Feijóo | Jordi Wild |
|---|---|---|
| Trabas | 23 | 14 |
| Por cada 100 palabras | 0,25 | 0,40 |
| Repite una palabra | 10 | 4 |
| Repite un grupo de palabras | 5 | 3 |
| Se corta (y reformula o no continúa) | 8 | 7 |
| En las primeras 8 palabras del turno, por 100 palabras | 0,19 | 0,27 |

Son muy pocas en los dos. Las 0,25 por cada 100 palabras de Feijóo son la tasa más baja de los cinco invitados comparados (Colau 0,28; Sánchez con Jordi 0,33; Abascal 0,41; Sánchez en *La Revuelta* 0,98).

**Dónde se concentran.** De las 23 de Feijóo, 9 caen entre el minuto 60 y el 80 (Marcial Dorado, las fotos de Sánchez, Gürtel, el abogado del PP y el piso). Y 19 están en respuestas a preguntas duras: 0,30 por cada 100 palabras frente a 0,13 en el resto. Con 23 casos, es una pista, no una prueba.

Ejemplos:

- 46:03, sobre Ceuta: «O sea, que desde el mes de julio… Mira, si tú tienes un presidente».
- 75:53, sobre el piso: «se iba a alquilar, no sé, yo no... A mí me dijeron simplemente que».
- 76:26, a la pregunta por el precio: «porque no quiero mentir, pero ahí los supervisores… ¿Cuánto ha costado la sede de».
- Jordi, 70:06: «tema que tú, como el jefe, tendrías que... Y además en temas tan delicados.»

La investigación clásica asocia las vacilaciones del habla espontánea, sobre todo las pausas, a la planificación sobre la marcha (**Goldman-Eisler, 1968**), y quien escucha tiende a leer las vacilaciones (muletillas, demoras al contestar) como menor seguridad en la respuesta (**Brennan y Williams, 1995**); ese estudio no midió repeticiones ni frases cortadas, que es lo que aquí se cuenta. El transcriptor no escribe las muletillas sonoras de duda, así que el recuento real de titubeos es mayor para los dos.

## 4. Silencios

Se cuentan como pausa los huecos de más de 0,4 segundos entre dos palabras seguidas de la misma persona.

**Una exclusión.** El archivo recoge 119 pausas de Feijóo, y la más larga dura 15,4 segundos (78:49). No es una pausa: coincide con uno de los tres huecos de la transcripción (9:54–10:22, 67:01–67:24 y 78:49–79:05). Se excluye, y quedan 118.

| | Feijóo (118) | Jordi Wild (34) |
|---|---|---|
| Por cada 1.000 palabras | 12,7 | 9,8 |
| Duración media | 0,79 s | 0,76 s |
| Duración mediana | 0,72 s | 0,63 s |
| De 1 segundo o más | 23 | 7 |
| La más larga | 2,4 s (84:19) | 1,7 s (43:27) |
| Antes de una frase con carga | 36 | 8 |
| Confirmadas por el detector acústico | 25 (21 %) | 3 (9 %) |

**Advertencia.** El detector acústico solo confirma el 21 % de las pausas de Feijóo y el 9 % de las de Jordi. En el resto puede haber una réplica del otro, una risa o ruido: estas cifras descansan en los huecos entre palabras transcritas, no en el sonido.

**Pausas antes de frases con carga.** 36 de las 118 pausas de Feijóo van justo antes de una frase con una cifra (20), una mención política (9) o un compromiso (4), o una mezcla (3); el detector confirma 8 de esas 36. No son más largas que las demás (0,81 s de media frente a 0,78 s). Ejemplos:

- 48:49 (0,9 s, confirmada), antes de «Que quede claro, no lo voy a consentir.»
- 27:05 (1,6 s, confirmada), antes de «Mire, yo cuando estaba en correos faltaban 5 .000 personas».
- 84:19 (2,4 s, sin confirmar), antes de «Las cosas fueron en mayo normales.», al definir a Pedro Sánchez.

La pausa más larga de Jordi (1,7 s, 43:27) precede a «Tú imagínate que ya están entrando, los tenemos, y sacas al ejército».

En los discursos políticos preparados las pausas silenciosas ocupan más tiempo que en las entrevistas y sirven para destacar lo que sigue (**Duez, 1982**, con políticos franceses); en entrevistas, como esta, ese uso es menos marcado. En la oratoria de mitin, el ritmo y las pausas ayudan a señalar al público dónde termina una frase rotunda (**Atkinson, 1984**); es un análisis de discursos ante público, no de entrevistas.

## 5. Voz

**Valores de base.** Tono medio: Feijóo 126 Hz, Jordi 122 Hz. Dentro de cada frase mueven el tono casi lo mismo (3,67 y 3,52 semitonos) y los dos terminan las frases hacia abajo mucho más que hacia arriba (38 % frente a 10 % y 40 % frente a 7 %), el patrón de quien afirma.

**Cuándo se sale de su media.** De las 556 frases medidas de Feijóo, el tono sube con claridad en 43 y baja en 19; la velocidad sube en 46 y baja en 21; el volumen baja en 47 y sube en 3. Las de tono más alto respecto a su media: «¿Ayuso es un activo de mi partido?» (74:22), «No, porque creo que no es el momento.» (13:48) y «¿Usted tiene un contrato de trabajo?» (54:15).

**El arco de la entrevista.** Se usa un índice de intensidad vocal que combina tono, volumen y tensión de la voz; 0 es la media de cada persona.

| Tema (frases de Feijóo) | Intensidad vocal | Velocidad (palabras/min) |
|---|---|---|
| Partido: Ayuso y el piso (36) | +0,32 | 234 |
| Corrupción: Gürtel y el abogado (59) | +0,23 | 214 |
| Economía y empleo: absentismo (30) | +0,20 | 205 |
| Defensa (34) | +0,16 | 185 |
| Rivales (84) | −0,02 | 204 |
| Fronteras y Marruecos (50) | −0,06 | 185 |
| Asuntos personales: Dorado e inglés (27) | −0,21 | 195 |
| Impuestos y autónomos (27) | −0,27 | 197 |
| Cierre y alegato (15) | −0,63 | 220 |

Por bloques de diez minutos, la voz de Feijóo es más intensa entre el 70 y el 80 (+0,35: Ayuso, el piso, el inglés) y más apagada entre el 80 y el final (−0,42). La de Jordi tiene su punto más bajo entre el 40 y el 50 (−0,40: Ceuta y Marruecos) y el más alto al final (+0,25).

**Voz bajo presión.** Se comparan las frases que Feijóo dice entre una pregunta dura y la siguiente pregunta (377 frases) con todas las demás (179).

| | Tras pregunta dura | Resto | Tamaño del efecto (d) |
|---|---|---|---|
| Tono | 126,6 Hz | 123,5 Hz | +0,19 |
| Volumen | 66,0 dB | 64,9 dB | +0,21 |
| Velocidad | 203 palabras/min | 198 palabras/min | +0,08 |
| Índice de intensidad vocal | +0,07 | −0,16 | +0,23 |
| Trabas por 100 palabras | 0,30 | 0,13 | (19 y 4 casos) |
| Pausas por 1.000 palabras | 11,2 | 16,1 | (70 y 48 casos) |

La d de Cohen mide el tamaño de una diferencia: en torno a 0,2 es pequeña, 0,5 media y 0,8 grande. Aquí todo es pequeño: tras una pregunta dura la voz sube unos 3 Hz, suena 1 dB más fuerte y casi no cambia de velocidad; donde más sube el tono es tras las insistencias (128,5 Hz, 131 frases). La investigación asocia las subidas de tono y de volumen con mayor activación del hablante (**Scherer, 2003; Juslin y Laukka, 2003**), que puede venir de la incomodidad, del énfasis o del interés en el tema.

La voz, en cambio, no distingue las respuestas que no contestan a lo preguntado: en sus 85 frases el tono es prácticamente igual que en el resto (126,4 frente a 125,5 Hz; d = +0,06) y la velocidad también (d = +0,02).

Con el mismo cálculo, la voz de Jordi apenas cambia al formular preguntas duras (tono 122,1 frente a 123,3 Hz, d = −0,08; velocidad 219 frente a 211, d = +0,14).

## 6. Cara

**Quién sale en pantalla.** La cara de Feijóo aparece 61,8 minutos y la de Jordi 26,6: la realización enfoca al invitado 2,3 veces más. Escuchando, de Feijóo solo hay 3,1 minutos de cara y de Jordi 5,9: lo que se diga de cómo escucha el invitado es frágil.

**Gestos respecto a su propia cara de base.** Cada cara se compara consigo misma: se cuentan los tramos de al menos 0,6 segundos en que una zona se aparta con claridad de su posición habitual.

| Movimiento | Feijóo: nº | por 10 min en pantalla | Jordi: nº | por 10 min en pantalla |
|---|---|---|---|---|
| AU6 + AU12 (mejillas elevadas y comisuras arriba: sonrisa) | 134 | 21,7 | 87 | 32,7 |
| AU5 (párpado superior arriba, ojos más abiertos) | 72 | 11,7 | 62 | 23,3 |
| AU1 + AU2 (cejas arriba) | 41 | 6,6 | 28 | 10,5 |
| AU17 (mentón arriba) | 10 | 1,6 | 12 | 4,5 |
| AU15 (comisuras abajo) | 1 | 0,2 | 0 | 0,0 |
| AU4 (cejas bajan y se juntan) | 0 | 0,0 | 0 | 0,0 |
| AU23/AU24 (labios apretados) | 0 | 0,0 | 0 | 0,0 |

El movimiento más frecuente en los dos es AU6 + AU12, más en Jordi. Feijóo levanta las cejas sobre todo al hablar (7,3 por 10 minutos frente a 3,2 escuchando). No hay ningún episodio marcado de AU4 ni de labios apretados en ninguno, lo que no excluye que los haya leves.

**Hablar frente a escuchar.** Al hablar, a Feijóo le baja AU4 (−0,086) y le suben AU2 (+0,053) y AU6 (+0,052); a Jordi le bajan AU15 (−0,059) y AU4 (−0,041) y le sube AU6 (+0,032). Feijóo gira la cabeza a 8,0 grados por segundo cuando habla y a 5,0 cuando escucha; Jordi, a 12,1 y 9,6. El 32,5 % de las ventanas de seis segundos de Feijóo tienen alguna AU fuera de su nivel habitual; en Jordi, el 24,5 %.

**El punto más alto de AU12.** En Feijóo, hacia el 78:34 (0,22 en la media de 30 segundos frente a 0,10 global; AU6, 0,30 frente a 0,17), en el intercambio sobre el inglés. En Jordi, en el 4:20 (0,32 frente a 0,10), en la presentación.

![Feijóo, 78:36](fotogramas/m12_durante.jpg)
*78:36, «De forma fluida, no de boca en la ceja.»*

![Jordi Wild, 78:19](fotogramas/e08_durante.jpg)
*78:19, Jordi formula «¿Qué tal llevas el inglés?».*

![Feijóo, 13:46](fotogramas/m03_durante.jpg)
*13:46, cuarta formulación de la pregunta por los ministerios.*

**Cómo leerlo.** AU6 + AU12 es la combinación que la literatura llama sonrisa de Duchenne (**Ekman, Davidson y Friesen, 1990**), pero aparece también por cortesía, ironía o incomodidad, y de un movimiento facial no se puede deducir con fiabilidad un estado interno (**Barrett y otros, 2019**). Los niveles absolutos de AU no se pueden comparar entre los dos: el programa no está calibrado por persona, cada uno está girado hacia un lado (Feijóo +29 grados de media, Jordi −40) y Jordi lleva barba. La cara acompaña poco a la voz: la correlación más alta entre un rasgo facial y la intensidad vocal es 0,24.

## 7. Las preguntas y cómo se responden

Este apartado sale de una lectura manual de la transcripción, hecha por un solo lector, sin segundo codificador. Ante la duda entre dos clases se eligió la más favorable al invitado (7 veces); 18 de las 111 entradas son dudosas por problemas de la transcripción.

### Cómo pregunta Jordi

| Dureza de la intervención | Nº | % |
|---|---|---|
| Repregunta (vuelve sobre lo mismo) | 38 | 34 % |
| Incómoda (crítica, contradicción, dato adverso) | 26 | 23 % |
| Neutra | 23 | 21 % |
| Insistencia (tercera vez o más) | 22 | 20 % |
| Cómoda | 2 | 2 % |
| **Duras (repregunta + incómoda + insistencia)** | **86** | **77 %** |

53 de las 111 (48 %) parten de una premisa adversa al invitado, 54 de una neutra y 4 de una favorable. Son 9,9 preguntas duras por cada diez minutos; a Colau le hizo 11,7 (83 % de duras). Jordi lo enuncia en antena: «Es mi misión hoy, es mi misión es poneros contra las cuerdas.» (25:12; la transcripción lo pone en el turno del invitado). Es el estilo de pregunta adversativa, cuya formulación ya contiene una crítica (**Clayman y Heritage, 2002**).

### Cómo responde Feijóo

| Clase de respuesta | Todas (111) | Solo a preguntas duras (86) |
|---|---|---|
| Responde a lo preguntado | 71 (64 %) | 52 (60 %) |
| Responde en parte | 18 (16 %) | 15 (17 %) |
| Contesta a otra pregunta | 16 (14 %) | 13 (15 %) |
| Cambia de tema | 3 (3 %) | 3 (3 %) |
| Ataca la pregunta | 1 (1 %) | 1 (1 %) |
| Jordi no deja contestar | 2 (2 %) | 2 (2 %) |
| **No contesta a lo preguntado (tres clases)** | **20 (18 %)** | **17 (20 %)** |

El porcentaje de la última fila se calcula sobre las preguntas en que Jordi dejó contestar; con Colau fueron el 15 % y el 18 %. La clase mide si la respuesta aborda lo preguntado, no si lo dicho es cierto. En entrevistas políticas una parte grande de las preguntas queda sin respuesta directa (**Bull y Mayer, 1993**), y en experimentos con vídeos de debates el público a menudo no lo nota cuando la respuesta trata un asunto parecido (**Rogers y Norton, 2011**).

**Dónde no contesta.** Por temas (con cuatro o más preguntas): partido interno, 5 de 14 (36 %); defensa, 2 de 6; fronteras y Marruecos, 2 de 6; rivales, 6 de 20 (30 %); corrupción, 2 de 7 (29 %). En deuda y gasto (0 de 9), pensiones (0 de 8), economía y empleo (0 de 4) e impuestos y autónomos (0 de 4) contesta siempre, del todo o en parte.

### Las cinco secuencias de más tensión

**1. Sánchez y la prostitución (61:22–63:55).** Jordi plantea qué pasaría si la foto con Marcial Dorado fuera de Sánchez: «La misma foto, y él explica lo mismo.» Feijóo responde con una pregunta propia: «¿Es verdad que las primarias de Sánchez se financiaron con el dinero de la prostitución?» (62:22). Jordi: «A mí no me lo tienes que preguntar, ni a la gente tampoco.» y «¿Pero eso es una pregunta o es una afirmación?» (63:31). Feijóo: «Ante una pregunta puede ser sí o no». Una acusación formulada como pregunta puede dejar huella en la opinión de quien la lee, según un estudio con titulares de prensa: es el efecto de la **insinuación (Wegner y otros, 1981)**. Algo parecido podría ocurrir con las 53 preguntas de Jordi que parten de una premisa adversa, aunque ese estudio no analizó entrevistas.

![Plano general, 62:49](fotogramas/m10_durante.jpg)
*62:49, plano general: «¿Pero cómo que si la sauna?».*

**2. El piso de 6,7 millones (75:40–77:50).** Siete intervenciones seguidas de Jordi sobre el precio, cinco de ellas insistencias. Feijóo: «Yo no quiero hablar de eso porque no quiero mentir» y, a continuación, «¿Cuánto ha costado la sede de la Generalitat en Madrid?» (76:27). Jordi: «Sí, pero eso es otro tema.» Feijóo concede, «Yo no lo discuto.» (76:50), y pasa a otro gasto público. Corta el intercambio el aviso de su equipo.

**3. La edad de jubilación (24:07–25:17).** A «no tenemos previsto ampliar» Jordi opone «no tener previsto no asegurarlo». Feijóo protesta, «primero me haces unas preguntas Que yo intento ser honesto en las contestaciones», y termina con un compromiso cerrado: «Jordi, no vamos a ampliar la edad de jubilación.» La insistencia produce aquí una respuesta más concreta.

**4. Marcial Dorado (59:22–61:15).** A «¿Erais amigos?» no hay un sí o un no: «alguien habrá hecho esa foto, ¿no?». Jordi: «Pero un meeting es una cosa y una foto en yate o barco es otra.» Feijóo: «yo soy responsable de mi biografía». La explicación completa llega en el 60:33: «a esta persona me la presentó un compañero de la Junta de Galicia». Separar contrabando de narcotráfico, como hace en el 61:39, es lo que la teoría de la reparación de imagen llama **diferenciación (Benoit, 1995)**.

**5. Gürtel (63:55–67:30).** «¿Tú ahí también habrías pedido la dimisión?», pregunta Jordi sobre Rajoy. En tres intentos no hay un sí o un no: «El caso Gürtel se ha juzgado por arriba, por abajo», «Pero si es que nos costó el gobierno. ¿Te parece poco?» y «¿tú te acuerdas de la financiación de Filesa, Timesport, etcétera, etcétera?». Parte del intercambio cae en un hueco de la transcripción (67:01–67:24).

![Jordi Wild, 64:13](fotogramas/e06_durante.jpg)
*64:13, Jordi formula la pregunta sobre Gürtel.*

Cuando declina, a veces lo dice de forma expresa: «yo no voy a concretar, te lo digo honradamente, mi estrategia de negociación» (13:05). La teoría del **equívoco (Bavelas y otros, 1990)** explica estas respuestas por la situación y no por la persona: cuando cualquier respuesta directa tiene coste, lo habitual es una respuesta indirecta.

### Preguntas devueltas

Feijóo devuelve la pregunta en 18 intercambios (Colau, en 6): «¿Sabes qué porcentaje de absentismo tiene un autónomo?» (26:39), «¿Pero qué credibilidad tenemos, Jordi?» (38:52). La primera se le vuelve en contra: Jordi lee el dato de los verificadores, «la incidencia de bajas médicas entre los trabajadores autónomos está en torno al 1%», y Feijóo responde «Le agradezco esa rectificación. Mis datos estaban entre el 3 ,5 y 4%.» (28:40).

### Quién saca cada tema y cuánto dura

De los 37 tramos temáticos, 30 los abre Jordi y 7 el invitado (19 %, igual que Colau); esos siete suman 14,3 minutos, el 16 % de la entrevista: Sánchez y la investidura de 2023 (8:29), las cuentas públicas (22:11), el absentismo (25:44), la deuda cuando se le pregunta por defensa (36:02), el ingreso mínimo vital (52:10), la población extranjera (55:18) y las fotos de Sánchez (61:15). Los partidos procuran llevar el debate a los temas en que el público los percibe como más competentes: es la **propiedad de los temas (Petrocik, 1996)**.

| Tema | Minutos | % |
|---|---|---|
| Rivales | 12,4 | 14 % |
| Corrupción | 8,5 | 10 % |
| Fronteras y Marruecos | 8,3 | 10 % |
| Inmigración | 7,8 | 9 % |
| Asuntos personales | 5,8 | 7 % |
| Pensiones | 5,5 | 6 % |
| Deuda y gasto | 5,5 | 6 % |
| Pactos y gobernabilidad | 5,4 | 6 % |
| Partido interno | 5,2 | 6 % |
| Defensa y seguridad | 4,8 | 6 % |
| Impuestos y autónomos | 4,3 | 5 % |
| Presentación y formato | 3,8 | 4 % |
| Cierre y alegato | 3,2 | 4 % |
| Economía y empleo | 3,1 | 4 % |
| Feminismo e igualdad | 2,4 | 3 % |
| Política internacional | 1,0 | 1 % |

**Temas ausentes.** No tienen tramo propio la vivienda (solo menciones), Cataluña y el modelo territorial, la sanidad y la educación, los medios, la juventud ni el clima y la energía.

### Ataque frente a propuesta

De las 111 respuestas, 27 (24 %) proponen algo propio, 30 (27 %) hablan de rivales o terceros, 18 (16 %) hacen las dos cosas y 36 (32 %) ninguna. Las dos primeras categorías se parecen a lo que la **teoría funcional del discurso de campaña (Benoit, 2007)** llama aclamaciones y ataques; aquí pesan parecido (24 % y 27 %). Las defensas no se han contado por separado. Cuánto habla del pasado y cuánto del futuro no se ha podido medir: ningún archivo clasifica las frases por tiempo, y aquí no se estima.

### Mérito y culpa

Se recogieron 60 frases en las que atribuye un logro, un fracaso o un problema.

| | Yo | Nosotros | El Gobierno | Pedro Sánchez | Ellos | Impersonal | Otros |
|---|---|---|---|---|---|---|---|
| Logro (16) | 6 | 7 | 0 | 0 | 0 | 0 | 3 |
| Fracaso (25) | 1 | 6 | 7 | 5 | 3 | 0 | 3 |
| Problema (19) | 1 | 0 | 4 | 1 | 4 | 8 | 1 |

Trece de los 16 logros llevan sujeto en primera persona: «Es que yo he conseguido un superávit en los últimos presupuestos de Galicia» (37:38). De los 25 fracasos, 15 se atribuyen al Gobierno, a Sánchez o a un *ellos* genérico. Hay siete fracasos en primera persona, cuatro de ellos sobre su partido, como «Pero si es que nos costó el gobierno» (64:48), y uno personal: «He de reconocer que no he hecho ningún esfuerzo en esto.» (79:16, sobre el inglés). Atribuirse los éxitos es un patrón bien documentado; que además se sitúen fuera los fracasos lo está menos (el trabajo clásico de **Miller y Ross, 1975**, lo puso en duda; revisiones posteriores, como **Zuckerman, 1979**, sí lo encuentran). En política, la tendencia a priorizar no cargar con la culpa se ha descrito como **evitación de la culpa (Weaver, 1986)**. Admitir un punto débil sin rodeos, como hace con el inglés («yo no sé inglés, pero sé gobernar», 78:19), puede restarle fuerza; el efecto mejor estudiado es el de quien lo revela antes de que se lo saquen (**Williams, Bourgeois y Croyle, 1993**, en juicios simulados), que no es exactamente este caso.

### Registro de promesas verificables

Se recogieron 40 compromisos. La mitad (20) tienen un objeto que se podrá comprobar: una cifra, una ley o una decisión de sí o no. Son 2,3 por cada diez minutos (Colau: 8 de 29, 0,6 por cada diez minutos). Como principio general, un compromiso público y concreto ata más a quien lo formula que una intención general (**compromiso y coherencia, Cialdini, 1984**).

| Minuto | Cita | Compromiso |
|---|---|---|
| 17:11 | «Mi estructura ministerial estará entre 14 y 15 ministerios.» | Gobierno de 14 o 15 ministerios |
| 17:19 | «El Ministerio de Igualdad se agrupará con otros» | Agrupar Igualdad con otros ministerios |
| 18:39 | «No va a haber un Ministerio de Igualdad, tampoco va a haber un Ministerio de Vivienda» | Sin ministerios de Igualdad ni de Vivienda como tales |
| 23:10 | «Yo me comprometo a la actualización de las pensiones, de acuerdo con el índice de precios al consumo.» | Revalorizar las pensiones con el IPC |
| 23:56 | «que yo le voy a facilitar el cobro parcial de su pensión y que será compatible con el sueldo» | Pensión parcial compatible con sueldo tras los 67, voluntaria |
| 24:44 | «no tenemos previsto te contesto, no tenemos previsto ampliar» | No prevé ampliar la edad de jubilación |
| 25:13 | «Jordi, no vamos a ampliar la edad de jubilación.» | No ampliar la edad de jubilación más allá de los 67 |
| 25:36 | «Si hacemos un millón de viviendas, crearemos 500 .000 puestos de trabajo.» | Un millón de viviendas (formulado en condicional) |
| 29:37 | «Los que llevan 12 años y facturan menos de 85 .000 euros no pagarán IVA.» | Exención de IVA para autónomos por debajo de 85.000 euros |
| 30:05 | «Un autónomo que contrate a otro el primer año de ese autónomo contratado no pagará la cuota.» | Sin cuota el primer año del primer contratado |
| 30:19 | «ese segundo trabajador no pagará el 50 % de la cuota» | 50 % de cuota por el segundo contratado |
| 30:26 | «si las hace trimestrales o puede hacerlas dos veces al año o una vez al año» | Declaraciones trimestrales, semestrales o anuales a elección |
| 30:31 | «una mujer autónoma que tiene derecho a un permiso de maternidad y no tendrá que pagar la cuota» | Sin cuota durante el permiso de maternidad |
| 31:21 | «No, vamos a hacer un estatuto al autónomo.» | Aprobar un estatuto del autónomo |
| 32:35 | «mi objetivo es que en esas patologías absolutamente invalidantes, patologías que ponen en riesgo la vida» | Baja al 100 % en enfermedades graves (como objetivo) |
| 39:40 | «Llegaré, haré la auditoría de gasto, explicaré cuál es el gasto en mi país» | Auditoría del gasto y comunicar a los aliados el gasto en defensa posible |
| 40:31 | «La primera transparencia de un presidente es someter a votación los presupuestos» | Someter los presupuestos a votación |
| 51:46 | «es un requisito que se puntuará de acuerdo con la antigüedad que acordemos» | Puntuar la antigüedad de empadronamiento en vivienda protegida y ayudas |
| 52:31 | «Le voy a establecer un camino hacia el empleo y van a tener la obligación de asumir un empleo» | Itinerario de empleo obligatorio para perceptores del ingreso mínimo vital |
| 54:21 | «No, le vamos a dar otros plazos para que usted vuelva a encontrar otro trabajo.» | Plazo para encontrar otro trabajo al acabar un contrato, sin expulsión |

Entre los 20 no verificables están los más generales, como «Mi planteamiento es clarísimo, bajar los impuestos.» (22:03), sin cifra.

### Sintonía con Jordi

El transcriptor no recoge risas, así que este recuento es de lectura. Hay 60 momentos de relación: 14 bromas (9 las inicia el invitado y 5 Jordi), 11 roces (4 y 7), 10 preguntas devueltas, 7 halagos (3 y 4), 7 acuerdos explícitos (4 y 3), 6 anécdotas personales (5 y 1) y 5 interrupciones notables (3 y 2). Bromas y roces se alternan: tras siete preguntas sobre el piso, Feijóo alarga la entrevista contra el aviso de su equipo, «Vamos hasta la una, venga.» Jordi, por su parte: «Por desgracia, a mí se me ha hecho muy corto.» (72:26). Atención mutua, tono positivo y coordinación son los tres componentes de la **sintonía entre dos personas (Tickle-Degnen y Rosenthal, 1990)**, y la simpatía hacia quien habla es uno de los principios generales de la persuasión (**Cialdini, 1984**). El clima no hace la entrevista menos dura: se miden por separado.

## 8. Comprobación de datos

Se extrajeron 171 afirmaciones factuales (149 del invitado y 22 de Jordi). 28 no eran comprobables (vivencias, intenciones) y no se buscaron; las otras 143 se contrastaron con fuentes públicas el 13 de noviembre.

| Veredicto | Feijóo | Jordi Wild |
|---|---|---|
| Se sostiene (respaldada) | 53 | 15 |
| Verdad a medias (respaldada en parte o imprecisa) | 45 | 5 |
| Verdad a medias (engañosa por contexto) | 1 | 0 |
| No se sostiene (sin respaldo) | 2 | 0 |
| No verificable | 2 | 0 |
| No se pudo comprobar | 20 | 0 |
| **Comprobadas** | **123** | **20** |

**Cuánta fuente se abrió de verdad.** Solo en 37 de las 143 filas (33 del invitado y 4 de Jordi) se abrió y leyó la fuente completa; en las otras 106 el veredicto descansa en extractos del buscador y de prensa. Los tres veredictos negativos pasaron una segunda revisión abriendo las fuentes; otros dos se suavizaron en ella a *verdad a medias* (la directiva del IVA y la inmigración irregular).

**Esto no es una nota.** Los dos hablan de cosas distintas (el invitado da muchas más cifras; Jordi hace sobre todo atribuciones y preguntas con dato) y varias afirmaciones repiten un mismo dato. **No es válido comparar porcentajes entre las dos personas**, ni con los de otras entrevistas.

| Minuto | Quién | Cita | Veredicto y qué dicen las fuentes | Fuente abierta |
|---|---|---|---|---|
| 44:45 | Feijóo | «Y la ministra de Defensa no deja comparecer a la directora del CNI en la Comisión de» | No se sostiene. La comparecencia no se produjo, pero las fuentes no atribuyen el bloqueo a la ministra, que pidió que se autorizara. [Fuente](https://www.democrata.es/politica/congreso-y-senado/armengol-cita-a-robles-ante-la-comision-de-secretos-el-dia-6-y-deja-fuera-a-la-directora-del-cni/) | sí |
| 66:07 | Feijóo | «con una sentencia que hablaba de que el PP era responsable del título lucrativo que posteriormente fue anulada por» | No se sostiene. El Supremo confirmó en 2020 la responsabilidad civil del PP a título lucrativo; solo corrigió las referencias a la caja B. [Fuente](https://www.poderjudicial.es/cgpj/en/Judiciary/Supreme-Court/Pressroom/Press-Archive/El-Tribunal-Supremo-confirma-penas-de-hasta-51-anos-de-prision-para-los-procesados-en-el--caso-Gurtel-) | sí |
| 58:43 | Feijóo | «conocí a esta persona cuando no tenía nada que ver con el narcotráfico» | Verdad a medias (engañosa por contexto). No tenía cargos por narcotráfico hasta 2003, pero había sido detenido en 1990 en la Operación Nécora y quedó en libertad. [Fuente](https://maldita.es/malditahemeroteca/20230719/feijoo-marcial-dorado-relacion-cronologia/) | sí |
| 36:13 | Feijóo | «incrementa la recaudación fiscal un 69%, más de 220 .000 millones de impuestos en el año 2026 que en el año 2018» | Verdad a medias. Los ingresos tributarios subieron un 56 % y 116.671 millones entre 2018 y 2025. [Fuente](https://www.hacienda.gob.es/es-ES/Prensa/Noticias/Paginas/2026/20260331-NP-CIERRE-DEFICIT.aspx) | sí |
| 20:38 | Feijóo | «se ha incrementado un 40 y pico por ciento la deuda» | Verdad a medias. En euros ha subido alrededor de un 50 % desde 2018, más de lo que dice. [Fuente](https://www.bde.es/wbe/es/noticias-eventos/actualidad-banco-espana/deuda-aapp-2026t2.html) | sí |
| 37:38 | Feijóo | «Es que yo he conseguido un superávit en los últimos presupuestos de Galicia.» | Verdad a medias. Galicia cerró 2018 con superávit, no sus últimos ejercicios. [Fuente](https://ficheiros-web.xunta.gal/transparencia/orzamentos/deficit-superavit-publico-2026.pdf) | no |
| 34:05 | Feijóo | «Galicia estuvo entre las tres o las cuatro comunidades autónomas de menor incremento de deuda pública» | Verdad a medias. Cuarta en puntos de PIB, novena en euros. [Fuente](https://maldita.es/malditodato/20230711/verificacion-deuda-cara-sanchez-feijoo/) | no |
| 29:41 | Feijóo | «Es que eso es una directiva que el gobierno se ha negado a transponer.» | Verdad a medias. La directiva no se ha transpuesto y Bruselas ha demandado a España, pero la exención interna es opcional para cada Estado. [Fuente](https://maldita.es/desinfo/20260316/bruselas-lleva-a-espana-a-los-tribunales-por-ser-el-unico-pais-de-la-ue-que-no-exime-de-iva-a-los-autonomos/) | sí |
| 55:37 | Feijóo | «Aproximadamente el censo de la ciudad de Lleida, más del 30 % son inmigrantes.» | Verdad a medias. El 27,8 % nació en el extranjero y el 23,3 % tiene nacionalidad extranjera. [Fuente](https://www.idescat.cat/emex/?id=251207&f=ssv&lang=es) | sí |
| 56:24 | Feijóo | «uno de cada tres inmigrantes que llegan a un cayucón a costa española» | Verdad a medias. La estimación localizada es de una muerte por cada seis llegadas. [Fuente](https://es.ara.cat/sociedad/inmigracion/rutas-migratorias-letales-1-317-muertos-intentando-llegar-espana-cinco-meses_1_5765186.amp.html) | sí |
| 55:24 | Feijóo | «El 20 % de la población española es de origen extranjero.» | Se sostiene. 20,7 % de nacidos en el extranjero a 1 de julio de 2026. [Fuente](https://www.ine.es/dyngs/Prensa/ECP2T26.htm) | sí |
| 22:44 | Feijóo | «Que tenemos un gobierno que finaliza la legislatura Sin aprobar ni un solo año las cuentas» | Se sostiene. La legislatura termina con los presupuestos de 2023 prorrogados. [Fuente](https://www.democrata.es/economia/fin-de-la-legislatura-sin-nuevos-presupuestos-por-primera-vez-en-democracia/) | sí |
| 53:11 | Feijóo | «Esto es el reglamento de retorno aprobado en la Unión Europea por la inmensa mayoría de los países con el voto en contra de Sánchez» | Se sostiene. Aprobado el 1 de octubre de 2026 con el único voto en contra de España. [Fuente](https://www.articulo14.es/internacional/espana-el-unico-pais-de-la-ue-que-rechaza-acelerar-las-expulsiones-de-migrantes-20261001.html) | sí |
| 71:56 | Feijóo | «El PP pide 30 años de cárcel para el señor Cordó [Koldo].» | Se sostiene. La acusación popular dirigida por el PP pidió 30 años. [Fuente](https://www.elindependiente.com/espana/2025/11/20/las-acusaciones-populares-piden-30-anos-de-prision-para-abalos-y-koldo-y-revisar-si-deben-permanecer-en-libertad/amp/) | sí |
| 27:32 | Feijóo | «Teníamos un absentismo del 8, te estoy hablando del año 2000 y lo bajamos al 4» | No se pudo comprobar. Las cifras solo aparecen en declaraciones propias y del partido. [Fuente](https://www.eldiario.es/1_cbe758) | no |
| 75:10 | Jordi | «cuando te enteras del tema del piso de 6 ,7 millones, que no puede ser oficinas» | Verdad a medias. La compra costó 6,3 millones; 6,7 es el precio al que después se puso en venta. [Fuente](https://www.eldiario.es/madrid/somos/atico-comprado-gobierno-ayuso-reuniones-no-oficina-destinarse-vivienda_1_13414404.amp.html) | sí |
| 29:28 | Jordi | «tu programa dice que les quitas el IVA a los nuevos y das cuota cero» | Verdad a medias. La exención de IVA del programa no es solo para los nuevos autónomos. [Fuente](https://www.moncloa.com/2026/11/10/pp-plan-reconstruccion-3465233/) | no |
| 33:22 | Jordi | «cuando fuiste el presidente de la Junta la deuda pasó de 4 .000 millones a 12» | Se sostiene. De 4.282 a 11.823 millones entre 2009 y 2022. [Fuente](https://maldita.es/malditodato/20230711/verificacion-deuda-cara-sanchez-feijoo/) | no |
| 35:43 | Jordi | «Esto serían unos 25 .000 millones más de» | Se sostiene. Unos 24.000 millones al año según un cálculo propio con datos del Banco de España. [Fuente](https://www.bde.es/wbe/es/noticias-eventos/actualidad-banco-espana/deuda-aapp-2026t2.html) | sí |

Donde la última columna dice *no*, hay que abrir la fuente antes de dar el veredicto por cerrado. El detalle de las 171 filas está en `verificacion_datos.md`.

Sobre el efecto en la audiencia: una corrección suele mejorar lo que la gente cree sobre el dato, pero rara vez cambia su opinión sobre el político corregido (**Nyhan, Porter, Reifler y Wood, 2020**). El efecto rebote que describió un estudio anterior (**Nyhan y Reifler, 2010**) no se ha reproducido en estudios más amplios (**Wood y Porter, 2019**). Aquí hay una corrección aceptada en directo, la del 1 % de bajas de los autónomos (28:40).

## 9. Momentos clave

Son puntos donde coinciden varias señales medidas por separado. Que coincidan no demuestra relación entre ellas ni intención alguna.

**13:46, los ministerios.** Cuarta formulación de la pregunta: «No, porque creo que no es el momento.» El tono alcanza uno de sus dos valores más altos (z = +3,4) y AU12 y AU14 quedan muy por encima de su nivel habitual (z = +4,0 y +2,5). (Fotograma en la sección 6.)

**48:51, Marruecos.** Pausa de 0,9 segundos, confirmada, antes de un compromiso: «Que quede claro, no lo voy a consentir.» El volumen baja (z = −3,4) y AU4 queda por debajo de su nivel (z = −2,0).

![Feijóo, 48:51](fotogramas/m08_durante.jpg)
*48:51, Feijóo.*

**62:49, la sauna.** «¿Pero cómo que si la sauna?»: suben el tono (z = +2,1) y la velocidad (z = +2,6) y baja AU5 (z = −2,2). Es la única respuesta clasificada como ataque a la pregunta. (Fotograma en la sección 7.)

**78:19–78:36, el inglés.** Jordi baja el volumen (z = −2,8) al preguntar, con AU6 y AU12 muy por encima de su base (z = +3,8 y +3,9). Feijóo contesta «Pues mira, yo no sé inglés, pero sé gobernar» y luego, más despacio que su media (z = −2,8), «De forma fluida, no de boca en la ceja.», con AU6, AU7 y AU14 muy por encima de su nivel (z = +4,1, +5,2 y +4,3). (Fotogramas en la sección 6.)

**64:13, Gürtel.** Jordi formula «Yo te pregunto lo mismo cuando pasó el caso Gürtel y Rajoy, un caso también gravísimo de tu partido,» más despacio (z = −1,9) y más bajo (z = −2,7) que su media, con AU5 por encima (z = +2,9). (Fotograma en la sección 7.)

**87:31, el alegato a cámara.** No responde a ninguna pregunta: Jordi le cede la cámara. Tras una pausa de 0,6 segundos, «soy un político que ha gestionado durante los últimos 30 años de su vida»; bajan el volumen (z = −3,8) y la velocidad (z = −1,6) y suben AU5 y AU1 (z = +3,7 y +2,7). El alegato se abre con «¿Viven mejor en el año 2026 que en el año 2018?», un ejemplo de **encuadre (Entman, 1993)**: se elige qué aspecto destacar, aquí la comparación entre dos momentos.

![Feijóo, 87:31](fotogramas/m15_durante.jpg)
*87:31, alegato final a cámara.*

## 10. Por qué cada espectador vio una entrevista distinta

Los mismos 87 minutos permiten dos resúmenes opuestos, ambos con datos ciertos. Un votante afín a Feijóo puede citar que contestó a lo preguntado en 71 de 111 ocasiones, que dejó 20 compromisos comprobables, que 53 de sus afirmaciones se sostienen, que aceptó una corrección en directo y que admitió una carencia («He de reconocer que no he hecho ningún esfuerzo en esto.»).

Un votante contrario puede citar que en 20 ocasiones no contestó a lo preguntado, que hicieron falta siete preguntas sobre el piso para llegar a «Yo no lo discuto.», que no dijo si habría pedido la dimisión de Rajoy, que dos de sus afirmaciones no se sostienen y que devolvió 18 preguntas.

Con Jordi ocurre lo mismo. Quien piense que fue duro tiene el 77 % de preguntas duras y el 48 % con premisa adversa. Quien piense que fue blando tiene que solo cerró él 15 de 111 intercambios y que dejó al invitado abrir siete temas.

La psicología describe tres mecanismos. El **sesgo de confirmación (Nickerson, 1998)**: se busca y se recuerda lo que encaja con lo que ya se pensaba. El **razonamiento motivado (Kunda, 1990; Taber y Lodge, 2006)**: la información contraria se examina con más exigencia que la favorable, de modo que cada bando da por buena la parte de la evidencia que le favorece (**Lord, Ross y Lepper, 1979**); que eso llegue a alejar más a los dos bandos es un resultado discutido que estudios recientes no reproducen (**Guess y Coppock, 2020**). Y el **efecto del medio hostil (Vallone, Ross y Lepper, 1985)**: los partidarios de cada lado tienden a ver la misma cobertura informativa (y, por extensión, al mismo entrevistador) como sesgada contra el suyo.

## 11. Lo que este análisis no puede decir

- **Transcripción automática.** Tiene tres huecos sin texto, turnos mal atribuidos cuando se pisan (sobre todo en 24:07–25:17 y 61:22–63:50) y nombres mal escritos, que se citan tal cual. Solo se usan las palabras verificadas por huella de voz (87 % de las del invitado, 81 % de las de Jordi): las réplicas breves dichas encima del otro están infrarrepresentadas. No transcribe risas ni titubeos.
- **Pausas.** Se miden entre palabras transcritas. El detector acústico solo confirma el 21 % de las del invitado y el 9 % de las de Jordi.
- **Voz.** Se mide sobre el audio publicado; la ventana usada para la presión (de una pregunta a la siguiente) es una elección de este análisis.
- **Cara.** La realización decide a quién se ve. Las caras se asignaron a mano sobre diez grupos formados por parecido; uno, de imágenes de archivo, se descartó, y otro incluye algún recorte suelto de otra persona. Las AU las estima un modelo estadístico, no un codificador humano, y el giro de la cabeza, la barba y el habla alteran sus valores. No se midieron la mirada ni el parpadeo.
- **Lectura de preguntas y respuestas.** La hizo un solo lector, sin segundo codificador; otra persona podría clasificar distinto algunos casos.
- **Comprobación de datos.** Tres de cada cuatro veredictos descansan en extractos, no en la fuente abierta. Varios hechos de 2026 se apoyan en uno o dos medios.
- **Comparaciones con otras entrevistas.** Son programas, duraciones y formatos distintos; las diferencias no se pueden atribuir a las personas.
- **Referencias.** Describen efectos medios observados en estudios, muchos de laboratorio y en inglés; no predicen lo que hará un espectador concreto ante esta entrevista.
- **Y lo principal:** es una sola entrevista, y nada de lo medido permite saber si alguien dice la verdad, qué siente o cómo es.

## 12. Para llevarte a casa

1. **Habló sobre todo él.** El 72,8 % de las palabras son de Feijóo, la proporción más alta de las cinco entrevistas comparadas.
2. **La entrevista fue dura en la forma.** 86 de 111 intervenciones de Jordi (77 %) fueron incómodas, repreguntas o insistencias, y 53 partían de una premisa adversa.
3. **Contestó a seis de cada diez preguntas duras.** 52 de 86; en 15 contestó en parte y en 17 habló de otra cosa. Donde menos, en partido interno (5 de 14) y rivales (6 de 20).
4. **Muchas cifras y compromisos.** 2,61 cifras por cada 100 palabras y 20 compromisos comprobables de 40. De 123 afirmaciones comprobadas, 53 se sostienen, 46 son verdad a medias y 2 no se sostienen.
5. **Habla casi sin tropiezos.** 23 trabas en 9.256 palabras, 19 en respuestas a preguntas duras.
6. **La voz cambia poco bajo presión.** Unos 3 Hz y 1 dB más tras una pregunta dura (d en torno a 0,2), y nada cuando no contesta a lo preguntado.
7. **Los logros, en primera persona; los fracasos, sobre todo fuera.** 13 de 16 logros en primera persona; 15 de 25 fracasos atribuidos al Gobierno, a Sánchez o a terceros, y 7 a sí mismo o a su partido.

## 13. Fuentes

**Vídeo.** *The Wild Project* n.º 392, entrevista de Jordi Wild a Alberto Núñez Feijóo, YouTube, 13 de noviembre de 2026: <https://www.youtube.com/watch?v=1YlGArMx_N4>.

**Referencias académicas citadas.**

- Atkinson, M. (1984). *Our Masters' Voices: The Language and Body Language of Politics*. Methuen.
- Barrett, L. F., Adolphs, R., Marsella, S., Martinez, A. M. y Pollak, S. D. (2019). Emotional expressions reconsidered: Challenges to inferring emotion from human facial movements. *Psychological Science in the Public Interest*, 20(1), 1–68.
- Bavelas, J. B., Black, A., Chovil, N. y Mullett, J. (1990). *Equivocal Communication*. Sage.
- Benoit, W. L. (1995). *Accounts, Excuses, and Apologies: A Theory of Image Restoration Strategies*. State University of New York Press.
- Benoit, W. L. (2007). *Communication in Political Campaigns*. Peter Lang.
- Bond, C. F. y DePaulo, B. M. (2006). Accuracy of deception judgments. *Personality and Social Psychology Review*, 10(3), 214–234.
- Brennan, S. E. y Williams, M. (1995). The feeling of another's knowing: Prosody and filled pauses as cues to listeners about the metacognitive states of speakers. *Journal of Memory and Language*, 34(3), 383–398.
- Bull, P. y Mayer, K. (1993). How not to answer questions in political interviews. *Political Psychology*, 14(4), 651–666.
- Cialdini, R. B. (1984). *Influence: How and Why People Agree to Things*. William Morrow.
- Clayman, S. y Heritage, J. (2002). *The News Interview: Journalists and Public Figures on the Air*. Cambridge University Press.
- DePaulo, B. M., Lindsay, J. J., Malone, B. E., Muhlenbruck, L., Charlton, K. y Cooper, H. (2003). Cues to deception. *Psychological Bulletin*, 129(1), 74–118.
- Duez, D. (1982). Silent and non-silent pauses in three speech styles. *Language and Speech*, 25(1), 11–28.
- Entman, R. M. (1993). Framing: Toward clarification of a fractured paradigm. *Journal of Communication*, 43(4), 51–58.
- Ekman, P. y Friesen, W. V. (1978). *Facial Action Coding System*. Consulting Psychologists Press.
- Ekman, P., Davidson, R. J. y Friesen, W. V. (1990). The Duchenne smile: Emotional expression and brain physiology II. *Journal of Personality and Social Psychology*, 58(2), 342–353.
- Goldman-Eisler, F. (1968). *Psycholinguistics: Experiments in Spontaneous Speech*. Academic Press.
- Guess, A. y Coppock, A. (2020). Does counter-attitudinal information cause backlash? Results from three large survey experiments. *British Journal of Political Science*, 50(4), 1497–1515.
- Juslin, P. N. y Laukka, P. (2003). Communication of emotions in vocal expression and music performance: Different channels, same code? *Psychological Bulletin*, 129(5), 770–814.
- Kunda, Z. (1990). The case for motivated reasoning. *Psychological Bulletin*, 108(3), 480–498.
- Lord, C. G., Ross, L. y Lepper, M. R. (1979). Biased assimilation and attitude polarization: The effects of prior theories on subsequently considered evidence. *Journal of Personality and Social Psychology*, 37(11), 2098–2109.
- Miller, D. T. y Ross, M. (1975). Self-serving biases in the attribution of causality: Fact or fiction? *Psychological Bulletin*, 82(2), 213–225.
- Miller, N., Maruyama, G., Beaber, R. J. y Valone, K. (1976). Speed of speech and persuasion. *Journal of Personality and Social Psychology*, 34(4), 615–624.
- Nickerson, R. S. (1998). Confirmation bias: A ubiquitous phenomenon in many guises. *Review of General Psychology*, 2(2), 175–220.
- Nyhan, B. y Reifler, J. (2010). When corrections fail: The persistence of political misperceptions. *Political Behavior*, 32(2), 303–330.
- Nyhan, B., Porter, E., Reifler, J. y Wood, T. J. (2020). Taking fact-checks literally but not seriously? The effects of journalistic fact-checking on factual beliefs and candidate favorability. *Political Behavior*, 42(3), 939–960.
- Petrocik, J. R. (1996). Issue ownership in presidential elections, with a 1980 case study. *American Journal of Political Science*, 40(3), 825–850.
- Rogers, T. y Norton, M. I. (2011). The artful dodger: Answering the wrong question the right way. *Journal of Experimental Psychology: Applied*, 17(2), 139–147.
- Scherer, K. R. (2003). Vocal communication of emotion: A review of research paradigms. *Speech Communication*, 40(1–2), 227–256.
- Smith, S. M. y Shaffer, D. R. (1995). Speed of speech and persuasion: Evidence for multiple effects. *Personality and Social Psychology Bulletin*, 21(10), 1051–1060.
- Taber, C. S. y Lodge, M. (2006). Motivated skepticism in the evaluation of political beliefs. *American Journal of Political Science*, 50(3), 755–769.
- Tickle-Degnen, L. y Rosenthal, R. (1990). The nature of rapport and its nonverbal correlates. *Psychological Inquiry*, 1(4), 285–293.
- Tversky, A. y Kahneman, D. (1974). Judgment under uncertainty: Heuristics and biases. *Science*, 185(4157), 1124–1131.
- Vallone, R. P., Ross, L. y Lepper, M. R. (1985). The hostile media phenomenon: Biased perception and perceptions of media bias in coverage of the Beirut massacre. *Journal of Personality and Social Psychology*, 49(3), 577–585.
- Weaver, R. K. (1986). The politics of blame avoidance. *Journal of Public Policy*, 6(4), 371–398.
- Wegner, D. M., Wenzlaff, R., Kerker, R. M. y Beattie, A. E. (1981). Incrimination through innuendo: Can media questions become public answers? *Journal of Personality and Social Psychology*, 40(5), 822–832.
- Williams, K. D., Bourgeois, M. J. y Croyle, R. T. (1993). The effects of stealing thunder in criminal and civil trials. *Law and Human Behavior*, 17(6), 597–609.
- Wood, T. y Porter, E. (2019). The elusive backfire effect: Mass attitudes' steadfast factual adherence. *Political Behavior*, 41(1), 135–163.
- Zuckerman, M. (1979). Attribution of success and failure revisited, or: The motivational bias is alive and well in attribution theory. *Journal of Personality*, 47(2), 245–287.

**Archivos de datos (carpeta de la entrevista).** `transcripcion.csv`, `palabras.csv`, `qa_pares.csv`, `hablantes.json`, `comparativa.csv`, `disfluencias_resumen.csv`, `disfluencias_eventos.csv`, `pausas_entrevistado.csv`, `pausas_entrevistador.csv`, `voz_entrevistado.csv`, `voz_entrevistador.csv`, `tonalidad_entrevistado.csv`, `tonalidad_entrevistador.csv`, `retorica.csv`, `cara_entrevistado.csv`, `cara_entrevistador.csv`, `expresiones_resumen.csv`, `expresiones_eventos.csv`, `movimiento_resumen.csv`, `momentos_entrevistado.csv`, `momentos_entrevistador.csv`, `cortes_plano.txt`, `fotogramas/`, `lectura/` (`preguntas.json`, `temas.json`, `afirmaciones.json`, `promesas.json`, `merito_culpa.json`, `sintonia.json`, `resumen.md`), `informe.md`, `informe_tonalidad.md`, `informe_expresiones.md`, `informe_movimiento.md`, `verificacion_datos.md` y `verificacion_datos.csv` (versión revisada). Comparación con otras entrevistas: `comparacion/v3/metricas.md`, `comparacion/v3/extra.md` y `comparacion/lectura/lectura_comparada.md`.
