# Cómo mueve cada uno sus rasgos al hablar, partiendo de su cara de base: Pedro Sánchez y Jordi Wild (YouTube · The Wild Project, 13/11/2026)

*Anexo. Mide cuánto y cómo se aparta la cara de cada uno, mientras habla, de su propia cara mientras escucha: cejas, ojos, boca y cabeza. Las cifras salen del vídeo de la entrevista. Es una aproximación y describe movimiento, no emociones, intenciones ni rasgos de carácter; tampoco sirve para saber si alguien dice la verdad. Las frases que comparan se generan a partir de las cifras, con el criterio indicado en cada una.*

## 1. Lo esencial

- **Cejas al hablar** (altura respecto a su base al escuchar): +9 % el entrevistado y +3 % el entrevistador; más altas en el entrevistado.
- **Apertura de la boca al hablar** (en % de la anchura de su boca, respecto a su base): habitual 1,0 % el entrevistado y 1,9 % el entrevistador; en las aperturas amplias (percentil 95), 8,7 % y 21,5 %. La habitual es mayor en el entrevistador.
- **Ojos al hablar** (apertura respecto a su base): 0 % el entrevistado y +2 % el entrevistador; más abiertos en el entrevistador.
- **Giro de cabeza:** el entrevistado, 7,8°/s al hablar y 4,0°/s al escuchar (más al hablar); el entrevistador, 12,1°/s al hablar y 7,4°/s al escuchar (más al hablar).
- **Qué rasgos acompañan a la intensidad de la voz** (correlación frase a frase de 0,10 o más en valor absoluto): en el entrevistado, boca: apertura (+0,19); en el entrevistador, ojos: apertura (-0,21), comisuras: altura (+0,18), boca: apertura (+0,17), boca: anchura (+0,14), cabeza: movimiento (+0,11).

## 2. Tabla: dónde queda cada rasgo al hablar

Cambio respecto a la cara de cada uno mientras escucha. Cejas, ojos y anchura de boca, en % de su propio valor de base; apertura de boca y comisuras, en % de la anchura de su boca.

| Rasgo | Entrevistado: habitual | recorrido (del 5 % al 95 % de los fotogramas) | Entrevistador: habitual | recorrido |
|---|---|---|---|---|
| cejas: altura | +9 % | de -22 % a +53 % | +3 % | de -20 % a +44 % |
| ojos: apertura | 0 % | de -53 % a +30 % | +2 % | de -71 % a +37 % |
| boca: apertura | +1 % | de -2 % a +9 % | +2 % | de -5 % a +21 % |
| boca: anchura | -1 % | de -11 % a +9 % | -2 % | de -11 % a +10 % |
| comisuras: altura | +2 % | de -5 % a +9 % | +1 % | de -5 % a +11 % |

| Cabeza | Entrevistado hablando | Entrevistado escuchando | Entrevistador hablando | Entrevistador escuchando |
|---|---|---|---|---|
| velocidad de giro (°/s) | 7,8 | 4,0 | 12,1 | 7,4 |
| velocidad de cabeceo (°/s) | 11,1 | 9,5 | 17,9 | 10,6 |
| velocidad de inclinación (°/s) | 8,6 | 6,5 | 9,2 | 6,2 |
| amplitud de giro (desviación, °) | 7,6 | 5,5 | 9,3 | 8,7 |
| amplitud de cabeceo (desviación, °) | 9,8 | 8,5 | 11,3 | 10,2 |

El «recorrido» incluye el ruido de la medida (ver límites), así que es más fiable comparar los valores habituales que los extremos.

## 3. Qué hace la cara cuando sube la voz

Para cada frase se compara el movimiento medio de cada rasgo con la intensidad de la voz en esa frase (tono, volumen y tensión, del anexo de tonalidad). «Más intensas» y «más apagadas» son el 20 % de frases de cada extremo.

| Rasgo | Entrevistado: frases más intensas | más apagadas | correlación | Entrevistador: frases más intensas | más apagadas | correlación |
|---|---|---|---|---|---|---|
| cejas: altura | +13 % | +9 % | +0,09 | +11 % | +5 % | +0,08 |
| ojos: apertura | -7 % | -5 % | +0,01 | -12 % | -1 % | -0,21 |
| boca: apertura | +2 % | +1 % | +0,19 | +4 % | +3 % | +0,17 |
| boca: anchura | -1 % | -1 % | -0,00 | -1 % | -2 % | +0,14 |
| comisuras: altura | +2 % | +2 % | +0,00 | +2 % | +1 % | +0,18 |
| cabeza: movimiento (°/s) | 14,2 | 14,0 | +0,03 | 22,5 | 19,4 | +0,11 |

- La correlación más alta en valor absoluto es 0,21: todas quedan por debajo de 0,30, así que la cara acompaña a la voz poco y no siempre.
- Cejas al preguntar (entrevistado): +8 % en sus 18 frases interrogativas con la cara en pantalla y +12 % en las demás (más bajas al preguntar).
- Cejas al preguntar (entrevistador): +3 % en sus 42 frases interrogativas con la cara en pantalla y +8 % en las demás (más bajas al preguntar).

![grafica](grafica_movimiento.png)

## 4. Relación con el anexo de expresiones

En `informe_expresiones.md` un gesto es un pico por encima del nivel habitual de esa persona en el mismo estado (hablando o escuchando). Aquí se mide el nivel mientras habla respecto a su cara mientras escucha. Un rasgo que se mantiene alto todo el tiempo que la persona habla aparece aquí y no como gesto allí, de modo que las dos medidas pueden no coincidir sin contradecirse.

## 5. Límites

- **Precisión.** A la distancia habitual de estos planos, una ceja se mueve unos pocos píxeles. Los puntos faciales tiemblan de un fotograma a otro, y por eso el «recorrido» sale amplio incluso cuando escuchan. Los valores habituales (medianas) son más fiables que los extremos; las cifras exactas son aproximadas.
- **Ángulo de cámara.** Se corrige el efecto del giro de cabeza, pero la corrección es aproximada, y se descartan los planos lejanos y las posturas muy distintas de la habitual.
- **5 fotogramas por segundo.** Los movimientos muy rápidos (un parpadeo, un golpe de ceja breve) se pierden, y las velocidades de cabeza están suavizadas.
- **La base es la cara de cada uno mientras escucha en esta entrevista.** Si alguien escucha con un gesto mantenido, su base lo incluye.
- **El vello facial** afecta a los puntos de la boca y la mandíbula.
- **La realización.** Fotogramas usados: entrevistado, 12198 hablando y 926 escuchando; entrevistador, 5470 y 526. Con menos de 1500 fotogramas escuchando (5 minutos), la base de esa persona es poco sólida.
- Son maneras de mover la cara al hablar, no estados de ánimo, y no dicen nada sobre la sinceridad de nadie.

## 6. Archivos

`movimiento_resumen.csv`, `movimiento_frases_entrevistado.csv`, `movimiento_frases_entrevistador.csv`, `movimiento_fotogramas_*.csv`; `grafica_movimiento.png`; scripts `26_movimiento_rasgos.py` y `27_informe_movimiento.py`.
