# Expresiones respecto a la cara de base de cada uno: Pedro Sánchez y Jordi Wild (YouTube · The Wild Project, 13/11/2026)

*Anexo. Cada persona tiene unas facciones de partida distintas, y un programa que compara una cara con un patrón universal confunde esas facciones con gestos. Aquí se hace al revés: se calcula la **cara de base** de cada uno y se mide solo lo que se aparta de ella. Las facciones dejan de contar; cuenta el movimiento. Un gesto medido no dice qué siente la persona ni si dice la verdad. Las frases que comparan se generan a partir de las cifras, con el criterio indicado en cada una.*

## 1. Cómo se ha hecho

1. **Se quita el efecto de la cámara.** Cada persona puede estar grabada desde un ángulo distinto. Para cada unidad de acción facial (AU) se resta la parte que depende del giro, el cabeceo y la inclinación de la cabeza de esa persona.
2. **Se calcula la cara de base de cada uno**: el valor central (mediana) de cada AU en sus propios fotogramas, por separado cuando habla y cuando escucha, porque hablar mueve la boca.
3. **Cada fotograma se mide en desviaciones respecto a esa base**, con una escala robusta propia de cada persona. Un valor de 0 es «su cara de siempre», tenga las facciones que tenga.
4. **Un gesto** es un tramo de al menos 0,6 s en el que una zona de la cara se aparta claramente de su base (2,5 desviaciones). Se cuentan por cada 10 minutos en pantalla, porque la cámara no enfoca a los dos el mismo tiempo.

No se usa ninguna etiqueta de emoción: los gestos se nombran por lo que hace la cara.

## 2. Lo esencial

Criterios: «parecida» = menos de un 20 % de diferencia; con menos de 5 minutos en pantalla en un estado, el dato se marca como frágil.

- **Ceño y labios apretados.** Episodios por encima de la base en toda la entrevista: ceño, 15 en el entrevistado y 0 en el entrevistador; labios apretados, 0 y 0.
- **Gesto más frecuente de cada uno** (por 10 minutos en pantalla): en el entrevistado, sonrisa (21,1); en el entrevistador, sonrisa (29,3).
- **Sonrisa.** 21,1 por 10 minutos en pantalla el entrevistado y 29,3 el entrevistador (más frecuente en el entrevistador). Dentro de cada uno: el entrevistado, 19,6 por 10 min al hablar y 21,1 al escuchar (parecida); el entrevistador, 28,7 por 10 min al hablar y 16,6 al escuchar (más al hablar).
- **Cejas arriba.** 1,4 por 10 minutos en pantalla el entrevistado y 14,2 el entrevistador (más frecuente en el entrevistador). Dentro de cada uno: el entrevistado, 1,2 por 10 min al hablar y 4,0 al escuchar (más al escuchar); el entrevistador, 21,4 por 10 min al hablar y 1,6 al escuchar (más al hablar).
- **Ojos más abiertos.** 14,9 por 10 minutos en pantalla el entrevistado y 25,3 el entrevistador (más frecuente en el entrevistador). Dentro de cada uno: el entrevistado, 17,1 por 10 min al hablar y 11,9 al escuchar (más al hablar); el entrevistador, 34,0 por 10 min al hablar y 11,1 al escuchar (más al hablar).
- **Mentón arriba.** 0,1 por 10 minutos en pantalla el entrevistado y 7,9 el entrevistador (más frecuente en el entrevistador). Dentro de cada uno: el entrevistado, 0,2 por 10 min al hablar y 0,0 al escuchar (más al hablar); el entrevistador, 7,7 por 10 min al hablar y 8,7 al escuchar (parecida).

## 3. Tabla completa

Tiempo con la cara en pantalla: entrevistado 72,7 min (de ellos 7,6 mientras habla el otro); entrevistador 47,1 min (12,7 mientras habla el otro).

| Gesto | Entrevistado: nº | por 10 min | hablando | escuchando | duración media | Entrevistador: nº | por 10 min | hablando | escuchando | duración media |
|---|---|---|---|---|---|---|---|---|---|---|
| sonrisa (comisuras arriba + mejillas) | 153 | 21,1 | 19,6 | 21,1 | 1,0 s | 138 | 29,3 | 28,7 | 16,6 | 1,2 s |
| cejas arriba | 10 | 1,4 | 1,2 | 4,0 | 0,9 s | 67 | 14,2 | 21,4 | 1,6 | 1,0 s |
| ojos más abiertos | 108 | 14,9 | 17,1 | 11,9 | 1,1 s | 119 | 25,3 | 34,0 | 11,1 | 1,1 s |
| mentón arriba | 1 | 0,1 | 0,2 | 0,0 | 0,6 s | 37 | 7,9 | 7,7 | 8,7 | 0,8 s |
| ceño (cejas bajan y se juntan) | 15 | 2,1 | 2,9 | 0,0 | 0,8 s | 0 | 0,0 | 0,0 | 0,0 | 0,0 s |
| labios apretados | 0 | 0,0 | 0,0 | 0,0 | 0,0 s | 0 | 0,0 | 0,0 | 0,0 | 0,0 s |
| comisuras hacia abajo | 4 | 0,6 | 0,6 | 0,0 | 0,8 s | 0 | 0,0 | 0,0 | 0,0 | 0,0 s |

«Hablando» y «escuchando» son gestos por cada 10 minutos en pantalla en ese estado.

![expresiones](grafica_expresiones.png)

## 4. Los gestos más marcados de cada uno

**Entrevistado**

- Sonrisa: 1:43, mientras el otro dice «a Pedro Sánchez, presidente de España durante ocho años,…»; 1:45, mientras el otro dice «España durante ocho años, candidato a las elecciones otra vez y…»; 46:31, mientras el otro dice «acabar con ese tema simplemente es al final…»; 69:10, mientras el otro dice «¿Y el viaje en que lo hicisteis?…»
- Cejas arriba: 37:12, mientras el otro dice «¿Dices en serio que el ejército marroquí, como es, si…»; 42:34, mientras el otro dice «compran todos los países es un sistema que se ha puesto a la…»; 46:05, mientras dice «antes comentabas tú, y es verdad que da la sensación…»; 106:23, mientras dice «Cuando yo he puesto encima de la mesa propuestas…»
- Ojos más abiertos: 35:15, mientras dice «al final, si tú te echas a nadar, pues……»; 62:12, mientras el otro dice «No, yo creo que tenemos que tocar más el dinero.…»; 86:31, mientras dice «Para hacerte una idea, durante estos años de gobierno, el 13 %…»; 107:19, mientras dice «Pues yo le diría que dije que iba a subir el salario mínimo…»

**Entrevistador**

- Sonrisa: 62:02, mientras el otro dice «A 19 semanas, que son 100 días,…»; 66:48, mientras el otro dice «Sí, claro que sí, el que necesites ¿Sí?…»; 94:16, mientras el otro dice «Ahora mismo está mal, pero fíjate...…»; 103:09, mientras el otro dice «mejor ni peor. No, claro, pero los políticos también tenemos derecho a cambiar…»
- Cejas arriba: 66:46, mientras el otro dice «Sí, claro que sí, el que necesites ¿Sí?…»; 67:42, mientras dice «caso, en el caso de Ábalos, ya condenado, 24 años de cárcel.…»; 70:46, mientras dice «mucho pensar que en esos largos viajes, en esas horas de carreteras de…»; 71:17, mientras el otro dice «Y te puedo…»
- Ojos más abiertos: 21:04, mientras el otro dice «No, a mi juicio no.…»; 63:16, mientras el otro dice «es una política equilibrada y ordenada de la migración, donde nos…»; 66:49, mientras el otro dice «que necesites ¿Sí?…»; 77:27, mientras el otro dice «pero desde el punto de vista con José Luis Ábalos, pues sí es…»

Son los momentos en que cada cara más se aparta de su propia base, no los más «emocionales»: una sonrisa puede ser de cortesía, de ironía o de incomodidad, y unas cejas arriba pueden ser énfasis o sorpresa. El gesto se puede medir; su significado, no.

## 5. Límites

- **La cara de base se calcula con la propia entrevista.** Si alguien mantuviera un gesto toda la entrevista, ese gesto pasaría a ser su «base» y no se detectaría. Para saberlo haría falta material suyo de otro día.
- **Gestos con valor de base alto.** Cuando una AU tiene en una persona un valor de base alto y variable, un gesto leve puede no superar el umbral. Que no haya episodios significa que no hay ninguno claro, no que la cara esté inmóvil.
- **El umbral lo fija el analista** (2,5 desviaciones, 0,6 s). Con otro umbral cambian las cifras.
- **Facciones, gafas y giros.** El vello facial y las gafas afectan a las medidas de la boca, el mentón y los ojos; la corrección por ángulo de cámara es aproximada.
- **La realización decide a quién se ve.** Hay 72,7 min de la cara del entrevistado y 47,1 min de la del entrevistador; mientras escuchan, 7,6 y 12,7 min.
- Hablar mueve la boca: por eso la base se calcula aparte al hablar y al escuchar, pero la sonrisa mientras se habla sigue siendo más difícil de medir que en silencio.
- Ningún gesto de este anexo permite saber qué siente una persona, qué pretende o si dice la verdad.

## 6. Archivos

`expresiones_eventos.csv` (cada gesto: quién, cuál, minuto, duración, intensidad, si hablaba o escuchaba y qué se decía), `expresiones_resumen.csv`, `grafica_expresiones.png`; scripts `22_expresiones_base.py` y `23_informe_expresiones.py`.
