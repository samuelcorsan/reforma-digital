# Análisis técnico de la entrevista de Jordi Wild a Pedro Sánchez: entrevistado y entrevistador

*Documento descriptivo y medible. Describe qué hace cada persona y cuándo. No atribuye intenciones, rasgos de personalidad ni diagnósticos, y ninguna medida de este documento (pausas, voz, unidades de acción) sirve para saber si alguien dice la verdad. La expresión facial se informa solo en unidades de acción (AU) del sistema FACS, sin etiquetas de emoción. El entrevistado y el entrevistador se analizan **por separado**, cada uno frente a su propia línea base, y después se comparan. Las frases que comparan a los dos se generan a partir de las cifras, con el criterio indicado en cada una.*

## 1. Ficha de la entrevista

| Campo | Valor |
|---|---|
| Medio | YouTube · The Wild Project |
| Título | «The Wild Project #393 - Pedro Sánchez \| Ábalos y Koldo, Ceuta y Marruecos, Su famosa hemeroteca» |
| Fecha | 13/11/2026 |
| Duración del vídeo | 1 h 52 min 7 s (6727 s) |
| Parte analizada | transcripción y hablantes: todo el vídeo. Todas las medidas de este informe: desde el inicio de la entrevista (1:23) hasta su final (112:06), según `hablantes.json` |
| Personas analizadas | **entrevistado** (Pedro Sánchez) y **entrevistador** (Jordi Wild) |
| Enlace | https://www.youtube.com/watch?v=mStOFBvToUI |
| Formato | Entrevista larga en estudio, sin público, dos personas sentadas frente a frente; forma parte de una serie con los candidatos a la presidencia; los primeros 1:23 son una introducción común a las tres entrevistas y quedan fuera de las medidas |

Todos los minutos son tiempo del vídeo (m:ss).

## 2. Comparativa entre entrevistado y entrevistador

Las mismas medidas para las dos personas, en el mismo vídeo y con el mismo audio. La **d de Cohen** indica el tamaño de la diferencia (alrededor de 0,2 pequeña, 0,5 media, 0,8 o más grande); con cientos de frases, casi cualquier diferencia sería estadísticamente significativa, así que se informa el tamaño y no un valor p. En las frases de esta sección, una diferencia con |d| menor de 0,2 se da como inapreciable.

### 2.1 Reparto del habla

| Medida | Entrevistado | Entrevistador |
|---|---|---|
| palabras verificadas | 10840 | 6266 |
| % de las palabras verificadas de ambos | 63.4 | 36.6 |
| tiempo de habla verificado (min) | 58.4 | 30.6 |
| turnos verificados | 320 | 235 |
| mediana de palabras por turno | 23.0 | 19.0 |
| turno más largo (s) | 91.8 | 42.5 |
| veces que toma la palabra tras el otro | 72 | 65 |
| latencia mediana al tomar la palabra (s) | 0.05 | 0.0 |
| % de tomas de palabra con hueco < 0,2 s | 72.0 | 80.0 |

La mayor parte de las palabras verificadas son del entrevistado (63,4 % frente a 36,6 %). El 72 % de las veces que el entrevistado toma la palabra y el 80 % de las del entrevistador se producen con menos de 0,2 s de hueco: más de la mitad en ambos sentidos, es decir, habla encadenada o solapada con frecuencia. La medida no distingue quién interrumpe a quién.

### 2.2 Voz

| Medida | Entrevistado | Entrevistador | Tamaño de la diferencia |
|---|---|---|---|
| tono F0 medio (Hz) | 121.0 | 123.0 | d de Cohen entrevistado−entrevistador = -0.19 |
| variación de tono dentro de la frase (semitonos, sd) | 3.64 | 3.4 | d de Cohen entrevistado−entrevistador = +0.27 |
| rango de tono dentro de la frase (semitonos, p5–p95) | 11.6 | 10.9 | d de Cohen entrevistado−entrevistador = +0.23 |
| intensidad media (dB relativos) | 64.7 | 67.0 | d de Cohen entrevistado−entrevistador = -0.39 |
| variación de intensidad dentro de la frase (dB, sd) | 16.7 | 14.1 | d de Cohen entrevistado−entrevistador = +0.33 |
| velocidad (palabras/min) | 204.0 | 227.0 | d de Cohen entrevistado−entrevistador = -0.40 |
| frases medidas | 563 | 393 |  |
| desviación del tono entre frases (Hz, sd) | 13.9 | 14.2 |  |
| desviación de la velocidad entre frases (palabras/min, sd) | 55.0 | 61.0 |  |
| % de frases con cambio claro de tono (\|z\| ≥ 1,5 respecto a su propia media) | 12.6 | 11.7 | sube/baja: entrevistado 52/19 · entrevistador 29/17 |
| % de frases con cambio claro de volumen (\|z\| ≥ 1,5 respecto a su propia media) | 8.5 | 9.2 | sube/baja: entrevistado 1/47 · entrevistador 3/33 |
| % de frases con cambio claro de velocidad (\|z\| ≥ 1,5 respecto a su propia media) | 10.5 | 14.0 | sube/baja: entrevistado 39/20 · entrevistador 32/23 |

- **Tono.** 121 Hz en el entrevistado y 123 Hz en el entrevistador (d = -0,19, |d| < 0,2: diferencia inapreciable). El tono medio refleja sobre todo la voz de cada persona, no una conducta.
- **Variación de tono dentro de la frase.** 3,64 semitonos en el entrevistado y 3,40 semitonos en el entrevistador (d = +0,27: diferencia pequeña, mayor en el entrevistado). Frases con el tono claramente fuera de la propia media (|z| ≥ 1,5): en el entrevistado 52 suben y 19 bajan; en el entrevistador 29 suben y 17 bajan.
- **Intensidad.** 64,7 dB en el entrevistado y 67,0 dB en el entrevistador (d = -0,39: diferencia pequeña, mayor en el entrevistador). La intensidad depende del micrófono y de la mezcla, así que una diferencia entre los dos no se puede atribuir a la forma de hablar.
- **Velocidad.** 204 palabras/min en el entrevistado y 227 palabras/min en el entrevistador (d = -0,40: diferencia pequeña, mayor en el entrevistador). Se mide solo en tramos de habla continua, sin pausas, por lo que las cifras son más altas que una velocidad media de conversación.

![voz](grafica_comparativa_voz.png)

![tono](grafica_tono.png)
![volumen](grafica_volumen.png)
![velocidad](grafica_velocidad.png)

### 2.3 Pausas

| Medida | Entrevistado | Entrevistador |
|---|---|---|
| pausas > 0,4 s | 112 | 51 |
| pausas por 1000 palabras | 10.3 | 8.1 |
| duración media (s) | 0.79 | 0.88 |
| duración mediana (s) | 0.68 | 0.76 |
| pausas de 1 s o más | 22 | 13 |
| pausa máxima (s) | 2.4 | 2.3 |
| pausas antes de frase con carga | 20 | 7 |
| % confirmadas por silencedetect | 15.0 | 8.0 |

El entrevistado hace más pausas por cada 1000 palabras (10,3 frente a 8,1). Las del entrevistador son más largas de media (0,88 s frente a 0,79 s). De 1 s o más: 22 del entrevistado y 13 del entrevistador. `silencedetect` confirma como silencio el 15 % de los huecos del entrevistado y el 8 % de los del entrevistador. Donde ese porcentaje no llega a la mitad, la mayoría de los huecos no son silencio para `ffmpeg`: pueden contener voz de la otra persona, risas, música o ruido (no se ha comprobado uno a uno).

### 2.4 Texto: pronombres, preguntas y patrones

| Medida | Entrevistado | Entrevistador | Nota |
|---|---|---|---|
| pronombre «yo» por 1000 palabras | 13.6 | 9.7 | recuento: entrevistado 147 · entrevistador 63 |
| pronombre «nosotros» por 1000 palabras | 3.0 | 0.3 | recuento: entrevistado 33 · entrevistador 2 |
| pronombre «tú» por 1000 palabras | 3.4 | 5.9 | recuento: entrevistado 37 · entrevistador 38 |
| pronombre «vosotros» por 1000 palabras | 0.1 | 0.5 | recuento: entrevistado 1 · entrevistador 3 |
| pronombre «ellos» por 1000 palabras | 0.5 | 0.9 | recuento: entrevistado 5 · entrevistador 6 |
| frases interrogativas | 23 | 59 | de las frases verificadas: entrevistado 544 · entrevistador 403 |
| contrastes «no X, sino Y» | 18 | 2 | detección automática sin revisar |
| listas de tres (candidatas) | 0 | 2 | detección automática sin revisar |
| preguntas seguidas por el mismo hablante (candidatas a retóricas) | 20 | 31 | detección automática sin revisar |
| frases con léxico de pérdida o riesgo | 7 | 4 | detección automática sin revisar |
| frases con léxico de logro o ganancia | 15 | 1 | detección automática sin revisar |
| relatos o personas concretas (candidatos) | 14 | 2 | detección automática sin revisar |

Lectura generada a partir de la tabla (por 1000 palabras verificadas de cada uno; «parecida» = menos de un 20 % de diferencia; por debajo de 1 por 1000 en los dos no se compara):

- «yo» explícito: más frecuente en el entrevistado (13,6 frente a 9,7).
- «nosotros» explícito: más frecuente en el entrevistado (3,0 frente a 0,3).
- «tú» explícito: más frecuente en el entrevistador (5,9 frente a 3,4).
- «vosotros» explícito: apenas aparece en ninguno de los dos (0,1 y 0,5).
- «ellos» explícito: apenas aparece en ninguno de los dos (0,5 y 0,9).
- Frases interrogativas: más frecuente en el entrevistador (9,1 frente a 2,1).
- Frases con léxico de pérdida o riesgo: apenas aparece en ninguno de los dos (0,6 y 0,6).
- Frases con léxico de logro o ganancia: más frecuente en el entrevistado (1,4 frente a 0,2).
- Relatos o personas concretas (candidatos): más frecuente en el entrevistado (1,3 frente a 0,3).

Son recuentos automáticos por patrones, sin revisar uno a uno.

### 2.5 Cara: unidades de acción y postura

| Medida | Entrevistado | Entrevistador |
|---|---|---|
| % de fotogramas muestreados con su cara | 66.0 | 42.0 |
| fotogramas con su cara mientras habla / mientras habla el otro | 15420 / 2270 | 7420 / 3798 |
| giro de cabeza: media (grados) | 45.5 | -40.9 |
| giro de cabeza: variabilidad (sd, grados) | 19.7 | 25.4 |
| cabeceo: media (grados) | -32.8 | -9.4 |
| cabeceo: variabilidad (sd, grados) | 49.2 | 27.5 |
| inclinación: media (grados) | -20.4 | -2.2 |
| inclinación: variabilidad (sd, grados) | 49.9 | 27.6 |
| ventanas de 6 s con alguna AU fuera de lo habitual (\|z\| ≥ 2 respecto a su propia línea base), % | 28.6 | 28.2 |

**Nivel medio de cada AU (0–1, sin calibrar)**

| AU | Entrevistado | Entrevistador | Tamaño de la diferencia |
|---|---|---|---|
| AU1 cejas: parte interna arriba | 0.507 | 0.453 | d (ventanas de 6 s) = +0.90 |
| AU2 cejas: parte externa arriba | 0.277 | 0.265 | d (ventanas de 6 s) = +0.16 |
| AU4 cejas bajan y se juntan | 0.369 | 0.428 | d (ventanas de 6 s) = -0.45 |
| AU5 párpado superior arriba | 0.34 | 0.353 | d (ventanas de 6 s) = -0.36 |
| AU6 mejillas elevadas | 0.146 | 0.161 | d (ventanas de 6 s) = -0.25 |
| AU7 párpados tensos | 0.052 | 0.058 | d (ventanas de 6 s) = -0.05 |
| AU12 comisura labios arriba | 0.135 | 0.092 | d (ventanas de 6 s) = +0.69 |
| AU14 hoyuelo comisura | 0.373 | 0.386 | d (ventanas de 6 s) = -0.14 |
| AU15 comisura labios abajo | 0.344 | 0.554 | d (ventanas de 6 s) = -3.09 |
| AU17 mentón arriba | 0.498 | 0.338 | d (ventanas de 6 s) = +6.17 |
| AU23 labios apretados | 0.544 | 0.64 | d (ventanas de 6 s) = -1.60 |
| AU24 labios presionados | 0.552 | 0.477 | d (ventanas de 6 s) = +0.85 |
| AU25 labios separados (habla) | 0.408 | 0.551 |  |
| AU26 mandíbula baja (habla) | 0.306 | 0.429 |  |
| AU43 ojos cerrados | 0.334 | 0.3 |  |

**Cambio de cada AU al hablar respecto a cuando habla el otro (misma persona)**

| AU | Entrevistado | Entrevistador |
|---|---|---|
| AU1 cejas: parte interna arriba | -0.016 | -0.009 |
| AU2 cejas: parte externa arriba | -0.003 | +0.024 |
| AU4 cejas bajan y se juntan | -0.121 | -0.015 |
| AU5 párpado superior arriba | +0.011 | +0.015 |
| AU6 mejillas elevadas | +0.020 | +0.042 |
| AU7 párpados tensos | -0.009 | -0.012 |
| AU12 comisura labios arriba | +0.034 | +0.029 |
| AU14 hoyuelo comisura | +0.053 | -0.001 |
| AU15 comisura labios abajo | -0.035 | -0.050 |
| AU17 mentón arriba | +0.007 | +0.003 |
| AU23 labios apretados | -0.020 | -0.028 |
| AU24 labios presionados | +0.063 | -0.045 |

- **Niveles absolutos.** Con diferencia grande (|d| ≥ 0,8, en ventanas de 6 s), el modelo da valores más altos al entrevistado en AU17, AU1, AU24 y al entrevistador en AU15, AU23. **Estas diferencias no se pueden leer como diferencias de expresión**: py-feat no está calibrado por persona, y la forma de la cara, el vello facial, las gafas, el ángulo de cámara (giro medio de cabeza: +46° el entrevistado y -41° el entrevistador) y la iluminación desplazan la línea base de cada cara. Son, en el mejor de los casos, rasgos de cómo el modelo ve cada rostro.
- **Dentro de cada persona** (más fiable). Los tres mayores cambios al hablar respecto a cuando habla el otro: en el entrevistado, AU4 -0,121; AU24 +0,063; AU14 +0,053; en el entrevistador, AU15 -0,050; AU24 -0,045; AU6 +0,042. El habla mueve la boca y contamina estas medidas (ver limitaciones). Fotogramas con su cara mientras habla el otro: 2270 del entrevistado y 3798 del entrevistador.
- **Frecuencia de desviaciones.** La proporción de ventanas de 6 s con alguna AU fuera de lo habitual es parecida (28,6 % el entrevistado y 28,2 % el entrevistador; menos de 5 puntos de diferencia). Cada uno se compara consigo mismo; no indica qué significa cada desviación.
- **Presencia en pantalla.** La cara del entrevistado se detecta en el 66 % de los fotogramas muestreados y la del entrevistador en el 42 %: la del entrevistado aparece 1,6 veces más. Depende de la realización (a quién enfoca la cámara).

![AU comparativa](grafica_comparativa_AU.png)

![AU](grafica_AU.png)

## 3. El entrevistado, por separado

### Pausas

- **112** huecos de más de 0,4 s entre palabras verificadas consecutivas. Duración media **0,79 s**, mediana 0,68 s, máxima 2.4 s. 22 duran 1 s o más y 2 duran 2 s o más.
- **20** van justo antes de una frase con carga: cifra (7), contraste (6), mencion politica (6), mencion politica+contraste (1).
- `ffmpeg silencedetect` confirma el 15%.
- Las cinco más largas: 92:20 (2.4 s, antes de «Discrepancia que tengo con la derecha y…»); 108:11 (2.1 s, antes de «si sales un poco de esta maravillosa…»); 101:42 (1.8 s, antes de «Por eso, y aquí meto la cuña…»); 23:47 (1.7 s, antes de «Accidentes, tragedias, desgracias, las sociedades desgraciadamente los…»); 72:26 (1.6 s, antes de «es renovar el gobierno y salen, creo…»).

### Voz

- 563 frases medidas. Tono (F0) medio **121 Hz** (desviación entre frases 14 Hz; variación dentro de la frase 3,64 semitonos).
- Intensidad media 64.7 dB (relativa). Velocidad media **204 palabras/min** (mediana 197).
- Cambios claros respecto a su propia media (|z| ≥ 1,5): tono sube 52 / baja 19; volumen sube 1 / baja 47; velocidad sube 39 / baja 20 (frases).
- Las tres frases con el tono más alto respecto a su media: 72:13 (z = +3.8) «No, eso fue otra historia.…»; 89:35 (z = +3.6) «Tiene que haberla, pero sobre todo pública.…»; 52:19 (z = +3.5) «Yo creo que sobre todo es…».

### Respuestas a las preguntas clasificadas

Se detectaron automáticamente 56 pares pregunta-respuesta (intervenciones del entrevistador con «?» seguidas de habla del entrevistado). La clasificación de las respuestas se hace aparte, a mano, leyendo la transcripción (`clase_respuestas.json`); aquí entran las **47** cuya cita se ha validado como literal. Distribución: **responde**: 30, **otra_pregunta**: 7, **en_parte**: 6, **sin_respuesta**: 4.

| Minuto de la respuesta | Clasificación | Cita literal de la respuesta | Pregunta |
|---|---|---|---|
| 5:33 | responde | «pues es momento de dar un paso al frente, no un paso al lado» | ¿por qué no decides dar un paso al lado, quizás vivir más tranquilo, quizás vivir más feliz y de alguna forma ceder el testigo |
| 6:10 | responde | «No, pero tú tienes mucha responsabilidad también, no solamente con tu equipo, también con tus» | Sí, pero no se puede comparar la responsabilidad de un presidente con un tío como yo |
| 6:35 | responde | «cuando las pongo en la balanza, pues evidentemente veo que hay muchas más cosas positivas» | ¿Por qué no decir, mira, ya he cumplido, yo he dado lo que he podido y ahora tranquilidad |
| 8:09 | responde | «lo siento más en algunas experiencias que han vivido mis hijas, que han estado en» | y sabes cómo van los memes. ¿Tú qué sientes, sinceramente? |
| 15:56 | otra_pregunta | «nosotros hemos multiplicado por 20 durante estos últimos ocho años, por 20 la inversión» | ¿Por qué no hay ya una dimisión o un cese? Cuando hay un accidente mortal y unos avisos de los sindicatos ferroviarios |
| 16:51 | responde | «eso ha implicado que haya habido más incidencias. Eso ha implicado también que haya habido» | las averías son algo habitual, los retrasos son algo habitual y esto no es serio |
| 19:29 | responde | «Hay una investigación abierta por, en este caso, la autoridad judicial.» | Cuando pasa el primer accidente, ¿por qué no hay claramente un responsable? |
| 19:47 | en_parte | «realmente no se sabe exactamente qué es lo que sucedió en Amuz» | ¿Cómo es posible que te apete tanto en determinar qué pasó? |
| 20:36 | otra_pregunta | «creo que ha hecho bien en tomar la decisión de dar un paso a un» | ¿crees que tendría que haber habido más responsabilidad en el primer accidente? |
| 25:35 | otra_pregunta | «me parece que lo mejor es dar la cara desde el principio, dar la cara» | ¿No tendrías que haber dicho, no es que me sorprenda, es que era algo esperable? |
| 27:17 | otra_pregunta | «Yo creo que ese debate hoy está superado.» | Si no hubiera dimitido, ¿lo hubieras cesado? |
| 27:42 | otra_pregunta | «este es un puesto en el que tienes que estar dando la cara constantemente» | es también entender cómo funciona el que quiere ser el siguiente o próximo presidente de España |
| 30:48 | responde | «Lo que se sabía era que empezaba a haber un pico de llegadas de migrantes» | cosas diferentes, CNI sí, CNI no. ¿Qué sabíais exactamente antes de que sucediera? |
| 31:54 | responde | «hubo un bulo, una lectura interesada de una sentencia del Tribunal Supremo» | no haya una forma de ver que una masa gigante de gente se está desplazando de un punto a otro? |
| 34:27 | en_parte | «Es que nosotros no recibimos ningún aviso de ningún servicio» | Si el CNI no pudo prever esto, ¿por qué no ha habido consecuencias en el CNI? ¿Por qué no ha habido responsables? |
| 34:49 | responde | «aumentamos la seguridad en frontera durante esos días, pero claro, a la escala, a la» | y también de que había unos bulos en redes sociales que estaban haciendo una concentración |
| 37:20 | en_parte | «Sí, pero vamos a ver, eso no lo sabemos todavía.» | quiere frenar eso, no podría haberlo frenado? |
| 38:23 | responde | «Porque tú al final ves y cuentas, y es lo que han hecho las fuerzas» | Este dato, ¿cómo lo sabéis? Porque yo el baile de cifras ha sido terrible. |
| 38:35 | responde | «No, hombre, las salidas no. Esa es la más fiable probablemente.» | Pero a dedo es poco fiable una información que se cuenta a dedo. |
| 43:10 | responde | «Bueno, por supuesto que tengo que hacer las cosas mejor, pero también te voy a» | ¿Tú crees que los ceutis están contentos contigo? |
| 43:22 | responde | «Pues evidentemente por esta crisis migratoria.» | Entonces, ¿por qué están enfadados contigo? |
| 43:25 | responde | «No se gestionó bien en el momento en el que se produce una crisis migratoria» | Entonces no se gestionó bien. |
| 45:20 | en_parte | «No, no, perdona, yo no me fui de vacaciones, porque un presidente del gobierno, Jordi» | Pero en ese momento, ¿cómo se debe sentir el Zotí cuando su presidente está |
| 46:56 | otra_pregunta | «Para mí el mejor momento era dar la cara como la di ese día, que» | Pero y el tema de imagen, a veces sabes que la percepción es muy importante |
| 48:35 | responde | «la capacidad que teníamos nosotros para responder a esa crisis no era necesario convocar el» | Tardaste 25 días aproximadamente en convocar el Consejo de Seguridad Nacional. En cambio, en el apagón lo convocaste inmediatamente. |
| 49:52 | responde | «Estaba con mi familia en otra residencia oficial del gobierno, pero por supuesto trabajando full» | Eras tú que habías dicho que, bueno, habías anunciado que estabas de vacaciones |
| 57:00 | responde | «No, pero es que precisamente el migrante es de la población que menos utiliza esos» | Cuando hay un crecimiento de población muy elevado en poco tiempo, evidentemente las cosas se saturan. |
| 59:00 | sin_respuesta | «nan» | En los últimos años no ha bajado. |
| 59:00 | responde | «Pero fíjate que Rumanía, que antes lo he dicho, el 40 % de Rumanía» | O sea, a veces yo escucho cosas que digo, es que no es lo que hay en la calle. |
| 66:47 | sin_respuesta | «nan» | aquí estamos viendo a veces un choque en el que no está funcionando |
| 68:41 | responde | «cuando se destaparon muchos de los audios de José Luis Ábalos, me llevé una tremenda» | Son dos personas que han sido muy cercanas. |
| 69:16 | sin_respuesta | «nan» | hay ciertas cosas que a mí me sorprende que no al menos preveyeras |
| 72:27 | responde | «es renovar el gobierno y salen, creo recordar que si no fueron cinco, fueron seis» | ¿Tú qué sabías en ese momento, en 2021? |
| 78:17 | responde | «a nivel ministerial estamos hablando de una persona, de José Luis Ábalos» | elegidos por ti, tengan este problema, ¿qué dice de |
| 80:21 | responde | «eso es algo que el Partido Socialista desconocía» | La UCO atribuye al partido 43 .225 euros que le llegaron a través de intermediarios. ¿Tú sabes algo de esto? |
| 81:02 | en_parte | «con Leire Díez no he tenido ninguna reunión como presidente del gobierno» | ¿Este caso te tiene tranquilo o te da miedo? Sabes que la UCO interpreta que a Leire Díaz se refería a ti como The One. |
| 81:27 | responde | «Bueno, a título del partido, porque a título personal es que yo no sé, esta» | ¿A título personal o a título del partido? |
| 82:19 | otra_pregunta | «Nosotros a todas las aerolíneas las rescatamos, pero fíjate, no las rescatamos a fondo perdido» | estamos hablando de un expresidente. ¿Tú pondrías la mano en el fuego por él? |
| 85:08 | responde | «pero en todo caso, siempre es insuficiente porque existe ese problema» | ha dicho que vosotros habéis hecho cero en ocho años, que no habéis mejorado en nada la situación de la vivienda en España |
| 86:37 | en_parte | «el 13 % han sido viviendas protegidas, más de 150 .000» | Son ocho años en que habéis mejorado la vivienda en España. |
| 87:10 | responde | «Hemos sentado las bases, yo creo que de una nueva política» | ¿creéis que habéis hecho suficiente como para que la situación de la vivienda en |
| 87:24 | responde | «Claro, fíjate, y además lo comparto.» | Pero la gente no quiere bases, quiere realidades, porque hoy en día se está volviendo cada vez más imposible el independizarte. |
| 87:30 | responde | «Hay una responsabilidad compartida por parte de todas las administraciones que tenemos que remar en» | tenéis una responsabilidad que son ocho años de gobierno, que se pueden hacer cosas |
| 91:57 | responde | «Pero no tantos años porque, insisto, como te he dicho antes» | Y al final, que una cosa llegue años más tarde es un problema. |
| 94:03 | sin_respuesta | «nan» | ¿Por qué no empezarlo esto hace años y hoy ya poder estar hablando? |
| 103:09 | responde | «No, claro, pero los políticos también tenemos derecho a cambiar nuestra opinión.» | me duele mucho cómo cambiáis vuestra palabra a veces tan fácilmente |
| 107:19 | responde | «yo le diría que dije que iba a subir el salario mínimo interprofesional y lo» | piensa que lo que estás prometiendo hoy en dos años puede cambiar radicalmente, ¿qué le dirías? |

Criterio de cada clase: «responde»: contesta a lo preguntado, aunque sea con matices; «otra_pregunta»: habla del tema pero contesta a una pregunta distinta de la formulada; «en_parte»: contesta una parte y deja otra sin contestar; «sin_respuesta»: el entrevistador sigue hablando o cambia sin dejar contestar. Se clasifica la respuesta inmediata. La clasificación procede de una sola lectura, sin segundo codificador que la contraste; describe si el texto de la respuesta aborda lo preguntado, no por qué.

### Pronombres explícitos

| yo | nosotros/as | tú | vosotros/as | ellos/as |
|---|---|---|---|---|
| 147 | 33 | 37 | 1 | 5 |

A quién se refiere «ellos/ellas» (columna «Referente»: lectura manual del contexto si existe `ref_ellos.json`; «sin clasificar» = no se ha leído; «incierto» = no se puede asegurar):

| Minuto | Referente | Contexto |
|---|---|---|
| 8:26 | sin clasificar | …que salir del local porque claro es una situación muy violenta para ellas tú antes dices que es un meme… |
| 65:35 | sin clasificar | …millón doscientas mil personas que ahora mismo por cierto medio millón de ellas ya está trabajando y cotizando a la… |
| 77:06 | sin clasificar | …he reconocido siempre ha sido con josé luis ábalos y con con ellos sí tenía una relación y para mí… |
| 98:00 | sin clasificar | …fui escuchando también a los líderes independentistas entendí también que parte de ellos eran conscientes de lo que había sucedido… |
| 106:31 | sin clasificar | …esa normalidad no he contado con el apoyo del partido popular que ellos en cambio sí tuvieron por cierto que… |

### Repeticiones principales

| Expresión | Veces | Primer minuto |
|---|---|---|
| a lo mejor | 8 | 1:54 |
| gobierno de españa | 8 | 6:59 |
| eso no significa | 6 | 13:04 |
| en nuestro país | 8 | 13:41 |
| ahora mismo | 14 | 13:47 |
| en este caso | 7 | 19:31 |
| desde el punto | 11 | 19:41 |
| el punto de vista | 11 | 19:42 |
| a mi juicio | 6 | 20:48 |
| momento en el que | 7 | 21:17 |
| lo que tenemos | 7 | 21:39 |
| tenemos que hacer es | 6 | 21:40 |
| dar la cara | 6 | 25:37 |
| presidente del gobierno | 9 | 30:07 |
| de la migración | 7 | 53:03 |
| josé luis | 11 | 68:44 |
| josé luis ábalos | 7 | 68:44 |
| con josé luis | 6 | 77:04 |
| vivienda protegida | 10 | 86:28 |
| de la vivienda | 6 | 86:33 |

La lista es automática y puede mezclar muletillas con términos del tema.

### Otras técnicas detectadas en el texto (candidatas)

**Contrastes «no X, sino Y»: 18** (primeros 5)

- 4:43 «Y por tanto, eso hizo que no solamente tuviera padres jóvenes, sino también»
- 4:58 «Y a mí eso me abrió una herida, no lo digo en términos negativos, sino en términos positivos, una herida de compromiso con la justicia social.»
- 6:10 «No, pero tú tienes mucha responsabilidad también, no solamente con tu equipo, también con tus oyentes.»
- 15:16 «La primera, hemos tenido que revertir la infradotación que había presupuestaria en la anterior administración, oye, que podía haber sido, ya no digo por compromiso político, sino también por carestía »
- 18:43 «Por ejemplo, si cae un sistema operativo, como fue el caso de este último accidente, pues la decisión humana, que para mí tiene que ser la última, no la máquina, sino el»

**Léxico de pérdida o riesgo: 7** (primeros 5)

- 8:40 «El mensaje es la motosierra, son los recortes,»
- 15:28 «Hoy, 15 años hemos tardado en revertir esos recortes, en lo que es la inversión»
- 29:40 «No solamente eso, sino que al final corremos el riesgo de banalizar noticias que realmente son importantes y equipararlas con noticias que nada tienen que ver en importancia con las primeras.»
- 64:03 «El debate sobre la seguridad no me da ningún miedo.»
- 82:06 «Ahí articulamos un fondo para rescatar a empresas que, siendo competitivas, productivas, pues desgraciadamente con la pandemia, pues corrían el riesgo de cerrar.»

**Léxico de logro o ganancia: 15** (primeros 5)

- 17:01 «Pero te diré, también lo que hemos hecho con esto ha sido aumentar exponencialmente el uso por parte de los ciudadanos de la alta»
- 22:03 «Al contrario, todas las políticas que se pusieron en marcha durante estos últimos años de inversión, de mantenimiento, de mejora laboral, en este caso de los trabajadores de Adif y de Renfe, ha sido b»
- 24:42 «Ahora bien, sí que es cierto que lo que tenemos que hacer es mejorar la capacidad que tienen los controladores para evitar al mínimo posible los»
- 28:24 «Y bueno, cuando no lo cumplimos, pues desde luego hago un examen de conciencia y una autoevaluación de las cosas que hemos hecho mal.»
- 46:56 «Para mí el mejor momento era dar la cara como la di ese día, que yo fui a Ceuta, le dije a los ceutíes no estéis solos, el gobierno de España está con vosotros y dijo una cosa muy importante, para mí »

**Listas de tres: 0**


Preguntas seguidas por el mismo hablante (candidatas a retóricas): 20; relatos o personas concretas candidatos: 14 (en `retorica.csv`). Detecciones automáticas **no revisadas una a una**.

### Cara (unidades de acción)

- Su cara se detecta en 21798 de ~33215 fotogramas muestreados a 5 fps (**66%**).
- Valores medios (0–1, sin calibrar a la escala A–E de FACS): AU1 cejas: parte interna arriba 0,51; AU2 cejas: parte externa arriba 0,28; AU4 cejas bajan y se juntan 0,37; AU5 párpado superior arriba 0,34; AU6 mejillas elevadas 0,15; AU7 párpados tensos 0,05; AU12 comisura labios arriba 0,14; AU14 hoyuelo comisura 0,37; AU15 comisura labios abajo 0,34; AU17 mentón arriba 0,50; AU23 labios apretados 0,54; AU24 labios presionados 0,55.
- Máximo de AU12 (comisura de los labios arriba) en la media de 30 s hacia el **1:46** (0,33 frente a una media global de 0,14); AU6 (mejillas elevadas) en ese punto: 0,26 (media 0,15). No se interpreta.
- Cabeza girada de media 46° respecto a la cámara (giro medio +46°), lo que afecta a la fiabilidad de todas las AU.

### Momentos clave del entrevistado

Criterio: se recorre la entrevista en ventanas de ±3 s en las que esa persona está hablando y se cuenta en cuántas **categorías distintas** coinciden señales: voz (cambio de tono, volumen o velocidad con |z| ≥ 1,5 respecto a su propia media; cuentan como una sola categoría), pausa (de 1 s o más, o antes de una frase con carga), pregunta (una respuesta clasificada de la tabla anterior), técnica retórica y AU (alguna AU con |z| ≥ 2 frente a su propia línea base, en ventanas de 6 s). Se toman los que más categorías reúnen (al menos dos), separados al menos 60 s: hasta 15 para el entrevistado y hasta 10 para el entrevistador. **Que dos señales coincidan no demuestra que estén relacionadas**, y de un momento así no se deduce ninguna intención ni estado interno: se listan para poder ir a verlos.

#### Entrevistado · momento 1 · minuto 4:19 · categorías: voz, pausa, AU

- **Cita literal:** «años. A mí me encantaba el baloncesto, el deporte. Pero me di cuenta de que mis abuelos, que era gente sabia, no»
- **Qué se mide:** pausa larga: 1.4 s; pausa antes de frase con carga: contraste; cambio tono: baja (z=-1.9); cambio volumen: baja (z=-4.4); AU fuera de lo habitual: AU15 comisura labios abajo z=+2.1.
- **Material:** `fotogramas/m01_antes.jpg`, `fotogramas/m01_durante.jpg`, `fotogramas/m01_despues.jpg`; clip con detección facial `clips_cara/m01_4-19.mp4`.

![antes](fotogramas/m01_antes.jpg) ![durante](fotogramas/m01_durante.jpg) ![después](fotogramas/m01_despues.jpg)

#### Entrevistado · momento 2 · minuto 22:01 · categorías: voz, pausa, retorica

- **Cita literal:** «Bueno, puedes decir por omisión, como hizo por ejemplo Mazón. No, no creo que fue el caso con Oscar Puente. Al contrario, todas las políticas que se pusieron en marcha durante estos»
- **Qué se mide:** pausa antes de frase con carga: mencion politica; cambio velocidad: sube (z=+1.7); tecnica retorica: encuadre ganancia.
- **Material:** `fotogramas/m02_antes.jpg`, `fotogramas/m02_durante.jpg`, `fotogramas/m02_despues.jpg`; clip con detección facial `clips_cara/m02_22-01.mp4`.

![antes](fotogramas/m02_antes.jpg) ![durante](fotogramas/m02_durante.jpg) ![después](fotogramas/m02_despues.jpg)

#### Entrevistado · momento 3 · minuto 27:19 · categorías: voz, pregunta, AU

- **Cita literal:** «Yo creo que ese debate hoy está superado.»
- **Qué se mide:** cambio velocidad: baja (z=-1.9); pregunta con respuesta clasificada: otra pregunta; AU fuera de lo habitual: AU23 labios apretados z=+2.3.
- **Material:** `fotogramas/m03_antes.jpg`, `fotogramas/m03_durante.jpg`, `fotogramas/m03_despues.jpg`; clip con detección facial `clips_cara/m03_27-19.mp4`.

![antes](fotogramas/m03_antes.jpg) ![durante](fotogramas/m03_durante.jpg) ![después](fotogramas/m03_despues.jpg)

#### Entrevistado · momento 4 · minuto 31:01 · categorías: voz, pregunta, AU

- **Cita literal:** «30 y el 31 de julio. Estamos hablando a lo mejor de llegadas de 1 .000, 1 .200 migrantes, pero no en absoluto los más de 80 .000 que el»
- **Qué se mide:** cambio tono: baja (z=-2.0); pregunta con respuesta clasificada: responde; AU fuera de lo habitual: AU15 comisura labios abajo z=+2.2.
- **Material:** `fotogramas/m04_antes.jpg`, `fotogramas/m04_durante.jpg`, `fotogramas/m04_despues.jpg`; clip con detección facial `clips_cara/m04_31-01.mp4`.

![antes](fotogramas/m04_antes.jpg) ![durante](fotogramas/m04_durante.jpg) ![después](fotogramas/m04_despues.jpg)

#### Entrevistado · momento 5 · minuto 33:31 · categorías: voz, pausa, AU

- **Cita literal:** «Cuando se produce la avalancha, Jordi, el dilema es el siguiente. El dilema es, ¿la gente que está llegando son sobre»
- **Qué se mide:** pausa larga: 1.0 s; cambio tono: sube (z=+1.7); cambio volumen: baja (z=-3.4); AU fuera de lo habitual: AU23 labios apretados z=-2.4.
- **Material:** `fotogramas/m05_antes.jpg`, `fotogramas/m05_durante.jpg`, `fotogramas/m05_despues.jpg`; clip con detección facial `clips_cara/m05_33-31.mp4`.

![antes](fotogramas/m05_antes.jpg) ![durante](fotogramas/m05_durante.jpg) ![después](fotogramas/m05_despues.jpg)

#### Entrevistado · momento 6 · minuto 45:18 · categorías: voz, pregunta, AU

- **Cita literal:** «caso, el día siguiente, estaba No, no, perdona, yo no me fui de vacaciones, porque un presidente del gobierno, Jordi, ya te digo, un»
- **Qué se mide:** cambio volumen: baja (z=-2.0); pregunta con respuesta clasificada: en parte; AU fuera de lo habitual: AU17 mentón arriba z=+2.4.
- **Material:** `fotogramas/m06_antes.jpg`, `fotogramas/m06_durante.jpg`, `fotogramas/m06_despues.jpg`; clip con detección facial `clips_cara/m06_45-18.mp4`.

![antes](fotogramas/m06_antes.jpg) ![durante](fotogramas/m06_durante.jpg) ![después](fotogramas/m06_despues.jpg)

#### Entrevistado · momento 7 · minuto 52:20 · categorías: voz, pausa, AU

- **Cita literal:** «Yo creo que sobre todo es el desafío de la integración. O sea, yo creo que la ciudadanía»
- **Qué se mide:** pausa larga: 1.1 s; cambio tono: sube (z=+3.5); cambio volumen: baja (z=-2.2); cambio velocidad: sube (z=+1.9); AU fuera de lo habitual: AU7 párpados tensos z=+3.1; AU17 mentón arriba z=-2.5; AU4 cejas bajan y se juntan z=+2.3.
- **Material:** `fotogramas/m07_antes.jpg`, `fotogramas/m07_durante.jpg`, `fotogramas/m07_despues.jpg`; clip con detección facial `clips_cara/m07_52-20.mp4`.

![antes](fotogramas/m07_antes.jpg) ![durante](fotogramas/m07_durante.jpg) ![después](fotogramas/m07_despues.jpg)

#### Entrevistado · momento 8 · minuto 61:49 · categorías: voz, retorica, AU

- **Cita literal:** «de natalidad. Oye, nosotros lo que hemos hecho ha sido pasar de cinco semanas los permisos de paternidad y maternidad, equipararlos. Cuando seas padre, Jordi,»
- **Qué se mide:** cambio volumen: baja (z=-2.0); tecnica retorica: encuadre ganancia; AU fuera de lo habitual: AU23 labios apretados z=-2.5; AU15 comisura labios abajo z=-2.4; AU12 comisura labios arriba z=+2.4.
- **Material:** `fotogramas/m08_antes.jpg`, `fotogramas/m08_durante.jpg`, `fotogramas/m08_despues.jpg`; clip con detección facial `clips_cara/m08_61-49.mp4`.

![antes](fotogramas/m08_antes.jpg) ![durante](fotogramas/m08_durante.jpg) ![después](fotogramas/m08_despues.jpg)

#### Entrevistado · momento 9 · minuto 65:31 · categorías: voz, pausa, AU

- **Cita literal:** «No, pero un millón doscientas mil personas que ahora mismo, por cierto, medio millón de ellas ya está trabajando y cotizando»
- **Qué se mide:** pausa antes de frase con carga: cifra; cambio velocidad: sube (z=+1.5); AU fuera de lo habitual: AU7 párpados tensos z=+3.1; AU6 mejillas elevadas z=+2.1.
- **Material:** `fotogramas/m09_antes.jpg`, `fotogramas/m09_durante.jpg`, `fotogramas/m09_despues.jpg`; clip con detección facial `clips_cara/m09_65-31.mp4`.

![antes](fotogramas/m09_antes.jpg) ![durante](fotogramas/m09_durante.jpg) ![después](fotogramas/m09_despues.jpg)

#### Entrevistado · momento 10 · minuto 80:19 · categorías: voz, pausa, pregunta

- **Cita literal:** «Que esos despachos de abogados contrataran a ley de día, eso es algo que el Partido Socialista desconocía.»
- **Qué se mide:** pausa larga: 1.2 s; cambio volumen: baja (z=-1.5); pregunta con respuesta clasificada: responde.
- **Material:** `fotogramas/m10_antes.jpg`, `fotogramas/m10_durante.jpg`, `fotogramas/m10_despues.jpg`; clip con detección facial `clips_cara/m10_80-19.mp4`.

![antes](fotogramas/m10_antes.jpg) ![durante](fotogramas/m10_durante.jpg) ![después](fotogramas/m10_despues.jpg)

#### Entrevistado · momento 11 · minuto 88:09 · categorías: voz, pausa, AU

- **Cita literal:** «crisis financiera del año 2011. Hemos multiplicado por 8 el presupuesto en vivienda. Hemos repartido a las comunidades autónomas más de 7 .000 millones de»
- **Qué se mide:** pausa antes de frase con carga: cifra; cambio tono: sube (z=+1.8); AU fuera de lo habitual: AU7 párpados tensos z=+3.5; AU2 cejas: parte externa arriba z=+2.6; AU5 párpado superior arriba z=+2.3.
- **Material:** `fotogramas/m11_antes.jpg`, `fotogramas/m11_durante.jpg`, `fotogramas/m11_despues.jpg`; clip con detección facial `clips_cara/m11_88-09.mp4`.

![antes](fotogramas/m11_antes.jpg) ![durante](fotogramas/m11_durante.jpg) ![después](fotogramas/m11_despues.jpg)

#### Entrevistado · momento 12 · minuto 93:47 · categorías: voz, retorica, AU

- **Cita literal:** «y, en segundo lugar, porque hubo muy poca vivienda protegida. Por tanto, lo que tenemos también en nuestro país es que mirar, por ejemplo, a grandes países»
- **Qué se mide:** cambio tono: sube (z=+1.5); tecnica retorica: contraste no X sino Y; AU fuera de lo habitual: AU2 cejas: parte externa arriba z=+2.6; AU1 cejas: parte interna arriba z=+2.1.
- **Material:** `fotogramas/m12_antes.jpg`, `fotogramas/m12_durante.jpg`, `fotogramas/m12_despues.jpg`; clip con detección facial `clips_cara/m12_93-47.mp4`.

![antes](fotogramas/m12_antes.jpg) ![durante](fotogramas/m12_durante.jpg) ![después](fotogramas/m12_despues.jpg)

#### Entrevistado · momento 13 · minuto 97:44 · categorías: voz, retorica, AU

- **Cita literal:** «gente de Cataluña, profesionales, clase media. Yo vi que había un problema serio de convivencia»
- **Qué se mide:** cambio velocidad: baja (z=-1.8); tecnica retorica: encuadre perdida; AU fuera de lo habitual: AU12 comisura labios arriba z=+2.0.
- **Material:** `fotogramas/m13_antes.jpg`, `fotogramas/m13_durante.jpg`, `fotogramas/m13_despues.jpg`; clip con detección facial `clips_cara/m13_97-44.mp4`.

![antes](fotogramas/m13_antes.jpg) ![durante](fotogramas/m13_durante.jpg) ![después](fotogramas/m13_despues.jpg)

#### Entrevistado · momento 14 · minuto 103:29 · categorías: voz, pausa, retorica

- **Cita literal:** «Partido de los Socialistas Catalanes, no solamente a nivel de Cataluña, sino de muchos municipios, se ha visto respaldado probablemente por sus aciertos, pero también por un gobierno»
- **Qué se mide:** pausa antes de frase con carga: contraste; cambio tono: sube (z=+1.6); cambio velocidad: sube (z=+1.7); tecnica retorica: contraste no X sino Y.
- **Material:** `fotogramas/m14_antes.jpg`, `fotogramas/m14_durante.jpg`, `fotogramas/m14_despues.jpg`; clip con detección facial `clips_cara/m14_103-29.mp4`.

![antes](fotogramas/m14_antes.jpg) ![durante](fotogramas/m14_durante.jpg) ![después](fotogramas/m14_despues.jpg)

#### Entrevistado · momento 15 · minuto 107:18 · categorías: voz, pregunta, retorica, AU

- **Cita literal:** «Pues yo le diría que dije que iba a subir el salario mínimo interprofesional y lo he subido. Dije que iba a apostar por la educación»
- **Qué se mide:** cambio velocidad: sube (z=+2.2); pregunta con respuesta clasificada: responde; tecnica retorica: encuadre ganancia; AU fuera de lo habitual: AU5 párpado superior arriba z=+5.9.
- **Material:** `fotogramas/m15_antes.jpg`, `fotogramas/m15_durante.jpg`, `fotogramas/m15_despues.jpg`; clip con detección facial `clips_cara/m15_107-18.mp4`.

![antes](fotogramas/m15_antes.jpg) ![durante](fotogramas/m15_durante.jpg) ![después](fotogramas/m15_despues.jpg)

## 4. El entrevistador, por separado

### Pausas

- **51** huecos de más de 0,4 s entre palabras verificadas consecutivas. Duración media **0,88 s**, mediana 0,76 s, máxima 2.3 s. 13 duran 1 s o más y 1 duran 2 s o más.
- **7** van justo antes de una frase con carga: contraste (4), promesa (2), cifra (1).
- `ffmpeg silencedetect` confirma el 8%.
- Las cinco más largas: 14:34 (2.3 s, antes de «Vamos primero a Damuz, cuando sucede, en…»); 107:11 (1.8 s, antes de «Para la gente que no confía en…»); 52:11 (1.8 s, antes de «¿Por qué crees que a la gente…»); 16:09 (1.6 s, antes de «Digamos, ¿qué es mejor ahora que hace…»); 30:30 (1.6 s, antes de «Vamos a empezar con los inicios, avisos,…»).

### Voz

- 393 frases medidas. Tono (F0) medio **123 Hz** (desviación entre frases 14 Hz; variación dentro de la frase 3,40 semitonos).
- Intensidad media 67.0 dB (relativa). Velocidad media **227 palabras/min** (mediana 223).
- Cambios claros respecto a su propia media (|z| ≥ 1,5): tono sube 29 / baja 17; volumen sube 3 / baja 33; velocidad sube 32 / baja 23 (frases).
- Las tres frases con el tono más alto respecto a su media: 3:38 (z = +3.4) «Vamos a empezar, a ver, lo primero que te quiero preguntar Es algo personal,…»; 95:25 (z = +3.0) «Este buguear a mi cerebro está buscando...…»; 85:29 (z = +2.8) «No, no, no, sí, yo no lo……».

### Preguntas

- 59 frases interrogativas verificadas; 56 intervenciones con pregunta seguidas de respuesta del entrevistado; **47** preguntas cuya respuesta está clasificada en la tabla de la sección 3.

### Pronombres explícitos

| yo | nosotros/as | tú | vosotros/as | ellos/as |
|---|---|---|---|---|
| 63 | 2 | 38 | 3 | 6 |

A quién se refiere «ellos/ellas» (columna «Referente»: lectura manual del contexto si existe `ref_ellos.json`; «sin clasificar» = no se ha leído; «incierto» = no se puede asegurar):

| Minuto | Referente | Contexto |
|---|---|---|
| 50:36 | sin clasificar | …la que ceuta estuvo en un estado lamentable es bastante inaceptable por ellos y por un país del primer mundo… |
| 57:41 | sin clasificar | …familias marroquíes yo tengo muchos amigos que son de marruecos pero incluso ellos lo que está pasando en los últimos… |
| 68:15 | sin clasificar | …es como lo sí no nadie es un angelito pero dos de ellos han formado parte del círculo y de… |
| 70:59 | sin clasificar | …muy feminista abiertamente feminista de verdad que me cuesta no pensar que ellos hicieron ese tipo de comentarios no si… |
| 90:21 | sin clasificar | …a día de hoy cuántas están entregadas y con gente viviendo en ellas pero es que es tan diferente en… |
| 95:16 | sin clasificar | …yo estoy entre dos tierras como la canción de héroes del silencio ellos me están diciendo diez minutos este buguear… |

### Repeticiones principales

| Expresión | Veces | Primer minuto |
|---|---|---|
| a dos verificadores | 3 | 0:25 |
| ocho años | 8 | 1:44 |
| porque al final | 11 | 2:30 |
| a lo mejor | 5 | 2:54 |
| no tan solo | 4 | 3:25 |
| lo que pasa | 4 | 3:44 |
| es un tema | 8 | 4:02 |
| a la gente | 4 | 7:18 |
| de pedro sánchez | 3 | 7:39 |
| mucha gente | 11 | 8:02 |
| que al final | 5 | 10:33 |
| es una cosa | 4 | 14:14 |
| en ese momento | 3 | 14:38 |
| que a veces | 4 | 24:01 |
| crisis de ceuta | 3 | 30:23 |
| para la gente | 4 | 31:09 |
| en los últimos | 3 | 54:45 |
| hay un choque | 5 | 55:22 |
| en muchos casos | 3 | 57:11 |
| situación de la vivienda | 3 | 85:04 |

La lista es automática y puede mezclar muletillas con términos del tema.

### Otras técnicas detectadas en el texto (candidatas)

**Contrastes «no X, sino Y»: 2**

- 3:18 «Verificadores Tenemos hoy a dos verificadores Bueno, hoy no, en las cuatro entrevistas A dos verificadores, Iván Muñoz, Javier Collado Que van a estar, no tan solo Por si tú dices alguna cosa que no e»
- 79:11 «En fin, con tintes ya no tan solo económicos, sino también morales para ti,»

**Léxico de pérdida o riesgo: 4**

- 57:49 «Inseguridad, desconfianza, extrañeza.»
- 60:59 «Es decir, ¿a ti eso te lleva a una pérdida de identidad cultural, nacional, etcétera?»
- 63:53 «Creo que tenemos que enfrentar este debate, porque yo he visto desde la izquierda que ha dado mucho miedo este debate, porque te tildaban rápidamente de racista.»
- 80:38 «¿Este caso te tiene tranquilo o te da miedo?»

**Léxico de logro o ganancia: 1**

- 103:36 «Es importante a veces mantener la palabra siendo político que conseguir un objetivo, porque a lo mejor esto lo podrías haber dicho de entrada, oye, pues si yo llego al poder voy a hacer»

**Listas de tres: 2**

- 10:14 «después, un ministro, y hablaremos»
- 49:59 «como, coño, y los políticos»

Preguntas seguidas por el mismo hablante (candidatas a retóricas): 31; relatos o personas concretas candidatos: 2 (en `retorica.csv`). Detecciones automáticas **no revisadas una a una**.

### Cara (unidades de acción)

- Su cara se detecta en 14116 de ~33215 fotogramas muestreados a 5 fps (**42%**).
- Valores medios (0–1, sin calibrar a la escala A–E de FACS): AU1 cejas: parte interna arriba 0,45; AU2 cejas: parte externa arriba 0,27; AU4 cejas bajan y se juntan 0,43; AU5 párpado superior arriba 0,35; AU6 mejillas elevadas 0,16; AU7 párpados tensos 0,06; AU12 comisura labios arriba 0,09; AU14 hoyuelo comisura 0,39; AU15 comisura labios abajo 0,55; AU17 mentón arriba 0,34; AU23 labios apretados 0,64; AU24 labios presionados 0,48.
- Máximo de AU12 (comisura de los labios arriba) en la media de 30 s hacia el **111:15** (0,31 frente a una media global de 0,09); AU6 (mejillas elevadas) en ese punto: 0,31 (media 0,16). No se interpreta.
- Cabeza girada de media 41° respecto a la cámara (giro medio -41°), lo que afecta a la fiabilidad de todas las AU.

### Momentos clave del entrevistador

Mismo criterio. En el entrevistador, la categoría «pregunta» indica que en ese momento formula una de las preguntas cuya respuesta está clasificada.

#### Entrevistador · momento 1 · minuto 1:29 · categorías: voz, pausa, AU

- **Cita literal:** «personas importantes pero hombre, pero no son históricas pero hoy sí hoy en The Wild Project tengo a alguien»
- **Qué se mide:** pausa larga: 1.2 s; cambio tono: sube (z=+2.1); cambio volumen: baja (z=-3.3); cambio velocidad: baja (z=-1.8); AU fuera de lo habitual: AU7 párpados tensos z=+3.0; AU17 mentón arriba z=+2.7; AU6 mejillas elevadas z=+2.2.
- **Material:** `fotogramas/e01_antes.jpg`, `fotogramas/e01_durante.jpg`, `fotogramas/e01_despues.jpg`; clip con detección facial `clips_cara/e01_1-29.mp4`.

![antes](fotogramas/e01_antes.jpg) ![durante](fotogramas/e01_durante.jpg) ![después](fotogramas/e01_despues.jpg)

#### Entrevistador · momento 2 · minuto 4:00 · categorías: voz, pregunta, AU

- **Cita literal:** «alguna forma ceder el testigo ¿Es un tema de servicio?»
- **Qué se mide:** cambio volumen: baja (z=-3.3); pregunta con respuesta clasificada: formula la pregunta; AU fuera de lo habitual: AU5 párpado superior arriba z=+2.2.
- **Material:** `fotogramas/e02_antes.jpg`, `fotogramas/e02_durante.jpg`, `fotogramas/e02_despues.jpg`; clip con detección facial `clips_cara/e02_4-00.mp4`.

![antes](fotogramas/e02_antes.jpg) ![durante](fotogramas/e02_durante.jpg) ![después](fotogramas/e02_despues.jpg)

#### Entrevistador · momento 3 · minuto 8:04 · categorías: voz, pregunta, AU

- **Cita literal:** «mucha gente que, sinceramente, esa política los canta, pues ya es para un poco ¿Tú qué sientes, sinceramente?»
- **Qué se mide:** cambio volumen: baja (z=-2.6); pregunta con respuesta clasificada: formula la pregunta; AU fuera de lo habitual: AU5 párpado superior arriba z=+4.0; AU2 cejas: parte externa arriba z=+2.6.
- **Material:** `fotogramas/e03_antes.jpg`, `fotogramas/e03_durante.jpg`, `fotogramas/e03_despues.jpg`; clip con detección facial `clips_cara/e03_8-04.mp4`.

![antes](fotogramas/e03_antes.jpg) ![durante](fotogramas/e03_durante.jpg) ![después](fotogramas/e03_despues.jpg)

#### Entrevistador · momento 4 · minuto 14:34 · categorías: voz, pausa, pregunta

- **Cita literal:** «realidad. Hablemos de los accidentes que han sucedido. Vamos primero a Damuz, cuando sucede, en ese momento,»
- **Qué se mide:** pausa larga: 2.3 s; cambio tono: baja (z=-1.9); cambio volumen: baja (z=-3.9); cambio velocidad: baja (z=-1.6); pregunta con respuesta clasificada: formula la pregunta.
- **Material:** `fotogramas/e04_antes.jpg`, `fotogramas/e04_durante.jpg`, `fotogramas/e04_despues.jpg`; clip con detección facial `clips_cara/e04_14-34.mp4`.

![antes](fotogramas/e04_antes.jpg) ![durante](fotogramas/e04_durante.jpg) ![después](fotogramas/e04_despues.jpg)

#### Entrevistador · momento 5 · minuto 19:25 · categorías: voz, pregunta, AU

- **Cita literal:** «pasa el primer accidente, ¿por qué no hay claramente un responsable?»
- **Qué se mide:** cambio volumen: baja (z=-2.2); cambio velocidad: sube (z=+1.9); pregunta con respuesta clasificada: formula la pregunta; AU fuera de lo habitual: AU15 comisura labios abajo z=-2.3.
- **Material:** `fotogramas/e05_antes.jpg`, `fotogramas/e05_durante.jpg`, `fotogramas/e05_despues.jpg`; clip con detección facial `clips_cara/e05_19-25.mp4`.

![antes](fotogramas/e05_antes.jpg) ![durante](fotogramas/e05_durante.jpg) ![después](fotogramas/e05_despues.jpg)

#### Entrevistador · momento 6 · minuto 30:31 · categorías: voz, pausa, AU

- **Cita literal:** «la tiene reciente. Vamos a empezar con los inicios, avisos, porque aquí hay un lío impresionante.»
- **Qué se mide:** pausa larga: 1.6 s; pausa antes de frase con carga: promesa; cambio tono: baja (z=-1.5); AU fuera de lo habitual: AU1 cejas: parte interna arriba z=-2.6.
- **Material:** `fotogramas/e06_antes.jpg`, `fotogramas/e06_durante.jpg`, `fotogramas/e06_despues.jpg`; clip con detección facial `clips_cara/e06_30-31.mp4`.

![antes](fotogramas/e06_antes.jpg) ![durante](fotogramas/e06_durante.jpg) ![después](fotogramas/e06_despues.jpg)

#### Entrevistador · momento 7 · minuto 68:13 · categorías: voz, pausa, AU

- **Cita literal:** «Sí, no, nadie es un angelito. Pero dos de ellos han formado parte del círculo. Y de»
- **Qué se mide:** pausa larga: 1.5 s; pausa antes de frase con carga: contraste; cambio volumen: baja (z=-1.7); AU fuera de lo habitual: AU5 párpado superior arriba z=+3.0; AU1 cejas: parte interna arriba z=+3.0; AU2 cejas: parte externa arriba z=+2.7.
- **Material:** `fotogramas/e07_antes.jpg`, `fotogramas/e07_durante.jpg`, `fotogramas/e07_despues.jpg`; clip con detección facial `clips_cara/e07_68-13.mp4`.

![antes](fotogramas/e07_antes.jpg) ![durante](fotogramas/e07_durante.jpg) ![después](fotogramas/e07_despues.jpg)

#### Entrevistador · momento 8 · minuto 78:01 · categorías: voz, pregunta, AU

- **Cita literal:** «elegidos por ti, tengan este problema, ¿qué dice de»
- **Qué se mide:** cambio volumen: baja (z=-4.0); pregunta con respuesta clasificada: formula la pregunta; AU fuera de lo habitual: AU24 labios presionados z=+2.4.
- **Material:** `fotogramas/e08_antes.jpg`, `fotogramas/e08_durante.jpg`, `fotogramas/e08_despues.jpg`; clip con detección facial `clips_cara/e08_78-01.mp4`.

![antes](fotogramas/e08_antes.jpg) ![durante](fotogramas/e08_durante.jpg) ![después](fotogramas/e08_despues.jpg)

#### Entrevistador · momento 9 · minuto 80:04 · categorías: voz, pausa, pregunta

- **Cita literal:** «que le llegaron a través de intermediarios. ¿Tú sabes algo de esto? ¿Sabes algo de qué trabajo pudo realizar»
- **Qué se mide:** pausa larga: 1.1 s; cambio tono: baja (z=-1.6); cambio volumen: baja (z=-3.8); pregunta con respuesta clasificada: formula la pregunta.
- **Material:** `fotogramas/e09_antes.jpg`, `fotogramas/e09_durante.jpg`, `fotogramas/e09_despues.jpg`; clip con detección facial `clips_cara/e09_80-04.mp4`.

![antes](fotogramas/e09_antes.jpg) ![durante](fotogramas/e09_durante.jpg) ![después](fotogramas/e09_despues.jpg)

#### Entrevistador · momento 10 · minuto 102:00 · categorías: voz, pregunta, AU

- **Cita literal:** «lo que pasa con todo esto? Yo no digo que no tenga razón en muchos de estos temas y no va por ahí el tema. Pero ayer lo hablaba con Colau también, que»
- **Qué se mide:** cambio velocidad: sube (z=+2.8); pregunta con respuesta clasificada: formula la pregunta; AU fuera de lo habitual: AU1 cejas: parte interna arriba z=-2.1.
- **Material:** `fotogramas/e10_antes.jpg`, `fotogramas/e10_durante.jpg`, `fotogramas/e10_despues.jpg`; clip con detección facial `clips_cara/e10_102-00.mp4`.

![antes](fotogramas/e10_antes.jpg) ![durante](fotogramas/e10_durante.jpg) ![después](fotogramas/e10_despues.jpg)

## 5. Limitaciones

**Emociones.** Las secciones de este documento no usan modelos de emociones: en la extracción de AU el de py-feat está sustituido por una función que devuelve NaN (`scripts/face_detector.py`). Si se ejecutan aparte clasificadores de expresión o de emoción en la voz, sus resultados y sus límites van en sus propios anexos.

**Qué no mide.** Pausas, cambios de voz, unidades de acción y postura son conductas observables. No existe base para leerlas como señales de sinceridad o de engaño, y este informe no lo hace. No se mide la mirada, y el parpadeo no se analiza.

**Comparación entre personas.** Las AU de py-feat no están calibradas por persona: la forma de la cara, el vello facial, las gafas, el ángulo de cámara y la iluminación cambian el valor base. La comparación de niveles absolutos de AU entre entrevistado y entrevistador es, por eso, la parte más débil del informe; las comparaciones dentro de cada persona (hablar frente a escuchar, desviaciones frente a su propia línea base) son más fiables. En la voz, el tono medio refleja sobre todo la voz de cada uno, y la intensidad depende del micrófono y de la mezcla.

**Transcripción.** Whisper `large-v3` comete errores, sobre todo en nombres propios y en el habla solapada. Las cifras escritas con dígitos las genera el modelo. No se ha revisado la transcripción completa a mano.

**Separación de hablantes.** pyannote 3.1 separó 3 voces en todo el vídeo; las dos con más tiempo suman el 99% del habla detectada. La asignación de papeles se decidió para este vídeo y está en `hablantes.json`. Una verificación por huella de voz (wespeaker) comprobó cada tramo de 1 s o más: se verificó el 84% de las palabras; el 86% de las del entrevistado (10840 de 12566) y el 81% de las del entrevistador (6469 de 8032). **Solo las palabras verificadas se usan** en pausas, voz, retórica y cara. Las frases cortas dichas encima de la otra persona tienden a quedar sin verificar, de modo que las réplicas breves y las interrupciones de ambos están infrarrepresentadas. Tramos limpios usados como huella de referencia: entrevistado 110, entrevistador 32.

**Pausas.** Se miden entre palabras consecutivas verificadas de la misma persona; los huecos pueden contener voz de la otra persona, risas, música o habla no transcrita. `silencedetect` confirma el 15% de las del entrevistado y el 8% de las del entrevistador.

**Voz.** F0 e intensidad se miden con Praat sobre el audio publicado (mezcla y compresión incluidas). Los cambios se definen respecto a la media de cada persona en este vídeo. Tono, volumen y velocidad están correlacionados entre sí.

**Cara.** py-feat (RetinaFace + modelo de AU) es un modelo estadístico: sus intensidades no son una codificación FACS manual. El giro de la cabeza, el habla y los cambios de plano alteran las AU sin que cambie el gesto. Con media de 0,40 o más en las dos personas (valor base alto, poco margen para subir): AU1, AU23, AU24. Muestreo a 5 fps. La realización decide a quién se ve: hay 21798 fotogramas con la cara del entrevistado y 14116 con la del entrevistador.

**Identidad de la cara.** Las caras se agruparon por similitud (k-means, 10 grupos): 5 grupos se asignaron al entrevistado, 3 al entrevistador y 2 se descartaron. El script propone la asignación por el acoplamiento entre el movimiento de la boca y el habla verificada de cada uno; en esta entrevista la asignación final se fijó a mano en `hablantes.json` (`grupos_cara`). Nota del analista: «Grupos asignados tras revisar tmp/montaje_grupos.jpg y la coincidencia con quién habla en cada plano. Se descartan el grupo 4 (otras personas e imágenes de archivo) y el 7 (mezcla con una figura del decorado). Los grupos 1 y 6 incluyen algún recorte suelto de la otra persona.» No se usó reconocimiento facial contra ninguna base de datos. Solo entran caras detectadas con confianza alta y de 50 px de ancho o más, y puede haber fotogramas mal asignados.

**Retórica y preguntas.** Los patrones son expresiones regulares (listas en `scripts/08_retorica.py`): no son exhaustivos y tienen falsos positivos, por ejemplo un verbo de la lista de «pérdida» usado en otro sentido. Las preguntas formuladas como afirmación, sin «?», no se detectan automáticamente. La clasificación de las respuestas procede de una sola lectura; al ser el contenido político, otra persona podría clasificar distinto algunos casos.

**Momentos clave.** Umbrales fijados por el analista (±3 s, |z| ≥ 1,5 en voz, |z| ≥ 2 en AU). Con 25 momentos y varias señales posibles, alguna coincidencia será casual.

**Alcance.** Es una sola entrevista de unos 112 minutos. Nada de lo medido permite concluir sobre intenciones, estados internos, sinceridad o rasgos de ninguna de las dos personas; solo describe conductas observables y cuándo ocurren.

## 6. Archivos

Presentes en la carpeta al generar este informe: `informe.md`, `informe_tonalidad.md`, `informe_expresiones.md`, `informe_movimiento.md`, `verificacion_datos.md`, `verificacion_datos.csv`, `comparativa.csv`, `pausas_entrevistado.csv`, `pausas_entrevistador.csv`, `voz_entrevistado.csv`, `voz_entrevistador.csv`, `cara_entrevistado.csv`, `cara_entrevistador.csv`, `momentos_entrevistado.csv`, `momentos_entrevistador.csv`, `centroides_entrevistado.npz`, `centroides_entrevistador.npz`, `transcripcion.csv`, `palabras.csv`, `palabras_verificadas.csv`, `retorica.csv`, `qa_pares.csv`, `clase_respuestas.json`, `diarizacion.csv`, `cara_grupos_identidad.csv`, `cambios_tema_aprox.csv`, `hablantes.json`, `grafica_tono.png`, `grafica_volumen.png`, `grafica_velocidad.png`, `grafica_AU.png`, `grafica_comparativa_voz.png`, `grafica_comparativa_AU.png`, `fotogramas/`, `clips_cara/`, `scripts/`. En los nombres por persona, `_entrevistado` y `_entrevistador`; en `fotogramas/`, m = entrevistado y e = entrevistador.
