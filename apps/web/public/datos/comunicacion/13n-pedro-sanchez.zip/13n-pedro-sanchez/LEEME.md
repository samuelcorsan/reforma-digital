# Pedro Sánchez en The Wild Project

Datos del análisis de comunicación de las entrevistas de The Wild Project del 13 de noviembre de 2026, tal como
se midieron. Los minutos y los segundos son los del vídeo original.

## Qué hay

- `informe_publicable.md` es el informe; `informe.md` y sus anexos, el informe técnico.
- Transcripción y hablantes: `transcripcion.csv` (por turnos), `palabras.csv` (palabra a palabra, con su instante
  y si su voz está verificada), la salida de Whisper y la separación de voces.
- Habla y voz: `disfluencias_*.csv` (trabas), `pausas_*.csv`, `voz_*.csv` y `tonalidad_*.csv` (tono, volumen y
  velocidad de cada frase) y `retorica.csv`.
- Cara: `cara_*.csv` (unidades de acción y postura, fotograma a fotograma), `expresiones_*.csv` (gestos respecto
  a su cara de base) y `movimiento_*.csv`.
- `momentos_*.csv`: donde coinciden varias señales.
- `lectura/`: cada pregunta con su dureza y su respuesta, los temas, las afirmaciones, las promesas, el mérito
  y la culpa y la sintonía.
- `verificacion_datos.csv` y `.md`: la comprobación de datos.
- `comparativa.csv` y `grafica_*.png`: las mismas medidas para las dos personas, y sus gráficas.

`entrevistado` es el invitado y `entrevistador` o `entrevistador_1`, quien entrevista.

## Lo que no va en este paquete

- El vídeo, el audio, los fotogramas y los clips: son del programa. Cada dato lleva su minuto para ir al original.
- Los comentarios de YouTube: llevan nombres de usuarios. Sí van los recuentos.
- Las huellas de identidad de caras y voces con las que se asignó cada cara y cada voz a su persona.
- La salida de los clasificadores de emoción en la voz y en la cara: el análisis no los usa.

## Para leerlo bien

- Ninguna de estas medidas sirve para saber si alguien dice la verdad.
- La transcripción es automática: tiene huecos, nombres mal escritos y algún turno atribuido a quien no es.
- La cara se mide con unidades de acción (AU) del sistema FACS, que nombran movimientos y no emociones, y cada
  persona se compara con su propia cara. Qué cara sale en pantalla lo decide la realización.
- En la comprobación de datos, `fuente_abierta` dice si la fuente se abrió y se leyó entera; si no, el veredicto
  se apoya solo en el extracto del buscador.
