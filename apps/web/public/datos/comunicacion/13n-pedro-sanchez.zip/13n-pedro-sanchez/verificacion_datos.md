# Comprobación de los datos citados en la entrevista

*Entrevista de Jordi Wild a Pedro Sánchez en The Wild Project, publicada el 13/11/2026. Se comprueban las afirmaciones factuales (cifras, hechos, atribuciones, normas) de las dos personas; no las opiniones ni las promesas. El veredicto dice si el dato tiene respaldo en las fuentes localizadas, no si la persona actuó de buena o mala fe.*

## Cómo leerlo

| Veredicto | Significado |
|---|---|
| respaldada | las fuentes coinciden con lo dicho |
| respaldada en parte / imprecisa | el dato de fondo existe, pero la cifra, la fecha o la formulación no coinciden |
| engañosa por contexto | dato real presentado omitiendo algo que cambia su sentido |
| sin respaldo | las fuentes localizadas lo contradicen |
| no verificable | no hay fuente pública suficiente, o es una relación causal o una interpretación |
| no he podido comprobarlo | no se encontraron fuentes suficientes |

**Límites que conviene tener presentes antes de citar nada de aquí:**

- La búsqueda se hizo el 13/11/2026 con buscador web. **La mayoría de las fuentes se consultaron a través de extractos del buscador y de prensa, no abriendo el documento oficial**: solo se abrieron 18 páginas completas, que sostienen 41 de las 166 filas comprobadas. Cada fila indica «Fuente abierta: sí/no»; donde pone «no», hay que abrir la fuente enlazada antes de publicar el veredicto.
- No se pudieron leer varias fuentes: la página del Ministerio del Interior con la cifra de efectivos policiales (error 403) y dos fichas de Maldita.es (la sentencia del Supremo en Facebook y la frase de «dormir tranquilo»), de las que solo se obtuvo el titular. Las fuentes primarias abiertas son tres notas y dos transcripciones de La Moncloa, dos notas del INE y la nota del Tribunal Supremo; Banco de España, CIS, CNMC, BOE, Congreso, Eurostat y los informes de la UCO y de la CIAF se citan por extracto o a través de prensa.
- Muchos hechos de 2026 (crisis de Ceuta, accidentes de Adamuz y Urda, dimisión de Puente, caso Leire Díez, decretos de vivienda, Casa 47) descansan en uno o dos medios, a veces de un solo signo político. Las fuentes de cada fila lo dejan ver. Sobre Ceuta no hay estadística oficial de entradas y salidas del 30 y 31 de julio: todas las cifras son declaraciones.
- La transcripción es automática: hay errores en nombres y cifras («Coldo», «Zerdán», «Damuz/Amuz», «Leire Díaz», «Berlín» por Melilla, «odisea nacional», «130.000 millones», «176 años», «crisis financiera del año 2011», «regularizar las pensiones») y cuatro huecos sin texto. Las citas se copian tal cual. Cuando el dato depende de una palabra dudosa se indica en la fila.
- El recuento no es una «nota»: los dos hablan de cosas distintas (el invitado da cifras de gestión y explica decisiones propias; el entrevistador lee datos preparados, hemeroteca y lo que le dictan los verificadores), y varias afirmaciones repiten el mismo dato (columna `grupo` del CSV). **Comparar porcentajes entre los dos, o con las otras entrevistas, no es válido.**
- De las 188 afirmaciones extraídas, 22 venían marcadas como no comprobables (experiencias personales, conversaciones privadas, valoraciones). No se buscaron; figuran al final y en el CSV como «no verificable», y se cuentan aparte.
- Varias filas repiten hechos ya comprobados en las entrevistas paralelas a Feijóo y Colau (condena de Ábalos, vacaciones durante la crisis de Ceuta, avisos del CNI, informe policial sobre Marruecos, regularización, joyas de Zapatero, Aliança Catalana, salario mínimo, los dos accidentes): se reutilizan sus fuentes y se mantiene el mismo criterio; solo se marcan como abiertas las que se abrieron aquí.
- Alguna cifra es un cálculo propio a partir de datos de la fuente (relación de renta entre España y Marruecos, peso de la inmigración irregular, días entre fechas); se indica en la fila. En varias filas el veredicto «respaldada» cubre el dato central y la explicación señala qué parte secundaria no se comprobó.
- El único veredicto negativo (100:05, Pablo Iglesias) se apoya en la transcripción oficial de La Moncloa, leída completa, y se buscó de forma expresa lo que pudiera sostener la versión del invitado. No ha pasado todavía una segunda revisión independiente como la de las otras dos entrevistas. Donde los datos localizados apuntaban en contra pero no había fuente abierta suficiente (vivienda protegida construida, menores en Ceuta, plazas de acogida) se ha dejado «no he podido comprobarlo» con los datos a la vista, en lugar de un veredicto negativo.

## Recuento

| Veredicto | Invitado (Sánchez) | Entrevistador (Jordi Wild) |
|---|---|---|
| sin respaldo | 1 | 0 |
| engañosa por contexto | 0 | 0 |
| respaldada en parte / imprecisa | 18 | 6 |
| respaldada | 71 | 42 |
| no verificable | 2 | 0 |
| no he podido comprobarlo | 23 | 3 |
| **Total comprobadas** | **115** | **51** |
| no comprobables según la extracción (no buscadas; «no verificable» en el CSV) | 22 | 0 |
| **Total filas** | **137** | **51** |

Fuente abierta en 26 filas del invitado y 15 del entrevistador; en el resto solo se vio el extracto.

## Pedro Sánchez (invitado)

### Sin respaldo (1)

**100:05 · Nunca dijo que no quería a Pablo Iglesias en el Gobierno.** (hecho)

- Cita literal: «yo nunca dije nunca dije que»
- Qué dicen las fuentes: La transcripción oficial de La Moncloa de su entrevista en laSexta (18-7-2019) recoge: «ese es el principal escollo […] no se dan las condiciones para que el señor Iglesias sea miembro de ese Gobierno», «el principal escollo […] es la participación del señor Iglesias en el Gobierno» y «no se dan las condiciones para que el señor Iglesias entre en el gobierno». A favor de su versión: en esa entrevista dijo que no le gustaba el verbo «vetar» y en septiembre de 2019 que «no era una cuestión de veto» y que respetaba a Iglesias; la frase del sueño también es real (fila siguiente). Pero sí dijo que Iglesias no podía estar en el Gobierno, y en la propia entrevista lo admite cuando Jordi le lee la cita («Bueno, claro, porque tuvimos que negociar»).
- Fuentes: <https://www.lamoncloa.gob.es/presidente/intervenciones/Documents/2019/20190718 PG Entrevista Al rojo vivo La sexta ferreras.pdf> · <https://orain.eus/es/politica/2019/07/18/investidura-pedro-sanchez-veta-pablo-iglesias-18-julio-2019/> · <https://www.lamoncloa.gob.es/presidente/intervenciones/Paginas/2019/prsp190919.aspx>
- Fuente abierta: sí · Grupo: `iglesias`

### Respaldada en parte / imprecisa (18)

**9:28 · Le han llamado dictador y psicópata.** (hecho)

- Cita literal: «A mí me han llamado dictador, me han llamado psicópata»
- Qué dicen las fuentes: Localizado lo de «dictador»: Ayuso habló de «dictadura» y de «estado dictatorial», Feijóo lo comparó con Franco y Abascal con Hitler. No localicé ninguna fuente en la que un dirigente le llame «psicópata» (Abascal sugirió que debía ser «diagnosticado»).
- Fuentes: <https://es.ara.cat/politica/corrupto-mentiroso-hitler-retrato-robot-derecha-pedro-sanchez_1_4859008.html> · <https://es.ara.cat/politica/feijoo-recibe-aplauso-ayuso-plantar-fiscal-general-basta-blanquear-dictatorial-sanchez_1_5487865.amp.html>
- Fuente abierta: no (solo extracto)

**9:32 · Abascal dijo que a Sánchez había que colgarlo de los pies.** (cita_de_tercero)

- Cita literal: «hasta incluso Abascal ha dicho, oye, a este señor hay que colgarle»
- Qué dicen las fuentes: En una entrevista en Clarín (10-12-2023) Abascal dijo que «habrá un momento dado en que el pueblo querrá colgarlo de los pies»: lo formuló como algo que querría «el pueblo», no como «hay que colgarle». El Supremo inadmitió en septiembre de 2025 la querella del PSOE.
- Fuentes: <https://www.elindependiente.com/espana/2025/09/17/abascal-no-incita-a-la-violencia-al-decir-que-el-pueblo-querra-colgar-de-los-pies-a-sanchez-segun-el-supremo/> · <https://theobjective.com/espana/politica/2023-12-11/palabras-exactamente-abascal-pedro-sanchez/> · <https://www.menorca.info/actualidad/nacional/2023/12/10/2066047/investidura-abascal-dice-pueblo-querra-colgar-pies-sanchez.html>
- Fuente abierta: no (solo extracto)

**10:52 · Existen "11 puntos" de la propaganda de Goebbels, entre ellos deshumanización, transposición y verosimilitud.** (hecho)

- Cita literal: «los 11 puntos de la comunicación fascista de Goebbels»
- Qué dicen las fuentes: La lista popular de «11 principios de la propaganda de Goebbels» incluye la simplificación y el enemigo único, la transposición y la verosimilitud, que él describe de forma reconocible. «Deshumanización» no figura con ese nombre en las listas localizadas, y las fuentes no remiten a un texto original de Goebbels sino a recopilaciones posteriores.
- Fuentes: <https://psicologiaymente.com/social/principios-propaganda-goebbels> · <https://www.diarioconstitucional.cl/2018/05/30/sobre-los-11-principios-de-la-propaganda-nazi-desarrollados-por-joseph-goebbels-hoy-vigentes-en-las-fake-news/>
- Fuente abierta: no (solo extracto)

**29:12 · Josep Borrell fue su ministro de Exteriores y ministro con Felipe González.** (hecho)

- Cita literal: «Pepe Borrell fue mi ministro de Asuntos Exteriores»
- Qué dicen las fuentes: Borrell fue ministro de Asuntos Exteriores con Sánchez (junio de 2018-noviembre de 2019). Con Felipe González fue secretario de Estado de Hacienda (1984-1991) y ministro de Obras Públicas desde 1991: ministro en los noventa, no «en los años 80».
- Fuentes: <https://www.lamoncloa.gob.es/gobierno/Documents/06062018_BiografíasGabinete2.pdf> · <https://www.exteriores.gob.es/ca/Ministerio/HistoriaDelMinisterio/Paginas/Ministros-de-Asuntos-Exteriores.aspx>
- Fuente abierta: no (solo extracto)

**30:59 · Las llegadas previas eran de 1.000 a 1.200 migrantes.** (cifra)

- Cita literal: «Estamos hablando a lo mejor de llegadas de 1 .000, 1 .200 migrantes»
- Qué dicen las fuentes: Las cifras previas varían según la fuente: 253 entradas consumadas entre el 13 y el 26 de julio (informe de la Guardia Civil), unas 1.500 en la segunda quincena (Ciudad Autónoma), más de 1.500 en la última semana (prensa) y unas 2.000 en diez días (Vivas). El orden de magnitud de 1.000-1.200 encaja con parte de ellas, no con todas.
- Fuentes: <https://www.lamoncloa.gob.es/consejodeministros/Documents/2026/situacion-ceuta/informes-GC/EM-3/20260730-Informe-presion-migratoria-Ceuta.pdf> · <https://es.ara.cat/politica/gobierno-sanchez-rinde-cuentas-26-dias-despues-crisis-ceuta_1_5831446.html> · <https://www.ondavasca.com/mas-de-1-500-migrantes-han-entrado-a-nado-en-ceuta-en-la-ultima-semana/amp/> · <https://maldita.es/desinfo/20260731/entrada-masiva-de-inmigrantes-logran-acceder-a-ceuta-a-traves-del-espigon-del-tarajal/>
- Fuente abierta: no (solo extracto) · Grupo: `ceuta_previas`

**31:04 · Más de 80.000 personas entraron en Ceuta el 30 y 31 de julio.** (cifra)

- Cita literal: «los más de 80 .000 que el 30 y el 31 de julio entraron»
- Qué dicen las fuentes: No hay cifra oficial única: Interior dio 72.000 (4-8-2026), el propio Sánchez habló de 70.000 en el Congreso (3-9-2026) y ARA de «unas 80.000». «Más de 80.000» está por encima de las cifras oficiales localizadas. El Faro de Ceuta señala que Interior excluyó esos días de su estadística.
- Fuentes: <https://es.ara.cat/politica/gobierno-sanchez-rinde-cuentas-26-dias-despues-crisis-ceuta_1_5831446.html> · <https://elfarodeceuta.es/marlaska-niega-cni-avisara-entrada-masiva-ceuta-confirma-72-000-personas-cruzaron-marruecos/> · <https://www.lamoncloa.gob.es/presidente/actividades/Paginas/2026/030926-sanchez-comparecencia-ceuta.aspx> · <https://www.diaridetarragona.com/espana/267344/cifras-entrada-masiva-ceuta-37-500-migrantes-han-regresado-marruecos-57-muertos.html>
- Fuente abierta: sí · Grupo: `ceuta_cifra`

**34:43 · Hubo reuniones con el gobierno ceutí y se reforzó la frontera esos días.** (hecho)

- Cita literal: «nosotros tuvimos reuniones con el gobierno Ceutí, estuvo el Ministerio del Interior también pendientes, aumentamos la seguridad en frontera»
- Qué dicen las fuentes: Constan reuniones del 27 y el 29 de julio con las fuerzas de seguridad y la Delegación del Gobierno (Robles). No localicé reuniones previas con el Gobierno de la Ciudad ni el refuerzo de la frontera en esos días; el despliegue de Guardia Civil y Regulares que recogen las fuentes es del 30-31 de julio.
- Fuentes: <https://es.ara.cat/politica/gobierno-sanchez-rinde-cuentas-26-dias-despues-crisis-ceuta_1_5831446.html> · <https://www.diaridetarragona.com/espana/267344/cifras-entrada-masiva-ceuta-37-500-migrantes-han-regresado-marruecos-57-muertos.html>
- Fuente abierta: sí

**42:39 · Abascal dice que el rey de Sánchez es Mohamed VI.** (cita_de_tercero)

- Cita literal: «como dice Abascal, que mi rey es el rey Mohamed VI»
- Qué dicen las fuentes: Abascal ha llamado a Sánchez «virrey de Mohamed VI», «lacayo de Marruecos» y ha dicho que Marruecos «no es su amigo; es su amo». La frase literal «su rey es Mohamed VI» no la localicé; el sentido es equivalente.
- Fuentes: <https://www.democrata.es/politica/congreso-y-senado/abascal-vuelve-a-llamar-traidor-a-sanchez-y-le-acusa-de-embajador-de-marruecos-y-virrey-de-al-andalus/> · <https://www.esdiario.com/nacional/260831/196568/abascal-acusa-sanchez-lacayo-marruecos-pide-activar-articulo-102-traicion.html>
- Fuente abierta: no (solo extracto)

**56:27 · El 25 % del crecimiento económico se debe a la migración.** (cifra)

- Cita literal: «el 25 % del crecimiento económico que hemos experimentado durante todo este tiempo trae causa del aporte de la migración»
- Qué dicen las fuentes: Las estimaciones del Banco de España dependen de la medida: entre 0,4 y 0,7 puntos del 2,9 % de crecimiento anual del PIB per cápita en 2022-2024 (del 14 % al 24 %) y unos 2 puntos del 3,9 % del PIB total (la mitad); para 2022-2025, 1,7 puntos de 3,7. BBVA habla del 40 % del PIB per cápita. El 25 % solo encaja con el extremo alto de la primera.
- Fuentes: <https://www.bolsamania.com/noticias_amp/economia/economia--inmigrantes-contribuyeron-en-hasta-07-puntos-al-alza-del-pib-per-capita-en-2022-2024-segun-banco-de-espana--19893560.html> · <https://www.bolsamania.com/noticias/economia/economia--los-inmigrantes-aportaron-17-puntos-al-alza-del-pib-espanol-entre-2022-y-2025-y-05-puntos-al-pib-per-capita--22906098.html> · <https://www.infobae.com/espana/2026/07/03/la-inmigracion-se-consolida-como-motor-del-crecimiento-economico-de-espana-ha-tenido-un-notable-impacto-en-el-aumento-del-pib/>
- Fuente abierta: no (solo extracto)

**60:14 · Muchos migrantes llegan en avión, por otros aeropuertos europeos y no por Barajas.** (hecho)

- Cita literal: «Y no te vienen, Jordi, por cierto, por barajas. Te vienen por otros aeropuertos europeos.»
- Qué dicen las fuentes: Respaldado que la vía aérea es la principal: un informe de la Comisaría General de Extranjería citado por The Objective le atribuye el 60-65 % de los flujos irregulares frente al 5-8 % de la marítima, y CIDOB explica que la mayoría entra legalmente y luego queda en situación irregular. No localicé nada que respalde que lleguen por otros aeropuertos europeos y no por Barajas.
- Fuentes: <https://theobjective.com/espana/2026-06-09/gobierno-mayoria-irregulares-espana-avion/> · <https://www.cidob.org/cidob-en-medios/mayoria-inmigrantes-situacion-irregular-espana-han-llegado-por-vias-legales>
- Fuente abierta: no (solo extracto)

**61:50 · Han equiparado los permisos de paternidad y maternidad y los han subido de 5 a 19 semanas.** (cifra)

- Cita literal: «pasar de cinco semanas los permisos de paternidad y maternidad, equipararlos»
- Qué dicen las fuentes: El permiso por nacimiento es de 19 semanas para cada progenitor desde el 31-7-2025 (Real Decreto-ley 9/2025). Lo que estaba en cinco semanas en 2018 era el de paternidad; el de maternidad ya era de 16, y ambos se igualaron en 16 en 2021.
- Fuentes: <https://www.cuatrecasas.com/es/spain/laboral/art/ampliacion-permiso-nacimiento-cuidado> · <https://www.osborneclarke.com/es/insights/el-permiso-por-nacimiento-y-cuidado-del-menor-se-amplia-19-semanas-32-en-familias>
- Fuente abierta: no (solo extracto)

**64:31 · Con Rajoy se recortaron 15.000 efectivos policiales; hoy hay 180.000.** (cifra)

- Cita literal: «se recortaron las fuerzas y cuerpos de seguridad del Estado en 15 .000 efectivos y hoy hay 180 .000 efectivos»
- Qué dicen las fuentes: El orden de magnitud del recorte y la recuperación está respaldado, no las dos cifras: las plantillas de Policía y Guardia Civil cayeron hasta un mínimo de 142.072 agentes en diciembre de 2017 y un documento del Congreso da 159.075 en diciembre de 2025 (máximo histórico). No abrí ninguna fuente con 180.000 efectivos (la página de Interior dio error 403) ni con un recorte de 15.000; las asociaciones de la Guardia Civil discuten el «récord».
- Fuentes: <https://www.defensa.com/homeland-security/maximo-historico-agentes-policia-nacional-guardia-civil-156-400> · <https://www.congreso.es/l15p/e10/e_0109612_n_000.pdf> · <https://www.esdiario.com/nacional/260317/182647/asociaciones-desmontan-record-marlaska-guardia-civil-faltan-20-000-agentes.html>
- Fuente abierta: no (solo extracto)

**65:26 · La regularización alcanza a unas 1.200.000 personas.** (cifra)

- Cita literal: «bueno, más o menos es un millón doscientas mil personas.»
- Qué dicen las fuentes: El proceso cerró con 1.174.978 solicitudes: cerca de 1,2 millones, pero son solicitudes, no personas ya regularizadas (609.737 tramitadas a 30 de junio). Mismo dato que en la comprobación de la entrevista a Feijóo.
- Fuentes: <https://www.lamoncloa.gob.es/serviciosdeprensa/notasprensa/inclusion/Paginas/2026/020726-balance-regularizacion-extraordinaria.aspx>
- Fuente abierta: sí · Grupo: `regularizacion`

**72:29 · En esa renovación salieron cinco o seis ministros.** (cifra)

- Cita literal: «creo recordar que si no fueron cinco, fueron seis ministros»
- Qué dicen las fuentes: Salieron siete ministros (Calvo, Ábalos, Campo, González Laya, Celaá, Duque y Rodríguez Uribes), no cinco o seis; él lo dice con un «creo recordar».
- Fuentes: <https://es.ara.cat/politica/pedro-sanchez-remodela-gobierno-prescinde-calvo-asciende-calvino-primera-vicepresidenta_1_4049768.html> · <https://diariodeavisos.elespanol.com/2021/07/sanchez-revoluciona-el-gobierno-saca-a-calvo-abalos-laya-campo-celaa-uribes-y-a-redondo/>
- Fuente abierta: no (solo extracto) · Grupo: `remodelacion_2021`

**74:34 · Sitúa los elogios en 2016, en la etapa del "No es No".** (hecho)

- Cita literal: «creo que recordar que fue en el año 2016, después de las elecciones, en el No es No»
- Qué dicen las fuentes: Las fuentes fechan los elogios en 2014 (blog, 24 de junio) y 2015 (Facebook), no en 2016. Él lo dice con un «creo recordar» y en la propia entrevista acepta la fecha de 2014 cuando se la dan.
- Fuentes: <https://www.vozpopuli.com/espana/politica/koldo-garcia-hombre-durmio-urnas-sanchez-narra-presidente-mision-manual-resistencia.html> · <https://www.vozpopuli.com/dolcevita/asi-es-koldo-garcia-su-expareja-patricia-uriz-sus-hijos-condena-y-los-trapos-sucios-que-destapo-su-primera-mujer.html>
- Fuente abierta: no (solo extracto) · Grupo: `elogios_koldo`

**80:13 · El PSOE pagó esos cuarenta y tantos mil euros a varios despachos de abogados.** (hecho)

- Cita literal: «contratamos los servicios de varios despachos de abogados»
- Qué dicen las fuentes: Según la UCO, el dinero llegó por dos vías: cuatro transferencias de 4.000 euros de Zaño, una consultora vinculada a Gaspar Zarrías, y 27.225 euros de Oliver Gruppe, del abogado Ismael Oliver. Es una consultora y un despacho, no «varios despachos de abogados». Que el PSOE los contratara es su versión; la UCO sitúa en el partido el origen de los pagos.
- Fuentes: <https://es.euronews.com/my-europe/2026/07/14/caso-leire-diez-la-uco-confirma-pagos-del-psoe-por-valor-de-43225-euros-a-traves-de-interm> · <https://www.que.es/2026/07/15/caso-leire-diez-uco-pagos-psoe/> · <https://www.ondavasca.com/la-uco-confirma-pagos-del-psoe-a-leire-diez-por-valor-de-43-225-euros/>
- Fuente abierta: no (solo extracto) · Grupo: `leire`

**82:18 · Se rescató a todas las aerolíneas con préstamos, no a fondo perdido.** (hecho)

- Cita literal: «Nosotros a todas las aerolíneas las rescatamos, pero fíjate, no las rescatamos a fondo perdido»
- Qué dicen las fuentes: El fondo de la SEPI prestó a cinco aerolíneas: Air Europa (475 millones), Volotea (200), Air Nostrum (111), Wamos (85) y Plus Ultra (53). Fueron préstamos, como dice, pero no «todas las aerolíneas»: las demás no recibieron ayuda de ese fondo.
- Fuentes: <https://www.hosteltur.com/176362_prestamos-sepi-cuanto-han-devuelto-air-europa-air-nostrum-volotea-y-plus-ultra.html> · <https://www.publico.es/economia/fondo-rescate-sepi-cierra-labor-67-dinero-gastar.html> · <https://forbes.es/turismo/519324/el-fondo-de-solvencia-de-sepi-recibe-la-devolucion-total-de-los-85-millones-de-ayuda-concedida-al-grupo-wamos/>
- Fuente abierta: no (solo extracto) · Grupo: `sepi`

**88:13 · Han repartido a las comunidades más de 7.000 millones para vivienda.** (cifra)

- Cita literal: «más de 7 .000 millones de euros para la construcción»
- Qué dicen las fuentes: El Plan Estatal de Vivienda 2026-2030 está dotado con 7.000 millones, pero el Estado aporta el 60 % y las comunidades el 40 %, y a 28-4-2026 no se había transferido nada: el primer pago previsto era de 800 millones para 2026. No son «más de 7.000 millones repartidos».
- Fuentes: <https://www.lamoncloa.gob.es/serviciosdeprensa/notasprensa/vivienda-agenda-urbana/Paginas/2026/280426-reparto-plan-estatal-vivienda.aspx> · <https://brainsre.news/distribucion-7000-millones-plan-vivienda-comunidades/>
- Fuente abierta: sí · Grupo: `presupuesto_vivienda`

### Respaldada (71)

**3:06 · Recibió el Gobierno en 2018 y sigue en 2026.** (hecho)

- Cita literal: «como la recibí en 2018, a como he estado hoy en 2026»
- Qué dicen las fuentes: Preside el Gobierno desde junio de 2018 (biografía oficial de La Moncloa). La valoración de que el país está mejor no se evalúa.
- Fuentes: <https://www.lamoncloa.gob.es/presidente/biografia/Paginas/index.aspx> · <https://maldita.es/control-del-poder/20260623/abalos-condenado-mocion-censura-corrupcion/>
- Fuente abierta: no (solo extracto) · Grupo: `ocho_anos`

**4:15 · Tiene 54 años.** (cifra)

- Cita literal: «Yo tengo 54 años, con 15 años, 16 años.»
- Qué dicen las fuentes: Nació en Madrid el 29 de febrero de 1972 (biografía oficial): 54 años en noviembre de 2026.
- Fuentes: <https://www.lamoncloa.gob.es/presidente/biografia/Paginas/index.aspx> · <https://www.cidob.org/es/biografias_lideres_politicos/europa/espana/pedro_sanchez_perez_castejon>
- Fuente abierta: no (solo extracto)

**12:23 · Durante la legislatura, a raíz de la ley de amnistía, hubo cánticos fascistas y agresiones a militantes y sedes del PSOE, incluida Ferraz.** (hecho)

- Cita literal: «empezamos con cánticos fascistas, con agresiones a militantes del Partido Socialista, a casas del pueblo del Partido Socialista»
- Qué dicen las fuentes: En noviembre de 2023, durante las protestas contra la amnistía, hubo concentraciones diarias ante la sede del PSOE en Ferraz con cargas policiales e intento de asalto, y ataques a sedes socialistas. Lo de «toda la legislatura» no se comprobó.
- Fuentes: <https://www.infobae.com/espana/2023/11/06/tension-en-ferraz-gases-lacrimogenos-y-pelotas-de-goma-tras-un-intento-de-asalto-a-la-sede-del-psoe/> · <https://es.ara.cat/politica/detras-manifestaciones-salvar-espana_1_4850359.amp.html>
- Fuente abierta: no (solo extracto)

**15:40 · Inauguró el AVE Madrid-Ourense y el Madrid-Murcia.** (hecho)

- Cita literal: «Yo he inaugurado, pues, el AVE Madrid, Ourense, el AVE Madrid»
- Qué dicen las fuentes: Inauguró con el Rey el tramo Pedralba-Ourense (20-12-2021), que completó el AVE Madrid-Galicia, y la línea Madrid-Murcia (19-12-2022).
- Fuentes: <https://www.lamoncloa.gob.es/presidente/actividades/Paginas/2021/201221-sanchez_ave-galicia.aspx> · <https://www.lamoncloa.gob.es/lang/en/presidente/news/Paginas/2022/20221219_hspeed-railway-line.aspx>
- Fuente abierta: no (solo extracto)

**15:51 · Los dos accidentes se produjeron en la misma línea (Madrid-Sevilla).** (hecho)

- Cita literal: «en la línea en la que se han concentrado los dos desgraciados accidentes ferroviarios»
- Qué dicen las fuentes: Adamuz (Córdoba, 18-1-2026) y Urda (Toledo, 28-10-2026) están en la línea de alta velocidad Madrid-Sevilla.
- Fuentes: <https://www.elnuevodia.com/noticias/mundo/notas/dos-tragedias-mortales-golpean-la-red-ferroviaria-de-alta-velocidad-espanola-en-nueve-meses/> · <https://es.ara.cat/politica/saldra-oscar-puente_129_5893607.html> · <https://www.diaridetarragona.com/espana/274809/dimite-oscar-puente.html>
- Fuente abierta: no (solo extracto) · Grupo: `dos_accidentes`

**17:06 · Ha aumentado mucho el uso de la alta velocidad.** (hecho)

- Cita literal: «aumentar exponencialmente el uso por parte de los ciudadanos de la alta»
- Qué dicen las fuentes: La CNMC contabilizó 44,5 millones de viajeros de alta velocidad comercial en 2025, un 12 % más que en 2024 y el doble que en 2019.
- Fuentes: <https://www.elespanol.com/invertia/observatorios/movilidad/20260717/alta-velocidad-duplica-numero-viajeros-rebaja-precios-liberalizacion/1003744325128_0.html> · <https://cnmc.es/prensa/balance-liberalizacion-ferroviaria-2024-20250922>
- Fuente abierta: no (solo extracto)

**17:10 · El precio del billete de alta velocidad ha bajado de forma sustantiva.** (hecho)

- Cita literal: «una rebaja sustantiva del precio de la alta velocidad del billete»
- Qué dicen las fuentes: Según la CNMC, los precios en los corredores abiertos a la competencia han bajado hasta un 34-40 % respecto a la etapa sin competencia. Matiz: en Madrid-Barcelona el precio medio subió un 15,2 % en 2025.
- Fuentes: <https://www.cnmc.es/los-precios-caen-mas-de-un-30-en-el-corredor-sur-gracias-la-competencia-417601> · <https://www.elespanol.com/invertia/observatorios/movilidad/20260717/alta-velocidad-duplica-numero-viajeros-rebaja-precios-liberalizacion/1003744325128_0.html>
- Fuente abierta: no (solo extracto)

**18:00 · El Gobierno negocia con los maquinistas coeficientes reductores y más descanso, y una auditoría extraordinaria de la línea Madrid-Sevilla.** (hecho)

- Cita literal: «Hoy en el Consejo de Ministros lo que estamos haciendo es negociar con los maquinistas coeficientes reductores»
- Qué dicen las fuentes: El Consejo de Ministros del 10-11-2026 aprobó un decreto-ley que extiende los coeficientes reductores al personal ferroviario, cambia el cómputo de los tiempos de conducción y refuerza la Agencia de Seguridad Ferroviaria, el primer día de huelga de maquinistas. El plan para la Madrid-Sevilla incluye una revisión extraordinaria de los sistemas de seguridad y una segunda validación de ciertas decisiones (él lo llama «auditoría» y «doble firma»).
- Fuentes: <https://www.articulo14.es/economia/gobierno-refuerza-seguridad-trenes-proteccion-profesionales-urda-tragedia-20261110.html> · <https://es.ara.cat/sociedad/movilidad/nuevo-calculo-horas-conduccion-supervision-moncloa-aprueba-medidas-dia-huelga-maquinistas_1_5906137.html> · <https://www.railjournal.com/passenger/high-speed/spain-approves-plan-to-improve-high-speed-rail-safety/>
- Fuente abierta: sí

**18:42 · En el último accidente cayó un sistema operativo.** (hecho)

- Cita literal: «si cae un sistema operativo, como fue el caso de este último accidente»
- Qué dicen las fuentes: En Urda falló el sistema de seguridad de la vía (LZB): el Iryo avisó de que estaba detenido por esa avería minutos antes del alcance.
- Fuentes: <https://es.ara.cat/politica/saldra-oscar-puente_129_5893607.html> · <https://www.democrata.es/en/economy/the-adif-regulations-prevented-the-control-center-from-giving-the-ave-the-all-clear-after-the-system-failure/amp/> · <https://es.ara.cat/sociedad/sucesos/renfe-trabaja-limitar-40km-h-reanudacion-tren-falla-sistema-seguridad_1_5897809.html> · <https://www.libertaddigital.com/landing/que-pudo-pasar-accidente-de-tren-urda/>
- Fuente abierta: sí · Grupo: `urda_protocolo`

**19:29 · Hay una investigación judicial abierta sobre el primer accidente.** (hecho)

- Cita literal: «Hay una investigación abierta por, en este caso, la autoridad judicial.»
- Qué dicen las fuentes: El Juzgado de Instancia n.º 2 de Montoro (Córdoba) instruye la causa por el accidente de Adamuz; la CIAF le remitió su informe provisional en abril de 2026.
- Fuentes: <https://www.infobae.com/espana/2026/04/28/conclusion-del-accidente-de-adamuz-la-ciaf-dice-que-se-rompio-el-carril-y-descarta-anomalias-previas-en-los-trenes/> · <https://www.menorca.info/actualidad/nacional/2026/02/24/2576481/jueza-pide-adif-abstenga-realizar-cualquier-operacion-sobre-vias-adamuz-autorizacion.html>
- Fuente abierta: sí · Grupo: `adamuz_causa`

**19:48 · No se sabe aún con exactitud qué ocurrió en el primer accidente (Adamuz).** (hecho)

- Cita literal: «realmente no se sabe exactamente qué es lo que sucedió en Amuz»
- Qué dicen las fuentes: El informe de la CIAF (abril de 2026) es provisional y puede modificarse; la investigación judicial sigue abierta. Matiz: ese informe ya señala como origen la rotura de un carril en el punto kilométrico 318,681; lo que no está determinado es por qué se rompió ni las responsabilidades.
- Fuentes: <https://www.infobae.com/espana/2026/04/28/conclusion-del-accidente-de-adamuz-la-ciaf-dice-que-se-rompio-el-carril-y-descarta-anomalias-previas-en-los-trenes/> · <https://www.ultimahora.es/noticias/comunidades/2026/04/28/2618713/ciaf-remarca-hipotesis-rotura-carril-como-causa-del-descarrilamiento-posterior-colision-adamuz.html>
- Fuente abierta: sí · Grupo: `adamuz_causa`

**20:23 · Se aprobó un real decreto ley de indemnizaciones y ayuda psicológica a las víctimas.** (voto_o_decision)

- Cita literal: «haber aprobado el Real Decreto Ley de Intimidaciones Materiales y Ayuda Psicológica»
- Qué dicen las fuentes: El Consejo de Ministros aprobó el 27-1-2026 ayudas y anticipos de indemnización para las víctimas de Adamuz y Gelida (20 millones), ampliadas en abril (Real Decreto-ley 10/2026), y otro paquete para Urda en noviembre. No localicé la mención expresa a la ayuda psicológica.
- Fuentes: <https://www.eldebate.com/economia/20260127/gobierno-aprueba20-millones-euros-ayudas-victimas-adamuz-gelida_378700.html> · <https://www.newtral.es/decreto-ley-gobierno-dana-adamuz/20260429/> · <https://www.lamoncloa.gob.es/consejodeministros/resumenes/Paginas/2026/270126-rueda-de-prensa-ministros.aspx>
- Fuente abierta: no (solo extracto)

**20:36 · Óscar Puente ha dimitido.** (voto_o_decision)

- Cita literal: «creo que ha hecho bien en tomar la decisión de dar un paso a un lado»
- Qué dicen las fuentes: Óscar Puente anunció su dimisión el 3-11-2026 ante la Diputación Permanente del Congreso, seis días después de Urda, y renunció a ir en las listas.
- Fuentes: <https://www.articulo14.es/politica/dimite-oscar-puente-y-renuncia-a-ser-diputado-tras-el-29-n-20261103.html> · <https://www.diaridetarragona.com/espana/274809/dimite-oscar-puente.html> · <https://www.vozpopuli.com/economia/transporte/oscar-puente-dimite-por-las-presiones-del-psoe-y-los-socios-y-renuncia-a-ir-en-las-listas-el-29-n.html>
- Fuente abierta: no (solo extracto)

**21:25 · El protocolo fija 40 km/h si falla el sistema operativo y entra el ASFA; no se cumplió.** (cifra)

- Cita literal: «si el sistema operativo falla y entra el sistema ASFA, la velocidad tiene que ser de 40 km»
- Qué dicen las fuentes: Según las fuentes, con el LZB caído solo cabe reanudar en «marcha a la vista» bajo ASFA, con un máximo de 40 km/h, y el centro de control autorizó al AVE a retomar la «marcha normal». Fuentes de prensa; no se abrió el reglamento de Adif.
- Fuentes: <https://es.ara.cat/politica/saldra-oscar-puente_129_5893607.html> · <https://www.democrata.es/en/economy/the-adif-regulations-prevented-the-control-center-from-giving-the-ave-the-all-clear-after-the-system-failure/amp/> · <https://es.ara.cat/sociedad/sucesos/renfe-trabaja-limitar-40km-h-reanudacion-tren-falla-sistema-seguridad_1_5897809.html> · <https://www.libertaddigital.com/landing/que-pudo-pasar-accidente-de-tren-urda/>
- Fuente abierta: no (solo extracto) · Grupo: `urda_protocolo`

**23:36 · Durante su mandato ha habido dos guerras (Irán y Ucrania), danas, incendios, un volcán y dos accidentes ferroviarios.** (hecho)

- Cita literal: «He sido el presidente de dos guerras, una en Irán y otra en Ucrania.»
- Qué dicen las fuentes: Durante su mandato: pandemia (2020), volcán de La Palma (2021), guerra de Ucrania (2022), DANA de Valencia (2024), incendios, guerra de Irán (ataques de EE. UU. e Israel desde el 28-2-2026) y los accidentes de Adamuz y Urda. Solo se buscó de forma específica la guerra de Irán.
- Fuentes: <https://es.ara.cat/politica/espana-rechaza-prestar-ayuda-eua-guerra-iran-no-usara-bases-rota-moron_1_5665730.html> · <https://www.elsaltodiario.com/iran/sanchez-responde-trump-no-guerra> · <https://es.ara.cat/politica/saldra-oscar-puente_129_5893607.html>
- Fuente abierta: no (solo extracto)

**25:13 · El primer día en Urda dijo que no era asumible sufrir dos accidentes así.** (hecho)

- Cita literal: «yo lo dije el primer día que estuve en Urda»
- Qué dicen las fuentes: ARA (29-10-2026): Sánchez calificó de «inasumibles» dos accidentes ferroviarios en un mismo año, el miércoles del accidente; el artículo no precisa el lugar.
- Fuentes: <https://es.ara.cat/politica/saldra-oscar-puente_129_5893607.html> · <https://www.diaridetarragona.com/espana/274428/sanchez-promete-soluciones-reforzar-sistema-alta-velocidad.html>
- Fuente abierta: sí

**30:50 · En los cinco días previos había un pico de llegadas a Ceuta.** (hecho)

- Cita literal: «empezaba a haber un pico de llegadas de migrantes irregulares a Ceuta durante los últimos cinco días»
- Qué dicen las fuentes: Los informes publicados recogen un aumento de entradas a nado en la segunda quincena de julio (1.380 intentos entre el 13 y el 26, frente a 459 en la quincena anterior) y Robles dijo que el 27 de julio se constató el incremento.
- Fuentes: <https://www.lamoncloa.gob.es/consejodeministros/Documents/2026/situacion-ceuta/informes-GC/EM-3/20260730-Informe-presion-migratoria-Ceuta.pdf> · <https://es.ara.cat/politica/gobierno-sanchez-rinde-cuentas-26-dias-despues-crisis-ceuta_1_5831446.html> · <https://www.ondavasca.com/mas-de-1-500-migrantes-han-entrado-a-nado-en-ceuta-en-la-ultima-semana/amp/> · <https://maldita.es/desinfo/20260731/entrada-masiva-de-inmigrantes-logran-acceder-a-ceuta-a-traves-del-espigon-del-tarajal/>
- Fuente abierta: sí · Grupo: `ceuta_previas`

**31:53 · Circuló un bulo basado en una sentencia del Supremo ("si entras a nado, no te pueden echar").** (hecho)

- Cita literal: «hubo un bulo, una lectura interesada de una sentencia del Tribunal Supremo»
- Qué dicen las fuentes: El Supremo falló (29-6-2026) que el rechazo en frontera no se aplica a quien es interceptado nadando; no elimina las devoluciones ni da derecho a quedarse. Maldita documentó el 30 de julio cientos de publicaciones idénticas con ese mensaje, y Gobierno y ministros lo describen como una lectura tergiversada difundida en redes.
- Fuentes: <https://www.lamoncloa.gob.es/presidente/actividades/Paginas/2026/030926-sanchez-comparecencia-ceuta.aspx> · <https://es.ara.cat/politica/gobierno-sanchez-rinde-cuentas-26-dias-despues-crisis-ceuta_1_5831446.html> · <https://maldita.es/investigaciones/20260806/tribunal-supremo-sentencia-ceuta-marruecos-facebook/> · <https://maldita.es/desinfo/20260805/sentencia-tribunal-supremo-devoluciones-caliente-ceuta-melilla/>
- Fuente abierta: sí

**32:13 · Coincidió con la fiesta del trono, con la seguridad marroquí volcada en sus autoridades.** (hecho)

- Cita literal: «Y lo hizo además un día, que es la fiesta del trono»
- Qué dicen las fuentes: La entrada masiva empezó el 30 de julio, día de la Fiesta del Trono en Marruecos; un mensaje del CNI del 27 de julio ya vinculaba las convocatorias a esa fecha. Que la seguridad marroquí estuviera volcada en proteger a sus autoridades es su explicación y no se comprobó.
- Fuentes: <https://www.lamoncloa.gob.es/consejodeministros/paginas/informes-y-comunicaciones-situacion-ceuta.aspx> · <https://www.eldebate.com/deportes/futbol/20260731/infantino-acude-aniversario-coronacion-mohamed-vi-mundial-2030-horizonte_445578.html>
- Fuente abierta: no (solo extracto)

**33:01 · La renta per cápita se multiplica por ocho de un lado a otro de la frontera.** (cifra)

- Cita literal: «estamos hablando de que se multiplica por ocho»
- Qué dicen las fuentes: Con los datos localizados para 2024 (unos 35.100 dólares de PIB per cápita en España y unos 4.700 en Marruecos) la relación es de 7,5 veces: cerca de ocho. Cálculo propio con cifras de un agregador, no de la serie del Banco Mundial.
- Fuentes: <https://www.focus-economics.com/es/country-indicator/espana/gdp-per-capita-usd/> · <https://www.focus-economics.com/es/country-indicator/marruecos/>
- Fuente abierta: no (solo extracto)

**35:22 · Hubo más de 140 muertos, muchos menores.** (cifra)

- Cita literal: «Bueno, tuvimos más de 140 muertos.»
- Qué dicen las fuentes: Caminando Fronteras contabilizó 141 fallecidos (140 según ARA, «la crisis migratoria más letal»). Las cifras oficiales son menores porque solo cuentan los cuerpos hallados en territorio español: 57 (Interior, 31-7), 75 (4-8), 82-88 (primera semana). No localicé cuántos eran menores.
- Fuentes: <https://es.ara.cat/politica/gobierno-sanchez-rinde-cuentas-26-dias-despues-crisis-ceuta_1_5831446.html> · <https://elfarodeceuta.es/marlaska-niega-cni-avisara-entrada-masiva-ceuta-confirma-72-000-personas-cruzaron-marruecos/> · <https://maldita.es/especial-ceuta-marruecos/> · <https://www.ultimahora.es/noticias/nacional/2026/08/03/2682265/gobierno-ceuta-eleva-numero-fallecidos-durante-entrada-masiva.html>
- Fuente abierta: sí

**38:01 · En las primeras 48 horas salieron 9 de cada 10 migrantes que habían entrado.** (cifra)

- Cita literal: «es que 9 de cada 10 migrantes que entraron, salieron»
- Qué dicen las fuentes: Es la cifra del Gobierno: unas 63.000 personas, más del 90 %, regresaron en 72 horas (Sánchez en el Congreso, 3-9-2026); el 31 de julio por la tarde Interior hablaba ya de más de 48.300. Él dice 48 horas; la fuente oficial, 72. No hay estadística pública de esos días.
- Fuentes: <https://www.lamoncloa.gob.es/presidente/actividades/Paginas/2026/030926-sanchez-comparecencia-ceuta.aspx> · <https://www.diaridetarragona.com/espana/267344/cifras-entrada-masiva-ceuta-37-500-migrantes-han-regresado-marruecos-57-muertos.html> · <https://elfarodeceuta.es/marlaska-niega-cni-avisara-entrada-masiva-ceuta-confirma-72-000-personas-cruzaron-marruecos/>
- Fuente abierta: sí · Grupo: `ceuta_salidas`

**38:57 · El 20 de agosto empezaron a instalar alojamientos temporales.** (hecho)

- Cita literal: «Nosotros el 20 de agosto empezamos a instalar todas las capacidades, alojamientos temporales»
- Qué dicen las fuentes: Hacia el 20 de agosto el Ministerio de Inclusión abrió dos espacios con 1.800 plazas y empezó a trasladar a quienes dormían en la calle; la instalación de carpas se anunció el 18 de agosto.
- Fuentes: <https://es.ara.cat/sociedad/inmigracion/ceuta-habilita-1-800-plazas-acoger-migrantes-dormian-calle_1_5827877.html> · <https://www.elespanol.com/espana/20260818/ceuta-teme-carpas-temporales-acoger-invasores-conviertan-permanentes/1003744355574_0.html> · <https://es.euronews.com/2026/08/31/sanchez-vincula-a-rusia-israel-y-una-internacional-ultraderechista-con-los-bulos-de-ceuta>
- Fuente abierta: no (solo extracto) · Grupo: `ceuta_acogida`

**41:33 · Le hackearon el móvil y lo denunció ante la Audiencia Nacional (también a Defensa e Interior).** (hecho)

- Cita literal: «a mí me hackearon el móvil, lo denuncié ante la Audiencia Nacional»
- Qué dicen las fuentes: La Abogacía del Estado denunció el 2-5-2022 ante la Audiencia Nacional la infección con Pegasus de los móviles de Sánchez y Robles; el 11 de mayo se amplió al de Marlaska. El juez archivó provisionalmente la causa en 2023 por falta de cooperación de Israel.
- Fuentes: <https://es.ara.cat/politica/gobierno-espanol-denuncia-espionaje-pegasus-moviles-pedro-sanchez-margarita-robles_1_4357938.html> · <https://www.ultimahora.es/noticias/nacional/2022/05/11/1732329/caso-pegasus-amplian-denuncia-moviles-marlaska-planas.html>
- Fuente abierta: no (solo extracto) · Grupo: `pegasus`

**42:28 · Pegasus es un sistema informático israelí.** (hecho)

- Cita literal: «es un sistema informático de Israel pero se compra»
- Qué dicen las fuentes: Pegasus es un programa espía de la empresa israelí NSO Group.
- Fuentes: <https://es.ara.cat/politica/gobierno-espanol-denuncia-espionaje-pegasus-moviles-pedro-sanchez-margarita-robles_1_4357938.html> · <https://www.ultimahora.es/noticias/nacional/2022/05/11/1732329/caso-pegasus-amplian-denuncia-moviles-marlaska-planas.html>
- Fuente abierta: no (solo extracto) · Grupo: `pegasus`

**45:15 · Estuvo en Ceuta al día siguiente.** (hecho)

- Cita literal: «en mi caso, el día siguiente, estaba en Ceuta dando la cara»
- Qué dicen las fuentes: La Moncloa registra su visita a Ceuta el 31-7-2026, con el ministro del Interior, al día siguiente del inicio de la entrada.
- Fuentes: <https://www.lamoncloa.gob.es/lang/en/presidente/news/Paginas/2026/20260731-visit-to-ceuta.aspx> · <https://www.lamoncloa.gob.es/presidente/actividades/paginas/2026/310726-sanchez-reunion-coordinacion-ceuta.aspx> · <https://www.esdiario.com/nacional/260801/194612/ceuta-mareta-sanchez-arranca-vacaciones-semana-incendios-crisis-migratoria.html>
- Fuente abierta: no (solo extracto) · Grupo: `visitas_ceuta`

**47:44 · Hay un cable eléctrico entre la península y Ceuta.** (hecho)

- Cita literal: «un cable de electricidad de la península a la ciudad autónoma de Ceuta»
- Qué dicen las fuentes: La interconexión eléctrica submarina Península-Ceuta (132 kV, entre Cádiz y Ceuta) empezó a construirse en junio de 2024 y está energizada y en servicio según Redeia.
- Fuentes: <https://www.datacenterdynamics.com/es/noticias/redeia-activa-el-cable-submarino-que-conecta-ceuta-con-la-pen%C3%ADnsula/> · <https://www.smartgridsinfo.es/2024/06/12/arranca-construccion-proyecto-interconexion-electrica-ceuta-peninsula>
- Fuente abierta: no (solo extracto)

**49:16 · El presidente de Ceuta pidió un mando único, que está en vigor.** (hecho)

- Cita literal: «el presidente de Ciudad Autónoma de Ceuta me pidió el que pudiéramos crear un mando único»
- Qué dicen las fuentes: Vivas pidió un mando único el 30 de julio (Maldita). El Gobierno lo creó el 25 de agosto al declarar la «situación de interés para la seguridad nacional» (Real Decreto 681/2026), vigente por ahora hasta el 31-12-2026.
- Fuentes: <https://www.lamoncloa.gob.es/presidente/actividades/Paginas/2026/030926-sanchez-comparecencia-ceuta.aspx> · <https://maldita.es/control-del-poder/20260915/gobierno-normalidad-ceuta-mando-unico/> · <https://www.esdiario.com/nacional/260825/196063/sanchez-seguridad-nacional-ceuta.html> · <https://www.lamoncloa.gob.es/serviciosdeprensa/notasprensa/economia-comercio-empresa/paginas/2026/250826-mando-unico-ceuta.aspx>
- Fuente abierta: sí · Grupo: `mando_unico`

**49:26 · El mando único tardó veintitantos días en crearse.** (cifra)

- Cita literal: «Bueno, esos 20 días, esos 20 y tantos días.»
- Qué dicen las fuentes: De la petición (30 de julio) a la creación (25 de agosto) pasaron 26 días.
- Fuentes: <https://www.lamoncloa.gob.es/presidente/actividades/Paginas/2026/030926-sanchez-comparecencia-ceuta.aspx> · <https://maldita.es/control-del-poder/20260915/gobierno-normalidad-ceuta-mando-unico/> · <https://www.esdiario.com/nacional/260825/196063/sanchez-seguridad-nacional-ceuta.html> · <https://www.lamoncloa.gob.es/serviciosdeprensa/notasprensa/economia-comercio-empresa/paginas/2026/250826-mando-unico-ceuta.aspx>
- Fuente abierta: sí · Grupo: `mando_unico`

**49:52 · Estaba con su familia en otra residencia oficial, no en la Moncloa.** (hecho)

- Cita literal: «Estaba con mi familia en otra residencia oficial del gobierno»
- Qué dicen las fuentes: Estuvo en La Mareta (Lanzarote), residencia oficial que usa el presidente en verano. Mismas fuentes que en la comprobación de Feijóo.
- Fuentes: <https://www.elespanol.com/espana/politica/20260801/sanchez-comparte-playlist-verano-plena-crisis-ceuta-seguro-dan-idea-voy/1003744341448_0.html> · <https://www.esdiario.com/nacional/260801/194612/ceuta-mareta-sanchez-arranca-vacaciones-semana-incendios-crisis-migratoria.html>
- Fuente abierta: no (solo extracto) · Grupo: `vacaciones`

**54:25 · La regularización benefició sobre todo a latinoamericanos; primera nacionalidad, la colombiana.** (hecho)

- Cita literal: «Era una población migrante Latinoamericana, la primera nacionalidad Colombiana»
- Qué dicen las fuentes: Balance oficial: Colombia es la primera nacionalidad (25,9 % de las solicitudes), seguida de Marruecos (13,3 %), Venezuela (11,8 %), Perú (8,8 %) y Honduras (4,9 %); elDiario.es cifra en el 67 % las solicitudes de latinoamericanos. El plazo cerró el 30-6-2026.
- Fuentes: <https://www.lamoncloa.gob.es/serviciosdeprensa/notasprensa/inclusion/Paginas/2026/020726-balance-regularizacion-extraordinaria.aspx> · <https://www.eldiario.es/desalambre/tercios-900-000-migrantes-han-pedido-regularizacion-son-latinoamericanos-mayoria-colombianos_1_13315436.html>
- Fuente abierta: sí · Grupo: `regularizacion`

**57:02 · Los migrantes usan los servicios públicos menos que el resto.** (comparacion)

- Cita literal: «el migrante es de la población que menos utiliza esos servicios públicos»
- Qué dicen las fuentes: Un informe del Ministerio de Sanidad (junio de 2026) concluye que los migrantes consumen menos recursos sanitarios que los españoles; estudios anteriores coinciden, con la excepción de las urgencias. El respaldo localizado es para la sanidad, no para todos los servicios públicos, y la diferencia se explica en parte por la edad.
- Fuentes: <https://www.lamoncloa.gob.es/serviciosdeprensa/notasprensa/sanidad14/Paginas/2026/010626-sanidad-informe-migrantes.aspx> · <https://www.consumer.es/salud/los-inmigrantes-usan-la-sanidad-publica-menos-que-los-espanoles-y-de-forma-distinta-segun-sendos-estudios.html>
- Fuente abierta: no (solo extracto)

**60:30 · La migración irregular es entre el 5 y el 10 % del total.** (cifra)

- Cita literal: «probablemente estemos hablando de entre un 5 y un 10 % como mucho»
- Qué dicen las fuentes: Funcas estima 840.000 extranjeros en situación irregular a 1-1-2025: en torno al 9 % de los casi 10 millones de nacidos en el extranjero (cálculo propio) y el 17,2 % de los extranjeros no comunitarios. Encaja con «entre el 5 y el 10 %» sobre el total de inmigrantes; la estimación es anterior a la regularización.
- Fuentes: <https://www.funcas.es/wp-content/uploads/2026/01/NOTAPRENSA-7.pdf> · <https://www.vozpopuli.com/economia/la-llegada-de-inmigrantes-irregulares-se-dispara-un-700-y-alcanza-los-840-000.html>
- Fuente abierta: no (solo extracto)

**64:53 · La criminalidad en España es baja frente a Alemania, Francia, Finlandia o Suecia.** (comparacion)

- Cita literal: «tenemos unos índices de criminalidad bastante bajos»
- Qué dicen las fuentes: España tiene una de las tasas de homicidio más bajas de la UE (0,69 por 100.000, Eurostat 2023) y una criminalidad convencional de 40,4 delitos por mil habitantes (Interior, 2025); para Alemania se cita una tasa de 6,1 por cien. Eurostat no publica una tasa total homogénea y no localicé datos de Finlandia: la comparación es orientativa.
- Fuentes: <https://elordenmundial.com/mapas-y-graficos/seguridad-espana-crimen/> · <https://elordenmundial.com/mapas-y-graficos/tasa-homicidios-ue/>
- Fuente abierta: no (solo extracto)

**65:34 · Medio millón de los regularizados ya trabaja y cotiza.** (cifra)

- Cita literal: «medio millón de ellas ya está trabajando y cotizando a la Seguridad Social»
- Qué dicen las fuentes: La ministra Saiz cifró en 490.586 los afiliados extranjeros en alta procedentes de la regularización a finales de octubre de 2026.
- Fuentes: <https://www.democrata.es/economia/el-empleo-logra-su-mejor-octubre-historico-por-el-tiron-del-curso-escolar-y-la-regularizacion/> · <https://www.bbvaresearch.com/publicaciones/espana-la-regularizacion-contribuyo-a-incrementar-la-afiliacion-y-el-paro-en-oct-26/>
- Fuente abierta: no (solo extracto) · Grupo: `regularizacion`

**65:44 · La tasa de paro de los españoles ha bajado estos años.** (hecho)

- Cita literal: «la tasa de paro de los nacionales durante estos años ha bajado»
- Qué dicen las fuentes: La tasa de paro general ha bajado con fuerza (10,25 % en el tercer trimestre de 2026; la prensa habla de una reducción a la mitad en diez años). No abrí el desglose por nacionalidad de la EPA, que es lo que mide exactamente la frase.
- Fuentes: <https://www.elindependiente.com/economia/2025/11/23/espana-reduce-mitad-tasa-paro-diez-anos-sigue-liderando-desempleo-union-europea/amp/> · <https://www.ine.es/dyngs/Prensa/EPA3T26.pdf>
- Fuente abierta: no (solo extracto)

**68:10 · La organización criminal son tres personas (Ábalos, Koldo y Aldama).** (hecho)

- Cita literal: «estamos hablando de esas tres personas»
- Qué dicen las fuentes: Los tres condenados por organización criminal son Ábalos (24 años y 3 meses), Koldo García (19 años y 8 meses) y Víctor de Aldama (4 años y 6 meses, con la pena suspendida).
- Fuentes: <https://www.poderjudicial.es/cgpj/es/Poder-Judicial/Tribunal-Supremo/Noticias-Judiciales/El-Tribunal-Supremo-condena-al-exministro-Jose-Luis-Abalos-y-a-su-exasesor-Koldo-Garcia-a-24-anos-y-19-anos-de-prision--respectivamente--por-delitos-de-organizacion-criminal--cohecho--malversacion-y-trafico-de-influencias>
- Fuente abierta: sí · Grupo: `condena_abalos`

**72:00 · Exigió a Ábalos el acta de diputado.** (voto_o_decision)

- Cita literal: «la decisión de exigirle a José Luis Ábalos el acta»
- Qué dicen las fuentes: En febrero de 2024, al estallar el caso Koldo, el PSOE exigió a Ábalos que entregara el acta en 24 horas; se negó y pasó al Grupo Mixto.
- Fuentes: <https://www.elindependiente.com/espana/2024/02/28/sanchez-presume-de-la-caida-de-abalos-por-el-caso-koldo-y-acusa-a-feijoo-de-ser-el-quien-tapa-la-corrupcion/> · <https://www.infobae.com/espana/2024/02/28/abalos-se-da-el-dia-libre-y-pone-el-foco-sobre-pedro-sanchez-en-el-congreso-con-feijoo-en-tromba-usted-lo-sabia-y-lo-oculto/>
- Fuente abierta: no (solo extracto)

**72:22 · En 2021, tras perder en Madrid, renovó el Gobierno.** (hecho)

- Cita literal: «después de unas elecciones en donde nos llevamos un revolcón en la Comunidad de Madrid»
- Qué dicen las fuentes: La remodelación del Gobierno se anunció el 10-7-2021, dos meses después de las elecciones madrileñas del 4 de mayo.
- Fuentes: <https://es.ara.cat/politica/pedro-sanchez-remodela-gobierno-prescinde-calvo-asciende-calvino-primera-vicepresidenta_1_4049768.html> · <https://diariodeavisos.elespanol.com/2021/07/sanchez-revoluciona-el-gobierno-saca-a-calvo-abalos-laya-campo-celaa-uribes-y-a-redondo/>
- Fuente abierta: no (solo extracto) · Grupo: `remodelacion_2021`

**72:42 · Quitó a Ábalos de la Secretaría de Organización, sin expulsarlo del partido.** (voto_o_decision)

- Cita literal: «No, le saco del secretario de Organización. No, no, no le expulso del partido.»
- Qué dicen las fuentes: En julio de 2021 Ábalos dejó la secretaría de Organización pero siguió como militante y diputado; la expulsión definitiva del partido llegó en 2025.
- Fuentes: <https://es.ara.cat/politica/pedro-sanchez-remodela-gobierno-prescinde-calvo-asciende-calvino-primera-vicepresidenta_1_4049768.html> · <https://diariodeavisos.elespanol.com/2021/07/sanchez-revoluciona-el-gobierno-saca-a-calvo-abalos-laya-campo-celaa-uribes-y-a-redondo/> · <https://rtvc.es/sanchez-pide-perdon-y-garantiza-que-el-psoe-derrotara-la-corrupcion/>
- Fuente abierta: no (solo extracto) · Grupo: `remodelacion_2021`

**73:35 · Pidió perdón y asumió la responsabilidad.** (hecho)

- Cita literal: «Oye, yo pedí perdón, asumí esa responsabilidad.»
- Qué dicen las fuentes: El 12-6-2025, tras el informe de la UCO sobre Cerdán, Sánchez pidió perdón a la ciudadanía y después a la militancia en el comité federal.
- Fuentes: <https://rtvc.es/sanchez-pide-perdon-y-garantiza-que-el-psoe-derrotara-la-corrupcion/> · <https://www.catalannews.com/politics/item/spanish-pm-apologizes-and-unveils-anti-corruption-plan-to-rebuild-trust>
- Fuente abierta: no (solo extracto)

**74:48 · Un comité federal lo apartó de la Secretaría General.** (hecho)

- Cita literal: «Yo tengo un comité federal donde en el partido me echan y me quitan como secretario general»
- Qué dicen las fuentes: El 1-10-2016 el comité federal rechazó su propuesta de congreso por 132 votos a 107 y Sánchez dimitió como secretario general.
- Fuentes: <https://orain.eus/es/politica/2016/10/01/pedro-sanchez-dimite-secretario-general-psoe/> · <https://theobjective.com/espana/2016-10-01/pedro-sanchez-dimite-como-secretario-general-del-psoe/>
- Fuente abierta: no (solo extracto) · Grupo: `octubre_2016`

**74:55 · Dimitió como diputado para no facilitar la investidura de Rajoy.** (voto_o_decision)

- Cita literal: «Y dimito también como diputado para no asumir una decisión que toma el partido»
- Qué dicen las fuentes: El 29-10-2016 renunció a su escaño para no tener que abstenerse en la investidura de Rajoy.
- Fuentes: <https://diariodeavisos.elespanol.com/2016/10/sanchez-renuncia-acta-diputado-no-facilitara-gobierno-rajoy/> · <https://orain.eus/es/politica/2016/10/29/pedro-sanchez-entrega-su-acta-diputado/>
- Fuente abierta: no (solo extracto) · Grupo: `octubre_2016`

**76:02 · 2014 fue antes de su primera elección como secretario general.** (hecho)

- Cita literal: «En 2014 fue precisamente antes de mi primera elección»
- Qué dicen las fuentes: La entrada es del 24-6-2014, durante la campaña de primarias; fue elegido secretario general en julio de 2014.
- Fuentes: <https://www.vozpopuli.com/espana/politica/koldo-garcia-hombre-durmio-urnas-sanchez-narra-presidente-mision-manual-resistencia.html> · <https://www.vozpopuli.com/dolcevita/asi-es-koldo-garcia-su-expareja-patricia-uriz-sus-hijos-condena-y-los-trapos-sucios-que-destapo-su-primera-mujer.html>
- Fuente abierta: no (solo extracto) · Grupo: `elogios_koldo`

**78:15 · De todos sus ministros, solo uno (Ábalos) está afectado.** (hecho)

- Cita literal: «a nivel ministerial estamos hablando de una persona, de José Luis Ábalos»
- Qué dicen las fuentes: En las búsquedas no localicé a ningún otro ministro o exministro de sus gobiernos imputado o condenado además de Ábalos. Los demás casos afectan a Cerdán (secretario de Organización, no ministro), al expresidente Zapatero y a familiares. Búsqueda no exhaustiva.
- Fuentes: <https://www.articulo14.es/politica/los-casos-de-corrupcion-que-marcaron-la-era-sanchez-de-abalos-al-caso-de-su-mujer-20261005.html> · <https://www.internazionale.it/ultime-notizie-reuters/2026/05/29/factbox-the-court-cases-plaguing-spain-s-ruling-socialist-party>
- Fuente abierta: no (solo extracto)

**81:36 · Leire Díez declaró en el Senado y ante la justicia que nunca se reunió con él.** (cita_de_tercero)

- Cita literal: «lo que ha dicho es que no ha tenido nunca una»
- Qué dicen las fuentes: Ante el juez declaró que solo había coincidido con Sánchez en «actos electorales y de campaña» y rechazó haberse reunido con él; en el Senado (8-9-2025) dijo que nunca había hablado con él.
- Fuentes: <https://www.vozpopuli.com/tribunales/el-video-de-leire-diez-ante-el-juez-solo-he-coincidido-con-sanchez-en-actos-electorales.html> · <https://www.elindependiente.com/espana/2025/09/08/leire-diez-niega-relacion-santos-cerdan-politica-personal-militante/amp/>
- Fuente abierta: sí · Grupo: `leire`

**81:59 · En la pandemia se creó un fondo de rescate de empresas a través de la SEPI.** (hecho)

- Cita literal: «nosotros durante la pandemia articulamos un fondo a través de la sociedad estatal, SEPI»
- Qué dicen las fuentes: En 2020 se creó el Fondo de Apoyo a la Solvencia de Empresas Estratégicas, gestionado por la SEPI y dotado con hasta 10.000 millones.
- Fuentes: <https://www.hosteltur.com/176362_prestamos-sepi-cuanto-han-devuelto-air-europa-air-nostrum-volotea-y-plus-ultra.html> · <https://www.publico.es/economia/fondo-rescate-sepi-cierra-labor-67-dinero-gastar.html> · <https://forbes.es/turismo/519324/el-fondo-de-solvencia-de-sepi-recibe-la-devolucion-total-de-los-85-millones-de-ayuda-concedida-al-grupo-wamos/>
- Fuente abierta: no (solo extracto) · Grupo: `sepi`

**83:08 · En un registro (Policía Nacional, UDEF) aparecieron joyas.** (hecho)

- Cita literal: «el tema de las joyas que aparecen cuando se le hace el registro»
- Qué dicen las fuentes: La UDEF halló el 19-5-2026 una caja fuerte con 103 objetos en el despacho de Zapatero; la tasación pedida por el juez los valoró en 1,3 millones. Mismo hecho y fuentes que en la comprobación de la entrevista a Colau.
- Fuentes: <https://www.eldebate.com/espana/20260611/joyas-intervenidas-zapatero-tienen-valor-13-millones-euros-segun-tasacion-pidio-juez_427835.html> · <https://es.euronews.com/my-europe/2026/06/11/tasacion-eleva-millones-euros-valor-joyas-zapatero>
- Fuente abierta: no (solo extracto) · Grupo: `zapatero`

**85:42 · En Manresa el metro cuadrado está a 1.500 euros.** (cifra)

- Cita literal: «Manresa, 1 .500 euros metro cuadrado»
- Qué dicen las fuentes: Manresa: 1.441 euros/m² según Tinsa (segundo trimestre de 2026) y 1.483 según RealAdvisor (julio de 2026).
- Fuentes: <https://www.tinsa.es/precio-vivienda/catalunya/barcelona/manresa/> · <https://realadvisor.es/es/precios-viviendas/municipio-manresa>
- Fuente abierta: no (solo extracto) · Grupo: `manresa_malaga`

**85:47 · En Málaga el metro cuadrado está a 4.000 euros.** (cifra)

- Cita literal: «Málaga 4 .000 euros el metro cuadrado»
- Qué dicen las fuentes: Málaga capital: 3.938 euros/m² según idealista (agosto de 2026, máximo histórico). Otras fuentes dan 4.304 (Brains, precios de oferta) y 3.111 (Gesvalt, tasaciones).
- Fuentes: <https://www.idealista.com/news/node/909783> · <https://www.merca2.es/2026/06/10/precio-vivienda-malaga-record-3755-idealista-2394122/>
- Fuente abierta: no (solo extracto) · Grupo: `manresa_malaga`

**87:36 · Aprobaron una ley estatal que permite intervenir precios en zonas tensionadas.** (voto_o_decision)

- Cita literal: «Nosotros aprobamos una ley estatal que permitía, por ejemplo, a las comunidades autónomas y a los ayuntamientos»
- Qué dicen las fuentes: La Ley 12/2023 por el derecho a la vivienda permite declarar zonas de mercado tensionado y limitar en ellas los precios con el índice de referencia, a petición de las comunidades autónomas.
- Fuentes: <https://maldita.es/malditateexplica/20240315/indice-precios-alquiler-ministerio-vivienda/> · <https://www.lamoncloa.gob.es/serviciosdeprensa/notasprensa/vivienda-agenda-urbana/paginas/2024/150324-indice-precios-alquiler-areas-tensionadas.aspx>
- Fuente abierta: no (solo extracto)

**88:03 · La construcción de vivienda está en máximos desde la crisis financiera.** (comparacion)

- Cita literal: «en construcción de vivienda en máximos desde la crisis financiera del año 2011»
- Qué dicen las fuentes: Los visados de obra nueva sumaron 139.016 viviendas en 2025 (un 8,8 % más), por encima de los de 2024, que ya eran el máximo desde 2008. La transcripción dice «crisis financiera del año 2011».
- Fuentes: <https://www.idealista.com/news/inmobiliario/construccion/2025/02/27/834302-los-visados-de-obra-nueva-marcan-maximos-desde-2008> · <https://www.cronista.com/espana/economia-finanzas/el-sueno-de-la-casa-propia-ya-es-una-realidad-los-visados-para-vivienda-crecen-por-quinto-ano-consecutivo-y-marcan-record-desde-la-crisis>
- Fuente abierta: no (solo extracto)

**88:09 · Han multiplicado por 8 el presupuesto de vivienda.** (cifra)

- Cita literal: «Hemos multiplicado por 8 el presupuesto en vivienda.»
- Qué dicen las fuentes: Es la cifra que da el propio Gobierno: de unos 400 millones en los Presupuestos de 2018 a unos 4.000 millones. No localicé una verificación independiente ni el detalle de las partidas que se comparan.
- Fuentes: <https://www.lamoncloa.gob.es/presidente/intervenciones/paginas/2025/20250113-acto-vivienda.aspx> · <https://www.vozpopuli.com/espana/politica/moncloa-exige-un-esfuerzo-en-vivienda-a-madrid-tras-aportar-solo-19-millones-en-5-anos.html>
- Fuente abierta: no (solo extracto) · Grupo: `presupuesto_vivienda`

**89:55 · Hay reales decretos leyes de vivienda pendientes de convalidar esta semana.** (hecho)

- Cita literal: «con los reales decretos leyes que espero que se puedan convalidar esta semana»
- Qué dicen las fuentes: La Diputación Permanente del Congreso tenía previsto votar el jueves 12-11-2026 la convalidación de dos decretos-leyes de vivienda (28/2026 y 29/2026). No comprobé el resultado de esa votación.
- Fuentes: <https://www.democrata.es/politica/el-congreso-preve-decidir-sobre-los-decretos-de-vivienda-justo-tras-la-huelga-general-y-en-la-antesala-de-la-campana/> · <https://www.bankinter.com/blog/finanzas-personales/decreto-vivienda-2026-medidas>
- Fuente abierta: no (solo extracto)

**90:41 · Hay unas 120.000-130.000 viviendas "entregadas o en proceso" ("millones" en la transcripción).** (cifra)

- Cita literal: «120, 130 .000 millones.»
- Qué dicen las fuentes: La web del Ministerio de Vivienda daba 120.479 viviendas «movilizadas en diferentes fases» en febrero de 2026, cifra que encaja con «120-130.000». No distingue entregadas de en construcción, que es lo que se le preguntaba. «Millones» es un error de la transcripción.
- Fuentes: <https://www.elindependiente.com/economia/2026/02/17/sanchez-anuncios-viviendas-desde-2023/> · <https://www.lamoncloa.gob.es/serviciosdeprensa/notasprensa/vivienda-agenda-urbana/Paginas/2024/130824-gobierno-viviendas-alquiler-asequible.aspx>
- Fuente abierta: sí · Grupo: `184000`

**90:56 · Se ha creado la empresa pública Casa 47, que recibe las viviendas del "banco malo".** (hecho)

- Cita literal: «crear una empresa pública que se llama Casa 47»
- Qué dicen las fuentes: Casa 47 es la nueva empresa estatal de vivienda; recibe unas 40.000 viviendas y 2.400 suelos de la Sareb y tiene abierta la solicitud en su web.
- Fuentes: <https://www.lamoncloa.gob.es/serviciosdeprensa/notasprensa/vivienda-agenda-urbana/Paginas/2026/solicitud-casa-47.aspx> · <https://www.idealista.com/news/node/896145> · <https://www.eldiario.es/economia/casa-47-nueva-empresa-publica-vivienda-suelo-echa-andar_1_12842696.amp.html>
- Fuente abierta: no (solo extracto)

**92:39 · En Barcelona y otras zonas de Cataluña donde se aplica la ley de vivienda se contiene el precio del alquiler.** (hecho)

- Cita literal: «se están conteniendo la evolución del precio de los alquileres»
- Qué dicen las fuentes: Datos de la Generalitat (fianzas del Incasòl, primer trimestre de 2026): el precio de los contratos nuevos bajó un 1,28 % en las zonas tensionadas desde marzo de 2024 y subió un 9,53 % en el resto; en Barcelona cayó un 6,4 % el primer año. Fedea ve moderación de precios; otras fuentes subrayan la caída de la oferta y que se alquilan pisos más pequeños.
- Fuentes: <https://es.ara.cat/economia/inmobiliario/topes-alquileres-bajan-precios-camara-propiedad-dice-efecto-positivo-transitorio_1_5797699.html> · <https://www.ultimahora.es/noticias/comunidades/2025/03/14/2345525/alquiler-baja-catalunya-barcelona-tras-ano-regulacion.html> · <https://www.idealista.com/news/node/903549>
- Fuente abierta: no (solo extracto)

**93:19 · Antes de la crisis financiera se construyeron 4,5 millones de viviendas y los precios se dispararon.** (cifra)

- Cita literal: «Antes de la crisis financiera, en España se construyeron 4 ,5 millones de»
- Qué dicen las fuentes: El orden de magnitud coincide: más de 5,5 millones de viviendas iniciadas entre 1997 y 2006 y una media de 493.000 terminadas al año entre 1998 y 2005, mientras los precios de tasación subían más de un 195 %. No precisa el periodo.
- Fuentes: <https://www.idealista.com/news/node/5241> · <https://elordenmundial.com/mapas-y-graficos/ladrillazo-vivienda-protegida-evolucion-construccion-espana/>
- Fuente abierta: no (solo extracto)

**99:15 · No ha gobernado con Bildu.** (hecho)

- Cita literal: «yo no he gobernado con Bildu ahora»
- Qué dicen las fuentes: EH Bildu no ha formado parte de ningún Gobierno de Sánchez; ha sido socio parlamentario.
- Fuentes: <https://theobjective.com/espana/politica/2023-08-15/maria-chivite-presidenta-navarra-bildu/> · <https://www.elespanol.com/espana/politica/20230810/militancia-bildu-avala-investir-chivite-presidenta-navarra-abstencion/785671444_0.amp.html>
- Fuente abierta: no (solo extracto) · Grupo: `bildu`

**99:35 · No ha pactado un gobierno con Bildu en Euskadi ni en Navarra.** (hecho)

- Cita literal: «yo no he pactado un gobierno en Euskadi ni en Navarra»
- Qué dicen las fuentes: En Navarra, EH Bildu facilitó con su abstención la investidura de Chivite (2019 y 2023) pero no entró en el Gobierno. En Euskadi el PSE gobierna con el PNV (no se buscó de forma específica). La excepción municipal es Pamplona.
- Fuentes: <https://theobjective.com/espana/politica/2023-08-15/maria-chivite-presidenta-navarra-bildu/> · <https://www.elespanol.com/espana/politica/20230810/militancia-bildu-avala-investir-chivite-presidenta-navarra-abstencion/785671444_0.amp.html>
- Fuente abierta: no (solo extracto) · Grupo: `bildu`

**100:13 · Lo que dijo es que le quitaba el sueño que Podemos llevara la Seguridad Social o Hacienda.** (hecho)

- Cita literal: «lo que me quitaba el sueño es que, por ejemplo, la Seguridad Social o la Hacienda la llevara a Podemos»
- Qué dicen las fuentes: El 19-9-2019 dijo en laSexta que con ministros de Podemos sin experiencia al frente de Hacienda, la política energética o la Seguridad Social sería «un presidente del Gobierno que no dormiría por la noche, junto con el 95 % de los ciudadanos» (transcripción oficial).
- Fuentes: <https://www.lamoncloa.gob.es/presidente/intervenciones/Paginas/2019/prsp190919.aspx> · <https://www.elindependiente.com/politica/2019/09/19/sanchez-el-95-de-los-espanoles-no-dormiria-con-podemos-en-el-gobierno/amp/>
- Fuente abierta: sí · Grupo: `iglesias`

**100:43 · Tras la repetición electoral el PP no facilitó la formación de gobierno.** (voto_o_decision)

- Cita literal: «el Partido Popular, por supuesto, no apoyó ni facilitó la formación de un gobierno»
- Qué dicen las fuentes: En la investidura del 7-1-2020, tras la repetición electoral, el PP (88 diputados) votó en contra; Sánchez fue investido por 167 a 165. El PSOE había sido primera fuerza el 10-N.
- Fuentes: <https://maldita.es/malditodato/20200107/sanchez-consigue-ser-presidente-en-la-votacion-mas-ajustada-de-la-democracia-asi-han-sido-las-distintas-votaciones-de-investidura-desde-1979/>
- Fuente abierta: no (solo extracto) · Grupo: `repeticion_2019`

**100:59 · El Gobierno llevó al Congreso una propuesta sobre la ley mordaza; decae con la legislatura.** (hecho)

- Cita literal: «hemos llevado una propuesta a los grupos parlamentarios en el Congreso»
- Qué dicen las fuentes: La reforma se tomó en consideración en octubre de 2024 con apoyo del Gobierno y sus socios y, según elDiario.es, el Gobierno presentó en 2025 su propio proyecto; la ponencia no se reunió en 2026 y la iniciativa decae con la disolución de las Cortes.
- Fuentes: <https://www.eldiario.es/1_caa1d7> · <https://www.eldiario.es/1_ccf72d> · <https://www.que.es/2024/10/29/el-congreso-busca-tramitar-con-urgencia-la-reforma-de-la-ley-mordaza/>
- Fuente abierta: no (solo extracto) · Grupo: `mordaza`

**101:46 · Tiene 121 escaños desde 2023.** (cifra)

- Cita literal: «si en lugar de tener 121 escaños»
- Qué dicen las fuentes: El PSOE obtuvo 121 escaños en las generales del 23-7-2023.
- Fuentes: <https://www.elindependiente.com/espana/2023/07/23/resultados-del-23-j/amp/>
- Fuente abierta: no (solo extracto)

**106:15 · Apoyó al PP desde la oposición en la crisis de 2017 y no recibió el mismo apoyo después.** (voto_o_decision)

- Cita literal: «yo les he apoyado cuando he estado en la oposición»
- Qué dicen las fuentes: El PSOE apoyó al Gobierno de Rajoy en la aplicación del 155 (2017). El PP votó después contra los indultos y la amnistía; esa segunda parte no se buscó de forma específica.
- Fuentes: <https://theobjective.com/rajoy-defiende-ante-el-senado-la-aplicacion-del-articulo-155/> · <https://orain.eus/es/politica/2017/10/27/las-medidas-del-articulo-155-a-votacion-en-senado/>
- Fuente abierta: no (solo extracto) · Grupo: `155`

**106:34 · Se especuló con que Feijóo llamaría a Puigdemont para una moción de censura con Vox.** (hecho)

- Cita literal: «que se especulara durante esta legislatura con que Feijóo iba a llamar a Puigdemont para hacer una moción de censura»
- Qué dicen las fuentes: Feijóo planteó en junio de 2026 una moción de censura «instrumental» con PNV y Junts, y Junts le retó a negociarla con Puigdemont en Waterloo; el PP respondió que no viajaría a verle. La idea ya había circulado en 2024 y 2025.
- Fuentes: <https://www.eldiario.es/politica/feijoo-arenga-pnv-junts-apoyarle-mocion-censura-pedro-sanchez-hagamoslo_1_13314673.amp.html> · <https://es.ara.cat/politica/junts-reta-feijoo-reunirse-puigdemont-oferta-seria-mocion-explique-waterloo_1_5755603.html> · <https://maldita.es/malditateexplica/20240604/feijoo-mocion-censura-sanchez-junts/>
- Fuente abierta: no (solo extracto)

**106:57 · Fue a una repetición electoral por no pactar con Pablo Iglesias.** (hecho)

- Cita literal: «yo fui a una repetición electoral por no pactar con Pablo Iglesias»
- Qué dicen las fuentes: Tras fracasar en julio de 2019 la negociación de una coalición con Unidas Podemos, se repitieron las elecciones el 10-11-2019; en septiembre él mismo dijo que la propuesta de Iglesias era «inviable» y abocaba a la repetición.
- Fuentes: <https://www.eldiario.es/politica/sanchez-entrevista_1_1351546.amp.html> · <https://www.lamoncloa.gob.es/presidente/intervenciones/Paginas/2019/prsp190919.aspx>
- Fuente abierta: no (solo extracto) · Grupo: `repeticion_2019`

**107:19 · Prometió subir el salario mínimo y lo subió.** (hecho)

- Cita literal: «dije que iba a subir el salario mínimo interprofesional y lo he subido»
- Qué dicen las fuentes: El salario mínimo pasó de 735,90 euros en 2018 a 1.221 en 2026 (14 pagas). Mismo dato y fuente que en la comprobación de la entrevista a Colau.
- Fuentes: <https://www.lamoncloa.gob.es/presidente/actividades/Paginas/2026/160226-sanchez-subida-salario-minimo.aspx>
- Fuente abierta: no (solo extracto)

**107:28 · Prometió revalorizar las pensiones con el IPC y lo hizo.** (hecho)

- Cita literal: «Dije que iba a regularizar las pensiones conforme al IPC y lo he hecho.»
- Qué dicen las fuentes: La Ley 21/2021 (en vigor desde 2022) liga la revalorización anual de las pensiones al IPC medio. En la transcripción dice «regularizar» por revalorizar.
- Fuentes: <https://www.elindependiente.com/economia/2021/12/02/el-congreso-aprueba-la-primera-reforma-de-pensiones-que-las-vuelve-a-subir-con-el-ipc/amp/> · <https://www.que.es/2021/11/10/escriva-revalorizacion-pensiones-ipc-garantizada/>
- Fuente abierta: no (solo extracto)

**107:33 · Dijo no a Trump al 5 % en defensa y lo ha mantenido.** (hecho)

- Cita literal: «Le dije al señor Trump que no al 5 % del presupuesto de defensa y lo he mantenido.»
- Qué dicen las fuentes: España fijó su gasto en el 2,1 % del PIB en junio de 2025 y lo mantenía ante la cumbre de la OTAN de Ankara (julio de 2026), con Trump «decepcionado». Matiz ya recogido en la comprobación de Feijóo: Sánchez firmó la declaración de La Haya, que fija el 5 % para 2035 como compromiso aliado, con una carta de Rutte que admite una senda inferior para España.
- Fuentes: <https://www.noticiasdenavarra.com/politica/2026/07/05/sanchez-mantendra-pulso-gasto-defensa-trump-11286852.amp.html> · <https://www.eldiario.es/internacional/pedro-sanchez-compromete-gastar-2-1-pib-defensa_1_12405692.amp.html> · <https://www.publico.es/internacional/aliados-otan-confirman-compromiso-aumentar-gasto-militar-5-pib.html>
- Fuente abierta: no (solo extracto)

**111:28 · El Papa ha votado.** (hecho)

- Cita literal: «Venga, yo diría, oye, hasta el Papa ha votado.»
- Qué dicen las fuentes: El Vaticano confirmó el 30-10-2026 que León XIV votó por correo en las elecciones de medio mandato de Estados Unidos; es el primer papa que lo hace.
- Fuentes: <https://www.primicias.ec/internacional/leon-xiv-voto-correo-elecciones-intermedias-vaticano-estados-unidos-136064/> · <https://lapatilla.com/2026/11/06/estoy-orgulloso-de-ser-americano-leon-xiv-defendio-su-voto-en-las-elecciones-de-eeuu/>
- Fuente abierta: no (solo extracto)

### No verificable (2)

**13:27 · Él no ha insultado ni a Feijóo ni a Abascal.** (hecho)

- Cita literal: «por mi parte no ha habido insultos al jefe de la oposición ni tampoco al líder de Vox»
- Qué dicen las fuentes: Depende de qué se considere insulto. En las búsquedas no localicé un insulto literal de Sánchez a Feijóo o Abascal (sí descalificaciones políticas: «amenaza para la democracia», «todo usted es mentira»); un medio crítico publica una «lista de insultos» de Sánchez al PP. No hay fuente pública que permita zanjarlo.
- Fuentes: <https://www.esdiario.com/nacional/240522/137358/lista-insultos-sanchez-al-pp.html> · <https://www.esdiario.com/nacional/260909/197273/feijoo-abascal-cercan-sanchez-marruecos-responde-sere-perro-amo_amp.html>
- Fuente abierta: no (solo extracto)

**81:02 · No ha tenido ninguna reunión con Leire Díez.** (hecho)

- Cita literal: «con Leire Díez no he tenido ninguna reunión como presidente del gobierno»
- Qué dicen las fuentes: No hay fuente pública que permita comprobarlo. El Gobierno lo niega «tajantemente»; el juez investiga una anotación «Reunión P.S.» en una libreta de Díez y mensajes suyos sobre supuestas felicitaciones.
- Fuentes: <https://www.eldebate.com/espana/20260609/gobierno-niega-reuniones-entre-sanchez-leire-como-nego-tres-directora-guardia-civil_426818.html> · <https://www.que.es/2026/06/07/caso-leire-diez-moncloa-desmiente/>
- Fuente abierta: no (solo extracto) · Grupo: `leire`

### No he podido comprobarlo (23)

**12:16 · El PSOE condenó esos ataques.** (hecho)

- Cita literal: «Y nosotros las hemos condenado. De hecho, fíjate, a propósito de la ley de amnistía»
- Qué dicen las fuentes: No localicé la condena del PSOE a los incidentes contra actos de Vox en esta campaña. En A Coruña, Abascal acusó a Sánchez de alentar los ataques.
- Fuentes: <https://www.moncloa.com/2026/10/21/abascal-protesta-coruna-detenidos-3452951/>
- Fuente abierta: no (solo extracto)

**15:28 · Se ha tardado 15 años en revertir los recortes en inversión ferroviaria de la etapa de Rajoy.** (cifra)

- Cita literal: «Hoy, 15 años hemos tardado en revertir esos recortes»
- Qué dicen las fuentes: No localicé una serie que permita comprobar los «15 años». Datos parciales: Artículo14 cifra el mantenimiento en unos 700 millones en 2011 y 1.370 en 2026; Maldita recoge, sin verificar, que la inversión cayó un 55,8 % con Rajoy y subió un 128 % después; El Debate sostiene que en términos reales la inversión en mantenimiento de alta velocidad es menor.
- Fuentes: <https://www.articulo14.es/economia/el-deterioro-de-la-alta-velocidad-en-siete-graficos-20261101.html> · <https://maldita.es/buloteca/claim/el-psoe-aumento-128-29-la-inversion-ferroviaria-mientras-que-durante-el-gobierno-de-rajoy-la-inversion-cayo-55-8> · <https://www.eldebate.com/economia/20260126/trampas-puente-graficos-inversion-real-mantener-red-alta-velocidad-menor-rajoy_378055.html>
- Fuente abierta: no (solo extracto)

**15:57 · En ocho años han multiplicado por 20 la inversión en esa línea.** (cifra)

- Cita literal: «nosotros hemos multiplicado por 20 durante estos últimos ocho años, por 20 la inversión»
- Qué dicen las fuentes: No localicé ninguna fuente con ese multiplicador. Datos próximos: la renovación integral de la línea Madrid-Sevilla se cifró en 650-668 millones (2023) y la Comisión Europea habla de 801,6 millones cofinanciados.
- Fuentes: <https://www.lamoncloa.gob.es/serviciosdeprensa/notasprensa/transportes/Paginas/2023/010323-infraestructuras-andalucia.aspx> · <https://ec.europa.eu/regional_policy/projects/projects-database/infrastructure-upgrades-on-the-madrid-seville-high-speed-railway_es>
- Fuente abierta: no (solo extracto)

**18:24 · Compromiso de invertir 19.000 millones entre 2026 y 2030 en mantenimiento de vías.** (cifra)

- Cita literal: «vamos a invertir 19 .000 millones de euros en el mantenimiento»
- Qué dicen las fuentes: No localicé la cifra de 19.000 millones. El acuerdo de Transportes con los sindicatos de febrero de 2026 recoge 5.266 millones (Adif) y 2.887 millones (Adif AV) en mantenimiento entre 2026 y 2030: unos 8.150 millones. Puede haber un anuncio posterior que no encontré.
- Fuentes: <https://www.deia.eus/economia/2026/02/09/claves-acuerdo-transportes-maquinistas-desconvocar-renfe-10680263.amp.html> · <https://www.articulo14.es/economia/gobierno-refuerza-seguridad-trenes-proteccion-profesionales-urda-tragedia-20261110.html>
- Fuente abierta: no (solo extracto)

**22:49 · La plantilla de ADIF y de controladores estaba bajo mínimos y la han elevado.** (hecho)

- Cita literal: «estaba bajo mínimos, es que lo hemos elevado de manera sustantiva»
- Qué dicen las fuentes: Datos contradictorios y parciales: Adif convocó 1.048 plazas en 2025 y 1.531 en 2026, pero las plazas de circulación de 2025 (203) fueron las más bajas desde 2020 y el sindicato de circulación denuncia turnos sin cubrir en el centro de Atocha; Vozpópuli cifra en un 3 % el aumento de plantilla entre 2017 y 2023. No localicé la serie de plantilla de controladores.
- Fuentes: <https://www.articulo14.es/economia/las-plazas-de-controladores-de-adif-cayeron-en-2025-a-su-nivel-mas-bajo-desde-2020-20261031.html> · <https://www.eldebate.com/economia/empleo/20260722/adif-busca-1531-trabajadores-cuantas-plazas-hay-demandan-como-solicitar-puesto-cns_442507.html> · <https://www.vozpopuli.com/economia/transporte/adif-en-la-era-sanchez-un-50-mas-de-viajeros-pero-solo-un-3-de-aumento-de-plantilla-para-mantener-la-red.html>
- Fuente abierta: no (solo extracto)

**25:45 · Óscar Puente dio una rueda de prensa de más de dos horas y media.** (cifra)

- Cita literal: «donde se cascó Oscar Puente más de dos horas y media de rueda de prensa»
- Qué dicen las fuentes: No localicé la duración de la rueda de prensa de Puente tras Urda (30-10-2026). La Moncloa habla de «casi dos horas» en la de enero por Adamuz, y la prensa de más de cuatro horas ante la Diputación Permanente el 3 de noviembre.
- Fuentes: <https://www.lamoncloa.gob.es/serviciosdeprensa/notasprensa/transportes-movilidad-sostenible/Paginas/2026/230126-obras-inspecciones-adamuz-accidente.aspx> · <https://www.articulo14.es/sociedad/tragedia-urda-en-directo-oscar-puente-no-dimite-directo-20261030.html> · <https://www.diaridetarragona.com/espana/274817/puente-dimite-sorpresa-6-dias-despues-urda-dura-comparecencia-congreso.html>
- Fuente abierta: no (solo extracto)

**26:05 · El PSOE no pidió la dimisión de Ana Pastor tras el accidente de Angrois.** (voto_o_decision)

- Cita literal: «el Partido Socialista, estando en la oposición, no pidió la dimisión de Ana Pastor»
- Qué dicen las fuentes: No localicé una fuente que confirme o desmienta que el PSOE no pidiera la dimisión de Ana Pastor. Sí consta que las víctimas la pidieron y que PP y PSOE rechazaron juntos en el Congreso las primeras peticiones de comisión de investigación.
- Fuentes: <https://www.eldiario.es/galicia/despropositos-angrois-2013-fallos-coordinacion-rescate-veto-feijoo-investigar-parlamento_1_12930424.amp.html> · <https://www.publico.es/actualidad/fomento-concluye-maquinista-unico-culpable-accidente-angrois.amp.html> · <https://www.esdiario.com/nacional/260211/179514/feijoo-acorrala-sanchez-adamuz-responde-risas-socialistas-cruda-realidad.html>
- Fuente abierta: no (solo extracto) · Grupo: `angrois`

**26:11 · Feijóo, presidente de la Xunta entonces, culpó al maquinista.** (hecho)

- Cita literal: «Por cierto, Fijo era el presidente de la Junta y acusó al trabajador, al»
- Qué dicen las fuentes: La versión oficial atribuyó el accidente al exceso de velocidad y al maquinista (Fomento, CIAF), pero no localicé una declaración de Feijóo culpándole. Sí consta que, como presidente de la Xunta, rechazó tres veces una investigación en el Parlamento gallego.
- Fuentes: <https://www.eldiario.es/galicia/despropositos-angrois-2013-fallos-coordinacion-rescate-veto-feijoo-investigar-parlamento_1_12930424.amp.html> · <https://www.publico.es/actualidad/fomento-concluye-maquinista-unico-culpable-accidente-angrois.amp.html> · <https://www.esdiario.com/nacional/260211/179514/feijoo-acorrala-sanchez-adamuz-responde-risas-socialistas-cruda-realidad.html>
- Fuente abierta: no (solo extracto) · Grupo: `angrois`

**30:06 · Es el presidente que más veces ha visitado Ceuta y Melilla en ejercicio.** (comparacion)

- Cita literal: «yo he sido el presidente del gobierno que más veces ha ido en ejercicio»
- Qué dicen las fuentes: Él mismo lo afirmó ya en la SER el 31-8-2026. La Moncloa documenta varias visitas (2022, 31-7-2026) y El Faro de Ceuta recoge una «tercera vez», pero no localicé un recuento que lo compare con otros presidentes.
- Fuentes: <https://es.euronews.com/2026/08/31/sanchez-vincula-a-rusia-israel-y-una-internacional-ultraderechista-con-los-bulos-de-ceuta> · <https://www.lamoncloa.gob.es/presidente/actividades/Paginas/2022/230222-sanchez-ceuta.aspx>
- Fuente abierta: sí · Grupo: `visitas_ceuta`

**39:21 · Desde el 20 de agosto han salido voluntariamente de Ceuta más de 15.000 personas.** (cifra)

- Cita literal: «han salido de Ceuta de manera voluntaria más de 15 .000 personas»
- Qué dicen las fuentes: No localicé la cifra de 15.000 salidas voluntarias desde el 20 de agosto.
- Fuente abierta: no (sin fuente localizada)

**39:37 · Esta semana se están desmantelando los centros de acogida temporal del puerto de Ceuta.** (hecho)

- Cita literal: «centros de acogida temporal en el puerto de Ceuta, pues los estamos desmantelando ya»
- Qué dicen las fuentes: No localicé noticias del desmantelamiento de los centros del puerto esta semana. Las últimas localizadas hablan de nuevos centros (Loma Margarita, La Hípica y parcelas del puerto).
- Fuentes: <https://diariodeavisos.elespanol.com/canariasenred/ceuta-loma-margarita-migrantes-acogida/>
- Fuente abierta: no (solo extracto)

**43:14 · Su Gobierno es el que más ha invertido en Ceuta y Melilla en democracia ("Berlín" en la transcripción).** (comparacion)

- Cita literal: «nosotros hemos sido el gobierno que más recursos económicos hemos invertido de la historia democrática en nuestro país en Ceuta y en Berlín»
- Qué dicen las fuentes: No localicé una serie de inversión del Estado en Ceuta y Melilla por gobiernos. Datos sueltos: plan integral de 2022 ampliado con 100 millones, paquete de 309 millones (16 % del PIB de Ceuta) el 1-9-2026 y 80 millones en fronteras en ocho años. La transcripción dice «Berlín» por Melilla.
- Fuentes: <https://www.lamoncloa.gob.es/presidente/actividades/Paginas/2026/030926-sanchez-comparecencia-ceuta.aspx> · <https://elfarodeceuta.es/marlaska-niega-cni-avisara-entrada-masiva-ceuta-confirma-72-000-personas-cruzaron-marruecos/>
- Fuente abierta: sí

**46:14 · Se aumentó la acogida temporal a más de 7.000 plazas.** (cifra)

- Cita literal: «aumentamos la capacidad de acogida temporal a más de 7000 plazas»
- Qué dicen las fuentes: No localicé las 7.000 plazas. Lo localizado: 1.800 plazas el 20 de agosto, más de 3.300 el 31 de agosto y un objetivo de 6.000 anunciado por él mismo ese día. Puede haber una cifra posterior que no encontré.
- Fuentes: <https://es.ara.cat/sociedad/inmigracion/ceuta-habilita-1-800-plazas-acoger-migrantes-dormian-calle_1_5827877.html> · <https://www.elespanol.com/espana/20260818/ceuta-teme-carpas-temporales-acoger-invasores-conviertan-permanentes/1003744355574_0.html> · <https://es.euronews.com/2026/08/31/sanchez-vincula-a-rusia-israel-y-una-internacional-ultraderechista-con-los-bulos-de-ceuta>
- Fuente abierta: sí · Grupo: `ceuta_acogida`

**47:34 · Han modernizado la terminal de Ceuta.** (hecho)

- Cita literal: «la terminal en Ceuta la hemos modernizado de arriba a abajo»
- Qué dicen las fuentes: No localicé la inauguración de la terminal (estación marítima) de Ceuta con Vivas.
- Fuente abierta: no (sin fuente localizada)

**50:22 · Cada día hubo un ministro en Ceuta.** (hecho)

- Cita literal: «cada día, hubo un ministro o ministra que estuvo en Ceuta»
- Qué dicen las fuentes: No localicé un registro de la presencia diaria de ministros en Ceuta. Sí constan visitas y desplazamientos de varios (Marlaska, Torres, Robles) y el envío de una delegación del Gobierno.
- Fuentes: <https://es.ara.cat/politica/gobierno-sanchez-rinde-cuentas-26-dias-despues-crisis-ceuta_1_5831446.html>
- Fuente abierta: no (solo extracto)

**51:11 · Los que entraron eran sobre todo menores.** (hecho)

- Cita literal: «porque realmente los que entraron eran sobre todo menores»
- Qué dicen las fuentes: No hay una composición por edad del total de entradas. Los datos localizados hablan de 750 menores en centros el 31 de julio, «al menos un millar» según el Gobierno ceutí el 4 de agosto y unos 1.200 entre los 5.000 que seguían en la ciudad el 31 de agosto, frente a 70.000-80.000 entradas; con ellos no puedo confirmar el «sobre todo menores», pero tampoco existe un recuento oficial de quienes entraron y volvieron en las primeras horas.
- Fuentes: <https://elfarodeceuta.es/marlaska-niega-cni-avisara-entrada-masiva-ceuta-confirma-72-000-personas-cruzaron-marruecos/> · <https://www.diaridetarragona.com/espana/267344/cifras-entrada-masiva-ceuta-37-500-migrantes-han-regresado-marruecos-57-muertos.html> · <https://es.euronews.com/2026/08/31/sanchez-vincula-a-rusia-israel-y-una-internacional-ultraderechista-con-los-bulos-de-ceuta>
- Fuente abierta: sí

**54:33 · De los migrantes que llegan, el 40 % son europeos y otro 40 % latinoamericanos.** (cifra)

- Cita literal: «el 40 % son europeos, el otro 40 % son latinoamericanos»
- Qué dicen las fuentes: No localicé un reparto por continentes de las llegadas. El INE (2024) da 1.288.562 llegadas y como primeras nacionalidades la colombiana (168.122), la marroquí (133.130) y la venezolana (103.225), que es lo que leen los verificadores en la entrevista; la nota no desglosa cuántos son europeos.
- Fuentes: <https://www.ine.es/dyngs/Prensa/es/EMCR2024.htm>
- Fuente abierta: sí · Grupo: `flujos`

**64:16 · Un delegado del Gobierno en Madrid dijo "quien quiera seguridad, que se la pague".** (cita_de_tercero)

- Cita literal: «el delegado del gobierno de entonces dijo, quien quiera seguridad, que se la pague»
- Qué dicen las fuentes: No localicé la frase ni a qué delegado del Gobierno en Madrid se atribuye.
- Fuente abierta: no (sin fuente localizada)

**66:22 · La regularización incluye 500 millones para políticas de integración de ayuntamientos y comunidades.** (cifra)

- Cita literal: «poner 500 millones de euros encima de la mesa para que los ayuntamientos y las comunidades autónomas»
- Qué dicen las fuentes: No localicé los 500 millones para políticas de integración.
- Fuentes: <https://www.lamoncloa.gob.es/serviciosdeprensa/notasprensa/inclusion/Paginas/2026/020726-balance-regularizacion-extraordinaria.aspx>
- Fuente abierta: no (solo extracto)

**69:42 · En las primarias empezó conduciendo solo su Peugeot y luego lo llevó Juan Manuel Serrano en un Mercedes.** (hecho)

- Cita literal: «y ese fue Juan Manuel Serrano ese fue la persona que me llevó en el coche, y él efectivamente tenía un Mercedes»
- Qué dicen las fuentes: Solo localicé columnas de opinión: unas hablan del Peugeot 407 de la campaña de primarias y otras de que Juan Manuel Serrano prestó su Mercedes. No hay una fuente independiente que confirme el relato completo.
- Fuentes: <https://www.esdiario.com/nacional/260709/192864/cae-5o-peugeot-uco-remata-ferraz-asi-han-acabado-cinco-hombres-auparon-sanchez.html> · <https://www.menorca.info/opinion/firmas-del-dia/2026/05/01/2619891/cuatro-peugeot.html>
- Fuente abierta: no (solo extracto)

**82:36 · En las aerolíneas se salvaron casi 8.500 empleos.** (cifra)

- Cita literal: «llegamos a salvar, me parece que son casi 8 .500 puestos de trabajo»
- Qué dicen las fuentes: No localicé la cifra de 8.500 empleos salvados en las aerolíneas.
- Fuentes: <https://www.hosteltur.com/176362_prestamos-sepi-cuanto-han-devuelto-air-europa-air-nostrum-volotea-y-plus-ultra.html>
- Fuente abierta: no (solo extracto) · Grupo: `sepi`

**85:54 · La renta de Manresa es superior a la de Málaga.** (comparacion)

- Cita literal: «renta Superior a la de Málaga»
- Qué dicen las fuentes: No localicé la renta por persona de Manresa y de Málaga en el Atlas de renta del INE.
- Fuentes: <https://ine.es/dyngs/Prensa/ADRH2023.htm>
- Fuente abierta: no (solo extracto) · Grupo: `manresa_malaga`

**86:34 · En sus años de gobierno se ha construido en torno a un millón de viviendas; el 13 % (más de 150.000), protegidas.** (cifra)

- Cita literal: «se han construido en torno a un millón de viviendas, el 13 % han sido viviendas protegidas, más de 150 .000»
- Qué dicen las fuentes: No localicé los totales acumulados. Datos parciales: las calificaciones definitivas de vivienda protegida fueron 14.371 en 2024 (máximo desde 2014) y 11.104 en 2025, y los visados de obra nueva 139.016 en 2025. Con esas cifras anuales no se llega a 150.000 protegidas en ocho años, pero el ministerio advierte de que esa estadística no recoge toda la vivienda pública (por ejemplo, la del Plan de Recuperación), así que no doy veredicto.
- Fuentes: <https://forbes.es/economia/897183/el-numero-de-viviendas-protegidas-retrocedio-un-227-en-2025-hasta-las-11-104-unidades/> · <https://www.lamoncloa.gob.es/serviciosdeprensa/notasprensa/vivienda-agenda-urbana/Paginas/2025/040725-vivienda-protegida-observatorio-suelo.aspx> · <https://okdiario.com/economia/gobierno-presume-records-viviendas-protegidas-pero-entregas-reales-siguen-bajo-minimos-15059933/amp>
- Fuente abierta: no (solo extracto)

### No comprobables según la extracción, no buscadas (22)

- **4:35** · Su madre lo tuvo con 18 años y su padre con 20. — «Mi madre me tuvo con 18 años, mi padre me tuvo con 20 años»
- **4:49** · Su abuelo trabajó 40 años emigrado en Alemania durante el franquismo. — «mi abuelo estuvo 40 años trabajando fuera, en la emigración, durante la dictadura franquista, en Alemania»
- **4:55** · Sus abuelos no sabían leer ni escribir. — «Mis abuelos no sabían leer ni escribir.»
- **8:13** · Sus hijas han estado en locales donde el DJ puso el cántico contra él y tuvieron que salir. — «han estado en locales donde de repente el pincha ha empezado con el Pedro Sánchez hijo de puta»
- **13:50** · España está mejor que otras muchas naciones de Europa. — «con nuestros aciertos y con nuestros errores, estamos infinitamente mejor que esos países»
- **21:53** · Pone a Ayuso y las residencias en la pandemia como ejemplo de decisión que afecta a una tragedia. — «como sucedió con Ayuso y las residencias de mayores durante»
- **23:20** · Mazón incurrió en omisión durante la dana. — «Dos, por omisión, como hizo Mazón, por ejemplo, durante la dana.»
- **27:11** · Óscar Puente le dijo que creía que debía dimitir. — «Óscar Puente me dijo, yo creo que tengo que dimitir»
- **34:28** · Ningún servicio de inteligencia avisó al Gobierno. — «nosotros no recibimos ningún aviso de ningún servicio»
- **37:02** · Marruecos, superado, facilitó en la frontera la gestión de la crisis. — «lo que hizo fue facilitar en frontera el que se pudiera gestionar de esa manera esta crisis migratoria»
- **43:51** · Marruecos es la puerta de entrada de España para invertir en África. — «es la puerta de entrada que tiene España»
- **45:34** · Trabajó todos los días; niega haber estado de vacaciones. — «Yo estuve trabajando todos los días.»
- **62:55** · Sin más población migrante, en 20-30 años la fuerza laboral sería como la de 1980-1990. — «vamos a tener una fuerza laboral muy semejante a la que teníamos en 1980 -1990»
- **71:01** · Apenas tenía comunicación con Koldo. — «yo con Koldo no tenía prácticamente comunicación.»
- **71:21** · Ábalos nunca hizo comentarios machistas delante de él. — «a mí José Luis Ábalos, conmigo delante, nunca hizo ningún comentario»
- **80:19** · El PSOE desconocía que esos despachos contrataran a Leire Díez. — «eso es algo que el Partido Socialista desconocía»
- **83:25** · Zapatero nunca le preguntó por Plus Ultra ni por ninguna empresa. — «es nunca me ha preguntado por Plus Ultra y»
- **89:00** · Durante 40 años España desreguló la vivienda. — «Durante los últimos 40 años, nuestro país lo que ha hecho ha sido de regular»
- **97:34** · En la campaña de 2019 sanitarios de un hospital catalán le dijeron "estáis encarcelando a nuestros líderes". — «ir a un hospital de Cataluña, encontrarme con profesionales sanitarios»
- **102:43** · Jordi votó el 1 de octubre de 2017. — «Tú, por ejemplo, el 1 de octubre de 2017 votaste.»
- **104:24** · Advirtió a Rajoy de que judicializar la crisis catalana era un error. — «yo advertí a Mariano Rajoy entonces de que judicializar la crisis política de Cataluña era un tremendo error»
- **108:19** · España es vista en buena parte del mundo como un ejemplo. — «ahora mismo España está siendo vista por buena parte del mundo como un ejemplo del buen hacer»

## Jordi Wild (entrevistador)

### Respaldada en parte / imprecisa (6)

**12:06 · Vox ha sufrido intentos de asalto en sus mítines de campaña.** (hecho)

- Cita literal: «En campaña han tenido problemas incluso de intentos de asalto durante sus meetings»
- Qué dicen las fuentes: Localicé un episodio de precampaña: el 20/21-10-2026, tras un acto de Abascal en A Coruña, manifestantes intentaron romper el cordón policial (dos detenidos, doce agentes heridos); el acto había terminado con normalidad. No localicé «intentos de asalto» a mítines de Vox ya en campaña oficial, lo que no significa que no existan.
- Fuentes: <https://www.moncloa.com/2026/10/21/abascal-protesta-coruna-detenidos-3452951/> · <https://www.vozpopuli.com/espana/politica/la-derecha-se-prepara-para-la-campana-mas-violenta-y-sucia-de-la-democracia-con-un-sanchez-desatado.html>
- Fuente abierta: no (solo extracto)

**19:35 · Ha pasado casi un año desde el primer accidente sin que se haya determinado la causa.** (hecho)

- Cita literal: «determinar qué pasó? Casi vamos al año.»
- Qué dicen las fuentes: Han pasado diez meses (18-1-2026). La comisión técnica (CIAF) atribuyó en abril de 2026 el descarrilamiento a la rotura de un carril y descartó anomalías en los trenes, pero su informe es provisional y la causa judicial sigue abierta: hay una causa técnica provisional, no una determinación definitiva ni responsables.
- Fuentes: <https://www.infobae.com/espana/2026/04/28/conclusion-del-accidente-de-adamuz-la-ciaf-dice-que-se-rompio-el-carril-y-descarta-anomalias-previas-en-los-trenes/> · <https://theobjective.com/espana/2026-04-08/guardia-civil-via-adamuz-dia-antes/>
- Fuente abierta: sí · Grupo: `adamuz_causa`

**31:14 · Se desplazaron casi 100.000 personas hacia Ceuta.** (cifra)

- Cita literal: «se esté moviendo casi 100 .000 personas»
- Qué dicen las fuentes: Las cifras localizadas van de 70.000 a 80.000 personas entradas; ninguna habla de 100.000. Algunos mensajes en redes convocaban a más gente (hasta 180.000, según un documento citado en la comprobación de Feijóo).
- Fuentes: <https://es.ara.cat/politica/gobierno-sanchez-rinde-cuentas-26-dias-despues-crisis-ceuta_1_5831446.html> · <https://elfarodeceuta.es/marlaska-niega-cni-avisara-entrada-masiva-ceuta-confirma-72-000-personas-cruzaron-marruecos/> · <https://www.lamoncloa.gob.es/presidente/actividades/Paginas/2026/030926-sanchez-comparecencia-ceuta.aspx> · <https://www.diaridetarragona.com/espana/267344/cifras-entrada-masiva-ceuta-37-500-migrantes-han-regresado-marruecos-57-muertos.html>
- Fuente abierta: sí · Grupo: `ceuta_cifra`

**58:22 · La preocupación por la inmigración no ha bajado en los últimos años.** (hecho)

- Cita literal: «En los últimos años no ha bajado.»
- Qué dicen las fuentes: La inmigración sigue entre los primeros problemas (20,9 % en octubre de 2026), pero sí ha tenido bajadas: tras el máximo de septiembre de 2024 varios barómetros de 2025 recogieron descensos («baja la preocupación por la inmigración»).
- Fuentes: <https://www.ondavasca.com/la-inquietud-por-la-vivienda-y-el-empleo-marcan-record-mientras-baja-la-preocupacion-por-la-inmigracion/> · <https://www.ondavasca.com/la-vivienda-es-el-principal-problema-para-mas-de-la-mitad-de-la-ciudadania/>
- Fuente abierta: no (solo extracto) · Grupo: `cis`

**76:00 · Sánchez dedicó a Koldo una publicación en su Instagram.** (hecho)

- Cita literal: «Le dedicas un post en tu propio Instagram.»
- Qué dicen las fuentes: Los textos localizados se publicaron en su blog («En la carretera») y en Facebook; no localicé una publicación de Instagram.
- Fuentes: <https://www.vozpopuli.com/espana/politica/koldo-garcia-hombre-durmio-urnas-sanchez-narra-presidente-mision-manual-resistencia.html> · <https://www.vozpopuli.com/dolcevita/asi-es-koldo-garcia-su-expareja-patricia-uriz-sus-hijos-condena-y-los-trapos-sucios-que-destapo-su-primera-mujer.html>
- Fuente abierta: no (solo extracto) · Grupo: `elogios_koldo`

**96:00 · Propuso para el Constitucional a su exministro Juan Carlos Campo tras defender en 2015-16 que el Gobierno no propusiera magistrados.** (voto_o_decision)

- Cita literal: «acabaste proponiendo a tu exministro de Justicia, Juan Carlos Capó, para el Constitucional»
- Qué dicen las fuentes: Respaldado que el Gobierno propuso al exministro Juan Carlos Campo para el Constitucional el 29-11-2022. No localicé la posición de 2015-2016 que le atribuye (que el Gobierno dejara de proponer magistrados).
- Fuentes: <https://www.boe.es/boe/dias/2022/11/30/pdfs/BOE-A-2022-19927.pdf> · <https://www.elindependiente.com/espana/2022/11/29/el-ministro-de-los-indultos-del-proces-llega-al-tribunal-constitucional/amp/>
- Fuente abierta: no (solo extracto) · Grupo: `hemeroteca`

### Respaldada (42)

**1:43 · Sánchez ha sido presidente durante ocho años y vuelve a ser candidato.** (hecho)

- Cita literal: «presidente de España durante ocho años, candidato a las elecciones otra vez»
- Qué dicen las fuentes: Sánchez es presidente del Gobierno desde junio de 2018 (moción de censura): ocho años y cinco meses en noviembre de 2026. Es candidato del PSOE el 29-N.
- Fuentes: <https://www.lamoncloa.gob.es/presidente/biografia/Paginas/index.aspx> · <https://maldita.es/control-del-poder/20260623/abalos-condenado-mocion-censura-corrupcion/>
- Fuente abierta: no (solo extracto) · Grupo: `ocho_anos`

**7:39 · Los cánticos contra Sánchez se oyeron en el Dogfight Wild Tournament 3.** (hecho)

- Cita literal: «que incluso se han dado en un evento mío, Dogfight Wild Tournament 3»
- Qué dicen las fuentes: El 31-1-2025, en el Dogfight Wild Tournament 3 (Palau Olímpic de Badalona), el público coreó insultos contra Sánchez; Jordi Wild dijo después que no le gustó el cántico y que se dio cuenta tarde.
- Fuentes: <https://www.esdiario.com/nacional/250201/151813/diez-mil-personas-acuerdan-unisono-pedro-sanchez-evento-jordi-wild-badalona-graves-insultos-coreados-manera-espontanea-publico.html> · <https://www.eldiario.es/132_b7da52> · <https://www.3djuegos.com/eventos/noticias/evento-ha-sido-ruina-jordi-wild-se-sincera-peor-dogfight-wild-tournament-3-habla-futuro-competicion>
- Fuente abierta: no (solo extracto)

**9:43 · Sánchez ha usado "fachosfera" y "máquina de fango" para referirse a medios críticos.** (hecho)

- Cita literal: «A ti te he escuchado la fachosfera, máquina de fango a cualquier medio más o menos crítico»
- Qué dicen las fuentes: Sánchez popularizó «fachosfera» en 2024 y habló de la «máquina del fango» y de «pseudomedios» desde su carta de abril de 2024. Que lo aplique «a cualquier medio más o menos crítico» es una caracterización de quien pregunta. Fuentes: sobre todo columnas de opinión.
- Fuentes: <https://www.periodicodeibiza.es/opinion/firmas-del-dia/2024/04/28/2152911/sanchez-fachosfera.html> · <https://www.eldebate.com/opinion/20240504/explicaciones-sobre-begona-cuando_194080.html> · <https://www.elperiodicodeceuta.es/pedro-sanchez-anuncia-su-plan-de-calidad-democraticapara-combatir-bulos-y-desinformacion>
- Fuente abierta: no (solo extracto)

**10:16 · El ministro de Transportes ha protagonizado trifulcas con insultos.** (hecho)

- Cita literal: «un ministro, y hablaremos por supuesto del tema de los trenes, que ha tenido un perfil en el que ha tenido trifulcas de insultos»
- Qué dicen las fuentes: Óscar Puente llamó «saco de mierda» a un agitador (admitió un «exceso verbal») y en mayo de 2024 sugirió que Milei había hablado tras «ingerir sustancias», lo que abrió una crisis con Argentina.
- Fuentes: <https://theobjective.com/espana/2024-06-24/puente-exceso-verbal-vito-quiles/> · <https://www.moncloa.com/2024/05/04/oscar-puente-crisis-argentina-2586741/> · <https://www.periodicodeibiza.es/opinion/editorial/2024/05/06/2157593/conflicto-internacional-por-ministro-bocazas.html>
- Fuente abierta: no (solo extracto)

**14:48 · Los sindicatos ferroviarios habían avisado de falta de mantenimiento y de subcontratación.** (hecho)

- Cita literal: «unos avisos de los sindicatos ferroviarios, de que faltaba mantenimiento, de que se estaba subcontratando todo»
- Qué dicen las fuentes: El sindicato de maquinistas Semaf envió el 8-8-2025 una carta pidiendo limitar la velocidad a 250 km/h por el deterioro de las vías, cinco meses antes de Adamuz; Adif la rechazó por falta de «argumentos técnicos». La subcontratación del mantenimiento está documentada en la comprobación de la entrevista a Colau.
- Fuentes: <https://maldita.es/malditobulo/20260120/los-maquinistas-pidieron-hace-cinco-meses-reducir-la-velocidad-en-el-tramo-en-el-que-se-ha-producido-el-accidente-de-adamuz-por-el-estado-de-la-via/> · <https://www.eldebate.com/economia/20250809/maquinistas-piden-bajar-velocidad-ave-mal-estado-vias_324568.html> · <https://theobjective.com/economia/transporte/2026-01-19/maquinistas-rebajar-velocidad-trenes-botes-vias/> · <https://www.vozpopuli.com/economia/empresas/el-gobierno-adjudico-a-fcc-ferrovial-ohla-y-azvi-el-cuidado-de-la-via-en-adamuz-por-56-millones-hasta-2028.html>
- Fuente abierta: no (solo extracto) · Grupo: `avisos_semaf`

**17:49 · Ha habido dos accidentes ferroviarios mortales en menos de un año, en la misma vía.** (hecho)

- Cita literal: «que se repitan dos accidentes en menos de un año»
- Qué dicen las fuentes: Adamuz (18-1-2026, 46 muertos) y Urda (28-10-2026, 69 muertos), con nueve meses de diferencia y en la misma línea Madrid-Sevilla. Mismo hecho que en la comprobación de la entrevista a Colau.
- Fuentes: <https://www.elnuevodia.com/noticias/mundo/notas/dos-tragedias-mortales-golpean-la-red-ferroviaria-de-alta-velocidad-espanola-en-nueve-meses/> · <https://es.ara.cat/politica/saldra-oscar-puente_129_5893607.html> · <https://www.diaridetarragona.com/espana/274809/dimite-oscar-puente.html>
- Fuente abierta: sí · Grupo: `dos_accidentes`

**20:42 · Tras el primer accidente ya se pidió la dimisión del ministro.** (hecho)

- Cita literal: «pero ya en el primero mucha gente pidió su cabeza»
- Qué dicen las fuentes: El PP pidió su «dimisión inmediata» el 25-1-2026 y Vox, UPN y Junts se sumaron en el Senado el 29 de enero; PNV, Más Madrid y EH Bildu pidieron esperar a la investigación.
- Fuentes: <https://www.eldiario.es/politica/pp-acusa-puente-mentir-renovacion-total-via-adamuz-exige-dimision_1_12933988.amp.html> · <https://theobjective.com/espana/politica/2026-01-29/pp-upn-vox-junts-dimision-puente-como-adamuz/>
- Fuente abierta: no (solo extracto)

**21:09 · En agosto de 2025 el sindicato de maquinistas pidió por escrito reducir la velocidad en cuatro líneas.** (hecho)

- Cita literal: «en agosto de 2025 el sindicato de maquinistas pidió por escrito bajar la velocidad en cuatro»
- Qué dicen las fuentes: Carta de Semaf del 8-8-2025: pedía un máximo de 250 km/h en las líneas de Madrid a Sevilla, Málaga, Valencia y Barcelona. Matiz de Maldita: en la Madrid-Sevilla la petición afectaba a tramos concretos, entre los que no estaba el de Adamuz.
- Fuentes: <https://maldita.es/malditobulo/20260120/los-maquinistas-pidieron-hace-cinco-meses-reducir-la-velocidad-en-el-tramo-en-el-que-se-ha-producido-el-accidente-de-adamuz-por-el-estado-de-la-via/> · <https://www.eldebate.com/economia/20250809/maquinistas-piden-bajar-velocidad-ave-mal-estado-vias_324568.html> · <https://theobjective.com/economia/transporte/2026-01-19/maquinistas-rebajar-velocidad-trenes-botes-vias/>
- Fuente abierta: no (solo extracto) · Grupo: `avisos_semaf`

**30:38 · Marlaska y Robles dieron versiones distintas sobre los avisos del CNI.** (hecho)

- Cita literal: «incluso hemos tenido a Marlaska y a Robles diciendo»
- Qué dicen las fuentes: El 25-8-2026 Robles dijo que el CNI compartió información en reuniones del 27 y el 29 de julio y Marlaska que ningún informe anticipaba lo ocurrido. Mismo hecho que en la comprobación de la entrevista a Colau.
- Fuentes: <https://es.ara.cat/politica/gobierno-sanchez-rinde-cuentas-26-dias-despues-crisis-ceuta_1_5831446.html> · <https://elfarodeceuta.es/crisis-defensa-interior-cni-aviso-entrada-masiva-ceuta-interior-niega/>
- Fuente abierta: sí · Grupo: `cni_avisos`

**34:33 · El CNI avisó del aumento de llegadas y de bulos en redes que convocaban.** (hecho)

- Cita literal: «el CNI os avisó de que, como tú dices, estaba habiendo una»
- Qué dicen las fuentes: Según Robles, el CNI trasladó el 27 de julio que crecían las entradas a nado y el 29 una convocatoria en redes para entrar al día siguiente; los documentos desclasificados citan una alerta del 29 de julio.
- Fuentes: <https://es.ara.cat/politica/gobierno-sanchez-rinde-cuentas-26-dias-despues-crisis-ceuta_1_5831446.html> · <https://es.euronews.com/2026/11/10/gobierno-desclasifica-los-informes-del-cni-sobre-ceuta-que-pidio-la-jueza-tardon>
- Fuente abierta: sí · Grupo: `cni_avisos`

**35:34 · Hay informaciones de que fuerzas de seguridad marroquíes guiaban a puntos de paso.** (hecho)

- Cita literal: «indican que habían fuerzas de seguridad marroquí que estaban guiando»
- Qué dicen las fuentes: Un informe del centro de inmigración y fronteras de la Policía Nacional, remitido a la Audiencia Nacional, habla de «guiado activo» hacia los puntos de paso; Interior discutió esa lectura. Mismo hecho que en la comprobación de la entrevista a Colau.
- Fuentes: <https://www.diariodeleon.es/nacional/260902/2096051/informe-policia-cuestiona-fuerzas-marruecos-apunta-guiado-activo-migrantes-ceuta-planificacion_amp.html> · <https://www.vozpopuli.com/tribunales/el-informe-concluye-que-marruecos-fomento-impulso-y-dirigio-un-flujo-masivo-de-personas-a-la-frontera-de-ceuta.html>
- Fuente abierta: no (solo extracto)

**36:07 · Sánchez pidió no precipitarse en culpar a Marruecos.** (hecho)

- Cita literal: «Tú dijiste eso, que no nos precipitemos, me acuerdo.»
- Qué dicen las fuentes: Sánchez dijo en la SER (31-8-2026) que ningún servicio de inteligencia «alumbra ninguna duda sobre la participación» de las autoridades marroquíes y, en el Congreso (3-9-2026), que «a día de hoy» nadie había aportado evidencia sólida contra Marruecos. La frase de Jordi es una paráfrasis.
- Fuentes: <https://es.euronews.com/2026/08/31/sanchez-vincula-a-rusia-israel-y-una-internacional-ultraderechista-con-los-bulos-de-ceuta> · <https://www.lamoncloa.gob.es/presidente/actividades/Paginas/2026/030926-sanchez-comparecencia-ceuta.aspx> · <https://www.diaridetarragona.com/espana/269580/sanchez-exculpa-marruecos-entrada-masiva-migrantes-ceuta.html>
- Fuente abierta: sí · Grupo: `marruecos_rusia`

**36:18 · En esa misma declaración Sánchez señaló a Rusia y a Israel.** (hecho)

- Cita literal: «en esa misma frase culpaste a Rusia y a Israel»
- Qué dicen las fuentes: En esa entrevista vinculó la difusión de los bulos con redes ligadas a Rusia, Israel y una «internacional ultraderechista», precisando que no implicaba necesariamente a sus gobiernos; Israel y Rusia lo rechazaron. Los relacionó con los bulos, no con la organización de la entrada.
- Fuentes: <https://es.euronews.com/2026/08/31/sanchez-vincula-a-rusia-israel-y-una-internacional-ultraderechista-con-los-bulos-de-ceuta> · <https://www.articulo14.es/internacional/israel-rusia-y-por-que-no-marruecos-sanchez-busca-culpables-internacionales-de-la-crisis-de-ceuta-20260831.html>
- Fuente abierta: sí · Grupo: `marruecos_rusia`

**38:14 · Se dieron cifras muy distintas sobre las salidas.** (hecho)

- Cita literal: «Porque yo el baile de cifras ha sido terrible. Algunos decían 10, 15, 20.»
- Qué dicen las fuentes: Las cifras publicadas divergen: 50.000, 70.000, 72.000 u 80.000 entradas y 48.300, 63.000 o 70.000 salidas según la fecha y la fuente.
- Fuentes: <https://es.ara.cat/politica/gobierno-sanchez-rinde-cuentas-26-dias-despues-crisis-ceuta_1_5831446.html> · <https://elfarodeceuta.es/marlaska-niega-cni-avisara-entrada-masiva-ceuta-confirma-72-000-personas-cruzaron-marruecos/> · <https://www.lamoncloa.gob.es/presidente/actividades/Paginas/2026/030926-sanchez-comparecencia-ceuta.aspx> · <https://www.diaridetarragona.com/espana/267344/cifras-entrada-masiva-ceuta-37-500-migrantes-han-regresado-marruecos-57-muertos.html>
- Fuente abierta: sí · Grupo: `ceuta_salidas`

**44:45 · Sánchez se fue de vacaciones durante la crisis de Ceuta.** (hecho)

- Cita literal: «que durante la crisis de Ceuta te vayas de vacaciones»
- Qué dicen las fuentes: Sánchez voló el 1-8-2026 a La Mareta (Lanzarote), dos días después de la entrada masiva. Mismo hecho y mismas fuentes que en las comprobaciones de Feijóo y Colau (no reabiertas aquí). Él sostiene que siguió trabajando.
- Fuentes: <https://www.elespanol.com/espana/politica/20260801/sanchez-comparte-playlist-verano-plena-crisis-ceuta-seguro-dan-idea-voy/1003744341448_0.html> · <https://www.esdiario.com/nacional/260801/194612/ceuta-mareta-sanchez-arranca-vacaciones-semana-incendios-crisis-migratoria.html>
- Fuente abierta: no (solo extracto) · Grupo: `vacaciones`

**48:14 · Sánchez tardó unos 25 días en convocar el Consejo de Seguridad Nacional.** (cifra)

- Cita literal: «Tardaste 25 días aproximadamente en convocar el Consejo de Seguridad Nacional.»
- Qué dicen las fuentes: El Consejo de Seguridad Nacional se reunió por Ceuta el 25-8-2026, 26 días después de la entrada masiva.
- Fuentes: <https://www.lamoncloa.gob.es/presidente/actividades/Paginas/2026/030926-sanchez-comparecencia-ceuta.aspx> · <https://maldita.es/control-del-poder/20260915/gobierno-normalidad-ceuta-mando-unico/> · <https://www.esdiario.com/nacional/260825/196063/sanchez-seguridad-nacional-ceuta.html> · <https://www.lamoncloa.gob.es/serviciosdeprensa/notasprensa/economia-comercio-empresa/paginas/2026/250826-mando-unico-ceuta.aspx>
- Fuente abierta: no (solo extracto) · Grupo: `mando_unico`

**48:18 · En el apagón lo convocó de inmediato.** (hecho)

- Cita literal: «En cambio, en el apagón lo convocaste inmediatamente.»
- Qué dicen las fuentes: El 28-4-2025, día del apagón, Sánchez convocó y presidió varias reuniones del Consejo de Seguridad Nacional.
- Fuentes: <https://www.eldiario.es/politica/sanchez-convoca-moncloa-reunion-consejo-seguridad-nacional_1_12253600.html> · <https://www.periodicodeibiza.es/noticias/nacional/2025/04/28/2375745/pedro-sanchez-preside-consejo-seguridad-nacional-moncloa.html>
- Fuente abierta: no (solo extracto)

**51:34 · Según el CIS, la inmigración es la segunda preocupación, tras la vivienda.** (hecho)

- Cita literal: «La inmigración es una de las mayores causas de preocupación según el CIS»
- Qué dicen las fuentes: Barómetro del CIS de octubre de 2026: vivienda 55,7 % (primer problema), inmigración 20,9 % (segundo) y crisis económica 20,3 %.
- Fuentes: <https://www.ondavasca.com/la-vivienda-es-el-principal-problema-para-mas-de-la-mitad-de-la-ciudadania/> · <https://www.democrata.es/politica/la-inquietud-por-la-vivienda-se-dispara-18-puntos-y-bate-record-como-principal-problema-al-superar-el-55-de-menciones/>
- Fuente abierta: no (solo extracto) · Grupo: `cis`

**52:00 · Partidos socialdemócratas europeos están endureciendo las leyes de inmigración.** (hecho)

- Cita literal: «hay partidos socialdemócratas que seguramente tienen muchas sintonías con el PSOE y contigo que están endureciendo mucho las leyes hacia la inmigración»
- Qué dicen las fuentes: Los socialdemócratas daneses aplican desde 2019 una de las políticas de asilo más estrictas de Europa y el Gobierno laborista británico aprobó en 2025 un endurecimiento inspirado en ese modelo.
- Fuentes: <https://es.ara.cat/editorial/starmer-apunta-modelo-migratorio-danes_129_5563701.html> · <https://legrandcontinent.eu/es/2025/05/28/en-el-reino-unido-que-significa-el-giro-de-starmer-en-materia-de-inmigracion/>
- Fuente abierta: no (solo extracto)

**55:12 · Aliança Catalana está subiendo en Cataluña.** (hecho)

- Cita literal: «En Cataluña no es de gratis que un partido como Alianza Catalana esté subiendo»
- Qué dicen las fuentes: Barómetro del CEO de julio de 2026: Aliança Catalana pasaría de 2 a 23-25 escaños. Mismo hecho y fuentes que en la comprobación de la entrevista a Colau.
- Fuentes: <https://www.elindependiente.com/espana/2026/07/09/encuesta-ceo-catalan-alianca-catalana-puigdemont-sorpasso/> · <https://es.ara.cat/politica/encuestas/alianza-catalana-supera-junts-ceo_1_5793561.html>
- Fuente abierta: no (solo extracto)

**56:49 · Las listas de espera de la sanidad pública son muy altas.** (hecho)

- Cita literal: «Tenemos unas listas de espera en sanidad pública elevadísimas.»
- Qué dicen las fuentes: A cierre de 2025 había 853.509 pacientes en lista de espera quirúrgica (récord), con 121 días de demora media y 102 días para una consulta de especialista (Ministerio de Sanidad).
- Fuentes: <https://es.euronews.com/salud/2026/04/16/un-nuevo-record-mas-de-853000-personas-esperan-una-operacion-en-espana> · <https://www.sanidad.gob.es/gl/estadEstudios/estadisticas/inforRecopilaciones/docs/Nota_Resumen_SISLE__dic25.pdf>
- Fuente abierta: no (solo extracto)

**58:38 · Dato de los verificadores que Jordi repite: Marruecos es el segundo país en flujos de inmigración, tras Colombia.** (hecho)

- Cita literal: «Marruecos, el segundo. Ah, pero Marruecos no lo habías dicho»
- Qué dicen las fuentes: INE, 2024: las tres primeras nacionalidades de los inmigrantes extranjeros fueron la colombiana (168.122), la marroquí (133.130) y la venezolana (103.225).
- Fuentes: <https://www.ine.es/dyngs/Prensa/es/EMCR2024.htm>
- Fuente abierta: sí · Grupo: `flujos`

**60:53 · Proyección del INE: en 50 años, alrededor del 40 % de los residentes habrá nacido fuera.** (cifra)

- Cita literal: «en 50 años el 40 % aproximado del residente español será inmigrante»
- Qué dicen las fuentes: Proyecciones del INE 2026-2076: la población nacida en España pasaría al 59,6 % dentro de 50 años, es decir, un 40,4 % nacida en el extranjero. La proyección anterior (2024-2074) daba un 39 %.
- Fuentes: <https://ine.es/dyngs/Prensa/PROP20262076.htm> · <https://www.vozpopuli.com/economia/un-extranjero-por-cada-tres-nativos-asi-sera-la-espana-de-los-50-millones-de-habitantes.html>
- Fuente abierta: sí

**67:41 · Ábalos ha sido condenado a 24 años de cárcel.** (cifra)

- Cita literal: «en el caso de Ábalos, ya condenado, 24 años de cárcel»
- Qué dicen las fuentes: El Supremo condenó a Ábalos a 24 años y 3 meses de prisión el 22-6-2026.
- Fuentes: <https://www.poderjudicial.es/cgpj/es/Poder-Judicial/Tribunal-Supremo/Noticias-Judiciales/El-Tribunal-Supremo-condena-al-exministro-Jose-Luis-Abalos-y-a-su-exasesor-Koldo-Garcia-a-24-anos-y-19-anos-de-prision--respectivamente--por-delitos-de-organizacion-criminal--cohecho--malversacion-y-trafico-de-influencias>
- Fuente abierta: sí · Grupo: `condena_abalos`

**67:49 · La condena habla de una organización criminal que operó desde el ministerio.** (hecho)

- Cita literal: «Se habla de una organización criminal que operó desde el»
- Qué dicen las fuentes: La nota del Supremo dice que los tres acusados «formaron una organización criminal con reparto de funciones que cometió graves delitos de corrupción», con adjudicaciones en Puertos del Estado y Adif. La expresión «desde el propio ministerio» no figura en la nota.
- Fuentes: <https://www.poderjudicial.es/cgpj/es/Poder-Judicial/Tribunal-Supremo/Noticias-Judiciales/El-Tribunal-Supremo-condena-al-exministro-Jose-Luis-Abalos-y-a-su-exasesor-Koldo-Garcia-a-24-anos-y-19-anos-de-prision--respectivamente--por-delitos-de-organizacion-criminal--cohecho--malversacion-y-trafico-de-influencias> · <https://es.ara.cat/politica/supremo-condena-exministro-abalos-24-anos-prision_1_5776792.html>
- Fuente abierta: sí · Grupo: `condena_abalos`

**68:18 · Santos Cerdán está en libertad provisional e investigado.** (hecho)

- Cita literal: «Y de Zerdán, que ahora está provisional, veremos lo que pasa, que está investigado.»
- Qué dicen las fuentes: Santos Cerdán salió de prisión provisional el 19-11-2025 tras cinco meses y sigue investigado por organización criminal, cohecho y tráfico de influencias. No localicé novedades de 2026 sobre su situación.
- Fuentes: <https://es.ara.cat/politica/juez-deja-santos-cerdan-libertad_1_5566495.html> · <https://www.publico.es/politica/juez-deja-libertad-santos-cerdan-casi-cinco-meses-prision.html>
- Fuente abierta: no (solo extracto)

**72:11 · Sánchez apartó a Ábalos en 2021, antes de que estallara el caso.** (hecho)

- Cita literal: «Porque lo apartas antes de que salte el caso.»
- Qué dicen las fuentes: Ábalos dejó el Gobierno y la secretaría de Organización del PSOE en la remodelación del 10-7-2021; el caso Koldo estalló en febrero de 2024.
- Fuentes: <https://es.ara.cat/politica/pedro-sanchez-remodela-gobierno-prescinde-calvo-asciende-calvino-primera-vicepresidenta_1_4049768.html> · <https://diariodeavisos.elespanol.com/2021/07/sanchez-revoluciona-el-gobierno-saca-a-calvo-abalos-laya-campo-celaa-uribes-y-a-redondo/>
- Fuente abierta: no (solo extracto) · Grupo: `remodelacion_2021`

**73:56 · Sánchez escribió en redes sobre Koldo: "gigante de la militancia", "titán contra los desahucios".** (cita_de_tercero)

- Cita literal: «Uno de los gigantes de la militancia en estas tierras navarras.»
- Qué dicen las fuentes: Los elogios existen: «el último aizkolari socialista; un titán contra los desahucios», «un inagotable aizkolari contra las injusticias, un ejemplo para la militancia». Las fuentes los sitúan en una entrada de su blog del 24-6-2014 y en Facebook. La expresión «gigantes de la militancia» no aparece en los extractos vistos.
- Fuentes: <https://www.vozpopuli.com/espana/politica/koldo-garcia-hombre-durmio-urnas-sanchez-narra-presidente-mision-manual-resistencia.html> · <https://www.vozpopuli.com/dolcevita/asi-es-koldo-garcia-su-expareja-patricia-uriz-sus-hijos-condena-y-los-trapos-sucios-que-destapo-su-primera-mujer.html>
- Fuente abierta: no (solo extracto) · Grupo: `elogios_koldo`

**75:51 · El mensaje de elogio a Koldo es de 2014.** (hecho)

- Cita literal: «que no es un fake, pero mira, esto es 2014»
- Qué dicen las fuentes: Las fuentes localizadas fechan la entrada sobre Koldo el 24-6-2014.
- Fuentes: <https://www.vozpopuli.com/espana/politica/koldo-garcia-hombre-durmio-urnas-sanchez-narra-presidente-mision-manual-resistencia.html> · <https://www.vozpopuli.com/dolcevita/asi-es-koldo-garcia-su-expareja-patricia-uriz-sus-hijos-condena-y-los-trapos-sucios-que-destapo-su-primera-mujer.html>
- Fuente abierta: no (solo extracto) · Grupo: `elogios_koldo`

**79:52 · En el Senado Sánchez dijo que no le constaban encargos de Leire Díez para el PSOE.** (hecho)

- Cita literal: «en el Senado te preguntaron si Leire había hecho algún encargo para el PSOE y dijiste que te conste a ti no»
- Qué dicen las fuentes: En la comisión del Senado (30-10-2025), preguntado por si le constaba algún encargo del PSOE a Leire Díez, respondió: «A mí no me consta».
- Fuentes: <https://theobjective.com/politica/2025-10-30/sanchez-senado-directo-caso-abalos-koldo/directo/>
- Fuente abierta: no (solo extracto) · Grupo: `leire`

**79:59 · La UCO atribuye al PSOE 43.225 euros que llegaron a Leire Díez por intermediarios.** (cifra)

- Cita literal: «La UCO atribuye al partido 43 .225 euros que le llegaron a través de intermediarios.»
- Qué dicen las fuentes: El informe de la UCO (julio de 2026) cifra en al menos 43.225 euros lo recibido por Leire Díez con origen en el PSOE, a través de dos intermediarios; la propia UCO admite que la titularidad de las cuentas no permite conclusiones definitivas.
- Fuentes: <https://es.euronews.com/my-europe/2026/07/14/caso-leire-diez-la-uco-confirma-pagos-del-psoe-por-valor-de-43225-euros-a-traves-de-interm> · <https://www.que.es/2026/07/15/caso-leire-diez-uco-pagos-psoe/> · <https://www.ondavasca.com/la-uco-confirma-pagos-del-psoe-a-leire-diez-por-valor-de-43-225-euros/>
- Fuente abierta: no (solo extracto) · Grupo: `leire`

**80:41 · La UCO interpreta que Leire Díez se refería a Sánchez como "The One".** (hecho)

- Cita literal: «la UCO interpreta que a Leire Díaz se refería a ti como The One»
- Qué dicen las fuentes: Según la prensa, la UCO identifica a Pedro Sánchez como «the one» al que se refería Leire Díez en sus gestiones. Solo extracto de prensa; no se abrió el informe.
- Fuentes: <https://es.euronews.com/2026/06/03/uco-senala-santos-cerdan-leire-diez-lideres-trama-apunta-lleno-psoe> · <https://www.eldebate.com/espana/20260604/uco-senala-psoe-como-origen-todos-pagos-trama-leire-diez_424918.html>
- Fuente abierta: no (solo extracto) · Grupo: `leire`

**81:42 · Zapatero está siendo investigado.** (hecho)

- Cita literal: «es el de Zapatero, en plena investigación, y es un caso serio»
- Qué dicen las fuentes: Un juez de la Audiencia Nacional investiga a Zapatero desde mayo de 2026 por presunto tráfico de influencias y blanqueo (caso Plus Ultra); la causa se amplió en junio a sus hijas.
- Fuentes: <https://www.menorca.info/actualidad/nacional/2026/05/26/2637477/sumar-critica-sanchez-este-escondido-ante-imputacion-zapatero-exige-mas-explicaciones-del-psoe.html> · <https://euronews.com/my-europe/2026/06/18/graft-probe-into-spanish-ex-pm-zapatero-expanded-to-daughters-and-secretary-court-says>
- Fuente abierta: no (solo extracto) · Grupo: `zapatero`

**90:08 · El 18-dic-2023 Sánchez se comprometió a habilitar 184.000 viviendas públicas y de alquiler asequible en la legislatura.** (cifra)

- Cita literal: «el 18 de diciembre del 23 te comprometiste a habilitar 184 .000 viviendas públicas»
- Qué dicen las fuentes: El compromiso de «habilitar 184.000 viviendas públicas y de alquiler asequible» figura en una nota de La Moncloa del 18-12-2023; la cifra venía de la campaña de 2023.
- Fuentes: <https://www.elindependiente.com/economia/2026/02/17/sanchez-anuncios-viviendas-desde-2023/> · <https://www.articulo14.es/economia/sanchez-se-olvida-de-las-184-000-viviendas-asequibles-anunciadas-para-esta-legislatura-20250114.html>
- Fuente abierta: sí · Grupo: `184000`

**95:48 · Sánchez negó que fuera a haber indultos y amnistía y los hizo.** (hecho)

- Cita literal: «Tú negaste categóricamente hacerlos, lo acabas haciendo.»
- Qué dicen las fuentes: Sánchez rechazó repetidamente la amnistía («no entra en la Constitución») hasta defenderla el 28-10-2023, y antes había descartado los indultos que concedió en 2021. Él lo reconoce en la entrevista.
- Fuentes: <https://maldita.es/malditahemeroteca/20231031/pedro-sanchez-amnistia-constitucion/> · <https://es.ara.cat/politica/veces-pedro-sanchez-psoe-han-rechazado-amnistia_1_4795761.amp.html>
- Fuente abierta: no (solo extracto) · Grupo: `hemeroteca`

**95:51 · Negó pactar con Bildu y llegó a acuerdos.** (hecho)

- Cita literal: «negaste pactar con Bildu, acabáis llegando a acuerdos»
- Qué dicen las fuentes: En 2015 dijo en televisión: «Con Bildu, se lo repito, no vamos a pactar». Después hubo acuerdos parlamentarios con EH Bildu y la moción de censura de Pamplona. La cita de 2015 procede de una columna de opinión.
- Fuentes: <https://www.vozpopuli.com/opinion/pedro-sanchez-bildu-foto.html> · <https://www.eldiario.es/politica/perder-alcaldia-pamplona-reputacion-sola-frase_129_10800224.html>
- Fuente abierta: no (solo extracto) · Grupo: `bildu`

**96:06 · Dijo que no se daban las condiciones para Iglesias en el Gobierno y medio año después era vicepresidente.** (hecho)

- Cita literal: «dijiste que no se dan las condiciones, medio año después era tu vicepresidente segundo»
- Qué dicen las fuentes: El 18-7-2019 dijo: «no se dan las condiciones para que el señor Iglesias sea miembro de ese Gobierno» (transcripción oficial). Iglesias fue vicepresidente segundo desde enero de 2020, seis meses después.
- Fuentes: <https://www.lamoncloa.gob.es/presidente/intervenciones/Documents/2019/20190718 PG Entrevista Al rojo vivo La sexta ferreras.pdf> · <https://orain.eus/es/politica/2019/07/18/investidura-pedro-sanchez-veta-pablo-iglesias-18-julio-2019/> · <https://maldita.es/malditodato/20200107/sanchez-consigue-ser-presidente-en-la-votacion-mas-ajustada-de-la-democracia-asi-han-sido-las-distintas-votaciones-de-investidura-desde-1979/>
- Fuente abierta: sí · Grupo: `iglesias`

**96:18 · En 2018 defendió la libre determinación del pueblo saharaui y en 2022 envió una carta en sentido contrario.** (hecho)

- Cita literal: «defendiste una solución que previera la libre determinación del pueblo saharaui»
- Qué dicen las fuentes: En la Asamblea General de la ONU de 2018 mencionó la «libre determinación» del pueblo saharaui; en la carta a Mohamed VI de marzo de 2022 calificó el plan de autonomía marroquí como la base «más seria, creíble y realista».
- Fuentes: <https://es.ara.cat/politica/sanchez-obvia-giro-espana-defiende-onu-solucion-politica-sahara-occidental_1_4497754.html> · <https://maldita.es/malditahemeroteca/20220323/psoe-sahara-referendum-autonomia-marruecos/>
- Fuente abierta: no (solo extracto) · Grupo: `hemeroteca`

**96:37 · Prometió en 2015 derogar la ley mordaza y sigue vigente en 2026.** (hecho)

- Cita literal: «en 2015 ya prometiste que la ibas a derogar, estamos en 2026, sigue activa»
- Qué dicen las fuentes: La ley de seguridad ciudadana de 2015 sigue vigente y su reforma lleva más de un año parada en el Congreso. La promesa de derogarla desde 2015 es conocida, pero no abrí una fuente con la cita.
- Fuentes: <https://www.eldiario.es/1_caa1d7> · <https://www.eldiario.es/1_ccf72d> · <https://www.que.es/2024/10/29/el-congreso-busca-tramitar-con-urgencia-la-reforma-de-la-ley-mordaza/>
- Fuente abierta: no (solo extracto) · Grupo: `mordaza`

**99:46 · El PSOE pactó con Bildu la moción de censura de Pamplona.** (voto_o_decision)

- Cita literal: «pactasteis con Bildu una moción que hizo alcalde de Pamplona»
- Qué dicen las fuentes: PSN y EH Bildu presentaron la moción de censura que el 28-12-2023 hizo alcalde de Pamplona a Joseba Asiron (EH Bildu).
- Fuentes: <https://orain.eus/es/politica/2023/12/27/asiron-conseguira-hoy-baston-de-mando-de-pamplona-gracias-a-mocion-de-censura/> · <https://www.elsaltodiario.com/pamplona/socialistas-navarros-presentan-mocion-censura-conjunta-ehbildu-investir-joseba-asiron>
- Fuente abierta: no (solo extracto) · Grupo: `bildu`

**105:16 · Verificación: Sánchez dijo en una entrevista que Iglesias era "el principal escollo" y no podía estar en el Gobierno.** (cita_de_tercero)

- Cita literal: «dijiste literalmente que Pablo Iglesias es el principal escollo, no puede estar en el gobierno»
- Qué dicen las fuentes: Transcripción oficial de la entrevista del 18-7-2019 en laSexta: «el principal escollo para que haya un acuerdo […] es la participación del señor Iglesias en el Gobierno».
- Fuentes: <https://www.lamoncloa.gob.es/presidente/intervenciones/Documents/2019/20190718 PG Entrevista Al rojo vivo La sexta ferreras.pdf> · <https://orain.eus/es/politica/2019/07/18/investidura-pedro-sanchez-veta-pablo-iglesias-18-julio-2019/>
- Fuente abierta: sí · Grupo: `iglesias`

**105:26 · Sánchez apoyó la aplicación del artículo 155.** (voto_o_decision)

- Cita literal: «Y tú apoyaste la aplicación del 155»
- Qué dicen las fuentes: El PSOE, con Sánchez de secretario general, votó a favor de aplicar el artículo 155 en el Senado el 27-10-2017 (214 votos a favor).
- Fuentes: <https://theobjective.com/rajoy-defiende-ante-el-senado-la-aplicacion-del-articulo-155/> · <https://orain.eus/es/politica/2017/10/27/las-medidas-del-articulo-155-a-votacion-en-senado/>
- Fuente abierta: no (solo extracto) · Grupo: `155`

### No he podido comprobarlo (3)

**16:29 · Averías y retrasos son habituales en el tren.** (hecho)

- Cita literal: «las averías son algo habitual, los retrasos son algo habitual»
- Qué dicen las fuentes: No localicé datos de puntualidad o de incidencias que permitan cuantificarlo. El invitado dice compartir el diagnóstico. Dato de contexto: Renfe elevó en 2024 de 15 a 90 minutos el retraso que da derecho a devolución íntegra.
- Fuentes: <https://www.directoalpaladar.com/actualidad-1/renfe-solo-devolvera-100-billete-ave-retrasos-superiores-a-90-minutos>
- Fuente abierta: no (solo extracto)

**84:57 · Colau dijo que el Gobierno ha hecho "cero" en vivienda en ocho años.** (cita_de_tercero)

- Cita literal: «ha dicho que vosotros habéis hecho cero en ocho años»
- Qué dicen las fuentes: En la transcripción automática de la entrevista de Jordi Wild a Colau no encontré la palabra «cero» aplicada a la política de vivienda del Gobierno (sí críticas al incumplimiento de promesas sobre alquileres), y no localicé esa cita en prensa. La transcripción tiene errores y la búsqueda fue por palabras.
- Fuente abierta: no (sin fuente localizada)

**96:30 · Dijo que los topes al alquiler que proponía Iglesias eran inviables.** (hecho)

- Cita literal: «tú dijiste que la propuesta de iglesia será inviable»
- Qué dicen las fuentes: No localicé una declaración de Sánchez calificando de inviables los topes al alquiler que proponía Iglesias. Sí consta que su Gobierno los dejó fuera del decreto de 2019 y que la vicepresidenta Calviño los rechazó en 2020.
- Fuentes: <https://www.elsaltodiario.com/vivienda/calvino-banco-españa-tope-alquileres-sindicato-inquilinos-podemos> · <https://www.publico.es/politica/iglesias-exige-sanchez-frene-subida-alquileres-apoyara-decretos.html>
- Fuente abierta: no (solo extracto) · Grupo: `hemeroteca`

## Páginas abiertas de verdad (18)

- <https://www.articulo14.es/economia/gobierno-refuerza-seguridad-trenes-proteccion-profesionales-urda-tragedia-20261110.html>
- <https://es.ara.cat/politica/saldra-oscar-puente_129_5893607.html>
- <https://www.infobae.com/espana/2026/04/28/conclusion-del-accidente-de-adamuz-la-ciaf-dice-que-se-rompio-el-carril-y-descarta-anomalias-previas-en-los-trenes/>
- <https://es.ara.cat/politica/gobierno-sanchez-rinde-cuentas-26-dias-despues-crisis-ceuta_1_5831446.html>
- <https://elfarodeceuta.es/marlaska-niega-cni-avisara-entrada-masiva-ceuta-confirma-72-000-personas-cruzaron-marruecos/>
- <https://www.lamoncloa.gob.es/presidente/actividades/Paginas/2026/030926-sanchez-comparecencia-ceuta.aspx>
- <https://es.euronews.com/2026/08/31/sanchez-vincula-a-rusia-israel-y-una-internacional-ultraderechista-con-los-bulos-de-ceuta>
- <https://www.diaridetarragona.com/espana/267344/cifras-entrada-masiva-ceuta-37-500-migrantes-han-regresado-marruecos-57-muertos.html>
- <https://www.lamoncloa.gob.es/serviciosdeprensa/notasprensa/inclusion/Paginas/2026/020726-balance-regularizacion-extraordinaria.aspx>
- <https://www.ine.es/dyngs/Prensa/es/EMCR2024.htm>
- <https://ine.es/dyngs/Prensa/PROP20262076.htm>
- <https://www.poderjudicial.es/cgpj/es/Poder-Judicial/Tribunal-Supremo/Noticias-Judiciales/El-Tribunal-Supremo-condena-al-exministro-Jose-Luis-Abalos-y-a-su-exasesor-Koldo-Garcia-a-24-anos-y-19-anos-de-prision--respectivamente--por-delitos-de-organizacion-criminal--cohecho--malversacion-y-trafico-de-influencias>
- <https://www.vozpopuli.com/tribunales/el-video-de-leire-diez-ante-el-juez-solo-he-coincidido-con-sanchez-en-actos-electorales.html>
- <https://www.lamoncloa.gob.es/serviciosdeprensa/notasprensa/vivienda-agenda-urbana/Paginas/2026/280426-reparto-plan-estatal-vivienda.aspx>
- <https://www.elindependiente.com/economia/2026/02/17/sanchez-anuncios-viviendas-desde-2023/>
- <https://www.lamoncloa.gob.es/presidente/intervenciones/Documents/2019/20190718 PG Entrevista Al rojo vivo La sexta ferreras.pdf>
- <https://orain.eus/es/politica/2019/07/18/investidura-pedro-sanchez-veta-pablo-iglesias-18-julio-2019/>
- <https://www.lamoncloa.gob.es/presidente/intervenciones/Paginas/2019/prsp190919.aspx>

La transcripción oficial de La Moncloa del 18-7-2019 es un PDF: se descargó y se leyó su texto completo. Se intentó abrir además, sin obtener el contenido: la nota del Ministerio del Interior sobre la oferta de empleo de 2026 (error 403), dos fichas de Maldita.es (solo titular) y un artículo de Vozpópuli sobre Koldo García (no contenía los elogios).
