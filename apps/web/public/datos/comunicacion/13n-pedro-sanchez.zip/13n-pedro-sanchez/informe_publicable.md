# Sánchez ante Jordi Wild: 131 de 152 preguntas fueron duras, contestó a lo preguntado en 89 y su voz no cambió al apretar

*Análisis de la entrevista de Jordi Wild a Pedro Sánchez en* The Wild Project *(YouTube, 13-nov-2026, 1 h 52 min, https://www.youtube.com/watch?v=mStOFBvToUI). Los minutos son los del vídeo (m:ss).*

De las 152 intervenciones de Jordi Wild que pedían respuesta, 131 (86 %) fueron incómodas, repreguntas o insistencias, y 111 (73 %) partían de una premisa adversa al invitado. A esas 131, Sánchez contestó a lo preguntado en 89, contestó en parte en 23 y contestó a otra pregunta en 14 (en 5 más, Jordi no dejó contestar). Su tono, su volumen y su velocidad son prácticamente iguales con pregunta dura que sin ella. Este informe cuenta lo que se puede medir y qué dice la investigación sobre su efecto probable en quien escucha. No valora ideas ni dice quién estuvo mejor.

Dos avisos. La cara se describe solo con unidades de acción (AU) del sistema FACS, que nombra movimientos musculares y no emociones (**Ekman y Friesen, 1978**). Y, dicho una sola vez: **ni las pausas, ni la voz, ni los gestos, ni las trabas sirven para saber si alguien dice la verdad**. La revisión de 158 señales de **DePaulo y otros (2003)** encontró que la mayoría no distingue a quien miente y que las que lo hacen tienen efectos pequeños, y las personas detectan mentiras poco mejor que al azar (**Bond y DePaulo, 2006**). Aquí esas medidas describen esfuerzo o tensión al hablar, nada más.

## 2. Lo que dicen los datos

| Medida | Sánchez | Jordi Wild |
|---|---|---|
| Palabras verificadas por huella de voz | 10.840 (63,4 %) | 6.266 (36,6 %) |
| Tiempo de habla verificado | 58,4 min | 30,6 min |
| Turnos | 320 | 235 |
| Mediana de palabras por turno | 23 | 19 |
| Turno más largo | 91,8 s | 42,5 s |
| Velocidad en tramos de habla continua | 204 palabras/min | 227 palabras/min |
| Tomas de palabra con menos de 0,2 s de hueco | 72 % | 80 % |
| Frases interrogativas | 23 | 59 |
| *yo* explícito por 1.000 palabras | 13,6 (147 veces) | 9,7 (63 veces) |
| *nosotros* explícito por 1.000 palabras | 3,0 (33 veces) | 0,3 (2 veces) |
| *tú* explícito por 1.000 palabras | 3,4 (37 veces) | 5,9 (38 veces) |
| Solapes de voz que inicia cada uno | 307 | 254 |

Esta tabla sale del informe técnico de esta entrevista, salvo la última fila. Las comparaciones con otras entrevistas usan otros archivos, con definiciones algo distintas de turno, velocidad y latencia; por eso algunas cifras no coinciden (204 y 189 palabras por minuto, 320 y 265 turnos). No se compara la latencia entre entrevistas.

**Reparto.** Sánchez dice el 63,4 % de las palabras, casi lo mismo que Colau con el mismo entrevistador (63,7 %) y menos que Feijóo (72,8 %). En la entrevista periodística los papeles están repartidos de antemano: el entrevistador pregunta y el entrevistado desarrolla la respuesta (**Clayman y Heritage, 2002**).

**Quién corta a quién.** En el recuento automático, Jordi corta el 36,8 % de las respuestas (a Colau, el 50,7 %; a Feijóo, el 22,0 %). Es la única de las tres entrevistas en la que el invitado inicia más solapes de voz que Jordi: 307 frente a 254 (Colau, 258 frente a 459; Feijóo, 133 frente a 187). La lectura manual anota seis interrupciones notables, cuatro de Jordi y dos del invitado. La conversación se organiza por turnos que los hablantes se reparten sobre la marcha (**Sacks, Schegloff y Jefferson, 1974**); cómo lee el espectador cada corte no lo dice ese estudio (sección 10).

**Velocidad.** Jordi habla más deprisa (227 frente a 204 palabras por minuto; diferencia pequeña, d = −0,40). La d de Cohen mide el tamaño de una diferencia: en torno a 0,2 es pequeña, 0,5 media y 0,8 grande.

**Cifras y nombres.** Sánchez dice 1,62 cifras por cada 100 palabras (Feijóo, 2,61; Colau, 0,67); la sección 8 las comprueba. En el recuento automático, sobre una lista fija de nombres, nombra al Gobierno 33 veces, a Abascal 4, a Podemos 4 y a Vox 3. La lectura (sección 7) recoge que de quien más habla es de alguien de su entorno: Ábalos, en 11 respuestas.

### Sánchez con dos entrevistadores

Hay una segunda entrevista de Sánchez medida con el mismo método: la de David Broncano en *La Revuelta*. Son formatos distintos (plató con público y dos presentadores frente a estudio sin público), así que la tabla describe qué cambia y qué se mantiene, sin atribuir causas.

| Medida de Sánchez | Con Jordi Wild | En *La Revuelta* |
|---|---|---|
| Duración del vídeo | 112,1 min | 102,9 min |
| % de las palabras | 63,4 % | 60,1 % |
| Palabras por minuto (con pausas) | 189 | 201 |
| Turnos | 265 | 289 |
| Mediana de palabras por turno | 25 | 16 |
| Mediana de palabras por respuesta | 66 | 19 |
| Palabras por frase | 28,4 | 19,7 |
| Trabas por 100 palabras | 0,33 (36) | 0,98 (83) |
| Trabas en el arranque del turno, por 100 palabras | 0,58 | 1,72 |
| Pausas de más de 0,4 s | 112 | 135 |
| Duración media de la pausa | 0,79 s | 0,95 s |
| Pausas de 2 s o más | 2 | 8 |
| Cifras por 100 palabras | 1,62 | 1,34 |
| Expresiones de certeza por 100 palabras | 0,65 | 0,55 |
| Expresiones de duda por 100 palabras | 0,97 | 0,77 |
| *yo* por 100 palabras (definición amplia) | 2,57 | 2,89 |
| *nosotros* por 100 palabras (definición amplia) | 0,67 | 0,58 |
| Respuestas cortadas por el presentador | 36,8 % | 35,8 % |
| Frases interrogativas del presentador | 59 | 120 |

**Qué cambia.** Con Jordi sus respuestas y sus frases son más largas (66 palabras de mediana frente a 19; 28,4 por frase frente a 19,7), se traba tres veces menos (0,33 frente a 0,98) y hace pausas más cortas (0,79 s frente a 0,95 s). Habla algo más despacio y da algo más de cifras. El presentador formula la mitad de preguntas (59 frente a 120).

**Qué se mantiene.** Su parte de la conversación (63,4 % y 60,1 %), la proporción de respuestas que le cortan (36,8 % y 35,8 %) y, con diferencias menores, el uso de *yo* y *nosotros*. Que una misma persona tenga 0,33 trabas por cada 100 palabras en una entrevista y 0,98 en otra recuerda que estas medidas describen una conversación concreta, no a la persona.

## 3. Trabas contadas una a una

Una traba es un tropiezo al hablar: repetir una palabra o un grupo de palabras, o cortarse a media frase.

| Tipo | Sánchez | Jordi Wild |
|---|---|---|
| Se corta (y reformula o no continúa) | 20 | 16 |
| Repite un grupo de palabras | 8 | 5 |
| Repite una palabra | 8 | 7 |
| Total | 36 | 28 |
| Por cada 100 palabras | 0,33 | 0,45 |
| En las 8 primeras palabras del turno, por 100 palabras | 0,58 | 0,23 |

Son pocas en los dos (Feijóo, 0,25; Colau, 0,28). El dato propio de Sánchez es el arranque: en las primeras ocho palabras de sus turnos se traba 0,58 veces por cada 100 palabras, más que en el resto y más que Jordi (0,23).

**Dónde se concentran.** Por bloques de diez minutos (cálculo propio), hay cinco en el 70–80 (Ábalos y Koldo), cinco en el 80–90 (Zapatero y vivienda) y cinco en el 100–110 (hemeroteca). De las 36, 27 caen tras preguntas duras (0,29 por cada 100 palabras) y 9 en el resto (0,65). Esta comparación es frágil y no debe leerse como que se traba menos bajo presión: el tramo no duro tiene solo 1.394 palabras, y cuatro de sus nueve trabas están en un minuto de anécdota sobre su coche (69:24–70:11).

Ejemplos:

- 19:28, sobre el primer accidente: «hay una investigación abierta por... Hay una investigación abierta por, en».
- 74:31, cuando le piden la fecha de sus elogios a Koldo: «Porque en ese momento... creo que recordar que fue en».
- 100:05, sobre Pablo Iglesias: «nunca dije nunca dije».
- Jordi, 84:06: «pues como no te quieres quitar el marrón... Yo quiero saber tu opinión, pero».

Once de los veinte cortes de Sánchez son frases que no continúan porque entra la otra voz. La psicolingüística clásica asocia las vacilaciones del habla espontánea, sobre todo las pausas, a la **planificación sobre la marcha (Goldman-Eisler, 1968)**; ese trabajo no estudió en concreto repeticiones ni cortes, que es lo que aquí se cuenta.

## 4. Silencios

Se cuentan como pausa los huecos de más de 0,4 segundos entre dos palabras seguidas de la misma persona.

| Medida | Sánchez | Jordi Wild |
|---|---|---|
| Pausas de más de 0,4 s | 112 | 51 |
| Por 1.000 palabras | 10,3 | 8,1 |
| Duración media | 0,79 s | 0,88 s |
| Duración mediana | 0,68 s | 0,76 s |
| De 1 s o más | 22 | 13 |
| Máxima | 2,4 s (92:20) | 2,3 s (14:34) |
| Antes de frase con carga (cifra, rival, contraste) | 20 | 7 |
| Confirmadas por el detector acústico | 17 de 112 (15 %) | 4 de 51 (8 %) |

Dos advertencias. La transcripción tiene cuatro huecos sin texto (22:21–22:46, 33:06–33:28, 92:47–93:13 y 98:25–98:46). Ninguna pausa de la tabla cae en ellos (la más larga dura 2,4 s), así que no hubo que excluir ninguna. Y el detector acústico solo confirma el 15 % de las pausas de Sánchez y el 8 % de las de Jordi: casi todas son huecos entre palabras transcritas, que pueden contener la voz del otro, una risa o ruido.

De las 20 pausas de Sánchez que preceden a una frase con carga, 7 van antes de una cifra, 7 antes de una mención política y 6 antes de un contraste; el detector confirma una sola. Duran casi lo mismo que las demás (0,83 s frente a 0,79 s, cálculo propio). Ejemplos:

- 100:08 (1,5 s), entre «yo nunca dije nunca dije que» y «no quería que Pablo Iglesias estuviera en el gobierno.».
- 38:05 (1,6 s), después de la cifra «es que 9 de cada 10 migrantes que entraron, salieron.».
- 82:18 (1,1 s), antes de «Nosotros a todas las aerolíneas las rescatamos», cuando la pregunta era por Zapatero.

La más larga (2,4 s, 92:20) precede a «Discrepancia que tengo con la derecha y con la ultraderecha.». La más larga de Jordi (2,3 s, 14:34) abre el bloque de los trenes (sección 9).

Tras preguntas duras Sánchez hace casi las mismas pausas que en el resto: 10,5 por cada 1.000 palabras frente a 9,3.

## 5. Voz

| Medida | Sánchez | Jordi Wild |
|---|---|---|
| Frases medidas | 563 | 393 |
| Tono medio (F0) | 121 Hz | 123 Hz |
| Variación del tono dentro de la frase | 3,64 semitonos | 3,40 semitonos |
| Volumen medio (relativo) | 64,7 dB | 67,0 dB |
| Frases con el tono claramente fuera de su media (suben / bajan) | 52 / 19 | 29 / 17 |
| Frases con el volumen claramente fuera de su media (suben / bajan) | 1 / 47 | 3 / 33 |
| Frases con la velocidad claramente fuera de su media (suben / bajan) | 39 / 20 | 32 / 23 |
| Frases que acaban hacia abajo / hacia arriba | 39 % / 8 % | 42 % / 9 % |

El tono medio es el de cada voz y el volumen depende del micrófono; no son conductas. Dentro de cada uno, lo que más se repite es subir el tono y bajar el volumen: Sánchez solo sube claramente el volumen en una frase de 563.

Las frases de Sánchez con el tono más alto respecto a su media son réplicas cortas: «No, eso fue otra historia.» (72:13, z = +3,8) y «Tiene que haberla, pero sobre todo pública.» (89:35, z = +3,6). La z indica cuántas desviaciones se aparta una frase de la media de esa persona. La más rápida es «Yo a día de hoy no tengo esa información.» (40:34, z = +4,0), sobre el papel de Marruecos.

**El arco de la entrevista.** Se usa un índice de intensidad vocal que combina tono, volumen y tensión de la voz; 0 es la media de cada persona. El reparto por temas es cálculo propio.

| Tema (frases de Sánchez) | Intensidad vocal | Tono | Velocidad (palabras/min) |
|---|---|---|---|
| Trayectoria y hemeroteca (33) | +0,46 | 129 Hz | 225 |
| Rivales (27) | +0,28 | 122 Hz | 189 |
| Vivienda (62) | +0,24 | 128 Hz | 209 |
| Corrupción (89) | +0,17 | 123 Hz | 205 |
| Inmigración (67) | +0,02 | 122 Hz | 204 |
| Cataluña (26) | −0,13 | 126 Hz | 182 |
| Fronteras y Marruecos (100) | −0,15 | 118 Hz | 197 |
| Asuntos personales (39) | −0,21 | 114 Hz | 221 |
| Trenes e infraestructuras (73) | −0,38 | 114 Hz | 200 |

La voz de Sánchez va de menos a más: el bloque de diez minutos más apagado es el 20–30 (−0,37, accidentes ferroviarios) y el más intenso el 90–100 (+0,30, vivienda y hemeroteca).

**Voz bajo presión.** Se comparan las frases que Sánchez dice tras una intervención dura de Jordi con las demás, con la misma definición para los tres invitados.

| | Tras pregunta dura (476 frases) | Resto (86 frases) | Tamaño del efecto (d) |
|---|---|---|---|
| Tono | 120,8 Hz | 119,8 Hz | +0,07 |
| Volumen | 64,7 dB | 65,0 dB | −0,04 |
| Velocidad | 204 palabras/min | 203 palabras/min | +0,02 |
| Trabas por 100 palabras | 0,29 (27 trabas) | 0,65 (9 trabas) | — |
| Pausas por 1.000 palabras | 10,5 | 9,3 | — |

Las tres diferencias de voz son inapreciables (por debajo de 0,1), las menores de los tres invitados: en Colau el tono daba d = +0,14 y la velocidad +0,24; en Feijóo, el tono +0,19 y el volumen +0,22. La investigación sobre voz y emoción asocia la activación alta del hablante con subidas de tono y de volumen (**Scherer, 2003; Juslin y Laukka, 2003**): aquí no se observan. Límite: como el 86 % de las preguntas son duras, el grupo de comparación es pequeño (86 frases y 1.394 palabras), y la fila de trabas es frágil (sección 3).

Tampoco cambian el tono ni el volumen en las 38 frases de respuestas que no contestan a lo preguntado (d = −0,11 y +0,01); la velocidad baja algo (d = −0,25).

## 6. Cara

Cada cara se compara con su propia base: se cuentan los tramos de al menos 0,6 segundos en que una zona se aparta con claridad de su posición habitual. La cámara enseña más al invitado: 72,7 minutos con su cara en pantalla frente a 47,1 de Jordi (1,5 veces más; Colau, 1,4; Feijóo, 2,3). A Sánchez casi no se le ve escuchar (7,6 minutos); a Jordi, 12,7.

| Movimiento (episodios por cada 10 min en pantalla) | Sánchez: nº | por 10 min | Jordi: nº | por 10 min |
|---|---|---|---|---|
| AU6 + AU12 (sonrisa: mejillas elevadas y comisuras arriba) | 153 | 21,1 | 138 | 29,3 |
| AU5 (párpado superior arriba, ojos más abiertos) | 108 | 14,9 | 119 | 25,3 |
| AU4 (cejas bajan y se juntan) | 15 | 2,1 | 0 | 0,0 |
| AU1 + AU2 (cejas arriba) | 10 | 1,4 | 67 | 14,2 |
| AU15 (comisuras abajo) | 4 | 0,6 | 0 | 0,0 |
| AU17 (mentón arriba) | 1 | 0,1 | 37 | 7,9 |
| AU23/AU24 (labios apretados) | 0 | 0,0 | 0 | 0,0 |

El movimiento más frecuente en los dos es AU6 + AU12, más en Jordi. En Sánchez aparece igual al hablar que al escuchar (19,6 y 21,1 por 10 minutos); en Jordi, más al hablar (28,7 frente a 16,6). El gesto propio de Jordi es AU1 + AU2: 67 episodios, casi todos mientras habla (21,4 por 10 minutos frente a 1,6 al escuchar), es decir, al preguntar. En Sánchez hay 15 episodios de AU4, todos mientras habla y repartidos por toda la entrevista (del 2:16 al 109:49).

La cara acompaña poco a la voz: la correlación más alta entre un rasgo facial y la intensidad vocal es 0,21.

![Sánchez, 107:18, unos segundos después](fotogramas/m15_despues.jpg)
*107:18, «Pues yo le diría que dije que iba a subir el salario mínimo interprofesional y lo he subido.». AU5 muy por encima de su base (z = +5,9). El fotograma es de unos segundos después: en el instante exacto la realización enfoca a Jordi.*

![Jordi Wild, 68:13, unos segundos después](fotogramas/e07_despues.jpg)
*68:13, Jordi tras decir «Pero dos de ellos han formado parte del círculo.». AU1, AU2 y AU5 por encima de su base (z de +2,7 a +3,0). Fotograma de unos segundos después: el del instante exacto muestra al invitado.*

AU6 + AU12 es la configuración que la literatura llama sonrisa de Duchenne (**Ekman, Davidson y Friesen, 1990**), pero de un movimiento facial no se puede deducir con fiabilidad un estado emocional interno (**Barrett y otros, 2019**). Los niveles absolutos no se comparan entre los dos: el programa no está calibrado por persona, cada uno está grabado con la cabeza girada más de 40 grados hacia un lado y Jordi lleva barba.

## 7. Las preguntas y cómo se responden

Este apartado sale de una lectura manual de la transcripción, hecha por un solo codificador. De las 152 entradas, 16 son dudosas por problemas de la transcripción.

### Cómo pregunta Jordi

| Dureza de la intervención | Nº | % |
|---|---|---|
| Repregunta (vuelve sobre lo mismo) | 66 | 43 % |
| Incómoda (crítica, contradicción, dato adverso) | 33 | 22 % |
| Insistencia (tercera vez o más) | 32 | 21 % |
| Neutra | 15 | 10 % |
| Cómoda | 6 | 4 % |
| **Duras (repregunta + incómoda + insistencia)** | **131** | **86 %** |

Son 13,7 intervenciones por cada diez minutos, 11,8 de ellas duras (Colau, 11,7; Feijóo, 9,9). La proporción de duras es parecida en las tres entrevistas (86 %, 83 % y 77 %). Lo que distingue a esta es la premisa: va en contra del invitado en 111 intervenciones (73 %), frente al 51 % con Colau y el 48 % con Feijóo; es neutra en 38 y a favor en 3. Es el estilo de pregunta adversativa, cuya formulación ya contiene una crítica (**Clayman y Heritage, 2002**). Jordi cierra con un corte o un comentario propio 14 intercambios; el invitado, 138.

### Cómo responde Sánchez

| Clase de respuesta | Todas (152) | Solo a duras (131) |
|---|---|---|
| Responde a lo preguntado | 108 (71 %) | 89 (68 %) |
| Responde en parte | 24 (16 %) | 23 (18 %) |
| Contesta a otra pregunta | 15 (10 %) | 14 (11 %) |
| Cambia de tema | 0 | 0 |
| Ataca la pregunta | 0 | 0 |
| Jordi no deja contestar | 5 (3 %) | 5 (4 %) |
| **No contesta a lo preguntado** | **15 (10 %)** | **14 (11 %)** |

El porcentaje de la última fila se calcula sobre las intervenciones en que Jordi dejó contestar. Con el mismo criterio, Colau quedó en el 15 % y el 18 %, y Feijóo en el 18 % y el 20 %. **Esa diferencia está dentro del margen de la clasificación.** La regla «ante la duda entre dos clases, la más favorable al invitado» se aplicó aquí 12 veces, más que en las otras dos lecturas (7 en la de Feijóo). Según las notas del codificador, en 8 de esas 12 la alternativa era «contesta a otra pregunta» (6 están clasificadas «en parte» y 2 «responde»). Sin la regla, las respuestas que no contestan pasarían de 15 a un máximo de 23 (16 %), y de 14 a 22 entre las duras (17 %), cifras como las de los otros dos. No se puede afirmar, por tanto, que Sánchez eludiera menos que ellos.

La clase mide si la respuesta aborda lo preguntado, no si lo dicho es cierto; negar la premisa dando una versión propia cuenta como responder o responder en parte. En entrevistas políticas una parte grande de las preguntas queda sin respuesta directa (56 % y 59 % en el estudio de **Bull y Mayer, 1993**, sobre Thatcher y Kinnock), y los oyentes a menudo no lo notan cuando la respuesta trata un asunto parecido (**Rogers y Norton, 2011**, en experimentos con vídeos).

**Dónde no contesta.** Casi la mitad de las respuestas a otra pregunta están en un solo tema: los trenes, con 7 de 20 intervenciones (35 %). Después, vivienda (2 de 14), fronteras y Marruecos (2 de 34) y corrupción (1 de 30).

### Las cinco secuencias de más tensión

**1. El cese de Óscar Puente (27:14–28:30).** Jordi: «Si no hubiera dimitido, ¿lo hubieras cesado?». Sánchez: «Yo creo que ese debate hoy está superado.». Jordi reformula y, a la tercera, dice «pero eso no es lo que te he preguntado». Respuesta: «Oscar Puente fue el que tomó la decisión». No hay un sí o un no en tres intentos. La teoría del **equívoco (Bavelas y otros, 1990)** explica estas respuestas por la situación, no por la persona: toda respuesta directa tiene coste.

**2. Las vacaciones durante la crisis de Ceuta (44:18–50:20).** Jordi: «¿cómo se debe sentir el Zotí [ceutí] cuando su presidente está» de vacaciones. Sánchez niega la premisa: «No, no, perdona, yo no me fui de vacaciones» y «Yo estuve trabajando todos los días.». A «¿Era el mejor momento?» contesta «Para mí el mejor momento era dar la cara como la di ese día».

**3. El papel de Marruecos (35:58–44:20).** A si Marruecos estuvo detrás de la avalancha responde «Yo a día de hoy no tengo esa información.». Después saca un asunto que no se le había preguntado, el hackeo de su teléfono: «aquí tienes mi móvil.» (41:57). Jordi: «Yo no te digo por el tema del hackeo, yo no te lo he mencionado.» y, al cerrar, «de momento no has dicho si el responsable es Marruecos o no».

**4. Ábalos y Koldo (71:40–77:25).** Los verificadores del programa sacan elogios antiguos de Sánchez a Koldo García. Jordi: «aquí yo veo que sientes admiración por él». Sánchez: «Es un reconocimiento.». Jordi: «Es una alabanza impresionante.». Sobre Ábalos: «me llevé una tremenda decepción, Jordi».

**5. Zapatero (81:40–84:30).** Jordi: «¿Tú pondrías la mano en el fuego por él?». Sánchez empieza por el fondo de rescate: «Nosotros a todas las aerolíneas las rescatamos». Jordi: «la pregunta era muy simple». Tras cuatro intervenciones más llega la respuesta: «Yo pongo la mano en el fuego por José Luis.» (84:11).

Fuera de esas cinco: a «A día de hoy, ¿cuántas están entregadas y con gente viviendo en ellas?» (90:17, sobre 184.000 viviendas comprometidas) responde «no te quiero decir ahora mismo el dato exacto porque no lo he buscado y no lo he encontrado» y, tras la insistencia, «vamos a cumplir con ese compromiso».

**Preguntas devueltas.** Sánchez devuelve la pregunta en 5 intercambios (Colau, 6; Feijóo, 18). La más marcada, cuando Jordi le reprocha los cambios de palabra: «Tú, por ejemplo, el 1 de octubre de 2017 votaste.» (102:43).

### Temas

| Tema | Minutos | % |
|---|---|---|
| Fronteras y Marruecos | 22,4 | 20 % |
| Corrupción | 15,6 | 14 % |
| Trenes e infraestructuras | 14,8 | 13 % |
| Inmigración | 14,8 | 13 % |
| Vivienda | 10,6 | 10 % |
| Trayectoria y hemeroteca | 6,0 | 5 % |
| Rivales | 5,7 | 5 % |
| Asuntos personales | 5,7 | 5 % |
| Cataluña y modelo territorial | 4,3 | 4 % |
| Resto (6 temas) | 10,7 | 10 % |

Jordi abre 42 de los 48 tramos; el invitado, 6 (12 %; Colau y Feijóo, 19 %), que suman 5,1 minutos, el 5 % del tiempo (cálculo propio): una anécdota de Borrell, el hackeo de su móvil, las inversiones en Ceuta, la decisión de alargar la entrevista, el origen de los migrantes y Pablo Iglesias. No tienen tramo propio economía y empleo, pensiones, impuestos, deuda, política internacional, defensa, sanidad y educación, feminismo, juventud ni clima. Los temas que destacan los medios tienden a ser los que la audiencia considera importantes (**fijación de agenda, McCombs y Shaw, 1972**), y los partidos procuran llevar el debate a los temas en que el público los percibe como más competentes (**propiedad de los temas, Petrocik, 1996**): aquí el invitado solo abre tramos breves, y los asuntos económicos que cita como logros (salario mínimo, pensiones) no llegan a tener tramo.

### Propuesta, terceros, mérito y culpa

En 45 respuestas (30 %) dice qué hizo o haría; en 38 (25 %) habla de rivales o terceros; en 18 (12 %), las dos cosas; en 51, ninguna. Aquí «terceros» no equivale a rivales: de las 56 respuestas en que habla de otros, 25 nombran a personas de su propio entorno (Ábalos, Koldo García, Cerdán, Puente, Zapatero, Leire Díez) y 22 a rivales políticos (Abascal, PP, Feijóo, Vox y otros), según un filtro propio sobre los nombres anotados.

| De qué habla | yo | nosotros | ellos | impersonal | otros |
|---|---|---|---|---|---|
| Logros (28) | 4 | 16 | 3 | 3 | 2 (Óscar Puente) |
| Fracasos (27) | 3 | 3 | 17 | 4 | 0 |
| Problemas (18) | 0 | 2 | 9 | 6 | 1 (todas las administraciones) |

Veinte de los 28 logros van en primera persona, sobre todo en plural: «Hemos multiplicado por 8 el presupuesto en vivienda.» (88:09). Diecisiete de los 27 fracasos se atribuyen a un *ellos*, que incluye a rivales («se recortaron las fuerzas y cuerpos de seguridad del Estado», 64:29, sobre los años de Rajoy) y a su propio entorno («me llevé una tremenda decepción, Jordi», 68:46, sobre Ábalos). Hay seis fracasos en primera persona, tres con *yo*: «Bueno, por supuesto que tengo que hacer las cosas mejor» (43:10, sobre Ceuta), «Oye, yo pedí perdón, asumí esa responsabilidad.» (73:35; la transcripción lo pone en un turno de Jordi) y «Y bueno, pues evidentemente yo cometo errores.» (108:32). Atribuirse los éxitos es un patrón bien documentado; que además se sitúen fuera los fracasos lo está menos (**Miller y Ross, 1975**, lo pusieron en duda; revisiones posteriores, como **Zuckerman, 1979**, sí lo encuentran). En política se ha descrito además la tendencia a priorizar evitar la culpa sobre reclamar el mérito (**Weaver, 1986**).

**Pasado frente a futuro.** Con una aproximación por terminaciones verbales, orientativa, Sánchez usa unas 10 formas de pasado por cada forma de futuro (Colau, 11,7; Feijóo, 2,8).

### Promesas verificables

Se recogieron 19 compromisos; 7 tienen un objeto que se podrá comprobar (0,6 por cada diez minutos, como Colau; Feijóo, 2,3).

| Minuto | Cita | Compromiso |
|---|---|---|
| 18:13 | «una auditoría extraordinaria de seguridad de la línea Madrid -Sevilla» | Auditoría de seguridad de la línea Madrid-Sevilla (la presenta como en marcha) |
| 18:24 | «vamos a invertir 19 .000 millones de euros en el mantenimiento» | 19.000 millones en mantenimiento de vías (2026-2030) |
| 19:12 | «Bueno, pues, hagámoslo también en el transporte ferroviario.» | Implantar la doble firma en el ferrocarril |
| 86:48 | «Pues regular, por ejemplo, el alquiler de habitaciones, los alojamientos temporales» | Regular el alquiler de habitaciones y de temporada |
| 89:28 | «por ejemplo, necesitamos modificar la ley» | Modificar la ley del suelo |
| 91:38 | «nosotros en lo que es la entrega y la construcción vamos a cumplir con ese compromiso» | Cumplir las 184.000 viviendas públicas y de alquiler asequible |
| 101:04 | «se ha acabado la legislatura y volverá en la próxima legislatura» | Volver a llevar al Congreso la derogación de la ley mordaza |

Solo dos llevan plazo. Los 12 restantes son intenciones generales o condicionadas, como «Tenemos que construir más vivienda protegida.» (86:41).

### Sintonía con Jordi

La transcripción automática no recoge risas, así que este recuento es de lectura: 66 momentos de relación, entre ellos 15 bromas (10 las inicia Jordi), 12 halagos (7 del invitado), 11 acuerdos explícitos (7 del invitado), 11 roces (6 de Jordi) y 7 anécdotas personales, todas del invitado. Por cada diez minutos hay más halagos y acuerdos que en las otras dos entrevistas (1,1 y 1,0; con Colau, 0,7 y 0,6; con Feijóo, 0,8 y 0,8). Bromas y roces se alternan: «Bueno, tienes un avión, no me jodas.» (70:11), a lo que Sánchez responde «Un día si quieres te subo.»; y Jordi, «Te lo prometo, yo me quedaría aquí tres horas contigo.» (96:50). Atención mutua, tono positivo y coordinación son los tres componentes de la **sintonía entre dos personas (Tickle-Degnen y Rosenthal, 1990)**.

## 8. Comprobación de datos

Se extrajeron 188 afirmaciones factuales (137 del invitado y 51 de Jordi). 22 del invitado no eran comprobables (vivencias, conversaciones privadas) y no se buscaron; las otras 166 se contrastaron con buscador web el mismo 13-nov-2026.

| Veredicto | Sánchez | Jordi Wild |
|---|---|---|
| Se sostiene (respaldada) | 71 | 42 |
| Verdad a medias (respaldada en parte o imprecisa) | 18 | 6 |
| No se sostiene (sin respaldo) | 1 | 0 |
| No verificable | 2 | 0 |
| No se pudo comprobar | 23 | 3 |
| **Total comprobadas** | **115** | **51** |

**Esto no es una nota, y comparar porcentajes entre los dos, o con las otras entrevistas, no es válido:** hablan de cosas distintas (él da cifras de gestión; Jordi lee datos preparados y hemeroteca) y varias filas repiten un mismo dato. Además, **solo 41 de las 166 filas (26 de él y 15 de Jordi) tienen la fuente abierta de verdad**; el resto se apoya en extractos del buscador y de prensa, y hay que abrir el enlace antes de citarlo.

**No se sostiene (1, del invitado).**

- 100:05 — «yo nunca dije nunca dije que» «no quería que Pablo Iglesias estuviera en el gobierno.». La transcripción oficial de La Moncloa de su entrevista del 18-7-2019 recoge que «no se dan las condiciones» para que Iglesias fuera miembro del Gobierno y que su participación era «el principal escollo». [Fuente](https://www.lamoncloa.gob.es/presidente/intervenciones/Documents/2019/20190718%20PG%20Entrevista%20Al%20rojo%20vivo%20La%20sexta%20ferreras.pdf). Aviso: este veredicto tiene la fuente oficial abierta y leída completa, pero **no ha pasado una segunda revisión independiente**, como sí la pasaron los veredictos negativos de las otras dos entrevistas.

**Verdades a medias (ejemplos).**

- Sánchez, 31:04 — «los más de 80 .000 que el 30 y el 31 de julio entraron». No hay cifra oficial única: Interior dio 72.000 y él mismo habló de 70.000 en el Congreso. [Fuente](https://es.ara.cat/politica/gobierno-sanchez-rinde-cuentas-26-dias-despues-crisis-ceuta_1_5831446.html) (abierta).
- Sánchez, 65:26 — «bueno, más o menos es un millón doscientas mil personas.». Son 1.174.978 solicitudes de regularización, no personas ya regularizadas. [Fuente](https://www.lamoncloa.gob.es/serviciosdeprensa/notasprensa/inclusion/Paginas/2026/020726-balance-regularizacion-extraordinaria.aspx) (abierta).
- Sánchez, 88:13 — «más de 7 .000 millones de euros para la construcción». El plan estatal está dotado con 7.000 millones, de los que el Estado pone el 60 %, y en abril de 2026 no se había transferido nada. [Fuente](https://www.lamoncloa.gob.es/serviciosdeprensa/notasprensa/vivienda-agenda-urbana/Paginas/2026/280426-reparto-plan-estatal-vivienda.aspx) (abierta).
- Jordi, 31:14 — «se esté moviendo casi 100 .000 personas». Las cifras localizadas van de 70.000 a 80.000. [Fuente](https://es.ara.cat/politica/gobierno-sanchez-rinde-cuentas-26-dias-despues-crisis-ceuta_1_5831446.html) (abierta).
- Jordi, 76:00 — «Le dedicas un post en tu propio Instagram.». Los textos localizados se publicaron en su blog y en Facebook (solo extracto). [Fuente](https://www.vozpopuli.com/espana/politica/koldo-garcia-hombre-durmio-urnas-sanchez-narra-presidente-mision-manual-resistencia.html).

**Se sostienen (ejemplos, todos con la fuente abierta).**

- Sánchez, 35:22 — «Bueno, tuvimos más de 140 muertos.». [Fuente](https://es.ara.cat/politica/gobierno-sanchez-rinde-cuentas-26-dias-despues-crisis-ceuta_1_5831446.html).
- Sánchez, 38:01 — «es que 9 de cada 10 migrantes que entraron, salieron». Es la cifra del Gobierno; la fuente oficial habla de 72 horas. [Fuente](https://www.lamoncloa.gob.es/presidente/actividades/Paginas/2026/030926-sanchez-comparecencia-ceuta.aspx).
- Jordi, 67:41 — «en el caso de Ábalos, ya condenado, 24 años de cárcel». [Fuente](https://www.poderjudicial.es/cgpj/es/Poder-Judicial/Tribunal-Supremo/Noticias-Judiciales/El-Tribunal-Supremo-condena-al-exministro-Jose-Luis-Abalos-y-a-su-exasesor-Koldo-Garcia-a-24-anos-y-19-anos-de-prision--respectivamente--por-delitos-de-organizacion-criminal--cohecho--malversacion-y-trafico-de-influencias).

Sobre el efecto en la audiencia: una corrección suele mejorar lo que la gente cree sobre el dato, pero apenas cambia su valoración del político corregido (**Nyhan, Porter, Reifler y Wood, 2020**).

## 9. Momentos clave

Son puntos donde coinciden varias señales medidas por separado. Que coincidan no demuestra que estén relacionadas, y de ninguno se deduce una intención.

**27:19 — El cese de Puente.** «Yo creo que ese debate hoy está superado.». La frase va más despacio que su media (z = −1,9), AU23 (labios apretados) queda por encima de su base (z = +2,3) y la respuesta está clasificada como «contesta a otra pregunta».

![Sánchez, 27:19](fotogramas/m03_durante.jpg)

**45:18 — Las vacaciones.** «No, no, perdona, yo no me fui de vacaciones». Baja el volumen (z = −2,0) y AU17 (mentón arriba) queda por encima de su base (z = +2,4).

![Sánchez, 45:18](fotogramas/m06_durante.jpg)

**52:20 — Por qué preocupa la inmigración.** Tras una pausa de 1,1 s, «Yo creo que sobre todo es el desafío de la integración.». Es uno de los tres tonos más altos de su entrevista (z = +3,5), con el volumen abajo (z = −2,2), la velocidad arriba (z = +1,9) y AU7 y AU4 por encima de su base (z = +3,1 y +2,3). La pregunta es neutra.

**107:18 — La hemeroteca.** El único momento con cuatro categorías de señal: «dije que iba a subir el salario mínimo interprofesional y lo he subido». Más rápido que su media (z = +2,2) y con la AU5 más marcada de sus momentos (z = +5,9). Fotograma en la sección 6.

**Jordi, 14:34 — Los accidentes.** La pausa más larga de su entrevista (2,3 s) antes de «Vamos primero a Damuz [Adamuz], cuando sucede, en ese momento,». Bajan el tono (z = −1,9), el volumen (z = −3,9) y la velocidad (z = −1,6).

![Plano general, 14:34](fotogramas/e04_durante.jpg)
*14:34, plano general.*

**Jordi, 78:01 — Dos secretarios de organización.** «elegidos por ti, tengan este problema, ¿qué dice de». Es la bajada de volumen más fuerte de sus momentos (z = −4,0), con AU24 (labios presionados) por encima de su base (z = +2,4). También baja la voz en «¿Tú sabes algo de esto?» (80:04, z = −3,8).

![Jordi Wild, 78:01](fotogramas/e08_durante.jpg)

## 10. Por qué cada espectador vio una entrevista distinta

Los mismos 111 minutos permiten dos resúmenes opuestos, los dos con datos ciertos.

Un votante afín a Sánchez puede citar que contestó a lo preguntado en 108 de 152 ocasiones, que 71 de sus afirmaciones se sostienen y que admitió errores en primera persona («Oye, yo pedí perdón, asumí esa responsabilidad.»). Uno contrario puede citar que en tres intentos no dijo si habría cesado a su ministro, que no dio el dato de las viviendas habitadas, que la afirmación sobre Pablo Iglesias no se sostiene y que 17 de sus 27 fracasos van en *ellos*.

Con Jordi ocurre lo mismo. Quien piense que fue duro tiene el 86 % de preguntas duras, el 73 % con premisa en contra. Quien piense que fue blando tiene los 12 halagos, que cerró él solo 14 de 152 intercambios.

La psicología describe varios mecanismos. El **sesgo de confirmación (Nickerson, 1998)**: se busca y se recuerda lo que encaja con lo que ya se pensaba. El **razonamiento motivado (Kunda, 1990; Taber y Lodge, 2006)**: la información contraria se examina con más exigencia que la favorable, de modo que cada bando valora como más sólida la evidencia que le favorece (**asimilación sesgada, Lord, Ross y Lepper, 1979**). Y el **efecto de medio hostil (Vallone, Ross y Lepper, 1985)**: los partidarios de cada bando perciben la misma cobertura informativa como sesgada contra el suyo; aplicarlo a un entrevistador es una extensión de ese estudio.

También influye el **encuadre (Entman, 1993)**, que consiste en destacar unos aspectos de un asunto frente a otros. La entrevista tiene un ejemplo explícito: sobre los insultos en política, Jordi dice «Sí, pero el juego sucio es bidireccional.» (9:38) y Sánchez, «Yo creo que los insultos son asimétricos» (10:35).

## 11. Lo que este análisis no puede decir

- **Transcripción automática.** Tiene cuatro huecos sin texto (unos 94 segundos en total) y muchos nombres mal escritos («Coldo», «Damuz», «Feijó»), que se citan tal cual. Donde se pisan las voces hay bastantes turnos mal atribuidos, sobre todo en 41:15–42:50, 68:27–68:35, 99:30–100:30 y 109:15–110:30. Solo se usan las palabras verificadas por huella de voz (86 % de las del invitado, 81 % de las de Jordi). No transcribe risas ni titubeos.
- **Pausas.** Se miden entre palabras transcritas. El detector acústico confirma 17 de las 112 del invitado y 4 de las 51 de Jordi.
- **Cara.** La realización decide a quién se ve, y al invitado casi no se le ve escuchar. Las caras se asignaron a mano sobre diez grupos formados por parecido: dos se descartaron y otros dos incluyen algún recorte suelto de la otra persona. Las AU las estima un modelo estadístico, no un codificador humano. No se midieron la mirada ni el parpadeo.
- **Lectura de preguntas y respuestas.** La hizo un solo codificador, con 16 entradas dudosas y 12 aplicaciones de la regla de la clase más favorable. Las diferencias de evasión entre los tres invitados caben dentro de ese margen.
- **Comprobación de datos.** Tres de cada cuatro veredictos descansan en extractos, no en la fuente abierta, y el único negativo no ha pasado segunda revisión.
- **Comparaciones.** Con las otras entrevistas de Jordi cambian la duración y los temas; con *La Revuelta*, además, el formato. Ninguna diferencia se puede atribuir a una causa concreta.
- **Referencias y alcance.** Los estudios describen efectos medios, muchos de laboratorio y en inglés. Es una sola entrevista, y nada de lo medido permite saber si alguien dice la verdad, qué siente o cómo es.

## 12. Para llevarte a casa

1. **Repreguntas con premisa en contra.** 131 de 152 intervenciones de Jordi fueron duras (86 %) y 111 partían de una premisa adversa (73 %, frente a la mitad con Colau y Feijóo).
2. **Sánchez contestó a lo preguntado en 89 de las 131 duras** y nunca atacó la pregunta ni cambió de tema. Donde menos contestó fue en los trenes (7 de 20).
3. **No se puede decir que eludiera menos que los otros dos:** sin la regla de la clase más favorable, aplicada 12 veces, su 10 % de respuestas que no contestan subiría hasta el 16 %.
4. **Su voz no cambia bajo presión.** Tono, volumen y velocidad apenas difieren entre preguntas duras y el resto (d = +0,07, −0,04 y +0,02), las diferencias menores de los tres invitados.
5. **Los logros, en *nosotros*; los fracasos, en *ellos*.** 16 de 28 logros con *nosotros* y 17 de 27 fracasos con *ellos*, que incluye a rivales y a personas de su entorno; 3 fracasos con *yo*.
6. **Con otro entrevistador y otro formato, otras cifras.** Con Jordi se traba tres veces menos que en *La Revuelta* (0,33 frente a 0,98 por 100 palabras) y responde más largo (66 palabras de mediana frente a 19); su parte de la conversación apenas cambia (63,4 % y 60,1 %).
7. **En los datos, 71 afirmaciones suyas se sostienen, 18 son verdad a medias y 1 no se sostiene** (la de Pablo Iglesias, pendiente de segunda revisión); solo 41 de 166 filas tienen la fuente abierta, y no es una nota.

## 13. Fuentes

**Vídeo.** *The Wild Project #393 - Pedro Sánchez*, YouTube, 13-nov-2026: https://www.youtube.com/watch?v=mStOFBvToUI

**Referencias académicas citadas.**

- Barrett, L. F., Adolphs, R., Marsella, S., Martinez, A. M. y Pollak, S. D. (2019). Emotional expressions reconsidered: Challenges to inferring emotion from human facial movements. *Psychological Science in the Public Interest*, 20(1), 1–68.
- Bavelas, J. B., Black, A., Chovil, N. y Mullett, J. (1990). *Equivocal Communication*. Sage.
- Bond, C. F. y DePaulo, B. M. (2006). Accuracy of deception judgments. *Personality and Social Psychology Review*, 10(3), 214–234.
- Bull, P. y Mayer, K. (1993). How not to answer questions in political interviews. *Political Psychology*, 14(4), 651–666.
- Clayman, S. y Heritage, J. (2002). *The News Interview: Journalists and Public Figures on the Air*. Cambridge University Press.
- DePaulo, B. M., Lindsay, J. J., Malone, B. E., Muhlenbruck, L., Charlton, K. y Cooper, H. (2003). Cues to deception. *Psychological Bulletin*, 129(1), 74–118.
- Ekman, P. y Friesen, W. V. (1978). *Facial Action Coding System*. Consulting Psychologists Press.
- Ekman, P., Davidson, R. J. y Friesen, W. V. (1990). The Duchenne smile: Emotional expression and brain physiology II. *Journal of Personality and Social Psychology*, 58(2), 342–353.
- Entman, R. M. (1993). Framing: Toward clarification of a fractured paradigm. *Journal of Communication*, 43(4), 51–58.
- Goldman-Eisler, F. (1968). *Psycholinguistics: Experiments in Spontaneous Speech*. Academic Press (editorial no confirmada).
- Juslin, P. N. y Laukka, P. (2003). Communication of emotions in vocal expression and music performance: Different channels, same code? *Psychological Bulletin*, 129(5), 770–814.
- Kunda, Z. (1990). The case for motivated reasoning. *Psychological Bulletin*, 108(3), 480–498.
- Lord, C. G., Ross, L. y Lepper, M. R. (1979). Biased assimilation and attitude polarization: The effects of prior theories on subsequently considered evidence. *Journal of Personality and Social Psychology*, 37(11), 2098–2109.
- McCombs, M. E. y Shaw, D. L. (1972). The agenda-setting function of mass media. *Public Opinion Quarterly*, 36(2), 176–187.
- Miller, D. T. y Ross, M. (1975). Self-serving biases in the attribution of causality: Fact or fiction? *Psychological Bulletin*, 82(2), 213–225.
- Nickerson, R. S. (1998). Confirmation bias: A ubiquitous phenomenon in many guises. *Review of General Psychology*, 2(2), 175–220.
- Nyhan, B., Porter, E., Reifler, J. y Wood, T. J. (2020). Taking fact-checks literally but not seriously? The effects of journalistic fact-checking on factual beliefs and candidate favorability. *Political Behavior*, 42(3), 939–960.
- Petrocik, J. R. (1996). Issue ownership in presidential elections, with a 1980 case study. *American Journal of Political Science*, 40(3), 825–850.
- Rogers, T. y Norton, M. I. (2011). The artful dodger: Answering the wrong question the right way. *Journal of Experimental Psychology: Applied*, 17(2), 139–147.
- Sacks, H., Schegloff, E. A. y Jefferson, G. (1974). A simplest systematics for the organization of turn-taking for conversation. *Language*, 50(4), 696–735.
- Scherer, K. R. (2003). Vocal communication of emotion: A review of research paradigms. *Speech Communication*, 40(1–2), 227–256.
- Taber, C. S. y Lodge, M. (2006). Motivated skepticism in the evaluation of political beliefs. *American Journal of Political Science*, 50(3), 755–769.
- Tickle-Degnen, L. y Rosenthal, R. (1990). The nature of rapport and its nonverbal correlates. *Psychological Inquiry*, 1(4), 285–293.
- Vallone, R. P., Ross, L. y Lepper, M. R. (1985). The hostile media phenomenon: Biased perception and perceptions of media bias in coverage of the Beirut massacre. *Journal of Personality and Social Psychology*, 49(3), 577–585.
- Weaver, R. K. (1986). The politics of blame avoidance. *Journal of Public Policy*, 6(4), 371–398.
- Zuckerman, M. (1979). Attribution of success and failure revisited, or: The motivational bias is alive and well in attribution theory. *Journal of Personality*, 47(2), 245–287.

**Archivos de datos (carpeta de la entrevista).** `informe.md`, `informe_tonalidad.md`, `informe_expresiones.md`, `informe_movimiento.md`; `transcripcion.csv`, `palabras.csv`, `qa_pares.csv`, `hablantes.json`; `disfluencias_resumen.csv`, `disfluencias_eventos.csv`; `pausas_entrevistado.csv`, `pausas_entrevistador.csv`; `voz_entrevistado.csv`, `voz_entrevistador.csv`, `tonalidad_entrevistado.csv`, `tonalidad_entrevistador.csv`; `retorica.csv`; `cara_entrevistado.csv`, `cara_entrevistador.csv`, `expresiones_resumen.csv`, `expresiones_eventos.csv`, `movimiento_resumen.csv`; `comparativa.csv`, `momentos_entrevistado.csv`, `momentos_entrevistador.csv`, `fotogramas/`; `lectura/` (`preguntas.json`, `temas.json`, `afirmaciones.json`, `promesas.json`, `merito_culpa.json`, `sintonia.json`, `resumen.md`); `verificacion_datos.md` y `verificacion_datos.csv`. Comparación con otras entrevistas: `comparacion/v3/metricas.md`, `comparacion/v3/extra.md`, `comparacion/lectura3/lectura_comparada.md` y `comparacion/presion/presion.md`; entrevista de *La Revuelta*: columna `sanchez_revuelta` de `comparacion/v3/` y `herramientas/prueba_abascal_sanchez.md`.
