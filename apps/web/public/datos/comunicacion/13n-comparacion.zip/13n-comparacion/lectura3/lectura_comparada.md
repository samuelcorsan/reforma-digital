# Lectura comparada de las entrevistas de Jordi Wild

Recuentos de la clasificación manual de cada intervención de Jordi que pide respuesta (criterios en `herramientas/criterios_lectura.md`, los mismos para todos). Las entradas marcadas como dudosas por la transcripción se cuentan, y su número se indica.

## 1. Cómo pregunta Jordi a cada invitado

### Dureza, premisa y cierre

| | Colau | Feijóo | Sánchez |
|---|---|---|---|
| minutos de entrevista | 133 | 87 | 111 |
| intervenciones que piden respuesta | 187 | 111 | 152 |
| por cada 10 minutos | 14.1 | 12.8 | 13.7 |
| marcadas como dudosas | 4 | 18 | 16 |
| dureza: neutra | 29 (16 %) | 23 (21 %) | 15 (10 %) |
| dureza: comoda | 2 (1 %) | 2 (2 %) | 6 (4 %) |
| dureza: incomoda | 43 (23 %) | 26 (23 %) | 33 (22 %) |
| dureza: repregunta | 70 (37 %) | 38 (34 %) | 66 (43 %) |
| dureza: insistencia | 43 (23 %) | 22 (20 %) | 32 (21 %) |
| duras (incómoda + repregunta + insistencia) | 156 (83 %) | 86 (77 %) | 131 (86 %) |
| duras por cada 10 minutos | 11.7 | 9.9 | 11.8 |
| premisa en contra | 95 (51 %) | 53 (48 %) | 111 (73 %) |
| premisa neutra | 89 (48 %) | 54 (49 %) | 38 (25 %) |
| premisa a favor | 3 (2 %) | 4 (4 %) | 3 (2 %) |
| intercambios que cierra Jordi | 11 (6 %) | 15 (14 %) | 14 (9 %) |

## 2. Cómo responde cada invitado

### Todas las intervenciones

| | Colau | Feijóo | Sánchez |
|---|---|---|---|
| responde | 121 (65 %) | 71 (64 %) | 108 (71 %) |
| responde en parte | 33 (18 %) | 18 (16 %) | 24 (16 %) |
| contesta a otra pregunta | 27 (14 %) | 16 (14 %) | 15 (10 %) |
| cambia de tema | 0 (0 %) | 3 (3 %) | 0 (0 %) |
| ataca la pregunta | 1 (1 %) | 1 (1 %) | 0 (0 %) |
| Jordi no deja contestar | 5 (3 %) | 2 (2 %) | 5 (3 %) |
| **no contesta a lo preguntado** (otra pregunta + cambia de tema + ataca la pregunta) | 28 (15 %) | 20 (18 %) | 15 (10 %) |

El porcentaje de «no contesta» se calcula sobre las intervenciones en las que Jordi dejó contestar.

### Solo a preguntas duras

| | Colau | Feijóo | Sánchez |
|---|---|---|---|
| responde | 94 (60 %) | 52 (60 %) | 89 (68 %) |
| responde en parte | 30 (19 %) | 15 (17 %) | 23 (18 %) |
| contesta a otra pregunta | 26 (17 %) | 13 (15 %) | 14 (11 %) |
| cambia de tema | 0 (0 %) | 3 (3 %) | 0 (0 %) |
| ataca la pregunta | 1 (1 %) | 1 (1 %) | 0 (0 %) |
| Jordi no deja contestar | 5 (3 %) | 2 (2 %) | 5 (4 %) |
| **no contesta a lo preguntado** (otra pregunta + cambia de tema + ataca la pregunta) | 27 (18 %) | 17 (20 %) | 14 (11 %) |

El porcentaje de «no contesta» se calcula sobre las intervenciones en las que Jordi dejó contestar.

### Preguntas devueltas y orientación de la respuesta

| | Colau | Feijóo | Sánchez |
|---|---|---|---|
| devuelve la pregunta a Jordi | 6 | 18 | 5 |
| orientación: propone | 39 (21 %) | 27 (24 %) | 45 (30 %) |
| orientación: critica | 71 (38 %) | 30 (27 %) | 38 (25 %) |
| orientación: ambas | 31 (17 %) | 18 (16 %) | 18 (12 %) |
| orientación: ninguna | 46 (25 %) | 36 (32 %) | 51 (34 %) |

«critica» = habla de rivales o terceros, aunque no sea en negativo.

### Temas donde no contesta a lo preguntado

**Colau** (temas con 4 o más intervenciones): corrupcion 6/14 (43 %) · partido_interno 4/15 (27 %) · asuntos_personales 1/4 (25 %) · inmigracion 4/19 (21 %) · vivienda 5/24 (21 %) · infraestructuras_y_transporte 2/14 (14 %) · fronteras_y_marruecos 3/21 (14 %) · trayectoria_y_gestion_pasada 2/15 (13 %) · defensa_y_seguridad 0/5 (0 %) · feminismo_e_igualdad 0/7 (0 %) · pactos_y_gobernabilidad 0/6 (0 %) · medios_y_redes 0/4 (0 %) · rivales 0/16 (0 %) · politica_internacional 0/12 (0 %)

**Feijóo** (temas con 4 o más intervenciones): partido_interno 5/14 (36 %) · defensa_y_seguridad 2/6 (33 %) · fronteras_y_marruecos 2/6 (33 %) · rivales 6/20 (30 %) · corrupcion 2/7 (29 %) · pactos_y_gobernabilidad 1/7 (14 %) · asuntos_personales 1/8 (12 %) · inmigracion 1/11 (9 %) · deuda_y_gasto 0/9 (0 %) · economia_y_empleo 0/4 (0 %) · impuestos_y_autonomos 0/4 (0 %) · pensiones 0/8 (0 %)

**Sánchez** (temas con 4 o más intervenciones): infraestructuras_y_transporte 7/20 (35 %) · vivienda 2/14 (14 %) · rivales 1/11 (9 %) · inmigracion 1/13 (8 %) · fronteras_y_marruecos 2/34 (6 %) · corrupcion 1/30 (3 %) · asuntos_personales 0/4 (0 %) · trayectoria_y_gestion_pasada 0/6 (0 %)


### A quién nombra al criticar o hablar de terceros

**Colau**: Pedro Sánchez 11, PSOE 11, Vox 10, PP 9, Podemos 8, Marruecos 6, la derecha 5, gobierno 4, Israel 4, Elon Musk 3

**Feijóo**: Pedro Sánchez 28, Gobierno 15, PSOE 6, Marruecos 4, Vox 3, Podemos 1, Bildu 1, gobiernos de izquierda 1, ministro del Interior 1, ministra de Defensa 1

**Sánchez**: José Luis Ábalos 11, Koldo García 6, José Luis Rodríguez Zapatero 6, Santiago Abascal 5, PP 5, Alberto Núñez Feijóo 4, Marruecos 4, Santos Cerdán 3, Javier Milei 2, gobierno de Mariano Rajoy 2


## 3. Reparto del tiempo por temas

Minutos (y % de la entrevista) por tema.

| tema | Colau | Feijóo | Sánchez |
|---|---|---|---|
| fronteras_y_marruecos | 15.2 (11 %) | 8.3 (10 %) | 22.4 (20 %) |
| inmigracion | 20.3 (15 %) | 7.8 (9 %) | 14.8 (13 %) |
| corrupcion | 9.9 (8 %) | 8.5 (10 %) | 15.6 (14 %) |
| vivienda | 17.3 (13 %) | — | 10.6 (10 %) |
| infraestructuras_y_transporte | 10.0 (8 %) | — | 14.8 (13 %) |
| rivales | 6.0 (4 %) | 12.4 (14 %) | 5.7 (5 %) |
| trayectoria_y_gestion_pasada | 14.4 (11 %) | — | 6.0 (5 %) |
| asuntos_personales | 3.1 (2 %) | 5.8 (7 %) | 5.7 (5 %) |
| pactos_y_gobernabilidad | 4.8 (4 %) | 5.4 (6 %) | 2.5 (2 %) |
| formato_y_presentacion | 4.8 (4 %) | 3.8 (4 %) | 3.5 (3 %) |
| partido_interno | 5.0 (4 %) | 5.2 (6 %) | 1.6 (1 %) |
| cierre_y_alegato | 4.0 (3 %) | 3.2 (4 %) | 1.2 (1 %) |
| feminismo_e_igualdad | 4.6 (4 %) | 2.4 (3 %) | — |
| politica_internacional | 5.7 (4 %) | 1.0 (1 %) | — |
| defensa_y_seguridad | 1.8 (1 %) | 4.8 (6 %) | — |
| pensiones | — | 5.5 (6 %) | — |
| deuda_y_gasto | — | 5.5 (6 %) | — |
| impuestos_y_autonomos | 0.8 (1 %) | 4.3 (5 %) | — |
| medios_y_redes | 3.9 (3 %) | — | 0.9 (1 %) |
| cataluna_y_territorial | — | — | 4.3 (4 %) |
| economia_y_empleo | 1.2 (1 %) | 3.1 (4 %) | — |
| otros | — | — | 0.9 (1 %) |

### Quién saca los temas

| | Colau | Feijóo | Sánchez |
|---|---|---|---|
| tramos que saca el invitado | 6 (19 %) | 7 (19 %) | 6 (12 %) |

![temas](grafica_temas.png)

![dureza](grafica_dureza.png)

![respuestas](grafica_respuestas.png)


## 4. Promesas, mérito y culpa, sintonía

### Compromisos y afirmaciones

| | Colau | Feijóo | Sánchez |
|---|---|---|---|
| compromisos recogidos | 29 | 40 | 19 |
| verificables | 8 (28 %) | 20 (50 %) | 7 (37 %) |
| verificables por cada 10 minutos | 0.6 | 2.3 | 0.6 |
| afirmaciones factuales recogidas (invitado) | 85 | 149 | 137 |
| afirmaciones factuales recogidas (Jordi) | 41 | 22 | 51 |

### Mérito y culpa: con qué sujeto habla de logros y de fracasos

**Colau**

| | el_gobierno | ellos | impersonal | nosotros | yo |
|---|---|---|---|---|---|
| fracaso | 3 | 7 | 0 | 3 | 0 |
| logro | 2 | 4 | 0 | 8 | 2 |
| problema | 0 | 15 | 6 | 0 | 0 |

**Feijóo**

| | Ada Colau | Donald Trump | Galicia | Isabel Díaz Ayuso | Marruecos | Pedro Sánchez | Santiago Abascal | el_gobierno | ellos | impersonal | nosotros | tesorero del PP | yo |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| fracaso | 1 | 1 | 0 | 0 | 0 | 5 | 0 | 7 | 3 | 0 | 6 | 1 | 1 |
| logro | 0 | 0 | 1 | 1 | 0 | 0 | 1 | 0 | 0 | 0 | 7 | 0 | 6 |
| problema | 0 | 0 | 0 | 0 | 1 | 1 | 0 | 4 | 4 | 8 | 0 | 0 | 1 |

**Sánchez**

| | ellos | impersonal | nosotros | todas las administraciones | yo | Óscar Puente |
|---|---|---|---|---|---|---|
| fracaso | 17 | 4 | 3 | 0 | 3 | 0 |
| logro | 3 | 3 | 16 | 0 | 4 | 2 |
| problema | 9 | 6 | 2 | 1 | 0 | 0 |


### Sintonía con Jordi


### Momentos de relación

| | Colau | Feijóo | Sánchez |
|---|---|---|---|
| acuerdo explicito | 8 (0.6 / 10 min) | 7 (0.8 / 10 min) | 11 (1.0 / 10 min) |
| anecdota personal | 5 (0.4 / 10 min) | 6 (0.7 / 10 min) | 7 (0.6 / 10 min) |
| halago | 9 (0.7 / 10 min) | 7 (0.8 / 10 min) | 12 (1.1 / 10 min) |
| interrupcion notable | 5 (0.4 / 10 min) | 5 (0.6 / 10 min) | 6 (0.5 / 10 min) |
| pregunta devuelta | 7 (0.5 / 10 min) | 10 (1.2 / 10 min) | 4 (0.4 / 10 min) |
| risa o broma | 15 (1.1 / 10 min) | 14 (1.6 / 10 min) | 15 (1.4 / 10 min) |
| roce | 12 (0.9 / 10 min) | 11 (1.3 / 10 min) | 11 (1.0 / 10 min) |
| risas o bromas que inicia jordi | 10 | 5 | 10 |
| risas o bromas que inicia invitado | 5 | 9 | 5 |
