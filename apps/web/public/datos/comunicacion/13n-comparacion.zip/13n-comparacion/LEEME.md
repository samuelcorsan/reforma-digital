# La comparación entre las entrevistas

Datos del análisis de comunicación de las entrevistas de The Wild Project del 13 de noviembre de 2026, tal como
se midieron. Los minutos y los segundos son los del vídeo original.

## Qué hay

- `v3/`: las medidas de habla de cada entrevista con las mismas reglas, y sus preguntas.
- `lectura3/`: la lectura de preguntas y respuestas de las tres, lado a lado.
- `presion/`: la voz tras una pregunta dura frente al resto, con la misma definición para las tres.
- `publico/`: vistas, me gusta y minutos citados en los comentarios de YouTube, en recuentos.
- `coherencia/`: lo que cada uno dijo antes y lo que dice ahora, y las frases que repite.
- `general/`: la comparación general, con sus gráficas.

## Lo que no va en este paquete

- El vídeo, el audio, los fotogramas y los clips: son del programa. Cada dato lleva su minuto para ir al original.
- Los comentarios de YouTube: llevan nombres de usuarios. Sí van los recuentos.
- Las huellas de identidad de caras y voces con las que se asignó cada cara y cada voz a su persona.
- La salida de los clasificadores de emoción en la voz y en la cara: el análisis no los usa.

## Para leerlo bien

- Ninguna de estas medidas sirve para saber si alguien dice la verdad.
- La transcripción es automática: tiene huecos, nombres mal escritos y algún turno atribuido a quien no es.
- La cara se mide con unidades de acción (AU) del sistema FACS, que nombran movimientos y no emociones, y cada
  persona se compara con su propia cara. Qué cara sale en pantalla lo decide la realización.
- En la comprobación de datos, `fuente_abierta` dice si la fuente se abrió y se leyó entera; si no, el veredicto
  se apoya solo en el extracto del buscador.
