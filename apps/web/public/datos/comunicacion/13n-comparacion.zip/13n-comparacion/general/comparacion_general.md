# Un entrevistador, tres entrevistas: la misma dureza para Colau, Feijóo y Sánchez, y tres de cada cuatro preguntas con premisa adversa solo para el presidente

*Comparación general de las entrevistas de Jordi Wild a Ada Colau, Alberto Núñez Feijóo y Pedro Sánchez en* The Wild Project *(YouTube, 13 de noviembre de 2026), candidatos a las elecciones generales del 29 de noviembre. Los minutos son los de cada vídeo (m:ss). Jordi Wild se analiza con el mismo listón que sus invitados.*

## 1. Titular y entrada

Jordi Wild aplicó a los tres candidatos casi la misma proporción de intervenciones duras: 83 % a Colau, 77 % a Feijóo y 86 % a Sánchez, entre 9,9 y 11,8 por cada diez minutos. Lo que cambia es de dónde parte la pregunta: la mitad de sus intervenciones a Colau y a Feijóo asumían algo adverso al invitado (51 % y 48 %), y con Sánchez fueron casi tres de cada cuatro (73 %). Los tres contestaron a lo preguntado en torno a dos de cada tres ocasiones, y la voz de ninguno cambió de forma apreciable cuando la pregunta apretaba. Las diferencias más claras entre ellos no están en cuánto contestan, sino en dónde no contestan, en cuántas cifras y compromisos dejan y en de qué se habló con cada uno.

Tres avisos que valen para todo el texto. Se describe conducta observable, no intenciones ni formas de ser. La cara se describe solo con unidades de acción (AU) del sistema FACS, que nombra movimientos musculares y no emociones (**Ekman y Friesen, 1978**). Y, dicho una sola vez: **ni las pausas, ni la voz, ni los gestos, ni las trabas, ni ninguna otra medida de este informe sirve para saber si alguien dice la verdad**. La revisión de 158 señales de **DePaulo y otros (2003)** encontró que la mayoría no distingue a quien miente y que las que lo hacen tienen efectos pequeños, y las personas detectan mentiras poco mejor que al azar, con un 54 % de acierto medio (**Bond y DePaulo, 2006**). Como mucho, estas medidas indican esfuerzo o tensión al hablar.

Tampoco hay aquí una clasificación de personas. Son tres entrevistas de duración distinta (133, 87 y 111 minutos), con temas distintos y a personas en posiciones distintas: una exalcaldesa que se presenta por una coalición, el jefe de la oposición y el presidente en ejercicio. Ninguna diferencia se puede atribuir sin más a la persona.

## 2. El mismo entrevistador, ¿el mismo trato?

Jordi anuncia el mismo propósito en las tres. A Feijóo: «Es mi misión hoy, es mi misión es poneros contra las cuerdas.» (25:12; la transcripción pone la frase en el turno del invitado). A Sánchez: «mi misión hoy es ponerte en un aprieto, igual que a todos» (2:38). A Colau, al despedirse: «me ha tocado tocar un poco los cojones» (131:29). Es el estilo que la investigación sobre entrevistas llama pregunta adversativa, cuya formulación ya contiene una crítica (**Clayman y Heritage, 2002**).

| Medida (Jordi Wild en cada entrevista) | con Colau | con Feijóo | con Sánchez |
|---|---|---|---|
| Minutos de entrevista | 133 | 87 | 111 |
| Intervenciones que piden respuesta | 187 | 111 | 152 |
| Intervenciones por cada 10 minutos | 14,1 | 12,8 | 13,7 |
| Neutras | 29 (16 %) | 23 (21 %) | 15 (10 %) |
| Cómodas | 2 (1 %) | 2 (2 %) | 6 (4 %) |
| Incómodas | 43 (23 %) | 26 (23 %) | 33 (22 %) |
| Repreguntas | 70 (37 %) | 38 (34 %) | 66 (43 %) |
| Insistencias | 43 (23 %) | 22 (20 %) | 32 (21 %) |
| **Duras (incómoda + repregunta + insistencia)** | **156 (83 %)** | **86 (77 %)** | **131 (86 %)** |
| Duras por cada 10 minutos | 11,7 | 9,9 | 11,8 |
| Repreguntas + insistencias por cada 10 minutos (cálculo propio) | 8,5 | 6,9 | 8,8 |
| **Premisa en contra** | **95 (51 %)** | **53 (48 %)** | **111 (73 %)** |
| Premisa neutra | 89 (48 %) | 54 (49 %) | 38 (25 %) |
| Premisa a favor | 3 (2 %) | 4 (4 %) | 3 (2 %) |
| Intercambios que cierra Jordi | 11 (6 %) | 15 (14 %) | 14 (9 %) |
| Respuestas que corta Jordi (recuento automático) | 50,7 % | 22,0 % | 36,8 % |
| Solapes de voz que inicia Jordi | 459 (34,5 / 10 min) | 187 (21,5 / 10 min) | 254 (22,9 / 10 min) |
| Solapes de voz que inicia el invitado | 258 (19,4 / 10 min) | 133 (15,3 / 10 min) | 307 (27,7 / 10 min) |
| Palabras de Jordi (parte del total) | 8.356 (36,3 %) | 3.463 (27,2 %) | 6.266 (36,6 %) |
| Palabras por pregunta de Jordi (mediana) | 22 | 24 | 21 |
| Bromas o risas: las inicia Jordi / el invitado | 10 / 5 | 5 / 9 | 10 / 5 |
| Roces: los inicia Jordi / el invitado (recuento propio) | 10 / 2 | 7 / 4 | 6 / 5 |
| Halagos: los inicia Jordi / el invitado (recuento propio) | 6 / 3 | 4 / 3 | 5 / 7 |
| Interrupciones notables: Jordi / el invitado (recuento propio) | 5 / 0 | 2 / 3 | 4 / 2 |

![Trato de Jordi a cada invitado](grafica_trato.png)

![Dureza de las intervenciones](../lectura3/grafica_dureza.png)

**Qué es igual.** El ritmo de preguntas (entre 12,8 y 14,1 intervenciones por cada diez minutos), la proporción de incómodas (22 % o 23 % en las tres), la de insistencias (entre el 20 % y el 23 %) y la longitud de la pregunta (21 a 24 palabras de mediana). También la mezcla de objeción y cortesía. A Colau le dice «Yo creo que tú crees lo que predicas.» (32:58) y también «Pero te he pedido autocrítica y no me has dicho ni una.» (89:06). A Feijóo, «Por desgracia, a mí se me ha hecho muy corto.» (72:26) y «A ver, aquí habéis jugado sucio todos.» (62:43). A Sánchez, «Te lo prometo, yo me quedaría aquí tres horas contigo.» (96:50) y «pero eso no es lo que te he preguntado» (27:47). La atención mutua, el tono positivo y la coordinación son los tres componentes con que se describe la **sintonía entre dos personas (Tickle-Degnen y Rosenthal, 1990)**; aquí conviven con la dureza, y se miden por separado.

**Qué cambia.**

- **La premisa.** Con Sánchez, 111 de las 152 intervenciones (73 %) parten de un supuesto adverso; con Colau, 95 de 187 (51 %), y con Feijóo, 53 de 111 (48 %). Por cada diez minutos son 10,0, 7,1 y 6,1 (cálculo propio). Ejemplos de premisa adversa a Sánchez: «Creo que la gestión es mala porque si no no pasaría lo que ha pasado.» (23:01) y «de momento no has dicho si el responsable es Marruecos o no» (44:18).
- **Las repreguntas.** Con Sánchez son el 43 % de las intervenciones; con Colau, el 37 %; con Feijóo, el 34 %. Sumadas a las insistencias, 8,8, 8,5 y 6,9 por cada diez minutos.
- **Los cortes.** En el recuento automático, Jordi corta la mitad de las respuestas de Colau (50,7 %), algo más de un tercio de las de Sánchez (36,8 %) y una de cada cinco de las de Feijóo (22,0 %). Con Colau inicia 34,5 solapes de voz por cada diez minutos; con Feijóo y Sánchez, 21,5 y 22,9. La lectura manual anota cinco interrupciones notables con Colau, todas de Jordi, como «Primero sí o no y luego me justificas.» (37:10). Con Sánchez es el invitado quien inicia más solapes (307 frente a 254).
- **El tiempo de palabra.** Jordi dice el 36 % de las palabras con Colau y con Sánchez, y el 27 % con Feijóo, el invitado con más parte de la palabra (72,8 %).
- **Quién cierra.** Jordi cierra con un corte o un comentario propio el 14 % de los intercambios con Feijóo, el 9 % con Sánchez y el 6 % con Colau.
- **Las bromas.** Con Colau y con Sánchez las inicia sobre todo Jordi (10 de 15 en cada una), como «Bueno, tienes un avión, no me jodas.» (70:11, a Sánchez); con Feijóo, sobre todo el invitado (9 de 14). Los roces los inicia más Jordi en las tres, y donde más, con Colau (10 de 12).

**Qué puede explicarlo, sin atribuir intención.** Primero, la posición de cada invitado. A un presidente en ejercicio se le pregunta por lo que ha hecho, y una pregunta sobre gestión propia lleva casi siempre un dato o un reproche dentro; Jordi lo dice al empezar: «no es lo mismo estar en la oposición que estar en el poder» (2:38). El 57 % de la entrevista a Sánchez se va en cuatro bloques de gestión de su Gobierno (trenes, Ceuta, corrupción y vivienda; 63,4 minutos, cálculo propio), mientras que a Feijóo le dedica 18,4 minutos (21 %) a su programa económico, donde la pregunta natural es qué haría. Segundo, la duración: la de Feijóo es 46 minutos más corta que la de Colau, y Jordi lo comenta en antena: «Es que, claro, las otras han sido más largas. Ya no queda tanto tiempo, ¿eh?» (50:08). Con menos tiempo hay menos margen para volver sobre lo mismo. Tercero, el estilo del invitado: quien responde con turnos largos y devuelve preguntas (Feijóo lo hace 18 veces) deja menos huecos para el corte. Y cuarto, el recuento automático de respuestas cortadas depende de cómo la transcripción reparte los turnos cuando las voces se pisan, que es justo donde más falla. La conversación se organiza por turnos que los hablantes se reparten sobre la marcha (**Sacks, Schegloff y Jefferson, 1974**); que un corte se lea como firmeza o como falta de respeto depende de quien mira, y eso es una lectura de este informe, no de ese estudio.

## 3. Tres maneras de responder

| Clase de respuesta | Colau: todas (187) | Colau: duras (156) | Feijóo: todas (111) | Feijóo: duras (86) | Sánchez: todas (152) | Sánchez: duras (131) |
|---|---|---|---|---|---|---|
| Responde a lo preguntado | 121 (65 %) | 94 (60 %) | 71 (64 %) | 52 (60 %) | 108 (71 %) | 89 (68 %) |
| Responde en parte | 33 (18 %) | 30 (19 %) | 18 (16 %) | 15 (17 %) | 24 (16 %) | 23 (18 %) |
| Contesta a otra pregunta | 27 (14 %) | 26 (17 %) | 16 (14 %) | 13 (15 %) | 15 (10 %) | 14 (11 %) |
| Cambia de tema | 0 (0 %) | 0 (0 %) | 3 (3 %) | 3 (3 %) | 0 (0 %) | 0 (0 %) |
| Ataca la pregunta | 1 (1 %) | 1 (1 %) | 1 (1 %) | 1 (1 %) | 0 (0 %) | 0 (0 %) |
| Jordi no deja contestar | 5 (3 %) | 5 (3 %) | 2 (2 %) | 2 (2 %) | 5 (3 %) | 5 (4 %) |
| **No contesta a lo preguntado (tres clases)** | 28 (15 %) | 27 (18 %) | 20 (18 %) | 17 (20 %) | 15 (10 %) | 14 (11 %) |

![Clases de respuesta](../lectura3/grafica_respuestas.png)

La clase mide si la respuesta aborda lo preguntado, no si lo dicho es cierto o convincente. Los tres responden del todo a entre el 64 % y el 71 % de las intervenciones y, sumando las respuestas parciales, a entre el 80 % y el 87 %. En entrevistas políticas una parte grande de las preguntas queda sin respuesta directa: el estudio clásico de **Bull y Mayer (1993)** contó el 56 % y el 59 % en Thatcher y Kinnock, con otro criterio y otro formato, de modo que la comparación solo da un orden de magnitud. En experimentos con vídeos, los oyentes a menudo no detectan que se ha contestado a otra pregunta si la respuesta trata un asunto parecido (**Rogers y Norton, 2011**). Y la teoría del **equívoco (Bavelas y otros, 1990)** explica estas respuestas por la situación y no por la persona: cuando toda respuesta directa tiene coste, lo habitual es una respuesta indirecta.

**La evasión es un rango, no un ranking.** La lectura la hizo un solo codificador con una regla fija: ante la duda entre dos clases, la más favorable al invitado. La regla se aplicó 12 veces con Sánchez, 7 con Feijóo y 5 anotadas con Colau. La tabla siguiente compara el porcentaje publicado con el que saldría si todas las dudas cuya alternativa era una clase de no contestar se hubieran resuelto en contra (cálculo propio a partir de las notas de la lectura).

| Invitado | Clasificaciones con duda anotada | No contesta, todas: publicado | Todas: máximo sin la regla | No contesta, duras: publicado | Duras: máximo sin la regla |
|---|---|---|---|---|---|
| Colau | 5 | 28 de 182 (15 %) | 30 de 182 (16 %) | 27 de 151 (18 %) | 28 de 151 (19 %) |
| Feijóo | 7 | 20 de 109 (18 %) | 26 de 109 (24 %) | 17 de 84 (20 %) | 23 de 84 (27 %) |
| Sánchez | 12 | 15 de 147 (10 %) | 23 de 147 (16 %) | 14 de 126 (11 %) | 22 de 126 (17 %) |

![Evasión como rango](grafica_evasion_rango.png)

En Sánchez, 8 de las 12 dudas tenían como alternativa una clase de no contestar (6 clasificadas *en parte* y 2 *responde*): sin la regla, su 10 % llegaría al 16 %. En Feijóo son 6 de 7, y su 18 % llegaría al 24 %. En Colau, 2 de 5. Los rangos de Colau y Sánchez se solapan, y entre el extremo alto de Sánchez y el bajo de Feijóo hay menos de tres puntos, que son tres o cuatro intervenciones sobre más de cien. Un segundo codificador movería varias más. Lo que se sostiene es esto: los tres dejan sin contestar a lo preguntado entre una de cada diez y una de cada cuatro intervenciones, algo más cuando la pregunta es dura, y con estos datos no se puede ordenar a los tres.

**Dónde no contesta cada uno** (temas con cuatro o más intervenciones) sí es una diferencia clara:

- **Colau:** corrupción (6 de 14, 43 %), partido interno (4 de 15), inmigración (4 de 19) y vivienda (5 de 24). En rivales, política internacional, feminismo, pactos y defensa, ninguna.
- **Feijóo:** partido interno (5 de 14, 36 %), defensa (2 de 6), fronteras y Marruecos (2 de 6), rivales (6 de 20) y corrupción (2 de 7). En deuda, pensiones, economía e impuestos, ninguna.
- **Sánchez:** infraestructuras y transporte (7 de 20, 35 %), casi todo en torno a la dimisión del ministro, y vivienda (2 de 14). En corrupción, 1 de 30; en fronteras y Marruecos, 2 de 34.

Cada uno deja más preguntas sin contestar en un tema distinto, y ese tema es en los tres uno que toca a los suyos: el socio de gobierno de su espacio en Colau, su partido en Feijóo, su ministro en Sánchez. También difiere la forma. Feijóo es el único que cambia de tema (3 veces). Colau no lo hace nunca: cuando no contesta, responde a una pregunta vecina. Sánchez no ataca la pregunta ni cambia de tema en ninguna ocasión; lo que hace con frecuencia es negar la premisa y dar su versión, que la lectura clasifica como respuesta o respuesta parcial.

|  | Colau | Feijóo | Sánchez |
|---|---|---|---|
| Propone (dice qué hizo o haría) | 39 (21 %) | 27 (24 %) | 45 (30 %) |
| Habla de rivales o terceros | 71 (38 %) | 30 (27 %) | 38 (25 %) |
| Las dos cosas | 31 (17 %) | 18 (16 %) | 18 (12 %) |
| Ninguna | 46 (25 %) | 36 (32 %) | 51 (34 %) |
| Devuelve la pregunta a Jordi (intercambios) | 6 | 18 | 5 |
| Frases interrogativas del invitado (recuento automático) | 32 | 46 | 23 |

**Preguntas devueltas.** Feijóo devuelve la pregunta en 18 intercambios; Colau, en 6, y Sánchez, en 5. Sánchez pide permiso para hacerlo: «¿Te puedo responder con una pregunta?» (61:15; la transcripción lo pone en la línea de Jordi).

**Proponer o hablar de otros.** Colau es quien más habla de rivales o terceros (38 % de sus respuestas) y Sánchez quien más dice qué hizo o haría (30 %). La categoría de terceros incluye menciones no negativas. A quién nombran: Colau reparte entre Pedro Sánchez (11), PSOE (11), Vox (10), PP (9) y Podemos (8). Feijóo concentra: Pedro Sánchez en 28 de sus 111 respuestas y el Gobierno en 15. Sánchez nombra sobre todo a personas de su entorno por las que se le pregunta: Ábalos (11), Koldo García (6) y Zapatero (6), por delante de Abascal (5), el PP (5) y Feijóo (4).

## 4. La misma pregunta, tres respuestas

Jordi repite varias preguntas casi con las mismas palabras. Son el mejor punto de comparación directa, con una cautela: no significan lo mismo para quien gobierna que para quien aspira a gobernar. La clase es la de la lectura manual.

**Quién es responsable de la crisis de Ceuta**

| | Colau | Feijóo | Sánchez |
|---|---|---|---|
| Pregunta de Jordi | «¿quién es el responsable de la crisis de Ceuta?» (47:57) | «Para ti, ¿quién es el responsable de esta crisis?» (45:42) | «Y yo quiero ahora saber si tú, a día de hoy, consideras a Marruecos responsable de esto o no.» (35:56) |
| Arranque de la respuesta | «Así que yo no puedo decir categóricamente quién es el único culpable.» (48:15) | «Marruecos.» (45:43) | «Yo no tengo información para acusar a todo un gobierno de esto.» (36:03) |
| Clase | Otra pregunta; a la repregunta, responde: «Yo creo que es imposible que se produjera lo de Ceuta sin que Marruecos lo permitiera.» (48:19) | Responde | Responde (declina acusar); Jordi lo retoma en el 44:18 |
| Cifra o compromiso | Cifra: 70.000 personas. Compromiso general: revisar el acuerdo con Marruecos | Compromiso general: «No podemos estar cerrando acuerdos de comercio con Marruecos cuando Marruecos no respeta la frontera europea» (48:21) | Cifra: nueve de cada diez entradas, con salida en 48 horas. Sin compromiso |

**Las vacaciones del presidente durante la crisis**

| | Colau | Feijóo | Sánchez |
|---|---|---|---|
| Pregunta de Jordi | «¿Qué te pareció que el presidente se fuera de vacaciones durante la crisis?» (50:46) | No se le pregunta | «Pero luego te fuiste de vacaciones.» (45:18; en la línea del invitado) |
| Arranque de la respuesta | «la primera respuesta que se dio por parte del gobierno y en concreto desde la presidencia no fue la mejor» (50:50) | Lo saca él: «cogerte el falcoyete [Falcon] de vacaciones 25 días» (46:00) | «No, no, perdona, yo no me fui de vacaciones» (45:20) |
| Clase | Responde | (tema que introduce el invitado) | En parte: niega la premisa; a la imagen que dio, cuatro repreguntas |
| Cifra o compromiso | Ninguno | Cifra: 25 días | Cifra: más de 7.000 plazas de acogida. Sin compromiso |

**La proyección de población: un 40 % de nacidos fuera en 50 años**

| | Colau | Feijóo | Sánchez |
|---|---|---|---|
| Pregunta de Jordi | «Pero un 40 % en 50 años. ¿Cómo lo ves?» (82:16) | «Y la proyección es que en 50 años sea un 40 % y no un 20%» (56:47) | «en 50 años el 40 % aproximado del residente español será inmigrante, se ha nacido fuera. ¿A ti eso te alarma?» (60:34) |
| Arranque de la respuesta | «Yo es que tengo un montón de personas queridas, amigas, que son nacidas fuera y no me supone ningún problema.» (82:19) | «Por eso es muy importante decirlo claramente, lo irregular» (56:55) | «Si nosotros no aumentamos la población migrante en nuestro país, lo que va a suceder de aquí a 20 -30 años es lo siguiente» (62:45) |
| Clase | Responde | Responde | En parte |
| Cifra o compromiso | Ninguno | Sin cifra propia; compromisos sobre inmigración irregular en otros minutos | Proyección de fuerza laboral; sin compromiso verificable |

Jordi le dice a Feijóo que es una pregunta repetida: «que esto es algo que he tratado con Calao [Colau] y con Sánchez» (56:47).

**La corrupción cercana**

| | Colau | Feijóo | Sánchez |
|---|---|---|---|
| Pregunta de Jordi | «¿hubieras sacado a tu coalición de este gobierno cuando salta lo de Ábalos y Cerdán?» (22:59) | «¿Tú ahí también habrías pedido la dimisión?» (64:13, sobre Rajoy y Gürtel) | «O no te enterabas de lo que pasaba y muy cerca de ti y a nivel grave, porque hablamos de organización criminal, o mirabas a otro lado.» (71:36) |
| Arranque de la respuesta | «tanto yo personalmente en mis redes como Sumar manifestamos tolerancia cero a la corrupción» (23:20) | «El caso Gürtel se ha juzgado por arriba, por abajo» (64:31) | «La segunda descártala absolutamente» (71:52) |
| Clase | Otra pregunta. Tras siete formulaciones: «Habría, o no me habría ido, o habría puesto más exigencias a lo mejor.» (27:11) | Otra pregunta; en tres intentos no hay un sí o un no | Responde |
| Cifra o compromiso | Ninguno | Ninguno | Ninguno |

Sobre el expresidente Zapatero hay pregunta a dos. Colau, a «¿Crees entonces que lo de Zapatero tiene pinta de ser loafer [lawfare]?» (29:50), contesta «no tengo ningún indicio de que sea culpable, no sé, lo están investigando» (29:55). Sánchez, a «¿Tú pondrías la mano en el fuego por él?» (81:40), empieza por el rescate de aerolíneas y, cuatro intervenciones después, dice «Yo pongo la mano en el fuego por José Luis.» (84:11).

**Accidentes ferroviarios y dimisiones** (a Feijóo no se le pregunta)

| | Colau | Sánchez |
|---|---|---|
| Pregunta de Jordi | «¿debería Puente haber dimitido en el primer accidente de hace casi un año?» (36:46) | «Si no hubiera dimitido, ¿lo hubieras cesado?» (27:14) |
| Arranque de la respuesta | «Yo entiendo que en ese primer momento no lo hiciera» (37:03) | «Yo creo que ese debate hoy está superado.» (27:17) |
| Clase | Responde (que no en el primero y sí en el segundo) | Otra pregunta, en tres intentos |
| Cifra o compromiso | Ninguno | Cifra: «nosotros hemos multiplicado por 20 durante estos últimos ocho años, por 20 la inversión» (15:57). Compromiso: «vamos a invertir 19 .000 millones de euros en el mantenimiento» (18:24) |

**Vivienda** (con Feijóo no hay bloque de vivienda)

| | Colau | Sánchez |
|---|---|---|
| Pregunta de Jordi | «¿Cómo lo solucionarías tú?» (97:52) | «¿cuántas están entregadas y con gente viviendo en ellas?» (90:17) |
| Arranque de la respuesta | «Hay que construir mucho más parque público de vivienda, pero eso lleva años» (97:59) | «no te quiero decir ahora mismo el dato exacto porque no lo he buscado y no lo he encontrado» (90:21) |
| Clase | Responde; a los plazos de desalojo, ocho peticiones seguidas | En parte; el dato no llega en tres intentos |
| Cifra o compromiso | Compromiso: «un impuesto del 10 % del valor de esa vivienda» (109:37) | Cifra: «Hemos multiplicado por 8 el presupuesto en vivienda.» (88:09). Compromiso: cumplir las 184.000 viviendas |

**Definir a los rivales y cerrar**

| | Colau | Feijóo | Sánchez |
|---|---|---|---|
| Pregunta de Jordi | «te voy a pedir que me definas a tus rivales» (121:02) | «Defineme a tus rivales en estas elecciones.» (82:19) | «Te voy a pedir que me definas a tus rivales en estas elecciones.» (109:03) |
| Sobre el primero | Sánchez: «que habla bien, pero que si no tiene presión no hace suficientes políticas progresistas» (121:17) | Colau: «Yo creo que hizo muy mal la gestión como alcaldesa de Barcelona.» (82:26) | Colau: «Pues yo diría activista.» (109:12) |
| Sobre el segundo | Feijóo: «es un hombre de derechas bastante sincero» (121:55) | Abascal: «convertirse en la tercera fuerza política del país» (82:51) | Feijóo: «diría conservador» (109:17) |
| Sobre el tercero | Abascal: «Santiago Abascal para mí es una persona cruel muy cruel» (122:21) | Sánchez: «Pues ha sido una gran decepción.» (84:07) | Abascal: «Que debería ir a otro sastre, porque se pone unas chaquetas muy estrechas.» (109:28); a la repregunta, «no es bueno el vivir en el rencor y en la revancha permanente» (109:46) |
| Clase | Responde a las tres | Responde a las tres | Responde a dos; la broma, otra pregunta |
| «¿Te arrepientes de haber venido?» | (130:11) «habías dicho que sería duro ha sido muy duro» (130:19) | No consta la pregunta en la transcripción | (111:13) «No, en absoluto.» (111:13; en la línea de Jordi) |
| Alegato a cámara | «uno de los errores que hemos cometido las izquierdas en los últimos años es, sí, ser demasiado moralistas» (131:58) | «¿Viven mejor en el año 2026 que en el año 2018?» (86:57) | «hay que responder a la involución con movilización y una movilización histórica» (111:28) |

Los tres alegatos encuadran la elección de forma distinta, en el sentido de **Entman (1993)**: encuadrar es seleccionar y destacar unos aspectos de un asunto frente a otros. Colau destaca un error propio de su espacio, Feijóo una comparación entre 2018 y 2026 y Sánchez el riesgo de retroceso.

## 5. Concreción y promesas

| Medida | Colau | Feijóo | Sánchez |
|---|---|---|---|
| Cifras por 100 palabras | 0,67 | 2,61 | 1,62 |
| Fechas por 100 palabras | 0,03 | 0,15 | 0,15 |
| Fórmulas de compromiso por 100 palabras (recuento automático) | 0,05 | 0,53 | 0,16 |
| Vaguedades por 100 palabras | 0,33 | 0,19 | 0,25 |
| Palabras por frase | 29,3 | 21,3 | 28,4 |
| Compromisos recogidos en la lectura | 29 | 40 | 19 |
| De ellos, verificables | 8 (28 %) | 20 (50 %) | 7 (37 %) |
| Verificables por cada 10 minutos | 0,6 | 2,3 | 0,6 |
| Formas verbales de pasado por 100 palabras (aprox.) | 3,82 | 2,95 | 3,85 |
| Formas verbales de futuro por 100 palabras (aprox.) | 0,33 | 1,07 | 0,38 |
| Formas de pasado por cada forma de futuro (aprox.) | 11,7 | 2,8 | 10,2 |

![Cifras, compromisos y tiempos verbales](grafica_concrecion.png)

Feijóo da 2,61 cifras por cada 100 palabras; Sánchez, 1,62, y Colau, 0,67. La lectura recogió 40 compromisos de Feijóo, 20 de ellos verificables (con una cifra, un plazo, una ley o una decisión de sí o no); 29 de Colau, 8 verificables, y 19 de Sánchez, 7 verificables. Por cada diez minutos: 2,3, 0,6 y 0,6. El recuento aproximado de tiempos verbales va en la misma dirección: Feijóo usa una forma de futuro por cada 2,8 de pasado; Colau, una por cada 11,7, y Sánchez, una por cada 10,2. Es una aproximación por terminaciones, útil para comparar a los tres con la misma regla y no como cifra exacta.

Hay una explicación de formato antes que de persona. A Feijóo se le dedican 18,4 minutos a pensiones, deuda, impuestos y empleo, con preguntas del tipo qué harás; a Sánchez se le pregunta sobre todo qué pasó, y a Colau, qué hizo en Barcelona y qué opina. Un número dicho pronto puede funcionar como punto de referencia para lo que se discute después (**efecto ancla, Tversky y Kahneman, 1974**, demostrado en estimaciones numéricas de laboratorio), y un compromiso público y concreto ata más a quien lo formula que una intención general (**compromiso y coherencia, Cialdini, 1984**). Más cifras no significa más cifras correctas: eso se mira en la sección 11.

**Registro de compromisos verificables, para comprobar más adelante**

| Quién | Minuto | Cita | Compromiso |
|---|---|---|---|
| Colau | 99:53 | «yo creo que esas 100 .000 viviendas de esos 13 fondos hay que recuperarlas y pasarlas al parque público» | Pasar al parque público las viviendas de 13 fondos |
| Colau | 109:37 | «pues un impuesto del 10 % del valor de esa vivienda para movilizar, pero no para recaudar,» | Impuesto del 10 % a grandes propietarios con vivienda vacía o precio abusivo |
| Colau | 110:01 | «entra la administración pública para garantizar que se pague ese alquiler» | Garantía pública de cobro al pequeño propietario |
| Colau | 120:24 | «Sobre todo romper las relaciones comerciales.» | Romper relaciones comerciales con Israel |
| Colau | 6:21 | «yo personalmente no voy a volver a Twitter respondiendo a tu pregunta» | No volver a usar Twitter a título personal |
| Feijóo | 17:11 | «Mi estructura ministerial estará entre 14 y 15 ministerios.» | Gobierno de 14 o 15 ministerios |
| Feijóo | 23:10 | «Yo me comprometo a la actualización de las pensiones, de acuerdo con el índice de precios al consumo.» | Revalorizar las pensiones con el IPC |
| Feijóo | 25:13 | «Jordi, no vamos a ampliar la edad de jubilación.» | No ampliar la edad de jubilación |
| Feijóo | 29:37 | «Los que llevan 12 años y facturan menos de 85 .000 euros no pagarán IVA.» | Exención de IVA para autónomos por debajo de 85.000 euros |
| Feijóo | 30:05 | «Un autónomo que contrate a otro el primer año de ese autónomo contratado no pagará la cuota.» | Sin cuota el primer año del primer contratado |
| Feijóo | 40:31 | «La primera transparencia de un presidente es someter a votación los presupuestos» | Someter los presupuestos a votación |
| Feijóo | 52:31 | «Le voy a establecer un camino hacia el empleo y van a tener la obligación de asumir un empleo» | Itinerario de empleo obligatorio para perceptores del ingreso mínimo vital |
| Sánchez | 18:13 | «una auditoría extraordinaria de seguridad de la línea Madrid -Sevilla» | Auditoría extraordinaria de seguridad de la línea Madrid-Sevilla (la presenta como en marcha) |
| Sánchez | 18:24 | «vamos a invertir 19 .000 millones de euros en el mantenimiento» | Invertir 19.000 millones en mantenimiento ferroviario (2026-2030) |
| Sánchez | 19:12 | «Bueno, pues, hagámoslo también en el transporte ferroviario.» | Implantar la doble firma en el transporte ferroviario |
| Sánchez | 86:48 | «Pues regular, por ejemplo, el alquiler de habitaciones, los alojamientos temporales» | Regular el alquiler de habitaciones y de temporada |
| Sánchez | 89:28 | «por ejemplo, necesitamos modificar la ley» | Modificar la ley del suelo |
| Sánchez | 91:38 | «nosotros en lo que es la entrega y la construcción vamos a cumplir con ese compromiso» | Cumplir el compromiso de las 184.000 viviendas públicas y de alquiler asequible |
| Sánchez | 101:04 | «se ha acabado la legislatura y volverá en la próxima legislatura» | Volver a llevar al Congreso la derogación de la ley mordaza (condicionado a los grupos) |

Los siete de Sánchez son todos los verificables que recogió la lectura; de Colau faltan tres de ocho y de Feijóo trece de veinte, que están en sus informes individuales. Casi ninguno lleva fecha: de los 19 de esta tabla, solo dos de Sánchez (2026-2030 y la próxima legislatura) y uno de Feijóo (el primer año del contratado) dan un plazo.

## 6. Voz, trabas y silencios bajo presión

Se comparan las frases que cada invitado dice tras una intervención dura de Jordi con todas las demás, con la misma definición para los tres. La d de Cohen mide el tamaño de una diferencia: alrededor de 0,2 es pequeña; 0,5, media, y 0,8, grande.

| Medida | Colau | Feijóo | Sánchez |
|---|---|---|---|
| Frases en ventanas duras | 577 | 377 | 476 |
| Frases en el resto | 122 | 178 | 86 |
| Tono (Hz): duras / resto | 164,7 / 162,6 | 126,6 / 123,6 | 120,8 / 119,8 |
| Tono (Hz): d de Cohen | +0,14 | +0,19 | +0,07 |
| Tono (Hz): d cuando no contesta a lo preguntado | +0,08 (n = 103) | +0,06 (n = 85) | −0,11 (n = 38) |
| Volumen (dB): duras / resto | 69,7 / 69,5 | 66,0 / 64,9 | 64,7 / 65,0 |
| Volumen (dB): d de Cohen | +0,09 | +0,22 | −0,04 |
| Volumen (dB): d cuando no contesta a lo preguntado | −0,05 (n = 103) | −0,17 (n = 85) | +0,01 (n = 38) |
| Velocidad (palabras/min): duras / resto | 227 / 214 | 203 / 198 | 204 / 203 |
| Velocidad (palabras/min): d de Cohen | +0,24 | +0,08 | +0,02 |
| Velocidad (palabras/min): d cuando no contesta a lo preguntado | +0,16 (n = 103) | +0,02 (n = 85) | −0,25 (n = 38) |
| Palabras del invitado: duras / resto | 12112 / 2542 | 6270 / 2978 | 9417 / 1394 |
| Trabas (n): duras / resto | 40 / 1 | 19 / 4 | 27 / 9 |
| Trabas por 100 palabras: duras / resto | 0,33 / 0,04 | 0,30 / 0,13 | 0,29 / 0,65 |
| Pausas > 0,4 s (sin huecos) | 105 | 118 | 112 |
| Pausa media (s) | 0,76 | 0,79 | 0,79 |
| Pausas de 2 s o más | 1 | 1 | 2 |
| Pausas por 1.000 palabras | 7,1 | 12,7 | 10,3 |
| Pausas por 1.000 palabras: duras / resto | 6,6 / 9,8 | 11,2 / 16,1 | 10,5 / 9,3 |
| Pausas antes de frase con carga | 20 (19 %) | 36 (31 %) | 20 (18 %) |
| Pausas confirmadas por el detector acústico | 4 (4 %) | 25 (21 %) | 17 (15 %) |

**La voz apenas cambia en ninguno.** Ningún efecto pasa de 0,24. Tras una pregunta dura, el tono de Colau sube 2 Hz, el de Feijóo 3 Hz y el de Sánchez 1 Hz; el volumen sube 1 dB en Feijóo y casi nada en los otros dos; Colau acelera de 214 a 227 palabras por minuto, y los otros no. La investigación asocia la activación alta del hablante con subidas de tono y de volumen (**Scherer, 2003; Juslin y Laukka, 2003**): aquí esas subidas son pequeñas o no aparecen.

**No contestar no cambia la voz.** En las frases de las respuestas clasificadas como no contestar a lo preguntado, las diferencias de tono van de −0,11 a +0,08 y las de volumen de −0,17 a +0,01. En Sánchez la velocidad baja algo (d = −0,25), con solo 38 frases.

**Trabas.** Colau y Feijóo se traban más tras preguntas duras (0,33 frente a 0,04 por cada 100 palabras, y 0,30 frente a 0,13). En Sánchez el dato sale al revés (0,29 frente a 0,65), pero es frágil: el grupo de comparación son 1.394 palabras, el 13 % de las suyas, con 9 trabas. Con cinco trabas menos en ese tramo, las dos tasas serían iguales. En los tres, el número total es bajo (41, 23 y 36), y parte de los cortes coinciden con la otra voz entrando.

**Silencios.** Excluido en Feijóo un hueco de transcripción de 15,4 segundos que no es una pausa, los tres hacen pausas de duración media casi idéntica (0,76, 0,79 y 0,79 segundos) y casi ninguna de dos segundos o más (1, 1 y 2). Feijóo hace más pausas por cada 1.000 palabras (12,7) que Sánchez (10,3) y Colau (7,1), y más antes de una frase con cifra, rival o compromiso (31 % de las suyas, frente al 19 % y el 18 %), lo que encaja con que es quien más cifras da. Colau y Feijóo hacen menos pausas tras preguntas duras que en el resto; Sánchez, casi las mismas. La investigación clásica asocia las pausas de vacilación con la planificación del habla sobre la marcha (**Goldman-Eisler, 1968**). El detector acústico solo confirma el 4 %, el 21 % y el 15 % de estas pausas: el resto son huecos entre palabras transcritas, que pueden contener la voz del otro.

**Latencia.** El tiempo que tarda cada uno en empezar a contestar se midió, pero es demasiado ruidoso para compararlo: depende de dónde corta la transcripción cada turno y de los solapes, y los dos archivos que lo calculan no coinciden. No se da.

## 7. Cara

Los niveles absolutos de AU **no son comparables entre personas**: el programa no está calibrado por individuo, cada cara tiene su fisonomía, Jordi lleva barba y cada uno está grabado con un ángulo y unos planos distintos. Por eso se cuentan los episodios en que cada cara se aparta con claridad de su propia posición habitual, por cada diez minutos en que esa cara está en pantalla.

| Movimiento: episodios por 10 min en pantalla (hablando / escuchando) | Colau | Feijóo | Sánchez |
|---|---|---|---|
| AU6 + AU12 (mejillas y comisuras arriba) | 30,5 (30,8 / 27,0) | 21,7 (22,8 / 22,4) | 21,1 (19,6 / 21,1) |
| AU5 (párpado superior arriba) | 32,8 (37,0 / 6,7) | 11,7 (12,8 / 3,2) | 14,9 (17,1 / 11,9) |
| AU1 + AU2 (cejas arriba) | 1,0 (1,1 / 0,0) | 6,6 (7,3 / 3,2) | 1,4 (1,2 / 4,0) |
| AU4 (cejas bajan y se juntan) | 10,6 (12,3 / 0,0) | 0,0 (0,0 / 0,0) | 2,1 (2,9 / 0,0) |
| AU17 (mentón arriba) | 0,0 (0,0 / 0,0) | 1,6 (1,2 / 0,0) | 0,1 (0,2 / 0,0) |
| AU15 (comisuras abajo) | 0,4 (0,5 / 0,0) | 0,2 (0,2 / 0,0) | 0,6 (0,6 / 0,0) |
| AU23/AU24 (labios apretados) | 0,0 (0,0 / 0,0) | 0,0 (0,0 / 0,0) | 0,0 (0,0 / 0,0) |

| Movimiento: episodios por 10 min en pantalla (hablando / escuchando) | Jordi con Colau | Jordi con Feijóo | Jordi con Sánchez |
|---|---|---|---|
| AU6 + AU12 (mejillas y comisuras arriba) | 25,7 (27,0 / 15,1) | 32,7 (26,7 / 30,6) | 29,3 (28,7 / 16,6) |
| AU5 (párpado superior arriba) | 22,2 (30,4 / 4,5) | 23,3 (26,1 / 11,9) | 25,3 (34,0 / 11,1) |
| AU1 + AU2 (cejas arriba) | 12,7 (15,9 / 3,0) | 10,5 (13,0 / 6,8) | 14,2 (21,4 / 1,6) |
| AU4 (cejas bajan y se juntan) | 0,5 (0,9 / 0,0) | 0,0 (0,0 / 0,0) | 0,0 (0,0 / 0,0) |
| AU17 (mentón arriba) | 7,6 (6,8 / 11,3) | 4,5 (4,8 / 5,1) | 7,9 (7,7 / 8,7) |
| AU15 (comisuras abajo) | 0,0 (0,0 / 0,0) | 0,0 (0,0 / 0,0) | 0,0 (0,0 / 0,0) |
| AU23/AU24 (labios apretados) | 0,0 (0,0 / 0,0) | 0,0 (0,0 / 0,0) | 0,0 (0,0 / 0,0) |

![Episodios de AU por 10 minutos en pantalla](grafica_cara.png)

**Lo común.** El movimiento más frecuente en todos es AU6 + AU12, la combinación que la literatura llama sonrisa de Duchenne (**Ekman, Davidson y Friesen, 1990**); aparece también por cortesía o ironía, y de un movimiento facial no se puede deducir con fiabilidad un estado interno (**Barrett y otros, 2019**). En ninguno de los cuatro hay un solo episodio marcado de labios apretados (AU23/AU24).

**Lo propio de cada uno, respecto a sí mismo.** En Colau, AU4 (10,6 episodios por cada diez minutos, todos mientras habla) y AU5 (32,8). En Feijóo, AU1 + AU2 al hablar (7,3) y ningún episodio de AU4. En Sánchez, pocas desviaciones de su base salvo AU5 (14,9) y algo de AU4 al hablar (2,9). A los invitados casi no se les ve escuchar, así que las cifras de escucha descansan en pocos minutos.

**Cómo cambia Jordi de una entrevista a otra.** Aquí la comparación es más firme, porque es la misma cara con el mismo decorado. Su AU6 + AU12 es más frecuente con Feijóo (32,7) que con Sánchez (29,3) y con Colau (25,7), y con Feijóo se mantiene mientras escucha (30,6, frente a 15,1 y 16,6). Sus cejas arriba (AU1 + AU2) al hablar, es decir, al preguntar, son más frecuentes con Sánchez (21,4) que con Colau (15,9) y con Feijóo (13,0). AU5 al hablar sigue el mismo orden (34,0, 30,4 y 26,1). Coincide con otros dos datos de la sección 2: con Feijóo las bromas las inicia sobre todo el invitado, y con Sánchez hay más repreguntas. Que coincidan no demuestra que una cosa cause la otra, y con Feijóo Jordi sale menos en pantalla (31 % de los fotogramas), de modo que su base se calcula con menos imagen.

## 8. Temas: de qué se habló con cada uno y de qué no

| Tema: minutos (% de la entrevista) | Colau | Feijóo | Sánchez |
|---|---|---|---|
| Fronteras y Marruecos | 15,2 (11 %) | 8,3 (10 %) | 22,4 (20 %) |
| Inmigración | 20,3 (15 %) | 7,8 (9 %) | 14,8 (13 %) |
| Corrupción | 9,9 (8 %) | 8,5 (10 %) | 15,6 (14 %) |
| Vivienda | 17,3 (13 %) | — | 10,6 (10 %) |
| Infraestructuras y transporte (trenes) | 10,0 (8 %) | — | 14,8 (13 %) |
| Rivales | 6,0 (4 %) | 12,4 (14 %) | 5,7 (5 %) |
| Trayectoria y gestión pasada | 14,4 (11 %) | — | 6,0 (5 %) |
| Asuntos personales | 3,1 (2 %) | 5,8 (7 %) | 5,7 (5 %) |
| Pactos y gobernabilidad | 4,8 (4 %) | 5,4 (6 %) | 2,5 (2 %) |
| Formato y presentación | 4,8 (4 %) | 3,8 (4 %) | 3,5 (3 %) |
| Partido interno | 5,0 (4 %) | 5,2 (6 %) | 1,6 (1 %) |
| Cierre y alegato | 4,0 (3 %) | 3,2 (4 %) | 1,2 (1 %) |
| Feminismo e igualdad | 4,6 (4 %) | 2,4 (3 %) | — |
| Política internacional | 5,7 (4 %) | 1,0 (1 %) | — |
| Defensa y seguridad | 1,8 (1 %) | 4,8 (6 %) | — |
| Pensiones | — | 5,5 (6 %) | — |
| Deuda y gasto | — | 5,5 (6 %) | — |
| Impuestos y autónomos | 0,8 (1 %) | 4,3 (5 %) | — |
| Medios y redes | 3,9 (3 %) | — | 0,9 (1 %) |
| Cataluña y modelo territorial | — | — | 4,3 (4 %) |
| Economía y empleo | 1,2 (1 %) | 3,1 (4 %) | — |
| Otros | — | — | 0,9 (1 %) |

![Reparto del tiempo por temas](../lectura3/grafica_temas.png)

**Lo común.** Ceuta y Marruecos, inmigración y corrupción aparecen en las tres y suman el 34 % de la entrevista a Colau, el 28 % de la de Feijóo y el 48 % de la de Sánchez (45,4, 24,6 y 52,8 minutos; cálculo propio).

**Lo exclusivo.** Solo con Feijóo se habla de pensiones y de deuda y gasto, y con él se concentran impuestos, economía y defensa. Solo con Sánchez hay bloque de Cataluña y modelo territorial (4,3 minutos, la amnistía). Vivienda, trenes y gestión pasada se tratan con Colau y con Sánchez y no tienen tramo con Feijóo. Feminismo y política internacional, con Colau y Feijóo y no con Sánchez.

**Lo ausente en las tres.** Sanidad y educación, juventud, y clima y energía no tienen tramo propio en ninguna.

**Quién saca los temas.** Jordi abre la gran mayoría de los tramos. Los invitados introducen 6, 7 y 6 (19 %, 19 % y 12 % de los tramos), que ocupan 10,7, 14,3 y 5,1 minutos: el 8 %, el 16 % y el 5 % del tiempo (cálculo propio). Los partidos procuran llevar el debate a los temas en que el público los percibe como más competentes (**propiedad de los temas, Petrocik, 1996**): Colau introduce los desahucios y la reforma fiscal; Feijóo, las cuentas públicas y el absentismo; Sánchez, la inversión en Ceuta y la empresa pública de vivienda. Sánchez es el único que lleva un tema al terreno del entrevistador: «Tú, por ejemplo, el 1 de octubre de 2017 votaste.» (102:43).

**Capítulos y títulos de YouTube.** El vídeo de Colau tiene 14 capítulos y los de Feijóo y Sánchez, 12, contando la introducción. El título de cada vídeo elige tres o cuatro asuntos: el de Colau, inmigración masiva, las críticas a su alcaldía, e Israel y la flotilla; el de Feijóo, su foto con el narco, pensiones, Ayuso y corrupción; el de Sánchez, Ábalos y Koldo, Ceuta y Marruecos, y su hemeroteca. Los tres títulos anuncian sobre todo los bloques con premisa adversa. En el de Feijóo, el primer asunto del título corresponde a un capítulo de 6,6 minutos (57:16 a 63:54, cálculo propio), mientras que el bloque económico, que ocupa 18,4, aparece solo como pensiones. Los temas que destacan los medios tienden a ser los que la audiencia considera importantes (**fijación de agenda, McCombs y Shaw, 1972**); un título es la forma más corta de destacar.

Una consecuencia para toda la comparación: como los temas no son los mismos, cada invitado queda examinado en materias distintas.

## 9. El montaje

| Medida | Colau | Feijóo | Sánchez |
|---|---|---|---|
| Cara del invitado en pantalla (% de los fotogramas) | 63 % | 71 % | 66 % |
| Cara de Jordi en pantalla (% de los fotogramas) | 45 % | 31 % | 42 % |
| Veces más en pantalla el invitado que Jordi | 1,4 | 2,3 | 1,5 |
| Parte de las palabras que dice el invitado | 64 % | 73 % | 63 % |
| Cortes de plano (aprox.) | 280 | 173 | 265 |
| Cortes por minuto | 2,1 | 2,0 | 2,4 |
| Mediana entre cortes (s) | 24 | 24 | 24 |

El tiempo de cara en pantalla sigue de cerca al reparto de palabras: el invitado ocupa el 63 %, el 71 % y el 66 % de los fotogramas y dice el 64 %, el 73 % y el 63 % de las palabras. Feijóo sale 2,3 veces más que Jordi y es también quien más habla. El ritmo de cortes de plano es casi idéntico en las tres (entre 2,0 y 2,4 por minuto, con la misma mediana de 24 segundos entre cortes).

**Qué se puede concluir.** Que la realización es la misma en las tres y enfoca sobre todo a quien habla; que no hay un invitado al que se muestre mucho más o mucho menos de lo que corresponde a lo que habla; y que el montaje no tiene un ritmo distinto con ninguno.

**Qué no.** Los cortes se cuentan por fotogramas clave del archivo de vídeo, que es una aproximación. No se ha medido qué plano se elige en los momentos de más tensión, ni si hay cortes de edición dentro de las respuestas, ni las miniaturas. A los invitados casi no se les ve escuchar, y eso limita todo lo que se diga de sus reacciones. Y los títulos, vistos en la sección anterior, son una decisión editorial que se describe, no una medida.

## 10. Mérito y culpa

Se recogieron las frases en que cada invitado atribuye un logro, un fracaso o un problema, y con qué sujeto lo dice: 50 de Colau, 60 de Feijóo y 73 de Sánchez.

| Con qué sujeto habla de… | Colau | Feijóo | Sánchez |
|---|---|---|---|
| Logros: en primera persona (yo + nosotros) | 10 de 16 | 13 de 16 | 20 de 28 |
| Logros: con otro sujeto | 6 de 16 | 3 de 16 | 8 de 28 |
| Fracasos: en primera persona (yo + nosotros) | 3 de 13 | 7 de 25 | 6 de 27 |
| Fracasos: con otro sujeto | 10 de 13 | 18 de 25 | 21 de 27 |
| Problemas: en primera persona (yo + nosotros) | 0 de 21 | 1 de 19 | 2 de 18 |
| Problemas: con otro sujeto | 21 de 21 | 18 de 19 | 16 de 18 |
| Fracasos con sujeto *yo* | 0 | 1 | 3 |

El patrón es el mismo en los tres. Los logros van mayoritariamente en primera persona (10 de 16, 13 de 16 y 20 de 28) y los fracasos, mayoritariamente con otro sujeto (10 de 13, 18 de 25 y 21 de 27). Cambia qué primera persona. Colau usa *nosotros* para los logros («podemos responder que tenemos cero casos de corrupción», 25:00) y no dice ningún fracaso con *yo*. Feijóo es quien más usa *yo* para los logros (6 de 16: «Es que yo he conseguido un superávit en los últimos presupuestos de Galicia», 37:38) y admite una carencia personal: «He de reconocer que no he hecho ningún esfuerzo en esto.» (79:16, sobre el inglés). Sánchez habla de logros sobre todo en *nosotros* (16 de 28: «nosotros hemos multiplicado por 20 durante estos últimos ocho años, por 20 la inversión», 15:57) y tiene tres fracasos con *yo*, como «Y bueno, pues evidentemente yo cometo errores.» (108:32).

También cambia a quién señalan. Feijóo pone los fracasos en el Gobierno y en Pedro Sánchez (12 de 25). Sánchez, en un *ellos* que incluye a gobiernos anteriores, a la oposición y a personas de su propio entorno (17 de 27: «durante los años de Mariano Rajoy se recortaron las fuerzas y cuerpos de seguridad del Estado», 64:29). Colau, en un *ellos* que incluye a la derecha y a los socios («PP, Junts y Vox tumbaron esos decretos», 12:52).

Atribuirse los éxitos es un patrón bien documentado; que además se sitúen fuera los fracasos lo está menos: el trabajo clásico de **Miller y Ross (1975)** lo puso en duda y revisiones posteriores, como **Zuckerman (1979)**, sí lo encuentran. En política se ha descrito además la tendencia a priorizar evitar la culpa sobre reclamar el mérito (**Weaver, 1986**). Que los tres, desde posiciones opuestas, repartan igual sujetos y resultados apunta a un rasgo del género y no de una persona. Aquí solo se cuenta con qué sujeto se dice cada cosa.

## 11. Comprobación de datos de los tres

Se contrastaron con fuentes públicas, el mismo 13 de noviembre, las afirmaciones factuales de las dos personas de cada entrevista. El veredicto dice si el dato tiene respaldo en las fuentes localizadas, no si la persona actuó de buena o mala fe.

**Invitados**

| Veredicto | Colau | Feijóo | Sánchez |
|---|---|---|---|
| Se sostiene (respaldada) | 43 | 53 | 71 |
| Verdad a medias (respaldada en parte o imprecisa) | 21 | 45 | 18 |
| Verdad a medias (engañosa por contexto) | 0 | 1 | 0 |
| No se sostiene (sin respaldo) | 2 | 2 | 1 |
| No verificable | 3 | 2 | 2 |
| No se pudo comprobar | 8 | 20 | 23 |
| **Total comprobadas** | **77** | **123** | **115** |
| No comprobables según la extracción (no buscadas) | 8 | 26 | 22 |
| Con la fuente abierta y leída | 27 de 77 | 33 de 123 | 26 de 115 |

**Jordi Wild**

| Veredicto | Jordi con Colau | Jordi con Feijóo | Jordi con Sánchez |
|---|---|---|---|
| Se sostiene (respaldada) | 30 | 15 | 42 |
| Verdad a medias (respaldada en parte o imprecisa) | 7 | 5 | 6 |
| Verdad a medias (engañosa por contexto) | 0 | 0 | 0 |
| No se sostiene (sin respaldo) | 0 | 0 | 0 |
| No verificable | 0 | 0 | 0 |
| No se pudo comprobar | 4 | 0 | 3 |
| **Total comprobadas** | **41** | **20** | **51** |
| No comprobables según la extracción (no buscadas) | 0 | 2 | 0 |
| Con la fuente abierta y leída | 13 de 41 | 4 de 20 | 15 de 51 |

**Esto no es una nota, y no se comparan porcentajes.** Hay tres razones. Los invitados dan cantidades muy distintas de datos comprobables (77, 123 y 115 afirmaciones comprobadas) y de naturaleza distinta: Feijóo da muchas cifras económicas, donde es fácil quedarse en una imprecisión; Sánchez, cifras de gestión que a menudo proceden de notas de su propio Gobierno; Colau, hechos de su alcaldía y de terceros. Solo una parte de los veredictos descansa en la fuente abierta y leída entera (40 de 118 filas en Colau, 37 de 143 en Feijóo y 41 de 166 en Sánchez, sumando invitado y entrevistador); el resto se apoya en extractos del buscador y de prensa. Y los veredictos negativos de Colau y de Feijóo pasaron una segunda revisión independiente con las fuentes abiertas, pero **el único de Sánchez (100:05, Pablo Iglesias) no ha pasado todavía esa segunda revisión** con el mismo procedimiento. Sí quedó confirmado de forma independiente por el análisis de coherencia de la sección 14, que lo contrastó por su cuenta con la transcripción oficial de La Moncloa del 18-7-2019. Además, donde los datos localizados apuntaban en contra de una afirmación de Sánchez sin fuente abierta suficiente, se dejó como no comprobada, y por eso tiene 23 filas en esa categoría.

De las 112 afirmaciones comprobadas de Jordi en las tres entrevistas, 87 se sostienen, 18 son verdad a medias, 7 no se pudieron comprobar y ninguna queda sin respaldo (suma propia). Jordi lee datos preparados y cuenta con verificadores en el estudio, una posición distinta de la de quien contesta de memoria.

**Los veredictos negativos, uno a uno**

| Quién | Minuto | Cita | Veredicto y explicación | Fuente |
|---|---|---|---|---|
| Colau | 45:35 | «no han dimitido nunca cuando les han pasado cosas incluso más graves como lo de la DANA» | No se sostiene. Carlos Mazón (PP) anunció su dimisión el 3-11-2025 vinculándola a la DANA. Matiz: lo hizo un año después y conservó el escaño. Segunda revisión: sí. | [orain.eus](https://orain.eus/es/politica/2025/11/03/mazon-dimite-presidente-la-generalitat-valenciana/) |
| Colau | 122:06 | «O sea, ha dicho que bajara las pensiones, que bajara el salario mínimo.» | No se sostiene. No se localizó ninguna declaración de Feijóo en ese sentido, y sí en sentido contrario. Búsqueda no exhaustiva. Segunda revisión: sí. | [democrata.es](https://www.democrata.es/politica/feijoo-insiste-en-que-la-subida-de-las-pensiones-con-el-ipc-es-innegociable-y-quiere-cerrar-la-polemica-se-acabo/) |
| Feijóo | 44:45 | «Y la ministra de Defensa no deja comparecer a la directora del CNI en la Comisión de» | No se sostiene. La comparecencia no se produjo, pero las fuentes no atribuyen el bloqueo a la ministra, que pidió que se autorizara. Segunda revisión: sí. | [democrata.es](https://www.democrata.es/politica/congreso-y-senado/armengol-cita-a-robles-ante-la-comision-de-secretos-el-dia-6-y-deja-fuera-a-la-directora-del-cni/) |
| Feijóo | 66:07 | «con una sentencia que hablaba de que el PP era responsable del título lucrativo que posteriormente fue anulada por» | No se sostiene. El Supremo confirmó en 2020 la responsabilidad civil del PP a título lucrativo; solo corrigió las referencias a la caja B. Segunda revisión: sí. | [poderjudicial.es](https://www.poderjudicial.es/cgpj/en/Judiciary/Supreme-Court/Pressroom/Press-Archive/El-Tribunal-Supremo-confirma-penas-de-hasta-51-anos-de-prision-para-los-procesados-en-el--caso-Gurtel-) |
| Feijóo | 58:43 | «conocí a esta persona cuando no tenía nada que ver con el narcotráfico» | Verdad a medias (engañosa por contexto). No tenía cargos por narcotráfico hasta 2003, pero había sido detenido en 1990 en la Operación Nécora y quedó en libertad. Segunda revisión: sí. | [maldita.es](https://maldita.es/malditahemeroteca/20230719/feijoo-marcial-dorado-relacion-cronologia/) |
| Sánchez | 100:05 | «yo nunca dije nunca dije que no quería que Pablo Iglesias estuviera en el gobierno» | No se sostiene. La transcripción oficial de su entrevista del 18-7-2019 recoge que la participación de Iglesias en el Gobierno era el principal escollo y que no se daban las condiciones para que entrara. A favor de su versión: dijo que no le gustaba el verbo vetar. **Segunda revisión: no, pendiente; confirmado de forma independiente por el análisis de coherencia (sección 14).** | [lamoncloa.gob.es](https://www.lamoncloa.gob.es/presidente/intervenciones/Documents/2019/20190718%20PG%20Entrevista%20Al%20rojo%20vivo%20La%20sexta%20ferreras.pdf) |

Sobre el efecto de estas correcciones en la audiencia: suelen mejorar lo que la gente cree sobre el dato, pero apenas cambian la valoración del político corregido (**Nyhan, Porter, Reifler y Wood, 2020**). En las tres entrevistas hay correcciones en directo de los verificadores del programa, en los dos sentidos: confirman a Jordi el dato de los hurtos ante Colau, corrigen a Feijóo el absentismo de los autónomos y leen a Sánchez su frase de 2019.

## 12. Sánchez con dos entrevistadores, y Abascal como referencia

Las mismas reglas de medida se aplicaron a dos entrevistas de *La Revuelta*, las de Broncano a Sánchez y a Abascal. Sirven de referencia de otro formato, con una cautela que pesa mucho: *La Revuelta* es un plató con público, humor y ritmo de espectáculo; *The Wild Project*, un estudio sin público y una conversación de dos horas.

| Medida (invitado) | Sánchez con Jordi Wild | Sánchez con Broncano | Abascal con Broncano |
|---|---|---|---|
| Duración (min) | 112,1 | 102,9 | 96,4 |
| Parte de las palabras | 63,4 % | 60,1 % | 53,5 % |
| Palabras por minuto | 189 | 201 | 228 |
| Turnos | 265 | 289 | 234 |
| Palabras por turno (media) | 40,9 | 29,4 | 36,1 |
| Palabras por respuesta (mediana) | 66 | 19 | 52 |
| Trabas por 100 palabras | 0,33 | 0,98 | 0,41 |
| Trabas por 100 palabras al arrancar el turno | 0,58 | 1,72 | 0,4 |
| Pausas de 2 s o más | 2 | 8 | 1 |
| Cifras por 100 palabras | 1,62 | 1,34 | 0,62 |
| Fórmulas de compromiso por 100 palabras | 0,16 | 0,18 | 0,34 |
| Expresiones de certeza por 100 palabras | 0,65 | 0,55 | 0,58 |
| Pronombre *yo* por 100 palabras | 2,57 | 2,89 | 3,25 |
| Pronombre *nosotros* por 100 palabras | 0,67 | 0,58 | 0,8 |
| Palabras por frase | 28,4 | 19,7 | 19,3 |
| Respuestas que corta el entrevistador | 36,8 % | 35,8 % | 38,5 % |

**Qué cambia en Sánchez.** Con Broncano sus respuestas son mucho más cortas (19 palabras de mediana frente a 66 con Jordi), sus frases también (19,7 palabras frente a 28,4) y se traba tres veces más (0,98 por cada 100 palabras frente a 0,33), sobre todo al arrancar el turno. Habla algo más deprisa (201 frente a 189 palabras por minuto) y hace más pausas largas (8 frente a 2).

**Qué se mantiene.** Su parte de la palabra (60,1 % y 63,4 %), su densidad de cifras (1,34 y 1,62 por cada 100 palabras), las fórmulas de compromiso (0,18 y 0,16), la frecuencia del *yo* (2,89 y 2,57) y la proporción de respuestas que le corta el entrevistador (35,8 % y 36,8 %). Lo que parece más del hablante que del formato es, por tanto, cuánto ocupa, cuántos números da y cuánto se compromete.

Abascal, con el mismo entrevistador que Sánchez en *La Revuelta*, tiene menos parte de la palabra (53,5 %), menos cifras (0,62) y menos trabas (0,41): la diferencia entre invitados dentro de un mismo formato es del mismo orden que la de un mismo invitado entre dos formatos.

| Medida (entrevistador) | Jordi con Colau | Jordi con Feijóo | Jordi con Sánchez | Broncano con Abascal | Broncano con Sánchez |
|---|---|---|---|---|---|
| Parte de las palabras | 36,3 % | 27,2 % | 36,6 % | 46,5 % | 39,9 % |
| Palabras por minuto | 216 | 198 | 209 | 224 | 254 |
| Palabras por turno (media) | 31,5 | 26,0 | 30,9 | 34,7 | 21,1 |
| Palabras por pregunta (mediana) | 22 | 24 | 21 | 15 | 13 |
| Frases interrogativas | 107 | 60 | 59 | 34 | 120 |
| Trabas | 38 | 14 | 28 | 101 | 78 |
| Trabas por 100 palabras | 0,45 | 0,4 | 0,45 | 1,37 | 1,39 |
| Frases que se cortan (propias) | 16 | 7 | 16 | 75 | 66 |
| Pausas de 2 s o más | 2 | 0 | 1 | 19 | 3 |
| Vaguedades por 100 palabras | 0,38 | 0,35 | 0,46 | 0,53 | 0,85 |
| Cifras por 100 palabras | 1,29 | 1,59 | 1,25 | 0,61 | 0,89 |
| Respuestas del invitado que corta | 50,7 % | 22,0 % | 36,8 % | 38,5 % | 35,8 % |

**Jordi frente a Broncano.** Jordi ocupa menos espacio (entre el 27 % y el 37 % de las palabras; Broncano, el 40 % y el 47 %), hace preguntas más largas (21 a 24 palabras de mediana frente a 13 y 15), se traba unas tres veces menos (0,40 a 0,45 por cada 100 palabras frente a 1,37 y 1,39) y deja muchas menos frases a medias (7 a 16 frente a 66 y 75). Da más cifras en sus preguntas (1,25 a 1,59 frente a 0,61 y 0,89). La proporción de respuestas que cortan es parecida, salvo los dos extremos de Jordi (50,7 % con Colau y 22,0 % con Feijóo): la variación de Jordi entre sus propios invitados es mayor que la distancia entre los dos entrevistadores.

Las entrevistas de *La Revuelta* no pasaron la lectura manual, así que no hay para ellas dureza, premisa ni clases de respuesta: no se puede decir cuál de los dos formatos aprieta más. El recuento de solapes de la entrevista de Broncano a Sánchez es cero en el archivo, lo que apunta a que no se midió, y no se usa.

## 13. Reacción del público (dos lecturas)

| Medida | Colau | Feijóo | Sánchez |
|---|---|---|---|
| Hora de la lectura (13-nov) | 12:02 h | 12:03 h | 14:19 h |
| Vistas | 627.837 | 260.877 | 281.186 |
| Me gusta | 32.096 | 20.756 | 28.309 |
| Me gusta por 1.000 vistas (cálculo propio) | 51,1 | 79,6 | 100,7 |
| Comentarios leídos | 1.249 | 1.249 | 1.283 |
| Comentarios que citan un minuto | 34 (2,7 %) | 9 (0,7 %) | 13 (1,0 %) |
| Citas a menos de 45 s de un momento clave del análisis | 8 de 34 | 0 de 9 | 3 de 13 |

La primera lectura está hecha pocas horas después de publicarse los vídeos, con los comentarios que YouTube ordena como más relevantes. Sus límites son grandes. Las lecturas no son simultáneas (la de Sánchez es dos horas posterior), así que las vistas no se pueden comparar entre vídeos. Los comentarios leídos son una muestra elegida por la plataforma. Muy pocos citan un minuto (34, 9 y 13). Y el mapa de lo más visto de YouTube aún no estaba disponible.

Con esas reservas: en el vídeo de Colau, los minutos citados caen sobre todo en corrupción (6), gestión pasada (4), fronteras y Marruecos (4) y medios y redes (4), y 8 de las 34 citas están a menos de 45 segundos de uno de los momentos clave señalados por el análisis de su entrevista. En el de Sánchez, en asuntos personales (4), y 3 de 13 coinciden con un momento clave. En el de Feijóo, las 9 citas se reparten sin patrón y ninguna coincide. La proporción de me gusta por vista no mide acuerdo con el invitado: mide, como mucho, la disposición de quienes llegaron primero.

### Segunda lectura (hacia las 15:05)

Tres horas después de la primera, con los 3.000 comentarios más recientes de cada vídeo en lugar de los más relevantes:

| | Colau | Feijóo | Sánchez |
|---|---|---|---|
| Vistas | 1.311.275 | 1.043.479 | 406.353 |
| Me gusta | 48.540 | 43.702 | 37.542 |
| Me gusta por 1.000 vistas | 37 | 42 | 92 |
| Comentarios leídos | 3.000 | 3.000 | 3.000 |
| Comentarios que citan algún minuto | 122 (4,1 %) | 64 (2,1 %) | 64 (2,1 %) |
| Minutos citados dentro de la entrevista | 121 | 64 | 65 |
| A menos de 45 s de un momento clave del análisis | 20 (17 %) | 13 (20 %) | 11 (17 %) |
| Lo esperable si se repartieran al azar | 17 % | 26 % | 20 % |

Las vistas siguen sin ser comparables entre vídeos: el de Sánchez se publicó dos horas más tarde y llevaba una hora disponible entero cuando se hizo esta lectura. El mapa de lo más visto de YouTube seguía sin estar disponible en ninguno.

El resultado más claro es negativo: **los minutos que cita el público no coinciden con los momentos clave del análisis más de lo que coincidirían por azar** (17 %, 20 % y 17 % frente a un 17 %, 26 % y 20 % esperables). Los momentos donde se juntan pausa, cambio de voz y gesto no son los que la gente señala en los comentarios.

Lo que el público señala son preguntas y temas. En el vídeo de Colau, el minuto más citado es el del alegato final (131:00, 7 citas) y, por tema, inmigración (22), corrupción (14) y el cierre (12). En el de Feijóo las citas se reparten (ningún minuto pasa de 3) entre rivales (11), inmigración (9) y pensiones (7). En el de Sánchez se concentran en los primeros quince minutos: los minutos 4:00 y 10:00 (5 citas cada uno), que corresponden a las preguntas sobre por qué no da un paso al lado y sobre los insultos y la polarización; por tema, asuntos personales (14), rivales (11) y trenes (11).

Sigue siendo una muestra pequeña y autoseleccionada: solo entre el 2 % y el 4 % de los comentarios cita un minuto, y quien comenta no representa a quien ve el vídeo.

## 14. Coherencia y argumentario

Un análisis aparte contrastó con la hemeroteca diez posiciones y diez fórmulas de cada candidato: si lo que dicen ahora coincide con lo que dijeron o hicieron antes, y si las frases más características de la entrevista ya las habían usado en los seis meses anteriores. **Cambiar de posición no se califica aquí: se documenta**, con fecha, cita anterior y fuente abierta. En esta sección las citas de la entrevista van entre «» y las anteriores, tomadas de las fuentes enlazadas, entre comillas inglesas.

**Coherencia: diez posiciones por político**

| Político | Coherente | Cambio documentado | Matiz | Sin antecedente localizado | Total |
|---|---|---|---|---|---|
| Ada Colau | 3 | 2 | 4 | 1 | 10 |
| Alberto Núñez Feijóo | 4 | 0 | 6 | 0 | 10 |
| Pedro Sánchez | 3 | 4 | 2 | 1 | 10 |

**Argumentario: diez fórmulas por político**

| Político | Casi literal | Misma idea con otras palabras | No localizada | Total |
|---|---|---|---|---|
| Ada Colau | 3 | 5 | 2 | 10 |
| Alberto Núñez Feijóo | 1 | 7 | 2 | 10 |
| Pedro Sánchez | 3 | 3 | 4 | 10 |

**Estos recuentos no sirven para comparar quién cambia más ni quién trae más frases ensayadas.** La selección no es aleatoria: siete de las diez posiciones de Sánchez salen de la lista de cambios de opinión que le lee Jordi, es decir, de temas elegidos porque había cambio, y a Feijóo no se le planteó un bloque equivalente. Las fuentes son desiguales: de Sánchez hay transcripciones oficiales literales de La Moncloa; de Feijóo, sobre todo notas de prensa de su partido, que resumen en estilo indirecto; de Colau, crónicas de prensa de una candidatura que existe desde octubre. Y la búsqueda fue corta, unas 8 a 10 consultas por político más la apertura directa de archivos: *no localizada* y *sin antecedente localizado* significan que no apareció en lo revisado, no que no existiera.

**Colau.**

- Volver a la política. Ahora: «Yo dije en ese momento que descartaba completamente volver a la primera línea y era totalmente cierto.» (13:46). Antes (9-11-2025, declaraciones a *La Vanguardia* recogidas por VilaWeb/ACN): “No tinc intenció de presentar-me ni a les primàries ni a les pròximes eleccions; ni municipals, ni estatals ni de cap altre tipus”. Cambio documentado, que ella reconoce y explica. [Fuente](https://www.vilaweb.cat/noticies/colau-descarta-tornar-a-ser-candidata/).
- La Copa América. Ahora la cuenta entre sus errores: «A finales del segundo mandato aceptar la Copa América» (89:24). Antes (29-3-2022, presentación de la sede, VilaWeb): “Després dels Jocs Olímpics i el Mundial de Futbol, es considera que és el tercer esdeveniment esportiu més important del món”. Cambio documentado; lo viene diciendo desde 2024. [Fuente](https://www.vilaweb.cat/noticies/barcelona-copa-america-de-vela-cost-70-milions/).
- Una fórmula repetida. Ahora: «Tengo muy claro quién es el adversario.» (19:21). Antes (24-10-2026, declaraciones en Madrid recogidas por *Público*): “Tenemos muy claro quién es el adversario. El adversario es la extrema derecha”. Casi literal. [Fuente](https://www.publico.es/politica/partidos/frente-amplio-afirma-unico-rival-extrema-derecha-bajo-siglas-pp-vox-cuya-unica-agenda-cargarse-salarios.html).

**Feijóo.**

- Autónomos. Ahora: «Los que llevan 12 años y facturan menos de 85 .000 euros no pagarán IVA.» (29:37). Antes (18-10-2025, reunión con autónomos en Soria, nota de pp.es): “eximiremos del pago del IVA a los autónomos con ingresos inferiores a los 85.000 euros anuales”. Coherente. [Fuente](https://www.pp.es/actualidad/articulos/feijoo-anuncia-un-plan-integral-de-autonomos-que-eximira-del-iva-a-los-que-ingresen-menos-de-85-000-euros-anuales/).
- Pensiones. Ahora: «Yo me comprometo a la actualización de las pensiones, de acuerdo con el índice de precios al consumo.» (23:10). Antes (23-10-2026, Cadena SER, nota de pp.es): “Mi compromiso es actualizar anualmente las pensiones al IPC y voy a reactivar el Pacto de Toledo”. Clasificado como matiz y no como coherente porque constan votos anteriores de su partido en otro sentido, sin cita literal suya. [Fuente](https://www.pp.es/actualidad/articulos/feijoo-mi-objetivo-no-solo-es-que-suba-el-salario-minimo-sino-tambien-el-salario-medio-para-hacer-crecer-la-economia/).
- Gobierno con Vox. Ahora: «yo no voy a concretar, te lo digo honradamente, mi estrategia de negociación» (13:05). Antes (6-7-2025, clausura del congreso del PP, pp.es): “Y yo quiero un Gobierno en solitario”. Matiz: lo anterior era una preferencia, no una negativa tajante. [Fuente](https://www.pp.es/actualidad/articulos/feijoo-ofrece-un-gobierno-en-solitario-en-una-espana-sin-vetos-ni-a-vox-ni-al-psoe-y-en-la-que-van-a-mandarla-mayoria-de-los-espanoles/).

Ninguna de sus diez posiciones queda como cambio documentado; hay que leerlo junto al límite ya dicho de que no se le planteó un bloque de hemeroteca.

**Sánchez.**

- Indultos y amnistía. Ahora: «Yo creo que efectivamente cambia de opinión. Y además lo he reconocido.» (96:59). Antes (25-10-2019, entrevista en laSexta, transcripción de La Moncloa), preguntado por una amnistía: “Inconstitucional. Eso es ilegal, eso no tiene cabida en nuestro ordenamiento constitucional.” Cambio documentado y reconocido por él. [Fuente](https://www.lamoncloa.gob.es/presidente/intervenciones/Paginas/2019/prsp25102019.aspx).
- Pablo Iglesias. Ahora: «yo nunca dije nunca dije que no quería que Pablo Iglesias estuviera en el gobierno» (100:05). Antes (18-7-2019, laSexta, transcripción de La Moncloa): “no se dan las condiciones para que el señor Iglesias sea miembro de ese Gobierno”. Cambio documentado; es la misma afirmación que la comprobación de datos deja sin respaldo. [Fuente](https://www.lamoncloa.gob.es/presidente/intervenciones/Paginas/2019/prs18072019.aspx).
- Sáhara. Ahora: «Por tanto, no es que nosotros hayamos cambiado, sino que después de 50 años» (98:45). Antes (27-9-2018, Asamblea General de la ONU, La Moncloa): “una solución política, justa y duradera y mutuamente aceptable, que prevea la libre determinación del pueblo del Sahara Occidental”; y el 30-3-2022, leyendo en el Congreso su carta a Mohamed VI: “España considera la propuesta marroquí de autonomía presentada en 2007 como la base más seria, creíble y realista”. Cambio documentado con las dos intervenciones oficiales. [Fuente](https://www.lamoncloa.gob.es/presidente/intervenciones/Paginas/2018/prsp20180927.aspx).

En el argumentario, tres fórmulas suyas son casi literales respecto a intervenciones recientes, como «es que 9 de cada 10 migrantes que entraron, salieron» (37:48), que en el Congreso, el 3-9-2026, fue “el 90% de todos ellos, nueve de cada diez, salieron”. [Fuente](https://www.lamoncloa.gob.es/presidente/intervenciones/Paginas/2026/20260903-transcripcion-pg-congreso-ceuta.aspx). Que una frase se repita indica que estaba preparada; no dice nada sobre si es cierta.

**Reproches de Jordi que la hemeroteca no respalda.** El mismo contraste se hizo con los reproches del entrevistador. De los trece revisados, la mayoría se sostiene del todo o en parte. Tres dirigidos a Sánchez, no:

- Que en 2015 y 2016 promovía que el Gobierno dejara de proponer magistrados del Tribunal Constitucional: no se localizó en dos búsquedas. Sánchez no contesta a ese punto.
- Que llamó inviable al tope al alquiler que pedía Pablo Iglesias: la cita no se localizó. Sí consta que el decreto de alquiler de diciembre de 2018 dejó fuera el límite de precios.
- «en esa misma frase culpaste a Rusia y a Israel» (36:16), sobre Ceuta: no coincide con la transcripción de su comparecencia en el Congreso del 3-9-2026.

Además, dos reproches quedan respaldados solo en parte: la fórmula de todos o ninguno que Jordi atribuye a Colau es una paráfrasis (lo documentado, del 8-10-2026, es “Si estamos todas, yo también estaré”), y de Feijóo no se localizó un compromiso propio con el 3,5 % en defensa, sino su crítica a que Sánchez dijera una cosa dentro de la cumbre y otra fuera.

**Otros límites.** No se abrieron el Diario de Sesiones ni los registros de votación: los votos se toman de verificadores, prensa y notas de partido. Algunos cambios son antiguos y ya reconocidos por el interesado. Y la transcripción tiene un hueco justo al inicio de la respuesta de Sánchez sobre el Sáhara (98:25 a 98:46).

## 15. Por qué cada espectador vio tres entrevistas distintas

Con estos mismos datos se pueden escribir resúmenes opuestos, todos con cifras ciertas.

**Sobre Jordi.** Quien piense que fue más duro con Sánchez tiene el 73 % de premisas adversas frente al 51 % y el 48 %. Quien piense que fue más duro con Colau tiene que le cortó la mitad de las respuestas (50,7 %) y le dedicó 11,7 intervenciones duras por cada diez minutos. Quien piense que fue más blando con Feijóo tiene el 77 % de duras frente al 83 % y el 86 %, el 22,0 % de respuestas cortadas y más AU6 + AU12 mientras lo escuchaba. Y quien piense lo contrario tiene que con Feijóo cerró él más intercambios (14 %) y que la entrevista fue 24 minutos más corta que la de Sánchez. Los partidarios de cada bando tienden a percibir la misma cobertura informativa como sesgada contra el suyo (**efecto del medio hostil, Vallone, Ross y Lepper, 1985**); el estudio trata de cobertura informativa, y aplicarlo a un entrevistador es una extensión.

**Sobre los invitados.** Un votante afín a Sánchez citará que respondió al 71 % de las intervenciones y que en corrupción solo dejó sin contestar 1 de 30. Uno contrario citará las tres veces que no dijo si habría cesado a su ministro y la afirmación sobre Pablo Iglesias que las fuentes no sostienen. Un votante afín a Feijóo citará sus 20 compromisos verificables y sus 2,61 cifras por cada 100 palabras; uno contrario, que 46 de sus 123 afirmaciones comprobadas son verdad a medias y que devolvió 18 preguntas. Un votante afín a Colau citará que nunca cambió de tema y que 43 de sus afirmaciones comprobadas se sostienen; uno contrario, las siete formulaciones que hicieron falta para que dijera qué habría hecho con el caso Ábalos y que solo 8 de sus 29 compromisos se pueden comprobar.

La psicología describe los mecanismos. El **sesgo de confirmación (Nickerson, 1998)**: se busca y se recuerda lo que encaja con lo que ya se pensaba. El **razonamiento motivado (Kunda, 1990; Taber y Lodge, 2006)**: la información contraria a la propia posición se examina con más exigencia que la favorable. Y la **asimilación sesgada (Lord, Ross y Lepper, 1979)**: cada bando valora como más sólida la evidencia que le favorece.

Hay además una razón que no es psicológica: pocos espectadores ven las tres. Son 331 minutos de entrevista (suma propia). Quien ve solo la de su candidato no tiene con qué comparar el trato de Jordi, y quien ve solo la del rival tampoco. La comparación al alcance de casi todos son los títulos y los recortes.

## 16. Lo que esta comparación no puede decir

- **Tres entrevistas distintas.** Duran 133, 87 y 111 minutos, tratan temas en parte distintos y se hacen a personas en posiciones distintas. Las diferencias entre invitados no se pueden atribuir a las personas, y las diferencias en el trato de Jordi pueden deberse a los temas y al tiempo disponible.
- **Un solo codificador.** La dureza, la premisa y la clase de cada respuesta salen de una lectura manual hecha por un único lector, sin segundo codificador ni medida de acuerdo, con la regla de elegir la clase más favorable en caso de duda. Las diferencias de evasión entre los tres están dentro de ese margen.
- **Transcripción automática.** Tiene huecos sin texto (cuatro en Colau, tres en Feijóo y cuatro en Sánchez; alrededor de un minuto y medio, un minuto y un minuto y medio) y turnos mal atribuidos cuando las voces se pisan. La lectura marca como dudosas 4 entradas de 187 en Colau, 18 de 111 en Feijóo y 16 de 152 en Sánchez: la calidad no es igual en las tres. No recoge risas ni titubeos sonoros, y escribe mal muchos nombres, que se citan tal cual.
- **Pausas.** Se apoyan en huecos entre palabras transcritas; el detector acústico confirma el 4 %, el 21 % y el 15 %.
- **Caras.** Los grupos de caras se asignaron a mano y algunos incluyen recortes sueltos de otra persona; las AU las estima un programa no calibrado por persona, y la realización decide a quién se ve. Los niveles no se comparan entre personas.
- **Latencia.** No es fiable y no se da.
- **Tiempos verbales.** Son una aproximación por terminaciones.
- **Comprobación de datos.** Entre dos tercios y tres cuartos de los veredictos descansan en extractos y no en la fuente abierta; varios hechos de 2026 dependen de uno o dos medios, y el veredicto negativo de Sánchez no tiene la segunda revisión de los otros, aunque el análisis de coherencia lo confirma.
- **Coherencia y argumentario.** Posiciones elegidas, no al azar; fuentes desiguales por político; búsqueda corta. Sus recuentos no comparan quién cambia más.
- **Otro formato.** La comparación con *La Revuelta* es entre programas de naturaleza distinta y sin lectura manual.
- **Público.** Dos lecturas tomadas a horas distintas del mismo día, sin el mapa de lo más visto de YouTube; solo entre el 2 % y el 4 % de los comentarios cita un minuto, y quien comenta no representa a quien ve el vídeo. Los datos de la segunda están en `comparacion/publico/publico_2.md`.
- **Referencias.** Describen efectos medios, muchos medidos en laboratorio y en inglés; no predicen lo que hará un espectador concreto.
- **Y lo principal:** nada de lo medido sirve para saber si alguien dice la verdad, qué siente o cómo es, ni para decir quién estuvo mejor.

## 17. Para llevarte a casa

1. **La dureza fue casi la misma con los tres.** 83 %, 77 % y 86 % de intervenciones duras; entre 9,9 y 11,8 por cada diez minutos.
2. **La premisa no.** Con Sánchez, el 73 % de las intervenciones partían de un supuesto adverso; con Colau y Feijóo, el 51 % y el 48 %. Es lo esperable cuando a uno se le pregunta por ocho años de gestión y a los otros por lo que harían, pero el dato existe.
3. **Jordi cortó más a Colau y menos a Feijóo.** 50,7 %, 36,8 % (Sánchez) y 22,0 % de respuestas cortadas, en entrevistas de 133, 111 y 87 minutos.
4. **Los tres contestan a lo preguntado en proporciones parecidas.** Entre el 64 % y el 71 % del todo; no contestan entre el 10 % y el 24 % según cómo se resuelvan las dudas. No hay base para ordenarlos.
5. **Cada uno deja más preguntas sin contestar donde le tocan a los suyos.** Colau, en corrupción del socio de gobierno (6 de 14); Feijóo, en su partido (5 de 14); Sánchez, en la dimisión de su ministro (7 de 20).
6. **Feijóo dejó más cifras y más compromisos comprobables.** 2,61 cifras por cada 100 palabras y 20 compromisos verificables, frente a 1,62 y 7 de Sánchez y 0,67 y 8 de Colau; también es al que más se le preguntó por su programa.
7. **La voz no delata nada.** Ningún cambio bajo presión pasa de d = 0,24, y no contestar no cambia la voz en ninguno.
8. **Los logros, en primera persona; los fracasos, fuera.** En los tres, y en proporciones parecidas: 10 de 16, 13 de 16 y 20 de 28 logros en primera persona; 10 de 13, 18 de 25 y 21 de 27 fracasos con otro sujeto.

## Fuentes

**Vídeos.** *The Wild Project* n.º 391, Ada Colau: <https://www.youtube.com/watch?v=-ESmAhdixfo>. N.º 392, Alberto Núñez Feijóo: <https://www.youtube.com/watch?v=1YlGArMx_N4>. N.º 393, Pedro Sánchez: <https://www.youtube.com/watch?v=mStOFBvToUI>. Los tres, YouTube, 13 de noviembre de 2026.

**Referencias académicas citadas** (todas de la lista verificada del proyecto, con sus matices).

- Barrett, L. F., Adolphs, R., Marsella, S., Martinez, A. M. y Pollak, S. D. (2019). Emotional expressions reconsidered: Challenges to inferring emotion from human facial movements. *Psychological Science in the Public Interest*, 20(1), 1–68.
- Bavelas, J. B., Black, A., Chovil, N. y Mullett, J. (1990). *Equivocal Communication*. Sage.
- Bond, C. F. y DePaulo, B. M. (2006). Accuracy of deception judgments. *Personality and Social Psychology Review*, 10(3), 214–234.
- Bull, P. y Mayer, K. (1993). How not to answer questions in political interviews. *Political Psychology*, 14(4), 651–666.
- Cialdini, R. B. (1984). *Influence: How and Why People Agree to Things*. William Morrow.
- Clayman, S. y Heritage, J. (2002). *The News Interview: Journalists and Public Figures on the Air*. Cambridge University Press.
- DePaulo, B. M., Lindsay, J. J., Malone, B. E., Muhlenbruck, L., Charlton, K. y Cooper, H. (2003). Cues to deception. *Psychological Bulletin*, 129(1), 74–118.
- Ekman, P. y Friesen, W. V. (1978). *Facial Action Coding System*. Consulting Psychologists Press.
- Ekman, P., Davidson, R. J. y Friesen, W. V. (1990). The Duchenne smile: Emotional expression and brain physiology II. *Journal of Personality and Social Psychology*, 58(2), 342–353.
- Entman, R. M. (1993). Framing: Toward clarification of a fractured paradigm. *Journal of Communication*, 43(4), 51–58.
- Goldman-Eisler, F. (1968). *Psycholinguistics: Experiments in Spontaneous Speech*. Academic Press (editorial no confirmada).
- Juslin, P. N. y Laukka, P. (2003). Communication of emotions in vocal expression and music performance: Different channels, same code? *Psychological Bulletin*, 129(5), 770–814.
- Kunda, Z. (1990). The case for motivated reasoning. *Psychological Bulletin*, 108(3), 480–498.
- Lord, C. G., Ross, L. y Lepper, M. R. (1979). Biased assimilation and attitude polarization: The effects of prior theories on subsequently considered evidence. *Journal of Personality and Social Psychology*, 37(11), 2098–2109.
- McCombs, M. E. y Shaw, D. L. (1972). The agenda-setting function of mass media. *Public Opinion Quarterly*, 36(2), 176–187.
- Miller, D. T. y Ross, M. (1975). Self-serving biases in the attribution of causality: Fact or fiction? *Psychological Bulletin*, 82(2), 213–225.
- Nickerson, R. S. (1998). Confirmation bias: A ubiquitous phenomenon in many guises. *Review of General Psychology*, 2(2), 175–220.
- Nyhan, B., Porter, E., Reifler, J. y Wood, T. J. (2020). Taking fact-checks literally but not seriously? The effects of journalistic fact-checking on factual beliefs and candidate favorability. *Political Behavior*, 42(3), 939–960.
- Petrocik, J. R. (1996). Issue ownership in presidential elections, with a 1980 case study. *American Journal of Political Science*, 40(3), 825–850.
- Rogers, T. y Norton, M. I. (2011). The artful dodger: Answering the wrong question the right way. *Journal of Experimental Psychology: Applied*, 17(2), 139–147.
- Sacks, H., Schegloff, E. A. y Jefferson, G. (1974). A simplest systematics for the organization of turn-taking for conversation. *Language*, 50(4), 696–735.
- Scherer, K. R. (2003). Vocal communication of emotion: A review of research paradigms. *Speech Communication*, 40(1–2), 227–256.
- Taber, C. S. y Lodge, M. (2006). Motivated skepticism in the evaluation of political beliefs. *American Journal of Political Science*, 50(3), 755–769.
- Tickle-Degnen, L. y Rosenthal, R. (1990). The nature of rapport and its nonverbal correlates. *Psychological Inquiry*, 1(4), 285–293.
- Tversky, A. y Kahneman, D. (1974). Judgment under uncertainty: Heuristics and biases. *Science*, 185(4157), 1124–1131.
- Vallone, R. P., Ross, L. y Lepper, M. R. (1985). The hostile media phenomenon: Biased perception and perceptions of media bias in coverage of the Beirut massacre. *Journal of Personality and Social Psychology*, 49(3), 577–585.
- Weaver, R. K. (1986). The politics of blame avoidance. *Journal of Public Policy*, 6(4), 371–398.
- Zuckerman, M. (1979). Attribution of success and failure revisited, or: The motivational bias is alive and well in attribution theory. *Journal of Personality*, 47(2), 245–287.

**Archivos de datos.** Métricas de habla con las mismas reglas para las cinco entrevistas: `comparacion/v3/metricas.md`, `metricas.csv`, `extra.md`. Lectura manual comparada: `comparacion/lectura3/lectura_comparada.md` y sus CSV y gráficas; criterios en `herramientas/criterios_lectura.md`. Voz, trabas, pausas, tiempos verbales y montaje: `comparacion/presion/presion.md`. Público: `comparacion/publico/publico_1.md`. Coherencia y argumentario: `comparacion/coherencia/coherencia_y_argumentario.md`, `coherencia.csv` y `argumentario.csv`. Por entrevista (`colau/`, `feijoo/`, `sanchez/`): `transcripcion.csv`, `lectura/` (`preguntas.json`, `temas.json`, `promesas.json`, `merito_culpa.json`, `sintonia.json`, `resumen.md`), `expresiones_resumen.csv`, `video/entrevista.info.json` (capítulos y títulos) y `verificacion_datos.md` y `.csv` (versiones revisadas de Colau y Feijóo; primera versión de Sánchez). Informes individuales: `colau/informe_publicable.md` y `feijoo/informe_publicable.md`. Tablas, gráficas y comprobaciones de este documento: `comparacion/general/tablas.py`, `graficas.py`, `construir.py` y `comprobar.py`.
