# Medidas cruzadas con la lectura (misma definición para las tres)

| medida | Colau | Feijóo | Sánchez |
|---|---|---|---|
| frases en ventanas duras | 577 | 377 | 476 |
| frases en el resto | 122 | 178 | 86 |
| tono (Hz): duras / resto | 164.7 / 162.6 | 126.6 / 123.6 | 120.8 / 119.8 |
| tono (Hz): d de Cohen | +0.14 | +0.19 | +0.07 |
| tono (Hz): d cuando no contesta a lo preguntado | +0.08 (n = 103) | +0.06 (n = 85) | -0.11 (n = 38) |
| volumen (dB): duras / resto | 69.7 / 69.5 | 66.0 / 64.9 | 64.7 / 65.0 |
| volumen (dB): d de Cohen | +0.09 | +0.22 | -0.04 |
| volumen (dB): d cuando no contesta a lo preguntado | -0.05 (n = 103) | -0.17 (n = 85) | +0.01 (n = 38) |
| velocidad (palabras/min): duras / resto | 227 / 214 | 203 / 198 | 204 / 203 |
| velocidad (palabras/min): d de Cohen | +0.24 | +0.08 | +0.02 |
| velocidad (palabras/min): d cuando no contesta a lo preguntado | +0.16 (n = 103) | +0.02 (n = 85) | -0.25 (n = 38) |
| palabras del invitado: duras / resto | 12112 / 2542 | 6270 / 2978 | 9417 / 1394 |
| trabas por 100 palabras: duras / resto | 0.33 / 0.04 | 0.30 / 0.13 | 0.29 / 0.65 |
| trabas (n): duras / resto | 40 / 1 | 19 / 4 | 27 / 9 |
| huecos de transcripción excluidos de las pausas | 0 | 1 | 0 |
| pausas > 0,4 s (sin huecos) | 105 | 118 | 112 |
| pausa media (s) | 0.76 | 0.79 | 0.79 |
| pausas de 2 s o más | 1 | 1 | 2 |
| pausas por 1.000 palabras | 7.1 | 12.7 | 10.3 |
| pausas por 1.000 palabras: duras / resto | 6.6 / 9.8 | 11.2 / 16.1 | 10.5 / 9.3 |
| pausas antes de frase con carga | 20 (19 %) | 36 (31 %) | 20 (18 %) |
| pausas confirmadas por el detector acústico | 4 (4 %) | 25 (21 %) | 17 (15 %) |
| latencia mediana tras intervención de Jordi (s) | 1.22 (n = 101) | 0.85 (n = 78) | 0.56 (n = 121) |
| latencia mediana: duras / resto (s) | 1.19 / 1.96 | 0.56 / 1.49 | 0.70 / 0.46 |
| respuestas que empiezan antes de que Jordi acabe (latencia < 0) | 0 % | 0 % | 0 % |
| temas con más latencia (mediana, n ≥ 5) | corrupcion 4.52 s; partido_interno 2.50 s; trayectoria_y_gestion_pasada 1.30 s | rivales 1.82 s; deuda_y_gasto 0.78 s; inmigracion 0.28 s | rivales 1.12 s; corrupcion 0.92 s; infraestructuras_y_transporte 0.72 s |
| temas con menos latencia (mediana, n ≥ 5) | fronteras_y_marruecos 0.94 s; politica_internacional 0.88 s; inmigracion 0.50 s | inmigracion 0.28 s; partido_interno 0.26 s; pactos_y_gobernabilidad 0.11 s | vivienda 0.59 s; inmigracion 0.37 s; fronteras_y_marruecos 0.10 s |
| formas verbales de pasado por 100 palabras (aprox.) | 3.82 | 2.95 | 3.85 |
| formas verbales de futuro por 100 palabras (aprox.) | 0.33 | 1.07 | 0.38 |
| pasado por cada forma de futuro (aprox.) | 11.7 | 2.8 | 10.2 |
| cara del invitado en pantalla (% de los fotogramas) | 63 % | 71 % | 66 % |
| cara de Jordi en pantalla (% de los fotogramas) | 45 % | 31 % | 42 % |
| veces más en pantalla el invitado que Jordi | 1.4 | 2.3 | 1.5 |
| % de las palabras que dice el invitado | 64 % | 73 % | 63 % |
| cortes de plano (aprox., fotogramas clave) | 280 | 173 | 265 |
| cortes por minuto | 2.1 | 2.0 | 2.4 |
| mediana entre cortes (s) | 24 | 24 | 24 |

d de Cohen: alrededor de 0,2 pequeña, 0,5 media, 0,8 grande. «Duras» = ventanas tras intervenciones clasificadas como incómoda, repregunta o insistencia. Las formas verbales son una aproximación por terminaciones (no un análisis morfológico): sirve para comparar a los tres con la misma regla, no como cifra exacta. Ninguna de estas medidas sirve para saber si alguien dice la verdad.
