| medida | colau | feijoo | sanchez | abascal | sanchez_revuelta |
|---|---|---|---|---|---|
| invitado: preguntas (frases con ?) | 32 | 46 | 23 | 41 | 34 |
| invitado: cifras /100 pal | 0.67 | 2.61 | 1.62 | 0.62 | 1.34 |
| invitado: fechas /100 pal | 0.03 | 0.15 | 0.15 | 0.02 | 0.07 |
| invitado: compromisos /100 pal | 0.05 | 0.53 | 0.16 | 0.34 | 0.18 |
| invitado: vaguedades /100 pal | 0.33 | 0.19 | 0.25 | 0.22 | 0.25 |
| invitado: palabras de ataque /100 pal | 0.1 | 0.03 | 0.02 | 0.05 | 0.08 |
| invitado: diversidad léxica (MATTR 100) | 0.663 | 0.66 | 0.675 | 0.656 | 0.671 |
| invitado: palabras por frase | 29.3 | 21.3 | 28.4 | 19.3 | 19.7 |
| invitado: sílabas por palabra | 1.88 | 1.86 | 1.9 | 1.85 | 1.86 |
| invitado: legibilidad Szigriszt | 60.3 | 69.4 | 60.0 | 72.1 | 71.3 |
| invitado: palabras largas (≥4 sílabas) % | 8.6 | 10.0 | 9.7 | 8.7 | 8.6 |
| invitado: a quién nombra | Gobierno 26, Podemos 14, Sánchez 10, PP 9, Vox 8, Trump 7, PSOE 6, Sumar 5 | Gobierno 39, Sánchez 13, PP 13, Vox 9, PSOE 5, Ayuso 5, Podemos 4, Bildu 2 | Gobierno 33, Abascal 4, Podemos 4, Vox 3, Israel 3, Sánchez 2, Trump 2, Ayuso 1 | Gobierno 22, Vox 12, Israel 10, Sánchez 4, Podemos 4, Abascal 2 | Gobierno 25, Vox 8, PP 4, Sánchez 3, Podemos 3, Yolanda Díaz 2, Junts 2, Illa 1 |
| presentador: preguntas (frases con ?) | 107 | 60 | 59 | 34 | 120 |
| presentador: cifras /100 pal | 1.29 | 1.59 | 1.25 | 0.61 | 0.89 |
| presentador: fechas /100 pal | 0.12 | 0.03 | 0.1 | 0.05 | 0.05 |
| presentador: compromisos /100 pal | 0.59 | 0.46 | 0.3 | 0.18 | 0.14 |
| presentador: vaguedades /100 pal | 0.38 | 0.35 | 0.46 | 0.53 | 0.85 |
| presentador: palabras de ataque /100 pal | 0.08 | 0.06 | 0.05 | 0.03 | 0.02 |
| presentador: diversidad léxica (MATTR 100) | 0.678 | 0.687 | 0.688 | 0.654 | 0.691 |
| presentador: palabras por frase | 20.0 | 18.7 | 19.9 | 21.5 | 14.8 |
| presentador: sílabas por palabra | 1.81 | 1.81 | 1.81 | 1.82 | 1.77 |
| presentador: legibilidad Szigriszt | 74.0 | 75.3 | 74.0 | 71.8 | 82.1 |
| presentador: palabras largas (≥4 sílabas) % | 7.2 | 7.6 | 7.2 | 7.4 | 6.0 |
| presentador: a quién nombra | Gobierno 16, PSOE 9, Israel 7, Trump 5, Colau 4, Sumar 4, Sánchez 4, PP 3 | Sánchez 9, Vox 5, PP 5, Gobierno 4, PSOE 4, Ayuso 4, Feijóo 1, Trump 1 | Gobierno 10, Sánchez 4, PSOE 3, Abascal 2, Colau 2, Bildu 2, Vox 1, Yolanda Díaz 1 | Gobierno 14, Sánchez 11, Israel 8, Vox 5, Trump 4, Podemos 2, Abascal 1 | Gobierno 8, Vox 5, PP 4, Sánchez 3, Feijóo 2, Colau 1, PSOE 1, Trump 1 |
| frases de 6 palabras que el invitado repite | 30 | 14 | 30 | 19 | 22 |
| preguntas de Jordi con respuesta | 73 | 41 | 38 | 26 | 67 |
| latencia mediana tras pregunta (s) | 0.78 | 0.38 | 0.32 | 0.19 | 0.76 |
| palabras por respuesta (mediana) | 77 | 88 | 66 | 52 | 19 |
| respuestas cortadas por Jordi % | 50.7 | 22.0 | 36.8 | 38.5 | 35.8 |
| palabras por pregunta de Jordi (mediana) | 22 | 24 | 21 | 15 | 13 |
| solapes de voz que inicia el presentador | 459 | 187 | 254 | 166 | 0 |
| solapes de voz que inicia el invitado | 258 | 133 | 307 | 142 | 0 |
| risas transcritas | 0 | 0 | 0 | 0 | 4 |
| vistas (al descargar) | 307642.0 | 230923.0 | 245668.0 |  |  |
| me gusta | 22095.0 | 15510.0 | 23224.0 |  |  |
| comentarios | 3400.0 | 2700.0 | 6700.0 |  |  |
| duración (min) | 134.2 | 88.3 | 112.1 | 96.4 | 102.9 |
