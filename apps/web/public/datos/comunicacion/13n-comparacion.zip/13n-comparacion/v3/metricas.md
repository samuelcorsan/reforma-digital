| medida | Colau (colau) | Jordi Wild (colau) | Feijóo (feijoo) | Jordi Wild (feijoo) | Sánchez (sanchez) | Jordi Wild (sanchez) | Abascal (abascal) | Broncano (abascal) | Sánchez (sanchez_revuelta) | Broncano (sanchez_revuelta) |
|---|---|---|---|---|---|---|---|---|---|---|
| palabras | 14693 | 8356 | 9256 | 3463 | 10840 | 6266 | 8455 | 7349 | 8487 | 5627 |
| pct_palabras | 63.7 | 36.3 | 72.8 | 27.2 | 63.4 | 36.6 | 53.5 | 46.5 | 60.1 | 39.9 |
| min_habla | 69.3 | 38.7 | 51.7 | 17.5 | 57.4 | 30.0 | 37.2 | 33.0 | 42.4 | 22.5 |
| ppm | 212 | 216 | 179 | 198 | 189 | 209 | 228 | 224 | 201 | 254 |
| turnos | 315 | 265 | 219 | 133 | 265 | 203 | 234 | 212 | 289 | 267 |
| pal_turno_media | 46.6 | 31.5 | 42.3 | 26.0 | 40.9 | 30.9 | 36.1 | 34.7 | 29.4 | 21.1 |
| pal_turno_mediana | 29 | 20 | 30 | 15 | 25 | 20 | 19.5 | 21.5 | 16 | 12 |
| turnos_60 | 88 | 39 | 44 | 17 | 56 | 28 | 38 | 37 | 38 | 18 |
| trabas | 41 | 38 | 23 | 14 | 36 | 28 | 35 | 101 | 83 | 78 |
| trabas_100 | 0.28 | 0.45 | 0.25 | 0.4 | 0.33 | 0.45 | 0.41 | 1.37 | 0.98 | 1.39 |
| cortes | 22 | 16 | 8 | 7 | 20 | 16 | 25 | 75 | 65 | 66 |
| rep_palabra | 8 | 13 | 10 | 4 | 8 | 7 | 3 | 14 | 8 | 9 |
| rep_grupo | 11 | 9 | 5 | 3 | 8 | 5 | 7 | 12 | 10 | 3 |
| trabas_100_arranque | 0.24 | 0.35 | 0.19 | 0.27 | 0.58 | 0.23 | 0.4 | 2.97 | 1.72 | 1.53 |
| pausas_04 | 105 | 87 | 119 | 34 | 112 | 51 | 112 | 124 | 135 | 58 |
| pausas_2s | 1 | 2 | 2 | 0 | 2 | 1 | 1 | 19 | 8 | 3 |
| pausa_media | 0.76 | 0.81 | 0.91 | 0.76 | 0.79 | 0.88 | 0.76 | 1.24 | 0.95 | 1.19 |
| latencia_mediana | 0.84 | 0.32 | 0.63 | 0.6 | 0.72 | 0.82 | 0.36 | 0.37 | 0.61 | 0.68 |
| pct_hueco_02 | 29 | 43 | 37 | 31 | 38 | 38 | 40 | 39 | 36 | 34 |
| certeza_100 | 0.42 | 0.25 | 0.45 | 0.55 | 0.65 | 0.49 | 0.58 | 0.49 | 0.55 | 0.3 |
| duda_100 | 1.07 | 1.04 | 0.55 | 1.04 | 0.97 | 0.75 | 1.61 | 1.61 | 0.77 | 1.16 |
| muletillas_100 | 3.21 | 3.7 | 3.35 | 3.41 | 3.1 | 4.23 | 3.45 | 3.21 | 3.7 | 4.09 |
| pron_yo_100 | 1.98 | 1.88 | 2.47 | 1.62 | 2.57 | 1.99 | 3.25 | 2.29 | 2.89 | 0.98 |
| pron_nosotros_100 | 0.63 | 0.13 | 0.3 | 0.09 | 0.67 | 0.08 | 0.8 | 0.31 | 0.58 | 0.32 |
| pron_tú/vosotros_100 | 0.74 | 2.25 | 0.67 | 2.34 | 1.07 | 2.09 | 1.32 | 1.81 | 0.92 | 1.67 |
| pron_ellos_100 | 1.82 | 1.18 | 2.04 | 1.39 | 1.95 | 1.04 | 2.4 | 1.52 | 1.9 | 1.33 |
| menciones | podemos 14, sánchez 10, vox 8, pp 7, psoe 6, sumar 5 | psoe 8, colau 4, sumar 4, sánchez 4, pp 3, podemos 2 | sánchez 13, pp 13, vox 9, ayuso 5, podemos 4, psoe 3 | sánchez 9, vox 5, pp 5, ayuso 4, psoe 3, feijóo 1 | abascal 4, podemos 4, vox 3, iglesias 3, sánchez 2, ayuso 1 | sánchez 4, psoe 3, iglesias 3, abascal 2, colau 2, bildu 2 | vox 12, sánchez 4, podemos 4, abascal 2 | sánchez 11, vox 5, podemos 2, abascal 1 | vox 8, pp 4, sánchez 3, podemos 3, junts 2, yolanda 1 | vox 5, pp 4, sánchez 3, feijóo 2, colau 1, psoe 1 |
