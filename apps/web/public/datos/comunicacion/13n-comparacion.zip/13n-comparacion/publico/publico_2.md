# Público de YouTube: segunda lectura (13/11/2026, hacia las 15:05)

Comentarios: los 3.000 más recientes de cada vídeo (la primera lectura tomó los ~1.250 más relevantes). El mapa de «lo más visto» de YouTube aún no está disponible en ninguno.

## Colau
- Vistas: 627,837 (1202) → 1,311,275 (1503). Me gusta: 32,096 → 48,540 (37 por 1.000 vistas).
- Comentarios leídos: 3000; citan algún minuto: 122 (4.1 %); minutos citados dentro de la entrevista: 121.
- Minutos más citados: 131:00 (7) tienes esa cámara para decir lo que te da real gana…; 82:00 (4) Pero un 40 % en 50 años. ¿Cómo lo ves?…; 31:00 (4) La verdad es que hay cosas que van a tener que hacer una investigación…; 26:00 (3) ¿Tú hubieras estado en el papel de Yolanda? ¿Tú hubieras sacado al par…; 33:00 (3) ¿Por qué te quieres juntar con ellos? Si es que tú misma estás diciend…; 16:00 (3) Sí, pero yo te pregunto por el otro tipo de gente que a lo mejor está …; 9:00 (3) Y aquí se ha roto un poco eso. ¿Cómo ves esa contradicción?…; 7:00 (3) Es decir, al final es el mismo perro con diferente collar, ¿verdad? ¿Y…
- Por tema (citas): inmigracion 22, corrupcion 14, cierre_y_alegato 12, trayectoria_y_gestion_pasada 11, fronteras_y_marruecos 11, infraestructuras_y_transporte 11, pactos_y_gobernabilidad 7.
- Citas por minuto de tema (temas de 3 min o más): cierre_y_alegato 3.0, asuntos_personales 1.6, pactos_y_gobernabilidad 1.5, corrupcion 1.4, medios_y_redes 1.3.
- Citas a menos de 45 s de uno de nuestros 15 momentos clave del invitado: 20 de 121 (17 %). Si los minutos citados se repartieran al azar, caerían cerca de un momento clave en torno al 17 %.

## Feijóo
- Vistas: 260,877 (1203) → 1,043,479 (1504). Me gusta: 20,756 → 43,702 (42 por 1.000 vistas).
- Comentarios leídos: 3000; citan algún minuto: 64 (2.1 %); minutos citados dentro de la entrevista: 64.
- Minutos más citados: 52:00 (3) O sea, les vas a quitar el ingreso mínimo vital.…; 11:00 (3) Para muchos ahora González está más cerca de vosotros que del PSOE de …; 8:00 (3) creo que todos participáis de esa polarización y de este enfrentamient…; 22:00 (3) ¿Tenéis o los vais? ¿Qué es diferente?…; 27:00 (3) Sí, pero tampoco un autónomo muchas veces trabaja enfermo.…; 18:00 (3) el ministerio no va a existir como tal, sino que va a estar en otros l…; 23:00 (2) Entonces, ¿para ti cuál es la solución?…; 49:00 (2) ¿Un español que nunca ha cotizado o un extranjero que lleva 20 años ha…
- Por tema (citas): rivales 11, inmigracion 9, pensiones 7, fronteras_y_marruecos 5, formato_y_presentacion 5, feminismo_e_igualdad 5, deuda_y_gasto 4.
- Citas por minuto de tema (temas de 3 min o más): formato_y_presentacion 1.3, pensiones 1.3, inmigracion 1.2, economia_y_empleo 1.0, rivales 0.9.
- Citas a menos de 45 s de uno de nuestros 15 momentos clave del invitado: 13 de 64 (20 %). Si los minutos citados se repartieran al azar, caerían cerca de un momento clave en torno al 26 %.

## Sánchez
- Vistas: 281,186 (1419) → 406,353 (1504). Me gusta: 28,309 → 37,542 (92 por 1.000 vistas).
- Comentarios leídos: 3000; citan algún minuto: 64 (2.1 %); minutos citados dentro de la entrevista: 65.
- Minutos más citados: 10:00 (5) Sí, pero el juego sucio es bidireccional. Yo he escuchado cosas vuestr…; 4:00 (5) ¿por qué no decides dar un paso al lado, quizás vivir más tranquilo, q…; 11:00 (4) Quiero decir que al final todos tenéis parte de culpa en esto.…; 8:00 (3) y sabes cómo van los memes. ¿Tú qué sientes, sinceramente?…; 17:00 (3) O sea, que se repitan dos accidentes en menos de un año es algo…; 14:00 (3) yo a veces las comparaciones son odiosas porque yo prefiero sentarnos …; 5:00 (3) ¿Por qué no decir, mira, ya he cumplido, yo he dado lo que he podido y…; 54:00 (2) 
- Por tema (citas): asuntos_personales 14, rivales 11, infraestructuras_y_transporte 11, fronteras_y_marruecos 7, trayectoria_y_gestion_pasada 3, vivienda 3, medios_y_redes 3.
- Citas por minuto de tema (temas de 3 min o más): asuntos_personales 2.5, rivales 1.9, infraestructuras_y_transporte 0.7, formato_y_presentacion 0.6, trayectoria_y_gestion_pasada 0.5.
- Citas a menos de 45 s de uno de nuestros 15 momentos clave del invitado: 11 de 65 (17 %). Si los minutos citados se repartieran al azar, caerían cerca de un momento clave en torno al 20 %.
